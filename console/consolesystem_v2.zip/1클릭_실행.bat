@echo off
title MACS - Multi AI Console System
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js not found. Install LTS from https://nodejs.org and run again.
  pause
  exit /b 1
)
echo MACS console starting. Keep this window open (minimize is OK). Closing it disconnects the phone.
node start_all.js
pause
