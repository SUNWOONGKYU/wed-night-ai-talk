@echo off
chcp 65001 >nul
title 원스톱 멀티 에이전트 모바일 콘솔
cd /d "%~dp0"
where node >nul 2>nul || (echo [오류] Node.js가 없습니다. https://nodejs.org 에서 LTS 설치 후 다시 실행하세요. & pause & exit /b 1)
echo 콘솔을 시작합니다. 이 창을 닫으면 폰 연결이 끊깁니다.
node start_all.js
pause
