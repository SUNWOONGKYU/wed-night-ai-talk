/**
 * 어댑터 공통 유틸 — 각 AI CLI 어댑터(codex/agy/grok/claude)가 같이 쓰는 작은 도구 모음.
 * 어댑터 계약(모든 adapters/<ai>.js 가 지킨다):
 *   ai            : 'codex' | 'agy' | 'grok' | 'claude'
 *   label         : 사람에게 보이는 이름
 *   resolveExe()  : { cmd, pre } — 실행 파일과 앞에 붙는 인자(node 트램폴린 등)
 *   buildArgs(prompt, opts) : { cmd, args, cwd, env, stdin }  — 명령줄 조립 (한 곳에서만)
 *   parseOutput(stdout, stderr, code, opts) : { ok, reply, format:'json'|'text', error, ...부가 }  — 출력 해석 (JSON 우선 → 텍스트 폴백)
 *   versionArgs   : `<cli> --version` 에 해당하는 { cmd, args }
 *   parseVersion(str) : '0.154.0' 처럼 숫자 버전만 뽑기
 */
const stripAnsi = (s) => String(s || '').replace(/\x1b\[[0-9;]*[A-Za-z]/g, '');

/** 출력 안에서 가장 바깥 JSON 객체 하나를 찾아 파싱. 실패하면 null (호출자는 텍스트로 폴백) */
function extractJson(text) {
  const s = String(text || '');
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end <= start) return null;
  try { return JSON.parse(s.slice(start, end + 1)); } catch (_) {}
  // 줄 단위 JSON(마지막 줄이 결과인 경우)도 시도
  const lines = s.split(/\r?\n/).map(l => l.trim()).filter(l => l.startsWith('{') && l.endsWith('}'));
  for (let i = lines.length - 1; i >= 0; i--) { try { return JSON.parse(lines[i]); } catch (_) {} }
  return null;
}

/** 브릿지가 spawn 할 때 물려주면 안 되는 Claude Code 내부 변수 제거 */
function cleanEnv(extraDrop) {
  const env = Object.assign({}, process.env);
  for (const k of Object.keys(env)) {
    if (k === 'CLAUDECODE' || k === 'CLAUDE_PID' || k === 'CLAUDE_EFFORT' || k.startsWith('CLAUDE_CODE_') || k === 'NoDefaultCurrentDirectoryInExePath') delete env[k];
    if (extraDrop && extraDrop.includes(k)) delete env[k];
  }
  return env;
}

function parseVersion(str) {
  const m = String(str || '').match(/(\d+)\.(\d+)\.(\d+)/);
  return m ? m[0] : '';
}

const IS_WIN = process.platform === 'win32';

module.exports = { stripAnsi, extractJson, cleanEnv, parseVersion, IS_WIN };
