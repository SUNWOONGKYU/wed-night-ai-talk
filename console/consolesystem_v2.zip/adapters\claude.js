/**
 * Claude Code CLI 어댑터 — 창 없는 `claude -p` 호출의 명령줄 조립(buildArgs) · 출력 해석(parseOutput).
 * 프롬프트는 argv 가 아니라 stdin 으로 넘긴다(길이·따옴표·한글 안전).
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { extractJson, parseVersion, IS_WIN } = require('./_common');

const ai = 'claude';
const label = 'Claude Code';

function resolveExe() {
  const local = path.join(os.homedir(), '.local', 'bin', 'claude.exe');
  if (fs.existsSync(local)) return { cmd: local, pre: [] };
  return { cmd: IS_WIN ? 'claude.cmd' : 'claude', pre: [] };
}

/** 안전 모드용 설정 파일(권한 규칙 + 위험 명령 차단 훅)을 콘솔 본체 폴더 hooks/ 에 만들어 두고 --settings 로 넘긴다 */
function safeSettingsFile() {
  const home = process.env.CONSOLE_HOME || path.resolve(__dirname, '..');
  const hookJs = [path.join(home, 'hooks', 'dangerous_cmd_block.js'), path.join(__dirname, '..', 'hooks', 'dangerous_cmd_block.js')].find(f => fs.existsSync(f));
  const file = path.join(home, 'hooks', 'claude_safe_settings.json');
  const settings = {
    permissions: {
      allow: ['Bash', 'Read', 'Edit', 'Write', 'MultiEdit', 'Glob', 'Grep', 'WebFetch', 'WebSearch', 'NotebookEdit'],
      deny: ['Read(**/.env)', 'Read(**/.env.*)', 'Read(**/.credentials*)', 'Read(**/*.pem)', 'Read(**/*keystore*)', 'Read(**/*.jks)', 'Read(**/*.p12)', 'Read(**/console_config.json)', 'Edit(**/console_config.json)', 'Write(**/console_config.json)']
    },
    hooks: hookJs ? { PreToolUse: [{ matcher: 'Bash', hooks: [{ type: 'command', command: JSON.stringify(process.execPath) + ' ' + JSON.stringify(hookJs), timeout: 20 }] }] } : {}
  };
  try {
    const txt = JSON.stringify(settings, null, 2);
    let cur = ''; try { cur = fs.readFileSync(file, 'utf8'); } catch (_) {}
    if (cur !== txt) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, txt, 'utf8'); }
    return file;
  } catch (_) { return null; }
}

/** opts: { sessionId, resume(bool), json(bool), cwd, extraArgs[], safe }  — safe: 우회 플래그 대신 acceptEdits + 작업 폴더(--add-dir) + --settings(권한 규칙·차단 훅) */
function buildArgs(prompt, opts) {
  opts = opts || {};
  const exe = resolveExe();
  const args = [...exe.pre, '-p'];
  if (opts.safe) {
    args.push('--permission-mode', 'acceptEdits');
    if (opts.cwd) args.push('--add-dir', opts.cwd);
    const sf = safeSettingsFile(); if (sf) args.push('--settings', sf);
  } else args.push('--dangerously-skip-permissions');
  if (opts.model) args.push('--model', opts.model); // 폰 설정(모델 선택) — console_settings.modelFor('claude')
  if (opts.sessionId) args.push(opts.resume ? '--resume' : '--session-id', opts.sessionId);
  if (opts.json) args.push('--output-format', 'json');
  if (Array.isArray(opts.extraArgs)) args.push(...opts.extraArgs);
  return { cmd: exe.cmd, args, cwd: opts.cwd, env: null, stdin: prompt };
}

function parseOutput(stdout, stderr, code, opts) {
  opts = opts || {};
  stdout = String(stdout || '').replace(/^Warning: no stdin data[^\n]*\n?/gm, '').trim();
  stderr = String(stderr || '').replace(/^Warning: no stdin data[^\n]*\n?/gm, '').trim();
  const j = extractJson(stdout);
  if (j && typeof j === 'object' && (typeof j.result === 'string' || j.is_error !== undefined)) {
    if (j.is_error) return { ok: false, reply: '', format: 'json', error: String(j.result || j.error || 'error') };
    return { ok: true, reply: String(j.result || '').trim() || '작업이 완료되었습니다.', format: 'json', sessionId: j.session_id || null };
  }
  if (code === 0) return { ok: true, reply: stdout || '작업이 완료되었습니다.', format: 'text' };
  return { ok: false, reply: '', format: 'text', error: stderr || stdout };
}

const versionArgs = (() => { const e = resolveExe(); return { cmd: e.cmd, args: [...e.pre, '--version'] }; })();

module.exports = { ai, label, resolveExe, buildArgs, parseOutput, versionArgs, parseVersion, safeSettingsFile };
