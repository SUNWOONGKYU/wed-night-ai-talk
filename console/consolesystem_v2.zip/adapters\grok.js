/**
 * Grok CLI 어댑터 — 명령줄 조립(buildArgs) · 출력 해석(parseOutput).
 * grok -p 는 텍스트를 내므로 ANSI 제거 후 그대로 답으로 쓴다. JSON 이 나오면 그것을 우선한다.
 */
const fs = require('fs');
const path = require('path');
const { extractJson, stripAnsi, parseVersion, IS_WIN } = require('./_common');

const ai = 'grok';
const label = 'Grok';

function resolveExe() {
  // shell:true 는 공백 프롬프트가 쪼개지고, .cmd 직접 spawn 은 EINVAL → npm 진입점을 node 로 실행
  const entry = path.join(process.env.APPDATA || '', 'npm', 'node_modules', '@xai-official', 'grok', 'bin', 'grok');
  if (fs.existsSync(entry)) return { cmd: process.execPath, pre: [entry] };
  return { cmd: IS_WIN ? 'grok.cmd' : 'grok', pre: [] };
}

// 안전 모드에서 grok 에 넘기는 거부 규칙 (hooks/dangerous_cmd_block.js 와 같은 취지 — grok 은 훅 대신 --deny 규칙을 지원)
const SAFE_DENY = ['Bash(rm -rf*)', 'Bash(rm -r*)', 'Bash(rmdir /s*)', 'Bash(del /s*)', 'Bash(Remove-Item*-Recurse*)', 'Bash(format *)', 'Bash(diskpart*)', 'Bash(reg add*)', 'Bash(reg delete*)', 'Bash(git push*--force*)', 'Bash(git push -f*)', 'Bash(git reset --hard*)', 'Bash(schtasks /delete*)', 'Bash(schtasks /change*)', 'Bash(shutdown*)', 'Bash(net user*)', 'Read(**/.env)', 'Read(**/.env.*)', 'Read(**/.credentials*)', 'Read(**/*.pem)', 'Read(**/*keystore*)', 'Read(**/console_config.json)'];

/** opts: { model, sessionId, resume(bool), cwd, safe }  — safe: --always-approve 대신 acceptEdits + 거부 규칙(위험 명령·비밀 파일) + 작업 폴더(--cwd) */
function buildArgs(prompt, opts) {
  opts = opts || {};
  const exe = resolveExe();
  const args = [...exe.pre, '-p', prompt];
  if (opts.model) args.push('-m', opts.model);
  if (opts.sessionId) args.push(opts.resume ? '--resume' : '--session-id', opts.sessionId);
  if (opts.safe) { args.push('--permission-mode', 'acceptEdits'); for (const r of SAFE_DENY) args.push('--deny', r); }
  else args.push('--always-approve');
  if (opts.cwd) args.push('--cwd', opts.cwd);
  return { cmd: exe.cmd, args, cwd: opts.cwd, env: null, stdin: null };
}

function parseOutput(stdout, stderr, code) {
  stdout = stripAnsi(stdout); stderr = stripAnsi(stderr);
  const j = extractJson(stdout);
  if (j && typeof j === 'object' && (typeof j.response === 'string' || typeof j.result === 'string')) {
    const text = (j.response || j.result || '').trim();
    if (text) return { ok: true, reply: text, format: 'json' };
  }
  const reply = (stdout.trim() || stderr.trim()).trim();
  if (reply && code === 0) return { ok: true, reply, format: 'text' };
  if (reply && !/\berror\b|unauthorized|not logged|rate limit|unexpected argument|unknown option|unrecognized/i.test(reply)) return { ok: true, reply, format: 'text' };
  if (code === 0) return { ok: true, reply: '작업이 완료되었습니다.', format: 'text' };
  return { ok: false, reply: '', format: 'text', error: reply };
}

const versionArgs = (() => { const e = resolveExe(); return { cmd: e.cmd, args: [...e.pre, '--version'] }; })();

module.exports = { ai, label, resolveExe, buildArgs, parseOutput, versionArgs, parseVersion, SAFE_DENY };
