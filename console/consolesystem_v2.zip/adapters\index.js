/** 어댑터 묶음 — require('./adapters').get('codex') */
const map = { claude: require('./claude'), codex: require('./codex'), agy: require('./agy'), grok: require('./grok') };
function get(ai) { return map[String(ai || '').toLowerCase().replace('antigravity', 'agy')] || null; }
module.exports = { get, all: map, names: Object.keys(map) };
