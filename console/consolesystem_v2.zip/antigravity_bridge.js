/**
 * Antigravity CLI(agy) Mobile Bridge Engine (서브 워커 2)
 * 모바일 웹 콘솔 ↔ agy -p 헤드리스 연동. 대화는 --conversation ID로 이어간다.
 */
const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const MESSAGES_FILE = path.join(__dirname, 'agy_messages.json');
const SESSION_FILE = path.join(__dirname, 'agy_session.json');
const WORK_DIR = path.resolve(__dirname, '..');
const TIMEOUT_MS = 10 * 60 * 1000;
const AGY_MODEL = process.env.AGY_MODEL || 'gemini-3.8-flash-high'; // agy models 로 목록 확인

const AGY_EXE = (() => {
  const candidates = [
    path.join(process.env.LOCALAPPDATA || '', 'agy', 'bin', 'agy.exe')
  ];
  return candidates.find(p => fs.existsSync(p)) || 'agy.exe';
})();

if (!fs.existsSync(MESSAGES_FILE)) {
  try {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify([
      {
        id: 1,
        role: 'ai',
        text: '🪐 Antigravity 모바일 서브 워커 2가 연결되었습니다!\n스마트폰에서 코딩 작업, 파일 수정, 분석을 지시하시면 PC의 Antigravity가 무인 자동 승인 모드로 실행합니다.',
        time: new Date().toLocaleTimeString('ko-KR')
      }
    ], null, 2), 'utf8');
  } catch (_) {}
}

let isAgyBusy = false;
let currentTask = '';
const activeChildren = new Set();
let conversationId = loadConversation();

function loadConversation() {
  try {
    if (fs.existsSync(SESSION_FILE)) return JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8')).conversationId || null;
  } catch (_) {}
  return null;
}
function saveConversation(id) {
  conversationId = id || null;
  try { fs.writeFileSync(SESSION_FILE, JSON.stringify({ conversationId, updatedAt: new Date().toISOString() }, null, 2), 'utf8'); } catch (_) {}
}

function getMessages() {
  try {
    if (fs.existsSync(MESSAGES_FILE)) return JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8'));
  } catch (_) {}
  return [];
}

function saveMessages(msgs) {
  try {
    const limited = msgs.slice(-100);
    const tmpFile = MESSAGES_FILE + '.tmp';
    fs.writeFileSync(tmpFile, JSON.stringify(limited, null, 2), 'utf8');
    fs.renameSync(tmpFile, MESSAGES_FILE);
  } catch (_) {
    try { fs.writeFileSync(MESSAGES_FILE, JSON.stringify(msgs.slice(-100), null, 2), 'utf8'); } catch (_) {}
  }
}

function pushAi(text) {
  const msgs = getMessages();
  msgs.push({ id: Date.now(), role: 'ai', text, time: new Date().toLocaleTimeString('ko-KR') });
  saveMessages(msgs);
}

function killChild(child) {
  try {
    if (child && child.pid) {
      if (process.platform === 'win32') execSync(`taskkill /pid ${child.pid} /T /F 2>nul || exit 0`, { shell: true });
      else child.kill('SIGKILL');
    }
  } catch (_) {}
}

function killCurrentProcess() {
  activeChildren.forEach(killChild);
  activeChildren.clear();
  isAgyBusy = false;
  currentTask = '';
  pushAi('🛑 [긴급 정지] 사용자에 의해 실행 중이던 모든 Antigravity 작업이 즉시 강제 종료되었습니다.');
  return true;
}

function resetConversation() {
  saveConversation(null);
  pushAi('🔄 Antigravity 대화를 새로 시작합니다.');
  return true;
}

function getStatus() {
  return {
    isWorking: isAgyBusy,
    currentTask,
    conversationId,
    model: AGY_MODEL,
    messages: getMessages()
  };
}

function cleanEnv() {
  const env = Object.assign({}, process.env);
  for (const k of Object.keys(env)) { if (k === 'CLAUDECODE' || k === 'CLAUDE_PID' || k.startsWith('CLAUDE_CODE_')) delete env[k]; }
  return env;
}

function runOnce(prompt, useConversation) {
  return new Promise((resolve) => {
    const args = ['-p', prompt, '--dangerously-skip-permissions', '--output-format', 'json', '--print-timeout', '9m', '--add-dir', WORK_DIR, '--model', AGY_MODEL];
    if (useConversation && conversationId) args.push('--conversation', conversationId);

    const child = spawn(AGY_EXE, args, {
      cwd: WORK_DIR,
      shell: false,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: cleanEnv()
    });
    activeChildren.add(child);

    let timedOut = false;
    const timer = setTimeout(() => {
      if (activeChildren.has(child)) {
        timedOut = true;
        killChild(child);
        activeChildren.delete(child);
        resolve({ ok: false, error: `⏱️ [작업 제한 시간 초과] ${TIMEOUT_MS / 60000}분 동안 응답이 없어 프로세스를 안전하게 종료했습니다.` });
      }
    }, TIMEOUT_MS);

    let out = '';
    let err = '';
    child.stdout.on('data', d => { out += d.toString('utf8'); });
    child.stderr.on('data', d => { err += d.toString('utf8'); });

    child.on('close', (code) => {
      clearTimeout(timer);
      activeChildren.delete(child);
      if (timedOut) return;

      let parsed = null;
      const start = out.indexOf('{');
      const end = out.lastIndexOf('}');
      if (start !== -1 && end > start) {
        try { parsed = JSON.parse(out.slice(start, end + 1)); } catch (_) {}
      }

      if (parsed) {
        if (parsed.conversation_id) saveConversation(parsed.conversation_id);
        const ok = !parsed.status || /success/i.test(parsed.status);
        const text = (parsed.response || '').trim();
        if (ok) return resolve({ ok: true, reply: text || '작업이 완료되었습니다.' });
        const convBroken = useConversation && /conversation|not found|resume/i.test((parsed.error || parsed.message || '') + err);
        return resolve({ ok: false, convBroken, error: parsed.error || parsed.message || text || `상태: ${parsed.status}` });
      }

      const cleaned = (out + '\n' + err).trim();
      if (code === 0 && cleaned) return resolve({ ok: true, reply: cleaned });
      const convBroken = useConversation && /conversation|not found|resume/i.test(cleaned);
      resolve({ ok: false, convBroken, error: cleaned || `오류 발생 (코드 ${code})` });
    });

    child.on('error', (e) => {
      clearTimeout(timer);
      activeChildren.delete(child);
      resolve({ ok: false, error: `Antigravity 실행 오류: ${e.message}` });
    });
  });
}

async function executeAgyPrompt(prompt) {
  if (!prompt || !prompt.trim()) return { success: false, error: 'Empty prompt' };
  const cleanPrompt = prompt.trim();

  const msgs = getMessages();
  msgs.push({ id: Date.now(), role: 'user', text: cleanPrompt, time: new Date().toLocaleTimeString('ko-KR') });
  saveMessages(msgs);

  isAgyBusy = true;
  currentTask = cleanPrompt;

  let result = await runOnce(cleanPrompt, true);
  if (!result.ok && result.convBroken) {
    saveConversation(null);
    result = await runOnce(cleanPrompt, false);
  }

  isAgyBusy = activeChildren.size > 0;
  if (!isAgyBusy) currentTask = '';

  const replyText = result.ok ? result.reply : `❌ ${result.error}`;
  pushAi(replyText);
  return result.ok ? { success: true, reply: replyText } : { success: false, error: result.error };
}

module.exports = {
  getStatus,
  getMessages,
  executeAgyPrompt,
  killCurrentProcess,
  resetConversation
};
