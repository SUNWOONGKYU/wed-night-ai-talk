/**
 * Antigravity CLI(agy) Mobile Bridge Engine (서브 워커 2)
 * 모바일 웹 콘솔 ↔ agy -p 헤드리스 연동. 대화는 --conversation ID로 이어간다.
 *
 * 2026-09-21: 명령줄 조립·출력 해석은 adapters/agy.js(JSON 우선 → 텍스트 폴백 → 그 다음에야 대화 복구 판정),
 *             실행·1회 자동 재시도·실패 문구는 bridge_retry.js + fail_msg.js 로 통일.
 */
const fs = require('fs');
const path = require('path');
const adapter = require('./adapters/agy');
const { runCli, runWithRetry, killTree } = require('./bridge_retry');
const { toMessage } = require('./fail_msg');
const { isSafe } = require('./perm');   // 권한 모드(safe 기본) — 2026-09-21
const { audit } = require('./audit');   // 감사 로그

const MESSAGES_FILE = path.join(__dirname, 'agy_messages.json');
const SESSION_FILE = path.join(__dirname, 'agy_session.json');
const WORK_DIR = path.resolve(__dirname, '..');
const TIMEOUT_MS = 20 * 60 * 1000; // PO 승인(2026-09-21 09:30): 데몬 워커 20분
const AGY_MODEL = process.env.AGY_MODEL || 'gemini-3.8-flash-high'; // agy models 로 목록 확인

if (!fs.existsSync(MESSAGES_FILE)) {
  try {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify([
      {
        id: 1,
        role: 'ai',
        text: '🪐 Antigravity 모바일 서브 워커 2가 연결되었습니다!\n스마트폰에서 코딩 작업, 파일 수정, 분석을 지시하시면 PC의 Antigravity가 무인 자동 승인 모드로 실행합니다.',
        time: new Date().toLocaleTimeString('ko-KR')
      }
    ], null, 2), 'utf8');
  } catch (_) {}
}

let isAgyBusy = false;
let currentTask = '';
let retrying = '';
let killedAt = 0;
const activeChildren = new Set();
let conversationId = loadConversation();

function loadConversation() {
  try {
    if (fs.existsSync(SESSION_FILE)) return JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8')).conversationId || null;
  } catch (_) {}
  return null;
}
function saveConversation(id) {
  conversationId = id || null;
  try { fs.writeFileSync(SESSION_FILE, JSON.stringify({ conversationId, updatedAt: new Date().toISOString() }, null, 2), 'utf8'); } catch (_) {}
}

function getMessages() {
  try {
    if (fs.existsSync(MESSAGES_FILE)) return JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8'));
  } catch (_) {}
  return [];
}

function saveMessages(msgs) {
  try {
    const limited = msgs.slice(-100);
    const tmpFile = MESSAGES_FILE + '.tmp';
    fs.writeFileSync(tmpFile, JSON.stringify(limited, null, 2), 'utf8');
    fs.renameSync(tmpFile, MESSAGES_FILE);
  } catch (_) {
    try { fs.writeFileSync(MESSAGES_FILE, JSON.stringify(msgs.slice(-100), null, 2), 'utf8'); } catch (_) {}
  }
}

function pushMessage(m) {
  const msgs = getMessages();
  msgs.push(Object.assign({ id: Date.now(), role: 'ai', time: new Date().toLocaleTimeString('ko-KR') }, m));
  saveMessages(msgs);
}
function pushAi(text) { pushMessage({ text }); }

function killCurrentProcess() {
  killedAt = Date.now();
  activeChildren.forEach(killTree);
  activeChildren.clear();
  isAgyBusy = false;
  currentTask = '';
  retrying = '';
  pushAi('🛑 [긴급 정지] 사용자에 의해 실행 중이던 모든 Antigravity 작업이 즉시 강제 종료되었습니다.');
  return true;
}

function resetConversation() {
  saveConversation(null);
  pushAi('🔄 Antigravity 대화를 새로 시작합니다.');
  return true;
}

function getStatus() {
  return {
    isWorking: isAgyBusy,
    currentTask,
    retrying,
    conversationId,
    model: AGY_MODEL,
    messages: getMessages()
  };
}

/** 1회 실행 (대화 이어가기 여부 지정) */
async function runOnce(prompt, useConversation) {
  const startedAt = Date.now();
  const spec = adapter.buildArgs(prompt, { model: AGY_MODEL, cwd: WORK_DIR, printTimeout: '9m', conversationId: useConversation ? conversationId : null, safe: isSafe() });
  const r = await runCli(spec, { timeoutMs: TIMEOUT_MS, register: c => activeChildren.add(c), unregister: c => activeChildren.delete(c) });
  if (killedAt >= startedAt) return { ok: false, kind: 'killed' };
  if (r.spawnError) return { ok: false, kind: 'spawn', code: r.code, stderr: r.spawnError, stdout: '' };
  if (r.timedOut) return { ok: false, kind: 'timeout', code: null, stderr: r.stderr, stdout: r.stdout };
  const p = adapter.parseOutput(r.stdout, r.stderr, r.code, { useConversation });
  if (p.conversationId) saveConversation(p.conversationId);
  if (p.ok) return { ok: true, reply: p.reply, code: r.code, format: p.format };
  return { ok: false, kind: p.format === 'json' ? 'exit' : (r.code === 0 ? 'parse' : 'exit'), code: r.code, stderr: r.stderr, stdout: r.stdout, error: p.error, convBroken: !!p.convBroken };
}

/** 대화 ID 가 깨졌으면 새 대화로 한 번 더 (이건 재시도가 아니라 복구) */
async function runRecovering(prompt) {
  let r = await runOnce(prompt, !!conversationId);
  if (!r.ok && r.convBroken) {
    saveConversation(null);
    r = await runOnce(prompt, false);
  }
  return r;
}

async function executeAgyPrompt(prompt) {
  if (!prompt || !prompt.trim()) return { success: false, error: 'Empty prompt' };
  const cleanPrompt = prompt.trim();
  pushMessage({ role: 'user', text: cleanPrompt });
  audit('instruction', { ai: 'agy', mode: isSafe() ? 'safe' : 'full', prompt: cleanPrompt });

  isAgyBusy = true;
  currentTask = cleanPrompt;
  retrying = '';

  const res = await runWithRetry({
    ai: 'agy',
    minutes: TIMEOUT_MS / 60000,
    attempt: () => runRecovering(cleanPrompt),
    onRetry: (s) => { retrying = s; }
  });

  retrying = '';
  isAgyBusy = activeChildren.size > 0;
  if (!isAgyBusy) currentTask = '';

  if (res.ok) { pushAi(res.reply); return { success: true, reply: res.reply }; }
  if (res.killed) return { success: false, error: '긴급 정지로 중단됨' };
  pushMessage(toMessage(res.fail));
  return { success: false, error: res.fail.title, fail: res.fail };
}

module.exports = {
  getStatus,
  getMessages,
  executeAgyPrompt,
  killCurrentProcess,
  resetConversation
};
