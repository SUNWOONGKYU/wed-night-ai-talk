/**
 * 감사 로그 (2026-09-21, 보안 리스크 4-b)
 *  - audit(event, data)  : logs/audit_YYYYMMDD.log 에 한 줄(JSON) 추가. 비밀값은 마스킹.
 *  - authLog(line)       : logs/auth_YYYYMMDD.log (로그인 시도·잠금)
 *  로그 폴더 = 콘솔 본체 폴더(CONSOLE_HOME)/logs — 프로젝트 자식들도 한 곳에 쓴다.
 *  기록되는 것: 폰/CLI 에서 온 지시(어느 AI·프로젝트·앞 300자), 실행 명령(/api/exec), 훅이 차단·허용한 명령, 권한 모드 변경, 세션 전체 로그아웃.
 */
const fs = require('fs');
const path = require('path');

const HOME = process.env.CONSOLE_HOME || __dirname;
const LOG_DIR = path.join(HOME, 'logs');

// [정규식, 앞부분(1번 그룹) 유지 여부] — 유지하면 "key=***" 꼴, 아니면 토큰 전체를 *** 로
const SECRET_RES = [
  [/sk-[A-Za-z0-9_-]{8,}/g, false], [/ghp_[A-Za-z0-9]{10,}/g, false], [/xai-[A-Za-z0-9_-]{8,}/g, false], [/ya29\.[A-Za-z0-9._-]{10,}/g, false],
  [/\b\d{9,10}:[A-Za-z0-9_-]{30,}/g, false],                                                            // 텔레그램 봇 토큰
  [/(Bearer\s+)[A-Za-z0-9._-]{10,}/gi, true],
  [/((?:api[_-]?key|secret|token|password|passwd|pwd|pin)\s*[=:]\s*)["']?[^\s"',;]{4,}/gi, true],       // key=value 꼴
  [/(KIS_APP_(?:KEY|SECRET)\s*=\s*)\S+/g, true]
];
function mask(s) {
  let t = String(s == null ? '' : s);
  for (const [re, keep] of SECRET_RES) t = t.replace(re, (m, g1) => (keep ? g1 + '***' : '***'));
  return t;
}

function day() { const d = new Date(); return d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0'); }
function append(name, line) {
  try { fs.mkdirSync(LOG_DIR, { recursive: true }); fs.appendFileSync(path.join(LOG_DIR, name + '_' + day() + '.log'), line + '\n', 'utf8'); } catch (_) {}
}

/** event: 'instruction' | 'exec' | 'hook_block' | 'hook_allow' | 'perm_mode' | 'logout_all' | 'agent_run' ... */
function audit(event, data) {
  const rec = { t: new Date().toISOString(), event, project: process.env.PROJECT_NAME || '' };
  for (const k of Object.keys(data || {})) {
    const v = data[k];
    rec[k] = typeof v === 'string' ? mask(v).slice(0, 300) : v;
  }
  append('audit', JSON.stringify(rec));
}

function authLog(ip, result, extra) {
  append('auth', new Date().toISOString() + ' ' + (ip || '-') + ' ' + result + (extra ? ' ' + extra : ''));
}

module.exports = { audit, authLog, mask, LOG_DIR };
