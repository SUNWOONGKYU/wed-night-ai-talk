/**
 * 브릿지 공통 래퍼 (2026-09-21)
 *  - runCli(spec, opts)        : 어댑터 buildArgs 결과(spec)를 spawn 해 { code, stdout, stderr, timedOut, spawnError } 로 돌려준다 (타임아웃·트리 종료 포함)
 *  - runWithRetry(o)           : 시간 초과·비정상 종료·해석 실패면 같은 지시를 1회 자동 재시도(상태줄 "다시 시도 중 (1/1)"), 그래도 실패면 fail_msg 로 통일 문구
 *
 *  attempt(n) 는 { ok, reply, kind:'timeout'|'exit'|'spawn'|'parse'|'killed', code, stdout, stderr, error, ... } 를 돌려준다.
 *  kind 'killed'(긴급 정지)는 재시도하지 않는다.
 */
const { spawn, execSync } = require('child_process');
const { classifyFailure, noteFailure } = require('./fail_msg');
const { cleanEnv } = require('./adapters/_common');

const RETRYABLE = new Set(['timeout', 'exit', 'spawn', 'parse']);

function killTree(child) {
  try {
    if (!child || !child.pid) return;
    if (process.platform === 'win32') execSync('taskkill /pid ' + child.pid + ' /T /F 2>nul || exit 0', { shell: true, windowsHide: true });
    else child.kill('SIGKILL');
  } catch (_) {}
}

/** spec: { cmd, args, cwd, env, stdin } / opts: { timeoutMs, register(child), unregister(child) } */
function runCli(spec, opts) {
  opts = opts || {};
  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(spec.cmd, spec.args, {
        cwd: spec.cwd || process.cwd(),
        shell: false,
        windowsHide: true,
        stdio: [spec.stdin != null ? 'pipe' : 'ignore', 'pipe', 'pipe'],
        env: spec.env || cleanEnv()
      });
    } catch (e) {
      return resolve({ code: -1, stdout: '', stderr: '', timedOut: false, spawnError: e.message, child: null });
    }
    if (opts.register) opts.register(child);
    const out = [], err = [];
    let done = false, timedOut = false;
    const finish = (r) => { if (done) return; done = true; if (opts.unregister) opts.unregister(child); resolve(Object.assign({ child }, r)); };
    const timer = setTimeout(() => {
      if (done) return;
      timedOut = true;
      killTree(child);
      finish({ code: null, stdout: Buffer.concat(out).toString('utf8'), stderr: Buffer.concat(err).toString('utf8'), timedOut: true, spawnError: null });
    }, opts.timeoutMs || 10 * 60 * 1000);
    child.stdout.on('data', d => out.push(d));
    child.stderr.on('data', d => err.push(d));
    child.on('error', (e) => { clearTimeout(timer); finish({ code: -1, stdout: '', stderr: '', timedOut: false, spawnError: e.message }); });
    child.on('close', (code) => { clearTimeout(timer); if (timedOut) return; finish({ code, stdout: Buffer.concat(out).toString('utf8'), stderr: Buffer.concat(err).toString('utf8'), timedOut: false, spawnError: null }); });
    if (spec.stdin != null) { try { child.stdin.end(Buffer.from(String(spec.stdin), 'utf8')); } catch (_) {} }
  });
}

/**
 * o: { ai, attempt(n)→Promise<result>, onRetry(statusText), maxRetry=1, minutes, project }
 * → { ok, reply, fail, attempts, last }
 */
async function runWithRetry(o) {
  const maxRetry = o.maxRetry == null ? 1 : o.maxRetry;
  let n = 0, r = null;
  while (true) {
    n++;
    r = await o.attempt(n);
    if (r && r.ok) return { ok: true, reply: r.reply, fail: null, attempts: n, last: r };
    const kind = (r && r.kind) || 'exit';
    if (n <= maxRetry && RETRYABLE.has(kind)) {
      if (o.onRetry) { try { o.onRetry('다시 시도 중 (' + n + '/' + maxRetry + ')', n, r); } catch (_) {} }
      continue;
    }
    break;
  }
  if (r && r.kind === 'killed') return { ok: false, reply: '', fail: null, attempts: n, last: r, killed: true };
  const fail = classifyFailure({ ai: o.ai, kind: (r && r.kind) || 'exit', code: r ? r.code : undefined, stderr: r && r.stderr, stdout: r && r.stdout, error: r && r.error, minutes: o.minutes, retried: n > 1 });
  noteFailure(fail, o.project);
  return { ok: false, reply: '', fail, attempts: n, last: r };
}

module.exports = { runCli, runWithRetry, killTree, RETRYABLE };
