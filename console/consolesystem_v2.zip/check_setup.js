// 설치 점검: Node / 4개 AI CLI 설치·로그인 여부
const { execSync } = require('child_process');
const path = require('path');
function run(cmd) { try { return execSync(cmd, { stdio: ['ignore', 'pipe', 'pipe'], timeout: 20000 }).toString().trim(); } catch (e) { return null; } }
const rows = [];
rows.push(['Node.js', run('node --version') ? 'OK ' + run('node --version') : '없음 → https://nodejs.org']);
rows.push(['Claude Code (메인)', run('claude --version') ? 'OK ' + run('claude --version') : '없음 → npm install -g @anthropic-ai/claude-code 후 claude 실행해 로그인']);
rows.push(['Codex (서브)', run('codex --version') ? 'OK ' + run('codex --version') : '없음(선택) → npm install -g @openai/codex 후 codex login']);
rows.push(['Antigravity (서브)', run('agy --version') ? 'OK ' + run('agy --version') : '없음(선택) → Antigravity 설치 후 agy 실행해 로그인']);
rows.push(['Grok (서브)', run('grok --version') ? 'OK ' + run('grok --version') : '없음(선택) → npm install -g @xai-official/grok 후 grok login']);
rows.push(['cloudflared.exe', require('fs').existsSync(path.join(__dirname, 'cloudflared.exe')) ? 'OK' : '없음 → 배포판 폴더에 포함돼 있어야 함']);
console.log('\n=== 설치 점검 ===');
for (const [k, v] of rows) console.log(k.padEnd(22) + v);
console.log('\n메인(Claude Code)과 Node, cloudflared 세 개만 OK면 시작할 수 있습니다. 서브 워커는 있는 것만 탭에서 동작합니다.');
