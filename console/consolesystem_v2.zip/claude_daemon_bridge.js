/**
 * Claude Daemon Bridge — 2번째 이후 프로젝트용 "창 없는" Claude Code (PC1 19:05 지시 · 2026-09-20)
 *
 *  - PC 창을 띄우지 않는다. 지시가 오면 그 프로젝트 폴더에서 `claude -p --resume <세션ID>` 를 실행해 처리한다 (큐 순차 실행).
 *  - 세션은 main_session.json 의 sessionId 하나를 계속 --resume 하므로 대화 맥락이 이어진다.
 *    (기존 대화형 창이 쓰던 세션ID를 그대로 이어받는다 → 그 창의 작업 내용이 데몬에 자동 전달)
 *  - 폰 표시: 같은 세션의 transcript(~/.claude/projects/<proj>/<id>.jsonl)를 main_worker_bridge.parseTranscript 로 읽어
 *    창 미러링 모드와 똑같은 말풍선(요약/상세/전체)으로 보여준다. 클라이언트/폰 코드 변경 없음.
 *  - 인터페이스는 main_worker_bridge.js 와 동일 (getStatus/executeMainPrompt/ensureWindow/killCurrentProcess/resetSession/injectKeys).
 *  - 메인 Claude(1번 프로젝트)가 부르는 통로: 라우터 7890 에 헤더 X-Console-Project:<프로젝트명> 을 붙여
 *      POST /api/send-mobile-input {text}  → GET /api/live-transcript 로 결과 확인   (편의 CLI: node daemon_ask.js <프로젝트> "<지시>")
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, execFile } = require('child_process');
const { parseTranscript } = require('./main_worker_bridge.js');
const adapter = require('./adapters/claude');            // 2026-09-21: 명령줄 조립·출력 해석
const { runCli, runWithRetry } = require('./bridge_retry'); // 실행 + 1회 자동 재시도
const { toMessage } = require('./fail_msg');              // 실패 문구 통일(원문은 "자세히" 안에만)
const { isSafe } = require('./perm');                     // 권한 모드(safe 기본) — 2026-09-21
const { audit } = require('./audit');                     // 감사 로그

const SESSION_FILE = path.join(__dirname, 'main_session.json');
const LOG_FILE = path.join(__dirname, 'daemon.log');
const WORK_DIR = path.resolve(__dirname, '..');
const WORKER_LABEL = 'Claude Code (Opus 5) 데몬';
const PROJECT_KEY = WORK_DIR.replace(/[^a-zA-Z0-9]/g, '-');
const TRANSCRIPT_DIR = path.join(os.homedir(), '.claude', 'projects', PROJECT_KEY);
const CLAUDE_EXE = fs.existsSync(path.join(os.homedir(), '.local', 'bin', 'claude.exe')) ? path.join(os.homedir(), '.local', 'bin', 'claude.exe') : 'claude';
const TIMEOUT_MS = 30 * 60 * 1000; // 지시 1건 최대 30분

let sessionState = loadSession();
let version = 0;
let lastAction = '';
let queue = [];            // 대기 중인 지시 [{ id, text, time, ts }]
let running = null;        // { child, text, startedAt }
let extra = [];            // transcript 에 안 남는 오류 안내 말풍선
let cache = { mtime: 0, size: 0, messages: [], isWorking: false };

function nowIso() { return new Date().toISOString(); }
function bump() { version++; }
function log(m) { const line = '[' + new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }) + '] ' + m; console.log('[daemon] ' + m); try { fs.appendFileSync(LOG_FILE, line + '\n', 'utf8'); } catch (_) {} }

// ---------- 세션 ----------
function loadSession() {
  try { if (fs.existsSync(SESSION_FILE)) { const s = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8')); if (s && s.sessionId) return s; } } catch (_) {}
  return { sessionId: null, started: false, createdAt: null };
}
function saveSession() { try { fs.writeFileSync(SESSION_FILE, JSON.stringify(sessionState, null, 2), 'utf8'); } catch (_) {} }
function newSession(note) { sessionState = { sessionId: crypto.randomUUID(), started: false, createdAt: nowIso(), mode: 'daemon', note: note || '' }; saveSession(); cache = { mtime: 0, size: 0, messages: [], isWorking: false }; return sessionState; }
function transcriptPath(id) { return path.join(TRANSCRIPT_DIR, (id || sessionState.sessionId) + '.jsonl'); }
/** 실제로 대화가 시작됐는지는 플래그가 아니라 transcript 파일 존재로 판정 (PC1 보고: 플래그만 믿으면 --resume 오판) */
function sessionStarted(id) { try { return fs.existsSync(transcriptPath(id)); } catch (_) { return false; } }
if (!sessionState.sessionId) newSession('데몬 첫 세션');

function cleanEnv() {
  const env = Object.assign({}, process.env);
  for (const k of Object.keys(env)) if (k === 'CLAUDECODE' || k === 'CLAUDE_PID' || k === 'CLAUDE_EFFORT' || k.startsWith('CLAUDE_CODE_') || k === 'NoDefaultCurrentDirectoryInExePath') delete env[k];
  return env;
}
function ps(args) {
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', ...args], { windowsHide: true, maxBuffer: 4 * 1024 * 1024, timeout: 60000 }, (err, stdout, stderr) => resolve({ err, stdout: String(stdout || ''), stderr: String(stderr || '') }));
  });
}
/** 프로세스 트리 종료 (자식 → 부모). Windows 는 PowerShell Stop-Process 사용 */
async function killTree(pid) {
  if (!pid) return;
  if (process.platform === 'win32') {
    await ps(['-Command', `$ids=@(${pid}); $q=@(${pid}); while($q.Count){ $p=$q[0]; $q=@($q | Select-Object -Skip 1); $kids=@(Get-CimInstance Win32_Process -Filter "ParentProcessId=$p" | ForEach-Object { $_.ProcessId }); $ids+=$kids; $q+=$kids }; [array]::Reverse($ids); foreach($i in $ids){ Stop-Process -Id $i -Force -ErrorAction SilentlyContinue }`]);
  } else { try { process.kill(pid, 'SIGKILL'); } catch (_) {} }
}

// ---------- 실행 ----------
let killedAt = 0; // 긴급 정지 시각 — 그 뒤 끝난 실행은 오류로 보지 않고 재시도도 하지 않는다
/** 1회 실행: adapters/claude.buildArgs → runCli(타임아웃·트리 종료 포함) → 원문 그대로 반환 */
async function runClaude(prompt, opts) {
  const spec = adapter.buildArgs(prompt, Object.assign({ cwd: WORK_DIR, safe: isSafe() }, opts || {}));
  spec.env = cleanEnv();
  const r = await runCli(spec, { timeoutMs: TIMEOUT_MS, register: (child) => { running = { child, text: prompt, startedAt: Date.now() }; } });
  if (r.timedOut) log('⏱️ ' + (TIMEOUT_MS / 60000) + '분 초과 → 강제 종료');
  return { code: r.spawnError ? -1 : r.code, out: String(r.stdout || '').trim(), err: String(r.spawnError || r.stderr || '').trim(), timedOut: r.timedOut, child: r.child };
}

/** 지시 1건 처리(세션 복구 포함). runWithRetry 가 부르는 attempt — 결과를 { ok, kind, ... } 로 돌려준다 */
async function runJob(job) {
  const startedAt = Date.now();
  const id = sessionState.sessionId;
  let resume = sessionStarted(id);
  lastAction = resume ? '🤖 데몬 실행 중 (세션 이어받기)...' : '🤖 데몬 실행 중 (새 세션)...'; bump();
  log((resume ? 'resume ' : 'new ') + id + ' ← ' + job.text.slice(0, 80).replace(/\s+/g, ' '));
  let r = await runClaude(job.text, { sessionId: id, resume });
  if (r.code !== 0 && !r.timedOut && /No conversation found/i.test(r.err) && resume) {
    // 세션 파일은 있는데 Claude 가 못 찾는 경우(손상 등) → 같은 폴더 새 세션으로 복구
    log('resume 실패 → 새 세션으로 재시도: ' + r.err.slice(0, 120));
    const s = newSession('resume 실패로 새 세션 (' + id + ' 대체)');
    r = await runClaude(job.text, { sessionId: s.sessionId, resume: false });
  } else if (r.code !== 0 && !r.timedOut && /already in use|already exists/i.test(r.err) && !resume) {
    const s = newSession('세션ID 충돌로 새 세션');
    r = await runClaude(job.text, { sessionId: s.sessionId, resume: false });
  }
  if (killedAt >= startedAt) return { ok: false, kind: 'killed' };
  if (r.timedOut) return { ok: false, kind: 'timeout', code: null, stdout: r.out, stderr: r.err };
  const p = adapter.parseOutput(r.out, r.err, r.code);
  if (p.ok) return { ok: true, reply: p.reply, code: r.code };
  return { ok: false, kind: r.code === -1 ? 'spawn' : 'exit', code: r.code, stdout: r.out, stderr: r.err, error: p.error };
}

let pumping = false;
async function pump() {
  if (pumping) return; pumping = true;
  try {
    while (queue.length) {
      const job = queue[0];
      const res = await runWithRetry({
        ai: 'claude', minutes: TIMEOUT_MS / 60000, project: process.env.PROJECT_NAME,
        attempt: () => runJob(job),
        onRetry: (s) => { lastAction = '🔁 ' + s; bump(); log(s); }
      });
      running = null;
      queue.shift();
      if (res.ok) { sessionState.started = true; sessionState.mode = 'daemon'; saveSession(); lastAction = ''; log('완료 (' + Math.round((Date.now() - job.ts) / 1000) + 's) → ' + String(res.reply || '').slice(0, 80).replace(/\s+/g, ' ')); }
      else if (res.killed) { lastAction = ''; }
      else {
        // 폰에는 통일 문구만(원문·종료 코드는 카드의 "자세히" 안). 로그에는 원인 분류 + 원문 앞부분
        lastAction = '⚠️ ' + res.fail.title;
        extra.push(toMessage(res.fail, { id: 'x-' + Date.now(), time: nowIso() }));
        extra = extra.slice(-20);
        log('오류 [' + res.fail.category + '] ' + res.fail.title + ' | ' + String(res.fail.detail || '').replace(/\s+/g, ' ').slice(0, 200));
      }
      bump();
    }
  } finally { pumping = false; running = null; }
}

// ---------- transcript ----------
function readTranscript() {
  const tp = transcriptPath(sessionState.sessionId);
  if (!fs.existsSync(tp)) return { messages: [], isWorking: false, mtime: 0 };
  let st; try { st = fs.statSync(tp); } catch (_) { return cache; }
  if (st.mtimeMs === cache.mtime && st.size === cache.size) return cache;
  const r = parseTranscript(fs.readFileSync(tp, 'utf8'));
  cache = { mtime: st.mtimeMs, size: st.size, messages: r.messages, isWorking: r.isWorking };
  return cache;
}

// ---------- 공개 API (main_worker_bridge 와 동일 인터페이스) ----------
function getStatus() {
  const tr = readTranscript();
  // 아직 transcript 에 안 찍힌 대기/실행 중 지시는 폰에 즉시 보여준다 (transcript 에 나타나면 중복 제거)
  const pend = queue.filter(p => !tr.messages.some(m => m.role === 'user' && m.text === p.text)).map(p => ({ id: p.id, role: 'user', text: p.text, time: p.time, isMobile: true }));
  const messages = tr.messages.concat(extra).concat(pend).sort((a, b) => String(a.time).localeCompare(String(b.time)));
  const working = !!running || queue.length > 0;
  return {
    success: true, worker: WORKER_LABEL, mode: 'headless-daemon', daemon: true,
    conversationId: sessionState.sessionId, windowPid: 'daemon', daemonPid: running && running.child ? running.child.pid : null,
    activeStep: version + messages.length * 7 + (working ? 1 : 0) + (tr.mtime || 0),
    isWorking: working,
    currentTask: working ? (running ? running.text : queue[0].text) : '',
    lastAction: working ? (lastAction || '🤖 데몬 실행 중...') : (lastAction || ''),
    retrying: (lastAction && lastAction.indexOf('🔁') === 0) ? lastAction.slice(2).trim() : '',
    queued: queue.length, count: messages.length, messages
  };
}

async function executeMainPrompt(prompt) {
  const clean = String(prompt || '').trim();
  if (!clean) return { success: false, error: 'Empty prompt' };
  queue.push({ id: 'm-' + Date.now(), text: clean, time: nowIso(), ts: Date.now() });
  audit('instruction', { ai: 'claude', mode: isSafe() ? 'safe' : 'full', prompt: clean });
  lastAction = '📥 데몬 큐에 접수 (' + queue.length + '건)'; bump();
  pump();
  return { success: true, reply: '데몬 큐에 접수됨', queued: queue.length };
}

/** 창이 없으므로 항상 즉시 'daemon' (폰/라우터의 windowPid 자리에 표시) */
async function ensureWindow() { return 'daemon'; }
async function findWindowPid() { return 'daemon'; }

async function injectKeys() { return { ok: false, error: '데몬 모드에는 선택 위젯이 없습니다 — 번호나 보기 글자를 채팅으로 답해 주세요' }; }

async function killCurrentProcess() {
  killedAt = Date.now();
  const n = queue.length; queue = [];
  const pid = running && running.child ? running.child.pid : null;
  if (pid) await killTree(pid);
  running = null;
  lastAction = pid ? '🛑 데몬 작업 강제 종료 (대기 ' + n + '건 취소)' : (n ? '🛑 대기 ' + n + '건 취소' : '⚠️ 실행 중인 데몬 작업 없음'); bump();
  log(lastAction);
  return true;
}

async function resetSession() {
  await killCurrentProcess();
  const s = newSession('폰/API 요청으로 새 세션');
  extra = [];
  lastAction = '🔄 새 세션 시작'; bump();
  log('새 세션 ' + s.sessionId);
  return s.sessionId;
}

function getMessages() { return getStatus().messages; }

log('데몬 브릿지 기동: ' + WORK_DIR + ' / 세션 ' + sessionState.sessionId + (sessionStarted(sessionState.sessionId) ? ' (기존 대화 이어받음)' : ' (대화 기록 없음 → 첫 지시에서 시작)'));

module.exports = { WORKER_LABEL, getStatus, getMessages, executeMainPrompt, killCurrentProcess, resetSession, ensureWindow, findWindowPid, injectKeys };
