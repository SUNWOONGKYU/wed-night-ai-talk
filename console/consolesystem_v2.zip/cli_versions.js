/**
 * CLI 버전 실측·비교 (2026-09-21)
 *  - detectVersions()  : 4개 CLI 에 `--version` 을 물어 설치 버전을 읽는다 (병렬, 각 30초 제한, 기동을 막지 않게 비동기)
 *  - compare()         : cli_compat.json(verified/min) 과 비교 → status: verified | newer_unverified | older_ok | too_old | missing
 *  - cli_versions.json(콘솔 본체 폴더)에 저장 → server.js /api/status 가 읽어 폰 상태줄에 사람 말로 안내
 *  CLI: node cli_versions.js   (표로 출력)
 */
const fs = require('fs');
const path = require('path');
const adapters = require('./adapters');
const { runCli } = require('./bridge_retry');
const { parseVersion } = require('./adapters/_common');

const STATE_DIR = process.env.CONSOLE_HOME || __dirname;
const COMPAT_FILE = path.join(__dirname, 'cli_compat.json');
const STATE_FILE = path.join(STATE_DIR, 'cli_versions.json');
const LABEL = { claude: 'Claude Code', codex: 'Codex', agy: 'Antigravity', grok: 'Grok' };

function readCompat() {
  try { return JSON.parse(fs.readFileSync(COMPAT_FILE, 'utf8').replace(/^﻿/, '')); } catch (_) { return {}; }
}

/** '1.2.10' vs '1.2.9' 숫자 비교 (-1/0/1) */
function cmpVer(a, b) {
  const pa = String(a || '').split('.').map(n => parseInt(n, 10) || 0);
  const pb = String(b || '').split('.').map(n => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d < 0 ? -1 : 1; }
  return 0;
}

async function detectOne(ai) {
  const ad = adapters.get(ai);
  if (!ad) return { installed: '', raw: '' };
  const v = ad.versionArgs;
  const r = await runCli({ cmd: v.cmd, args: v.args, cwd: __dirname }, { timeoutMs: 30000 });
  const raw = ((r.stdout || '') + ' ' + (r.stderr || '')).trim();
  if (r.spawnError) return { installed: '', raw: r.spawnError };
  return { installed: parseVersion(raw), raw: raw.slice(0, 120) };
}

function judge(ai, installed, compat) {
  const c = compat[ai] || {};
  const label = LABEL[ai] || ai;
  const out = { ai, label, installed: installed || '', verified: c.verified || '', min: c.min || '', status: '', message: '' };
  if (!installed) { out.status = 'missing'; out.message = label + '가 설치되어 있지 않거나 버전을 읽지 못했습니다.'; return out; }
  if (c.verified && cmpVer(installed, c.verified) === 0) { out.status = 'verified'; return out; }
  if (c.min && cmpVer(installed, c.min) < 0) { out.status = 'too_old'; out.message = label + ' 버전(' + installed + ')이 너무 오래됐습니다. ' + c.min + ' 이상으로 업데이트해 주세요.'; return out; }
  if (c.verified && cmpVer(installed, c.verified) > 0) { out.status = 'newer_unverified'; out.message = label + '가 새 버전(' + installed + ')으로 바뀌었습니다. 아직 확인되지 않아 문제가 생길 수 있습니다.'; return out; }
  out.status = 'older_ok'; return out; // min 이상 verified 미만 — 동작 범위
}

async function detectVersions(ais) {
  const compat = readCompat();
  const list = ais && ais.length ? ais : adapters.names;
  const found = await Promise.all(list.map(a => detectOne(a).then(v => [a, v])));
  const versions = {};
  for (const [ai, v] of found) versions[ai] = Object.assign(judge(ai, v.installed, compat), { raw: v.raw });
  const state = { at: new Date().toISOString(), verified_at: compat.verified_at || '', versions, unverified: Object.keys(versions).filter(k => /newer_unverified|too_old/.test(versions[k].status)) };
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8'); } catch (_) {}
  return state;
}

function readVersions() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch (_) { return { at: null, versions: {}, unverified: [] }; }
}

module.exports = { detectVersions, readVersions, readCompat, cmpVer, judge, LABEL, STATE_FILE };

if (require.main === module) {
  detectVersions().then((s) => {
    console.log('검증표 기준일: ' + (s.verified_at || '-'));
    for (const k of Object.keys(s.versions)) {
      const v = s.versions[k];
      console.log((v.label + ' ').padEnd(14) + (v.installed || '없음').padEnd(10) + ' 검증 ' + (v.verified || '-').padEnd(10) + ' ' + v.status + (v.message ? '  — ' + v.message : ''));
    }
    process.exit(0);
  });
}
