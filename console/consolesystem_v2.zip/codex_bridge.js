/**
 * Codex CLI Mobile Bridge Engine
 * Handles bi-directional communication between mobile web console and OpenAI Codex CLI
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const MESSAGES_FILE = path.join(__dirname, 'codex_messages.json');
const WORK_DIR = path.resolve(__dirname, '..');

// Initialize messages file if not exists
if (!fs.existsSync(MESSAGES_FILE)) {
  try {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify([
      {
        id: 1,
        role: 'ai',
        text: '⚡ Codex (GPT-5.6-terra) 모바일 서브 워커가 연결되었습니다!\n스마트폰에서 코딩 작업, 스크립트 실행, 파일 수정을 지시하시면 PC의 Codex (GPT-5.6-terra Medium)가 실시간으로 실행합니다.',
        time: new Date().toLocaleTimeString('ko-KR')
      }
    ], null, 2), 'utf8');
  } catch (_) {}
}

let isCodexBusy = false;
let currentTask = '';
const activeChildren = new Set();

function getMessages() {
  try {
    if (fs.existsSync(MESSAGES_FILE)) {
      return JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8'));
    }
  } catch (_) {}
  return [];
}

function saveMessages(msgs) {
  try {
    const limited = msgs.slice(-100);
    const tmpFile = MESSAGES_FILE + '.tmp';
    fs.writeFileSync(tmpFile, JSON.stringify(limited, null, 2), 'utf8');
    fs.renameSync(tmpFile, MESSAGES_FILE);
  } catch (_) {
    try {
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(msgs.slice(-100), null, 2), 'utf8');
    } catch (_) {}
  }
}

function killCurrentProcess() {
  if (activeChildren.size > 0) {
    activeChildren.forEach(child => {
      try {
        if (child && child.pid) {
          if (process.platform === 'win32') {
            const { execSync } = require('child_process');
            execSync(`taskkill /pid ${child.pid} /T /F 2>nul || exit 0`, { shell: true });
          } else {
            child.kill('SIGKILL');
          }
        }
      } catch (_) {}
    });
    activeChildren.clear();
  }
  isCodexBusy = false;
  currentTask = '';
  const updatedMsgs = getMessages();
  updatedMsgs.push({
    id: Date.now(),
    role: 'ai',
    text: '🛑 [긴급 정지] 사용자에 의해 실행 중이던 모든 Codex 연산 작업이 즉시 강제 종료되었습니다.',
    time: new Date().toLocaleTimeString('ko-KR')
  });
  saveMessages(updatedMsgs);
  return true;
}

function getStatus() {
  return {
    isWorking: isCodexBusy,
    currentTask: currentTask,
    messages: getMessages()
  };
}

function executeCodexPrompt(prompt) {
  return new Promise((resolve) => {
    if (!prompt || !prompt.trim()) {
      return resolve({ success: false, error: 'Empty prompt' });
    }

    const cleanPrompt = prompt.trim();
    const msgs = getMessages();
    const userMsgId = Date.now();
    msgs.push({
      id: userMsgId,
      role: 'user',
      text: cleanPrompt,
      time: new Date().toLocaleTimeString('ko-KR')
    });
    saveMessages(msgs);

    isCodexBusy = true;
    currentTask = cleanPrompt;

    const codexJs = path.join(process.env.APPDATA || '', 'npm', 'node_modules', '@openai', 'codex', 'bin', 'codex.js');

    const child = spawn(process.execPath, [
      codexJs,
      'exec',
      '--dangerously-bypass-approvals-and-sandbox',
      '--skip-git-repo-check',
      '--ephemeral',
      cleanPrompt
    ], {
      cwd: WORK_DIR,
      shell: false,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });

    activeChildren.add(child);

    // 120초 타임아웃 안전 장치
    const timer = setTimeout(() => {
      if (activeChildren.has(child)) {
        try {
          if (process.platform === 'win32') {
            const { execSync } = require('child_process');
            execSync(`taskkill /pid ${child.pid} /T /F 2>nul || exit 0`, { shell: true });
          } else {
            child.kill('SIGKILL');
          }
        } catch (_) {}
        activeChildren.delete(child);
        isCodexBusy = activeChildren.size > 0;
        currentTask = isCodexBusy ? currentTask : '';
        const updatedMsgs = getMessages();
        updatedMsgs.push({
          id: Date.now(),
          role: 'ai',
          text: '⏱️ [작업 제한 시간 초과] 10분 동안 응답이 없어 프로세스를 안전하게 종료했습니다.',
          time: new Date().toLocaleTimeString('ko-KR')
        });
        saveMessages(updatedMsgs);
        resolve({ success: false, error: 'Timeout 120s' });
      }
    }, 600000);

    let stdoutData = '';
    let stderrData = '';

    child.stdout.on('data', (d) => {
      stdoutData += d.toString();
    });

    child.stderr.on('data', (d) => {
      stderrData += d.toString();
    });

    child.on('close', (code) => {
      clearTimeout(timer);
      activeChildren.delete(child);
      isCodexBusy = activeChildren.size > 0;
      if (!isCodexBusy) currentTask = '';

      let replyText = '';
      const marker = '\ncodex\n';
      const idx = stdoutData.indexOf(marker);
      if (idx !== -1) {
        let sub = stdoutData.slice(idx + marker.length);
        const endIdx = sub.lastIndexOf('\ntokens used');
        if (endIdx !== -1) {
          sub = sub.slice(0, endIdx);
        }
        replyText = sub.trim();
      }

      if (!replyText) {
        const cleanLines = (stdoutData || stderrData).split('\n').filter(l => 
          !l.startsWith('Reading additional') &&
          !l.startsWith('OpenAI Codex') &&
          !l.startsWith('workdir:') &&
          !l.startsWith('model:') &&
          !l.startsWith('provider:') &&
          !l.startsWith('approval:') &&
          !l.startsWith('sandbox:') &&
          !l.startsWith('reasoning') &&
          !l.startsWith('session id:') &&
          !l.startsWith('--------') &&
          !l.startsWith('user') &&
          !l.startsWith('codex') &&
          !l.startsWith('hook:') &&
          !l.startsWith('tokens used') &&
          !l.includes('ERROR codex_core::session')
        );
        replyText = cleanLines.join('\n').trim() || (code === 0 ? '작업이 완료되었습니다.' : `오류 발생 (코드 ${code}): ${stderrData}`);
      }

      const updatedMsgs = getMessages();
      updatedMsgs.push({
        id: Date.now(),
        role: 'ai',
        text: replyText,
        time: new Date().toLocaleTimeString('ko-KR')
      });
      saveMessages(updatedMsgs);

      resolve({ success: true, reply: replyText, code });
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      activeChildren.delete(child);
      isCodexBusy = activeChildren.size > 0;
      if (!isCodexBusy) currentTask = '';
      resolve({ success: false, error: err.message });
    });
  });
}

module.exports = {
  getStatus,
  getMessages,
  executeCodexPrompt,
  killCurrentProcess
};
