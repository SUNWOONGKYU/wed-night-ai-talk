/**
 * Codex CLI Mobile Bridge Engine
 * Handles bi-directional communication between mobile web console and OpenAI Codex CLI
 *
 * 2026-09-21: 명령줄 조립·출력 해석은 adapters/codex.js, 실행·1회 자동 재시도·실패 문구는 bridge_retry.js + fail_msg.js 로 통일.
 */
const fs = require('fs');
const path = require('path');
const adapter = require('./adapters/codex');
const { runCli, runWithRetry, killTree } = require('./bridge_retry');
const { toMessage } = require('./fail_msg');
const { isSafe } = require('./perm');   // 권한 모드(safe 기본) — 2026-09-21
const { audit } = require('./audit');   // 감사 로그

const MESSAGES_FILE = path.join(__dirname, 'codex_messages.json');
const WORK_DIR = path.resolve(__dirname, '..');
const settings = require('./console_settings'); // 폰 ⚙ 설정: 모델·제한 시간·재시도 (매 지시마다 읽음)
const TIMEOUT_MS_DEFAULT = 20 * 60 * 1000; // PO 승인(2026-09-21 09:30): 데몬 워커 20분 — 설정에서 늘리기만 가능
function timeoutMs() { try { return settings.timeoutMsFor('codex'); } catch (_) { return TIMEOUT_MS_DEFAULT; } }

// Initialize messages file if not exists
if (!fs.existsSync(MESSAGES_FILE)) {
  try {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify([
      {
        id: 1,
        role: 'ai',
        text: '⚡ Codex (GPT-5.6-terra) 모바일 서브 워커가 연결되었습니다!\n스마트폰에서 코딩 작업, 스크립트 실행, 파일 수정을 지시하시면 PC의 Codex (GPT-5.6-terra Medium)가 실시간으로 실행합니다.',
        time: new Date().toLocaleTimeString('ko-KR')
      }
    ], null, 2), 'utf8');
  } catch (_) {}
}

let isCodexBusy = false;
let currentTask = '';
let retrying = '';          // "다시 시도 중 (1/1)" — 폰 상태줄
let killedAt = 0;           // 긴급 정지 시각 — 그 뒤 끝난 실행은 재시도하지 않는다
const activeChildren = new Set();

function getMessages() {
  try {
    if (fs.existsSync(MESSAGES_FILE)) {
      return JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8'));
    }
  } catch (_) {}
  return [];
}

function saveMessages(msgs) {
  try {
    const limited = msgs.slice(-100);
    const tmpFile = MESSAGES_FILE + '.tmp';
    fs.writeFileSync(tmpFile, JSON.stringify(limited, null, 2), 'utf8');
    fs.renameSync(tmpFile, MESSAGES_FILE);
  } catch (_) {
    try {
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(msgs.slice(-100), null, 2), 'utf8');
    } catch (_) {}
  }
}

function pushMessage(m) {
  const msgs = getMessages();
  msgs.push(Object.assign({ id: Date.now(), role: 'ai', time: new Date().toLocaleTimeString('ko-KR') }, m));
  saveMessages(msgs);
}

function killCurrentProcess() {
  killedAt = Date.now();
  activeChildren.forEach(killTree);
  activeChildren.clear();
  isCodexBusy = false;
  currentTask = '';
  retrying = '';
  pushMessage({ text: '🛑 [긴급 정지] 사용자에 의해 실행 중이던 모든 Codex 연산 작업이 즉시 강제 종료되었습니다.' });
  return true;
}

function getStatus() {
  return {
    isWorking: isCodexBusy,
    currentTask: currentTask,
    retrying: retrying,
    messages: getMessages()
  };
}

function codexModel() { try { return settings.modelFor('codex'); } catch (_) { try { return (JSON.parse(process.env.CONSOLE_WORKERS || '{}').codex || {}).model || ''; } catch (_) { return ''; } } }

/** 1회 실행: 어댑터로 명령줄을 만들고 → 실행 → 어댑터로 해석 */
async function runOnce(prompt) {
  const startedAt = Date.now();
  const spec = adapter.buildArgs(prompt, { model: codexModel(), cwd: WORK_DIR, safe: isSafe() });
  const r = await runCli(spec, { timeoutMs: timeoutMs(), register: c => activeChildren.add(c), unregister: c => activeChildren.delete(c) });
  if (killedAt >= startedAt) return { ok: false, kind: 'killed' };
  if (r.spawnError) return { ok: false, kind: 'spawn', code: r.code, stderr: r.spawnError, stdout: '' };
  if (r.timedOut) return { ok: false, kind: 'timeout', code: null, stderr: r.stderr, stdout: r.stdout };
  const p = adapter.parseOutput(r.stdout, r.stderr, r.code);
  if (p.ok) return { ok: true, reply: p.reply, code: r.code, format: p.format };
  return { ok: false, kind: 'exit', code: r.code, stderr: r.stderr, stdout: r.stdout, error: p.error };
}

async function executeCodexPrompt(prompt) {
  if (!prompt || !prompt.trim()) return { success: false, error: 'Empty prompt' };
  const cleanPrompt = prompt.trim();
  pushMessage({ role: 'user', text: cleanPrompt });
  audit('instruction', { ai: 'codex', mode: isSafe() ? 'safe' : 'full', prompt: cleanPrompt });

  isCodexBusy = true;
  currentTask = cleanPrompt;
  retrying = '';

  const res = await runWithRetry({
    ai: 'codex',
    minutes: timeoutMs() / 60000,
    maxRetry: settings.maxRetryFor(),
    attempt: () => runOnce(cleanPrompt),
    onRetry: (s) => { retrying = s; }
  });

  retrying = '';
  isCodexBusy = activeChildren.size > 0;
  if (!isCodexBusy) currentTask = '';

  if (res.ok) {
    pushMessage({ text: res.reply });
    return { success: true, reply: res.reply, code: res.last && res.last.code };
  }
  if (res.killed) return { success: false, error: '긴급 정지로 중단됨' };
  pushMessage(toMessage(res.fail));
  return { success: false, error: res.fail.title, fail: res.fail };
}

module.exports = {
  getStatus,
  getMessages,
  executeCodexPrompt,
  killCurrentProcess
};
