/**
 * 원격 호환 공지 (2026-09-21) — 콘솔이 하루 1회 WAAT 의 compat.json 을 읽어 폰 상태줄에 안내한다.
 *  URL : https://www.waat.community/market/onemacs/compat.json   (없거나 실패하면 조용히 무시)
 *  스키마:
 *    { "updated": "2026-09-21",
 *      "notices": [
 *        { "ai": "codex",           // claude | codex | agy | grok | * (전체)
 *          "min_unsupported": "0.160.0",   // 이 버전 이상은 아직 미지원 (설치 버전 >= 이 값이면 안내). 비우면 무조건 안내
 *          "message": "Codex 0.160 이후 버전은 확인 중입니다. 문제가 생기면 Claude Code에게 맡기세요.",
 *          "until": "2026-10-31"    // (선택) 이 날짜 지나면 안내 안 함
 *        } ] }
 *  캐시: compat_remote.json(콘솔 본체 폴더) — 24시간.
 */
const fs = require('fs');
const path = require('path');
const https = require('https');
const { cmpVer } = require('./cli_versions');

const URL_ = process.env.ONEMACS_COMPAT_URL || 'https://www.waat.community/market/onemacs/compat.json';
const STATE_DIR = process.env.CONSOLE_HOME || __dirname;
const CACHE_FILE = path.join(STATE_DIR, 'compat_remote.json');
const TTL_MS = 24 * 60 * 60 * 1000;

function readCache() { try { return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8')); } catch (_) { return null; } }

function fetchRemote() {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    try {
      const req = https.get(URL_, { headers: { 'User-Agent': 'onemacs-console', 'Cache-Control': 'no-cache' }, timeout: 8000 }, (res) => {
        let b = ''; res.on('data', d => { b += d; if (b.length > 200000) req.destroy(); });
        res.on('end', () => { if (res.statusCode !== 200) return finish(null); try { const j = JSON.parse(b); finish(j && Array.isArray(j.notices) ? j : null); } catch (_) { finish(null); } });
      });
      req.on('timeout', () => { req.destroy(); finish(null); });
      req.on('error', () => finish(null));
    } catch (_) { finish(null); }
  });
}

/** 하루 1회만 원격을 읽고 캐시. 실패면 이전 캐시 유지 */
async function refresh(force) {
  const c = readCache();
  if (!force && c && c.fetchedAt && Date.now() - new Date(c.fetchedAt).getTime() < TTL_MS) return c;
  const j = await fetchRemote();
  const next = j ? { fetchedAt: new Date().toISOString(), ok: true, data: j } : Object.assign(c || { data: null }, { fetchedAt: new Date().toISOString(), ok: false });
  try { fs.writeFileSync(CACHE_FILE, JSON.stringify(next, null, 2), 'utf8'); } catch (_) {}
  return next;
}

/** 설치 버전(cli_versions.readVersions().versions)과 대조해 지금 보여줄 공지만 고른다 */
function applicable(versions) {
  const c = readCache();
  const list = c && c.data && Array.isArray(c.data.notices) ? c.data.notices : [];
  const today = new Date().toISOString().slice(0, 10);
  const out = [];
  for (const n of list) {
    if (!n || !n.message) continue;
    if (n.until && String(n.until) < today) continue;
    const ai = String(n.ai || '*').toLowerCase();
    if (ai !== '*') {
      const v = versions && versions[ai] && versions[ai].installed;
      if (!v) continue;                                        // 설치 안 된 AI 공지는 무의미
      if (n.min_unsupported && cmpVer(v, n.min_unsupported) < 0) continue; // 아직 그 버전 아님
    }
    out.push({ ai, kind: 'remote', message: String(n.message).slice(0, 200) });
  }
  return out;
}

function schedule(log) {
  const run = () => refresh(false).then(c => { if (c && c.ok && c.data) (log || console.log)('호환 공지 확인: ' + (c.data.notices || []).length + '건'); }).catch(() => {});
  const t = setTimeout(run, 30000); const iv = setInterval(run, TTL_MS);
  if (t.unref) t.unref(); if (iv.unref) iv.unref();
}

module.exports = { refresh, applicable, schedule, URL: URL_, CACHE_FILE };

if (require.main === module) {
  refresh(true).then((c) => { console.log(JSON.stringify(c, null, 2)); process.exit(0); });
}
