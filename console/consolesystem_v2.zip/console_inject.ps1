﻿# 폰 지시를 PC의 진짜 Claude Code 콘솔 창에 타이핑해 넣는다 (포커스 안 뺏음).
#   powershell -NoProfile -ExecutionPolicy Bypass -File console_inject.ps1 -TargetPid <claude.exe PID> -Text "<지시>"
#   -CtrlC 스위치: Ctrl+C 전송 (현재 작업 중단)
# 원리: 우리 콘솔을 떼고(FreeConsole) 대상 프로세스의 콘솔에 붙어(AttachConsole) CONIN$ 입력 버퍼에 키 이벤트를 쓴다(WriteConsoleInputW).
param(
  [Parameter(Mandatory=$true)][int]$TargetPid,
  [string]$Text = "",
  [string]$Keys = "",
  [switch]$CtrlC
)
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class ConIn {
  [DllImport("kernel32.dll", SetLastError=true)] public static extern bool FreeConsole();
  [DllImport("kernel32.dll", SetLastError=true)] public static extern bool AttachConsole(uint pid);
  [DllImport("kernel32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
  public static extern IntPtr CreateFileW(string name, uint access, uint share, IntPtr sec, uint disp, uint flags, IntPtr tmpl);
  [DllImport("kernel32.dll", SetLastError=true)] public static extern bool WriteConsoleInputW(IntPtr h, INPUT_RECORD[] buf, uint n, out uint written);
  [DllImport("kernel32.dll", SetLastError=true)] public static extern bool CloseHandle(IntPtr h);
  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
  public struct KEY_EVENT_RECORD { public int bKeyDown; public ushort wRepeatCount; public ushort wVirtualKeyCode; public ushort wVirtualScanCode; public char UnicodeChar; public uint dwControlKeyState; }
  [StructLayout(LayoutKind.Sequential)]
  public struct INPUT_RECORD { public ushort EventType; public ushort pad; public KEY_EVENT_RECORD KeyEvent; }
  public static INPUT_RECORD Key(bool down, ushort vk, char ch, uint ctrl) {
    INPUT_RECORD r = new INPUT_RECORD(); r.EventType = 1;
    r.KeyEvent.bKeyDown = down ? 1 : 0; r.KeyEvent.wRepeatCount = 1; r.KeyEvent.wVirtualKeyCode = vk;
    r.KeyEvent.wVirtualScanCode = 0; r.KeyEvent.UnicodeChar = ch; r.KeyEvent.dwControlKeyState = ctrl; return r;
  }
}
"@
[void][ConIn]::FreeConsole()
if (-not [ConIn]::AttachConsole([uint32]$TargetPid)) { $e = [Runtime.InteropServices.Marshal]::GetLastWin32Error(); [Console]::Error.WriteLine("ATTACH_FAIL $e"); exit 2 }
$h = [ConIn]::CreateFileW("CONIN$", [uint32]3221225472, [uint32]3, [IntPtr]::Zero, [uint32]3, [uint32]0, [IntPtr]::Zero)  # GENERIC_READ|GENERIC_WRITE
if ($h -eq [IntPtr]::Zero -or $h.ToInt64() -eq -1) { [Console]::Error.WriteLine("CONIN_FAIL"); exit 3 }

$recs = New-Object System.Collections.Generic.List[ConIn+INPUT_RECORD]
$VK = @{ UP=0x26; DOWN=0x28; LEFT=0x25; RIGHT=0x27; ENTER=0x0D; TAB=0x09; ESC=0x1B; SPACE=0x20; BACKSPACE=0x08 }
$CH = @{ ENTER=[char]13; TAB=[char]9; ESC=[char]27; SPACE=[char]32; BACKSPACE=[char]8 }
if ($CtrlC) {
  $recs.Add([ConIn]::Key($true,  0x43, [char]3, 0x0008))   # LEFT_CTRL_PRESSED
  $recs.Add([ConIn]::Key($false, 0x43, [char]3, 0x0008))
} elseif ($Keys -ne "") {
  foreach ($k in ($Keys -split ',')) {
    $k = $k.Trim().ToUpper(); if ($k -eq "") { continue }
    if ($VK.ContainsKey($k)) { $vk = [uint16]$VK[$k]; $ch = if ($CH.ContainsKey($k)) { $CH[$k] } else { [char]0 } }
    else { $vk = [uint16]0; $ch = [char]$k[0] }
    $recs.Add([ConIn]::Key($true,  $vk, $ch, 0))
    $recs.Add([ConIn]::Key($false, $vk, $ch, 0))
  }
} else {
  $clean = ($Text -replace "`r`n", " " -replace "`n", " ").Trim()
  foreach ($ch in $clean.ToCharArray()) {
    $recs.Add([ConIn]::Key($true,  0, $ch, 0))
    $recs.Add([ConIn]::Key($false, 0, $ch, 0))
  }
}
$arr = $recs.ToArray(); $w = 0
$ok = [ConIn]::WriteConsoleInputW($h, $arr, [uint32]$arr.Length, [ref]$w)
if (-not $ok) { [Console]::Error.WriteLine("WRITE_FAIL"); exit 4 }
if (-not $CtrlC -and $Keys -eq "") {
  Start-Sleep -Milliseconds 150   # TUI가 붙여넣기를 소화할 시간
  $enter = @([ConIn]::Key($true, 0x0D, [char]13, 0), [ConIn]::Key($false, 0x0D, [char]13, 0))
  [void][ConIn]::WriteConsoleInputW($h, $enter, 2, [ref]$w)
}
[void][ConIn]::CloseHandle($h)
Write-Output "OK $w"
