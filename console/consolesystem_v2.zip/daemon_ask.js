/**
 * daemon_ask.js — 메인 Claude(1번 프로젝트)가 다른 프로젝트의 Claude 데몬에게 지시하고 답을 받는 CLI
 *
 *   node daemon_ask.js "<프로젝트명>" "<지시>"            → 지시 보내고 끝날 때까지 기다려 마지막 답을 출력
 *   node daemon_ask.js "<프로젝트명>" "<지시>" --nowait   → 접수만 하고 바로 종료
 *   node daemon_ask.js --list                              → 프로젝트 목록·상태
 *   node daemon_ask.js "<프로젝트명>" --status             → 그 프로젝트의 최근 대화 5줄
 *
 * 통로: 라우터(7890) /api/send-mobile-input · /api/live-transcript + 헤더 X-Console-Project (폰 콘솔과 같은 길)
 * 환경: CONSOLE_URL(기본 http://127.0.0.1:7890), CONSOLE_PIN(기본 console_config.json 의 pin)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

let cfg = {}; try { cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'console_config.json'), 'utf8').replace(/^﻿/, '')); } catch (_) {}
const BASE = process.env.CONSOLE_URL || ('http://127.0.0.1:' + (cfg.port || 7890));
const PIN = process.env.CONSOLE_PIN || cfg.pin || '';
const WAIT_MAX_MS = Number(process.env.DAEMON_WAIT_MS || 30 * 60 * 1000);

function call(method, pathname, project, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(pathname, BASE); u.searchParams.set('pin', PIN);
    const data = body ? Buffer.from(JSON.stringify(body), 'utf8') : null;
    const headers = { 'Accept': 'application/json' };
    if (project) headers['X-Console-Project'] = encodeURIComponent(project);
    if (data) { headers['Content-Type'] = 'application/json; charset=utf-8'; headers['Content-Length'] = data.length; }
    const r = http.request({ host: u.hostname, port: u.port, path: u.pathname + u.search, method, headers, timeout: 20000 }, (res) => {
      const bufs = []; res.on('data', d => bufs.push(d)); res.on('end', () => { const t = Buffer.concat(bufs).toString('utf8'); try { resolve({ status: res.statusCode, body: JSON.parse(t) }); } catch (_) { resolve({ status: res.statusCode, body: t }); } });
    });
    r.on('timeout', () => { r.destroy(new Error('timeout')); }); r.on('error', reject);
    if (data) r.write(data); r.end();
  });
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  const argv = process.argv.slice(2);
  if (!argv.length || argv[0] === '--list') {
    const r = await call('GET', '/api/projects');
    const list = (r.body && r.body.projects) || [];
    for (const p of list) console.log((p.current ? '* ' : '  ') + p.name + '  [' + (p.windowPid === 'daemon' ? '데몬' : (p.windowPid ? '창 ' + p.windowPid : (p.alive ? '창 없음' : '죽음'))) + ']  ' + p.dir);
    return;
  }
  const project = argv[0];
  if (argv[1] === '--status') {
    const r = await call('GET', '/api/live-transcript?limit=5', project);
    const st = r.body || {};
    console.log('worker=' + st.worker + ' mode=' + st.mode + ' session=' + st.conversationId + ' working=' + st.isWorking + ' queued=' + st.queued);
    for (const m of (st.messages || []).slice(-5)) console.log('[' + m.role + '] ' + String(m.text || m.summary || '').slice(0, 300).replace(/\s+/g, ' '));
    return;
  }
  const text = argv[1];
  if (!text) { console.error('사용법: node daemon_ask.js "<프로젝트명>" "<지시>" [--nowait]'); process.exit(2); }
  const before = await call('GET', '/api/live-transcript?limit=1', project);
  const baseCount = (before.body && before.body.count) || 0;
  const sent = await call('POST', '/api/send-mobile-input', project, { text });
  if (sent.status !== 200) { console.error('전송 실패', sent.status, JSON.stringify(sent.body)); process.exit(1); }
  if (argv.includes('--nowait')) { console.log('접수됨 (queued=' + ((sent.body || {}).queued || 0) + ')'); return; }
  const t0 = Date.now(); let seenWorking = false;
  while (Date.now() - t0 < WAIT_MAX_MS) {
    await sleep(2000);
    const r = await call('GET', '/api/live-transcript', project).catch(() => null);
    const st = r && r.body; if (!st) continue;
    if (st.isWorking) seenWorking = true;
    if (!st.isWorking && (seenWorking || (st.count || 0) > baseCount + 1)) {
      const msgs = st.messages || [];
      // 이번 지시 이후의 마지막 AI 텍스트
      let idx = msgs.map(m => m.role === 'user' && m.text === text).lastIndexOf(true);
      const after = idx >= 0 ? msgs.slice(idx + 1) : msgs.slice(-3);
      const ai = after.filter(m => m.role === 'ai').slice(-1)[0];
      if (ai) { process.stdout.write(ai.text + '\n'); return; }
      if (Date.now() - t0 > 15000) { console.log('(답변 텍스트 없음 — 상태: ' + (st.lastAction || '') + ')'); return; }
    }
  }
  console.error('대기 시간 초과'); process.exit(3);
})().catch(e => { console.error('오류:', e.message); process.exit(1); });
