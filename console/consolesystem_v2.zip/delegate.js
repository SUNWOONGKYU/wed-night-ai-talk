/**
 * 메인 워커(Claude Code) -> 서브 워커(Codex / Antigravity) 작업 위임 엔진
 *
 * CLI: node _mobile_remote/delegate.js <codex|agy> "지시 프롬프트"
 *      node _mobile_remote/delegate.js both "지시 프롬프트"   (두 워커에 동시 위임, 결과 비교)
 * 모듈: const { delegateTask } = require('./_mobile_remote/delegate');
 *      await delegateTask('codex', '지시 내용');
 *
 * 콘솔 서버(7890)가 떠 있으면 서버 API를 경유해 실행한다 → 폰의 Codex/Antigravity 탭에 진행·결과가 그대로 보인다.
 * 서버가 없으면 브릿지를 직접 호출한다.
 */
const http = require('http');
const path = require('path');

const SERVER = 'http://127.0.0.1:' + (process.env.PORT || 7890);
let _cfg = {}; try { _cfg = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, 'console_config.json'), 'utf8').replace(/^\uFEFF/, '')); } catch (_) {}
const PIN = process.env.PIN || _cfg.pin || '0000';
const POLL_MS = 2000;
const WAIT_MAX_MS = 15 * 60 * 1000;

const WORKERS = {
  codex: { label: 'Codex (GPT-5.6)', send: '/api/codex-send', status: '/api/codex-status', bridge: './codex_bridge', fn: 'executeCodexPrompt' },
  agy: { label: 'Antigravity', send: '/api/agy-send', status: '/api/agy-status', bridge: './antigravity_bridge', fn: 'executeAgyPrompt' },
  grok: { label: 'Grok (grok-4.6)', send: '/api/grok-send', status: '/api/grok-status', bridge: './grok_bridge', fn: 'executeGrokPrompt' }
};

function request(method, urlPath, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = http.request(SERVER + urlPath + (urlPath.includes('?') ? '&' : '?') + 'pin=' + PIN, {
      method,
      headers: data ? { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(data) } : {}
    }, (res) => {
      let raw = '';
      res.on('data', c => raw += c);
      res.on('end', () => { try { resolve(JSON.parse(raw)); } catch (e) { reject(new Error('bad json: ' + raw.slice(0, 200))); } });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function serverAlive() {
  try { await request('GET', '/api/info'); return true; } catch (_) { return false; }
}

async function viaServer(w, prompt) {
  const before = await request('GET', w.status);
  const baseCount = (before.messages || []).length;
  const sent = await request('POST', w.send, { text: prompt });
  if (!sent || !sent.success) throw new Error('전송 실패: ' + JSON.stringify(sent));

  const started = Date.now();
  await sleep(1500);
  while (Date.now() - started < WAIT_MAX_MS) {
    const st = await request('GET', w.status);
    const msgs = st.messages || [];
    const newAi = msgs.slice(baseCount).filter(m => m.role === 'ai');
    if (!st.isWorking && newAi.length > 0) {
      return { success: true, reply: newAi[newAi.length - 1].text };
    }
    await sleep(POLL_MS);
  }
  throw new Error('응답 대기 시간 초과 (' + WAIT_MAX_MS / 60000 + '분)');
}

async function viaBridge(w, prompt) {
  const bridge = require(path.join(__dirname, w.bridge));
  const res = await bridge[w.fn](prompt);
  if (!res || !res.success) throw new Error(res && res.error ? res.error : '실행 실패');
  return { success: true, reply: res.reply };
}

async function delegateTask(targetWorker, prompt) {
  const key = String(targetWorker || '').toLowerCase().replace('antigravity', 'agy').replace('claude', '');
  const w = WORKERS[key];
  if (!w) throw new Error(`지원하지 않는 서브 워커입니다: ${targetWorker} (codex / agy / grok 지정 필요)`);
  const cleanPrompt = String(prompt || '').trim();
  if (!cleanPrompt) throw new Error('지시 내용이 비어 있습니다.');

  const useServer = await serverAlive();
  const res = useServer ? await viaServer(w, cleanPrompt) : await viaBridge(w, cleanPrompt);
  return { worker: key, label: w.label, via: useServer ? 'server' : 'bridge', reply: res.reply };
}

module.exports = { delegateTask };

if (require.main === module) {
  const [target, ...rest] = process.argv.slice(2);
  const prompt = rest.join(' ');
  if (!target || !prompt) {
    console.log('사용법: node _mobile_remote/delegate.js <codex|agy|grok|both|all> "<작업 지시 내용>"');
    process.exit(1);
  }
  const targets = target === 'both' ? ['codex', 'agy'] : (target === 'all' ? ['codex', 'agy', 'grok'] : [target]);
  Promise.all(targets.map(t => delegateTask(t, prompt).catch(e => ({ worker: t, error: e.message }))))
    .then(results => {
      for (const r of results) {
        console.log(`\n===== [${r.label || r.worker}] ${r.error ? '❌ 실패' : '✅ 완료'} (${r.via || '-'}) =====`);
        console.log(r.error ? r.error : r.reply);
      }
      process.exit(results.some(r => r.error) ? 2 : 0);
    });
}
