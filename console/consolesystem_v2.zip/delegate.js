/**
 * 메인 워커(Claude Code) -> 서브 워커(Codex / Antigravity / Grok) 작업 위임 엔진
 *
 * CLI: node _mobile_remote/delegate.js <codex|agy|grok> "지시 프롬프트"
 *      node _mobile_remote/delegate.js both "지시 프롬프트"   (Codex + Antigravity 동시 위임, 결과 비교)
 *      node _mobile_remote/delegate.js all "지시 프롬프트"    (세 워커 동시 위임)
 * 모듈: const { delegateTask } = require('./_mobile_remote/delegate');
 *      await delegateTask('codex', '지시 내용');
 *
 * 콘솔 서버(7890)가 떠 있으면 서버 API를 경유해 실행한다 → 폰의 Codex/Antigravity 탭에 진행·결과가 그대로 보인다.
 * 서버가 없으면 브릿지를 직접 호출한다.
 *
 * 2026-09-21: 실패 문구는 fail_msg.js 로 통일. all/both 는 헬스체크(healthcheck.js)에서 실패한 AI 를 자동 제외한다.
 */
const http = require('http');
const path = require('path');
const { classifyFailure } = require('./fail_msg');

const SERVER = 'http://127.0.0.1:' + (process.env.PORT || 7890);
let _cfg = {}; try { _cfg = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, 'console_config.json'), 'utf8').replace(/^\uFEFF/, '')); } catch (_) {}
const PIN = process.env.PIN || _cfg.pin || '0000';
const POLL_MS = 2000;
const WAIT_MAX_MS = 15 * 60 * 1000;

const WORKERS = {
  codex: { label: 'Codex (GPT-5.6)', send: '/api/codex-send', status: '/api/codex-status', bridge: './codex_bridge', fn: 'executeCodexPrompt' },
  agy: { label: 'Antigravity', send: '/api/agy-send', status: '/api/agy-status', bridge: './antigravity_bridge', fn: 'executeAgyPrompt' },
  grok: { label: 'Grok (grok-4.6)', send: '/api/grok-send', status: '/api/grok-status', bridge: './grok_bridge', fn: 'executeGrokPrompt' }
};

function request(method, urlPath, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = http.request(SERVER + urlPath + (urlPath.includes('?') ? '&' : '?') + 'pin=' + PIN, {
      method,
      headers: data ? { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(data) } : {}
    }, (res) => {
      let raw = '';
      res.on('data', c => raw += c);
      res.on('end', () => { try { resolve(JSON.parse(raw)); } catch (e) { reject(new Error('bad json: ' + raw.slice(0, 200))); } });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function serverAlive() {
  try { await request('GET', '/api/info'); return true; } catch (_) { return false; }
}

/** 헬스체크에서 실패로 표시된 AI 목록 (healthcheck.js 의 health_state.json). 파일이 없으면 아무도 제외하지 않는다 */
function unhealthyWorkers() {
  try {
    const { readHealth } = require('./healthcheck');
    const h = readHealth();
    return Object.keys(WORKERS).filter(k => h && h.results && h.results[k] && h.results[k].ok === false);
  } catch (_) { return []; }
}

async function viaServer(w, key, prompt) {
  const before = await request('GET', w.status);
  const baseCount = (before.messages || []).length;
  const sent = await request('POST', w.send, { text: prompt });
  if (!sent || !sent.success) throw new Error(w.label + '에게 지시를 보내지 못했습니다. 콘솔이 켜져 있는지 확인해 주세요.');

  const started = Date.now();
  await sleep(1500);
  while (Date.now() - started < WAIT_MAX_MS) {
    const st = await request('GET', w.status);
    const msgs = st.messages || [];
    const newAi = msgs.slice(baseCount).filter(m => m.role === 'ai');
    if (!st.isWorking && newAi.length > 0) {
      const last = newAi[newAi.length - 1];
      if (last.fail) { const e = new Error(last.fail.title + (last.fail.hint ? ' ' + last.fail.hint : '')); e.fail = last.fail; throw e; }
      return { success: true, reply: last.text };
    }
    await sleep(POLL_MS);
  }
  const f = classifyFailure({ ai: key, kind: 'timeout', minutes: WAIT_MAX_MS / 60000 });
  const e = new Error(f.title); e.fail = f; throw e;
}

async function viaBridge(w, key, prompt) {
  const bridge = require(path.join(__dirname, w.bridge));
  const res = await bridge[w.fn](prompt);
  if (!res || !res.success) {
    const f = res && res.fail ? res.fail : classifyFailure({ ai: key, kind: 'exit', stderr: res && res.error });
    const e = new Error(f.title + (f.hint ? ' ' + f.hint : '')); e.fail = f; throw e;
  }
  return { success: true, reply: res.reply };
}

async function delegateTask(targetWorker, prompt) {
  const key = String(targetWorker || '').toLowerCase().replace('antigravity', 'agy').replace('claude', '');
  const w = WORKERS[key];
  if (!w) throw new Error(`지원하지 않는 서브 워커입니다: ${targetWorker} (codex / agy / grok 지정 필요)`);
  const cleanPrompt = String(prompt || '').trim();
  if (!cleanPrompt) throw new Error('지시 내용이 비어 있습니다.');

  const useServer = await serverAlive();
  const res = useServer ? await viaServer(w, key, cleanPrompt) : await viaBridge(w, key, cleanPrompt);
  return { worker: key, label: w.label, via: useServer ? 'server' : 'bridge', reply: res.reply };
}

module.exports = { delegateTask, unhealthyWorkers };

if (require.main === module) {
  const [target0, ...rest] = process.argv.slice(2);
  // 'default' 또는 'auto' 는 폰 ⚙ 설정의 "동시에 시키기 기본 대상"(delegate_default: both|all)
  let target = target0; if (target === 'default' || target === 'auto') { try { target = require('./console_settings').get().delegate_default; } catch (_) { target = 'both'; } }
  const prompt = rest.join(' ');
  if (!target || !prompt) {
    console.log('사용법: node _mobile_remote/delegate.js <codex|agy|grok|both|all> "<작업 지시 내용>"');
    process.exit(1);
  }
  let targets = target === 'both' ? ['codex', 'agy'] : (target === 'all' ? ['codex', 'agy', 'grok'] : [target]);
  // all/both: 헬스체크 실패(업데이트 후 점검 중) AI 는 자동 제외
  if (target === 'both' || target === 'all') {
    const bad = unhealthyWorkers();
    const skipped = targets.filter(t => bad.includes(t));
    if (skipped.length) {
      console.log('건너뜀(점검 중): ' + skipped.map(t => WORKERS[t].label).join(', ') + ' — 업데이트 후 점검 중이라 Claude Code 가 대신 처리하세요.');
      targets = targets.filter(t => !bad.includes(t));
    }
    if (!targets.length) { console.log('보낼 수 있는 서브 워커가 없습니다. Claude Code 가 직접 처리하세요.'); process.exit(3); }
  }
  Promise.all(targets.map(t => delegateTask(t, prompt).catch(e => ({ worker: t, label: (WORKERS[t] || {}).label, error: e.message, fail: e.fail }))))
    .then(results => {
      for (const r of results) {
        console.log(`\n===== [${r.label || r.worker}] ${r.error ? '❌ 실패' : '✅ 완료'} (${r.via || '-'}) =====`);
        console.log(r.error ? r.error : r.reply);
        if (r.fail && r.fail.detail) console.log('\n[자세히]\n' + r.fail.detail);
      }
      process.exit(results.some(r => r.error) ? 2 : 0);
    });
}
