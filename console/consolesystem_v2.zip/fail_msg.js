/**
 * 실패 문구 공용 모듈 (2026-09-21) — AI 가 답을 못 냈을 때 폰에 보이는 말을 한 곳에서 만든다.
 *
 *  classifyFailure({ ai, kind, code, stderr, stdout, minutes, retried })
 *    → { ai, label, kind, category, title, cause, hint, actions:[{label, act}], detail, at }
 *
 *  - kind 'timeout' : "{AI}가 {N}분 안에 답하지 못했습니다. 다시 시키거나 Claude Code에게 맡기세요."
 *  - kind 'exit' / 'spawn' / 'parse' : "{AI}가 작업을 끝내지 못했습니다. (원인: …)"
 *      원인은 stderr/stdout 에서 판별: 로그인 만료 / 사용 한도 초과 / 명령 형식 변경(업데이트) / 설치 안 됨 / 인터넷 연결
 *      판별 불가 → "원인을 알 수 없습니다. 설정의 문제 신고를 눌러 주세요."
 *  - 원문(종료 코드·stderr)은 detail 에만 담는다. 본문(title/cause/hint)에는 코드·원문이 절대 들어가지 않는다.
 *
 *  toMessageText(f)  : 채팅 말풍선 본문(순수 텍스트) — 원문 없음
 *  toMessage(f)      : { role:'ai', text, fail } — 브릿지가 메시지 파일에 넣는 형태 (fail 은 폰이 카드/자세히 접기로 그림)
 *  noteFailure(f)    : 마지막 실패를 last_failure.json(콘솔 본체 폴더)에 기록 → /api/status.last_failure
 */
const fs = require('fs');
const path = require('path');

const LABEL = { claude: 'Claude Code', codex: 'Codex', agy: 'Antigravity', grok: 'Grok' };
const STATE_DIR = process.env.CONSOLE_HOME || __dirname;
const LAST_FILE = path.join(STATE_DIR, 'last_failure.json');

// 순서가 곧 우선순위 — 위에서 먼저 맞는 것을 쓴다
const CAUSES = [
  { category: 'login', re: /unauthorized|not logged in|not authenticated|please (log ?in|sign ?in)|login required|authentication (failed|required|error)|invalid[_ ]?(api[_ ]?key|token|credentials)|\b401\b|token (has )?expired|re-?authenticate|session expired|oauth/i,
    cause: '로그인 만료', hint: 'PC에서 그 AI에 다시 로그인하면 됩니다. (Claude Code에 "원맥스 진단해줘"라고 하면 어느 AI인지 찾아 줍니다)' },
  { category: 'quota', re: /rate ?limit|usage limit|quota|too many requests|\b429\b|no capacity|capacity available|resource_?exhausted|\b503\b|overloaded|limit exceeded|insufficient[_ ]quota|billing/i,
    cause: '사용 한도 초과', hint: '한도가 풀릴 때까지 기다리거나, 다른 AI 에게 맡기세요.' },
  { category: 'cli_changed', re: /unknown option|unrecognized (option|argument|subcommand)|unexpected argument|invalid (argument|value|option)|no such (option|command|subcommand)|unknown (command|argument)|found argument .* which wasn't expected|error: (the following|a value is required)/i,
    cause: '명령 형식 변경(업데이트)', hint: 'AI 프로그램이 업데이트되어 명령 형식이 바뀐 것 같습니다. Claude Code에 "원맥스 진단해줘"라고 시켜 주세요.' },
  { category: 'not_installed', re: /ENOENT|spawn( \S+)? EINVAL|is not recognized|command not found|not found|cannot find|no such file|could not (find|locate)|not installed/i,
    cause: '설치 안 됨', hint: 'AI 프로그램이 없거나 경로를 못 찾았습니다. 설치 점검(설치점검.bat)을 실행해 주세요.' },
  { category: 'network', re: /ECONNREFUSED|ECONNRESET|ETIMEDOUT|ENOTFOUND|EAI_AGAIN|EHOSTUNREACH|network|fetch failed|socket hang up|getaddrinfo|connection (refused|reset|closed)|unable to connect|dns/i,
    cause: '인터넷 연결', hint: 'PC 의 인터넷 연결을 확인하고 다시 시키세요.' }
];

function labelOf(ai) { return LABEL[String(ai || '').toLowerCase()] || String(ai || 'AI'); }

function detect(text) {
  const t = String(text || '');
  if (!t.trim()) return null;
  for (const c of CAUSES) if (c.re.test(t)) return c;
  return null;
}

/** 원문에서 비밀로 보이는 토큰을 가린다 (detail 에도 키·토큰은 남기지 않는다) */
function scrub(s) {
  return String(s || '')
    .replace(/(sk-[A-Za-z0-9_-]{8,}|ghp_[A-Za-z0-9]{10,}|xai-[A-Za-z0-9_-]{8,}|ya29\.[A-Za-z0-9._-]{10,}|Bearer\s+[A-Za-z0-9._-]{10,})/g, '***')
    .replace(/\x1b\[[0-9;]*[A-Za-z]/g, '');
}

function classifyFailure(o) {
  o = o || {};
  const ai = String(o.ai || '').toLowerCase();
  const label = labelOf(ai);
  const kind = o.kind || 'exit';
  const minutes = o.minutes || 10;
  // 원문: stderr → stdout → error 순, 이미 들어 있는 조각은 다시 붙이지 않는다
  const rawParts = [];
  for (const piece of [o.stderr, o.stdout, o.error]) { const t = String(piece || '').trim(); if (t && !rawParts.some(x => x.includes(t))) rawParts.push(t); }
  const raw = scrub(rawParts.join('\n')).trim();
  const f = { ai, label, kind, category: '', title: '', cause: '', hint: '', actions: [], detail: '', at: new Date().toISOString(), retried: !!o.retried };

  if (kind === 'timeout') {
    f.category = 'timeout';
    f.title = label + '가 ' + minutes + '분 안에 답하지 못했습니다. 다시 시키거나 Claude Code에게 맡기세요.';
    f.cause = '시간 초과';
    f.hint = '';
    f.actions = [{ label: '다시 시키기', act: 'retry' }, { label: 'Claude Code에게', act: 'to_claude' }];
  } else {
    const c = detect(raw);
    if (c) { f.category = c.category; f.cause = c.cause; f.hint = c.hint; }
    else if (kind === 'parse') { f.category = 'parse'; f.cause = '답변 형식이 달라짐'; f.hint = 'AI 가 낸 답을 읽지 못했습니다. AI 프로그램이 업데이트됐을 수 있으니 Claude Code에 "원맥스 진단해줘"라고 시켜 주세요.'; }
    else { f.category = 'unknown'; f.cause = '알 수 없음'; f.hint = '원인을 알 수 없습니다. 설정의 문제 신고를 눌러 주세요.'; }
    f.title = label + '가 작업을 끝내지 못했습니다. (원인: ' + f.cause + ')';
    f.actions = [{ label: '다시 시키기', act: 'retry' }, { label: 'Claude Code에게', act: 'to_claude' }];
  }
  // 원문은 "자세히" 안에만
  const parts = [];
  if (o.code !== undefined && o.code !== null) parts.push('종료 코드: ' + o.code);
  if (kind === 'timeout') parts.push('제한 시간: ' + minutes + '분');
  if (o.retried) parts.push('자동 재시도 1회 후에도 실패');
  if (raw) parts.push(raw.slice(0, 1500));
  f.detail = parts.join('\n');
  return f;
}

/** 폰 말풍선 본문 — 원문·코드 없음 */
function toMessageText(f) {
  const lines = [f.title];
  if (f.hint) lines.push(f.hint);
  if (f.retried) lines.push('(한 번 더 자동으로 시켜 봤지만 같은 결과였습니다)');
  return lines.join('\n');
}

/** 브릿지가 메시지 파일에 넣는 형태. fail 필드는 폰이 카드(액션 칩 + 자세히 접기)로 그린다 */
function toMessage(f, extra) {
  return Object.assign({
    id: Date.now(),
    role: 'ai',
    text: toMessageText(f),
    fail: { ai: f.ai, label: f.label, kind: f.kind, category: f.category, title: f.title, cause: f.cause, hint: f.hint, actions: f.actions, detail: f.detail, at: f.at, retried: f.retried },
    time: new Date().toLocaleTimeString('ko-KR')
  }, extra || {});
}

function noteFailure(f, project) {
  try {
    let cur = {};
    try { cur = JSON.parse(fs.readFileSync(LAST_FILE, 'utf8')); } catch (_) {}
    cur.last = { ai: f.ai, label: f.label, kind: f.kind, category: f.category, cause: f.cause, title: f.title, at: f.at, project: project || process.env.PROJECT_NAME || '' };
    cur.byAi = cur.byAi || {};
    cur.byAi[f.ai] = cur.last;
    fs.writeFileSync(LAST_FILE, JSON.stringify(cur, null, 2), 'utf8');
  } catch (_) {}
}

function readLastFailure() {
  try { return JSON.parse(fs.readFileSync(LAST_FILE, 'utf8')); } catch (_) { return { last: null, byAi: {} }; }
}

/** 한 줄짜리 실패 메시지가 필요한 곳(delegate.js 예외 문구, server.js 에이전트 종료 등) */
function oneLine(o) { const f = classifyFailure(o); return f.title + (f.hint ? ' ' + f.hint : ''); }

module.exports = { classifyFailure, toMessageText, toMessage, noteFailure, readLastFailure, oneLine, labelOf, detect, LABEL, LAST_FILE };
