/**
 * Grok Daemon Bridge (서브 워커 3) — 순수 백그라운드 데몬
 *
 * Codex·Antigravity 와 동일 구조. 지시가 올 때만 `grok -p` 를 띄우고,
 * 그 대화를 grok_messages.json 에 쌓아 모바일 콘솔이 그대로 읽는다.
 *
 * 연속성: 최초 --session-id <UUID> 로 세션을 만들고,
 *         이후 --resume <UUID> 로 같은 대화를 이어간다.
 *
 * 2026-09-21: 명령줄 조립·출력 해석은 adapters/grok.js, 실행·1회 자동 재시도·실패 문구는 bridge_retry.js + fail_msg.js 로 통일.
 */
const fs = require('fs');
const path = require('path');
const adapter = require('./adapters/grok');
const { runCli, runWithRetry, killTree } = require('./bridge_retry');
const { toMessage } = require('./fail_msg');
const { isSafe } = require('./perm');   // 권한 모드(safe 기본) — 2026-09-21
const { audit } = require('./audit');   // 감사 로그

const MESSAGES_FILE = path.join(__dirname, 'grok_messages.json');
const SESSION_FILE = path.join(__dirname, 'grok_session_id.txt');
const WORK_DIR = path.resolve(__dirname, '..');
const settings = require('./console_settings'); // 폰 ⚙ 설정: 모델·제한 시간·재시도 (매 지시마다 읽음)
const TIMEOUT_MS_DEFAULT = 20 * 60 * 1000; // PO 승인(2026-09-21 09:30): 데몬 워커 20분 — 설정에서 늘리기만 가능
function timeoutMs() { try { return settings.timeoutMsFor('grok'); } catch (_) { return TIMEOUT_MS_DEFAULT; } }
function grokModel() { try { return settings.modelFor('grok'); } catch (_) { try { return (JSON.parse(process.env.CONSOLE_WORKERS || '{}').grok || {}).model || 'grok-4.6'; } catch (_) { return 'grok-4.6'; } } }

let isBusy = false;
let currentTask = '';
let retrying = '';
let killedAt = 0;
const activeChildren = new Set();

function readJson(file, fallback) {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {}
  return fallback;
}

function writeJson(file, data) {
  try {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmp, file);
  } catch (_) {
    try { fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8'); } catch (_) {}
  }
}

function getMessages() {
  const list = readJson(MESSAGES_FILE, []);
  return Array.isArray(list) ? list : [];
}

function appendMessage(role, text, extra) {
  const list = getMessages();
  list.push(Object.assign({
    id: Date.now() + Math.floor(Math.random() * 1000),
    role: role,
    text: text,
    time: new Date().toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul' })
  }, extra || {}));
  writeJson(MESSAGES_FILE, list.slice(-100));
}

// ── 대화 연속성 ─────────────────────────────────────────
function getSessionId() {
  try {
    if (fs.existsSync(SESSION_FILE)) {
      const v = fs.readFileSync(SESSION_FILE, 'utf8').trim();
      if (/^[0-9a-f-]{36}$/i.test(v)) return { id: v, existing: true };
    }
  } catch (_) {}
  const uuid = require('crypto').randomUUID();
  try { fs.writeFileSync(SESSION_FILE, uuid, 'utf8'); } catch (_) {}
  return { id: uuid, existing: false };
}

function resetSession() {
  try { if (fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE); } catch (_) {}
  try { writeJson(MESSAGES_FILE, []); } catch (_) {}
  return true;
}

function getStatus() {
  return {
    success: true,
    isWorking: isBusy,
    currentTask: currentTask,
    retrying: retrying,
    sessionId: (function () { try { return fs.readFileSync(SESSION_FILE, 'utf8').trim(); } catch (_) { return ''; } })(),
    count: getMessages().length,
    messages: getMessages()
  };
}

function killCurrentProcess() {
  killedAt = Date.now();
  activeChildren.forEach(killTree);
  activeChildren.clear();
  isBusy = false;
  currentTask = '';
  retrying = '';
  appendMessage('ai', '🛑 [긴급 정지] 실행 중이던 작업이 강제 종료되었습니다.');
  return true;
}

/** 1회 실행 */
async function runOnce(prompt) {
  const startedAt = Date.now();
  const sess = getSessionId();
  const spec = adapter.buildArgs(prompt, { model: grokModel(), sessionId: sess.id, resume: sess.existing, cwd: WORK_DIR, safe: isSafe() });
  const r = await runCli(spec, { timeoutMs: timeoutMs(), register: c => activeChildren.add(c), unregister: c => activeChildren.delete(c) });
  if (killedAt >= startedAt) return { ok: false, kind: 'killed' };
  if (r.spawnError) return { ok: false, kind: 'spawn', code: r.code, stderr: r.spawnError, stdout: '' };
  if (r.timedOut) return { ok: false, kind: 'timeout', code: null, stderr: r.stderr, stdout: r.stdout };
  const p = adapter.parseOutput(r.stdout, r.stderr, r.code);
  if (p.ok) return { ok: true, reply: p.reply, code: r.code, format: p.format };
  return { ok: false, kind: 'exit', code: r.code, stderr: r.stderr, stdout: r.stdout, error: p.error };
}

async function executeGrokPrompt(prompt) {
  const cleanPrompt = (prompt || '').trim();
  if (!cleanPrompt) return { success: false, error: 'Empty prompt' };

  appendMessage('user', cleanPrompt);
  audit('instruction', { ai: 'grok', mode: isSafe() ? 'safe' : 'full', prompt: cleanPrompt });
  isBusy = true;
  currentTask = cleanPrompt;
  retrying = '';

  const res = await runWithRetry({
    ai: 'grok',
    minutes: timeoutMs() / 60000,
    maxRetry: settings.maxRetryFor(),
    attempt: () => runOnce(cleanPrompt),
    onRetry: (s) => { retrying = s; }
  });

  retrying = '';
  isBusy = activeChildren.size > 0;
  if (!isBusy) currentTask = '';

  if (res.ok) { appendMessage('ai', res.reply); return { success: true, reply: res.reply, code: res.last && res.last.code }; }
  if (res.killed) return { success: false, error: '긴급 정지로 중단됨' };
  const m = toMessage(res.fail);
  appendMessage('ai', m.text, { fail: m.fail });
  return { success: false, error: res.fail.title, fail: res.fail };
}

module.exports = {
  getStatus,
  getMessages,
  resetSession,
  executeGrokPrompt,
  killCurrentProcess
};
