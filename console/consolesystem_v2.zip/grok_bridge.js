/**
 * Grok Daemon Bridge (서브 워커 3) — 순수 백그라운드 데몬
 *
 * Codex·Antigravity 와 동일 구조. 지시가 올 때만 `grok -p` 를 띄우고,
 * 그 대화를 grok_messages.json 에 쌓아 모바일 콘솔이 그대로 읽는다.
 *
 * 연속성: 최초 --session-id <UUID> 로 세션을 만들고,
 *         이후 --resume <UUID> 로 같은 대화를 이어간다.
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const MESSAGES_FILE = path.join(__dirname, 'grok_messages.json');
const SESSION_FILE = path.join(__dirname, 'grok_session_id.txt');
const WORK_DIR = path.resolve(__dirname, '..');
const MODEL = (() => { try { return (JSON.parse(process.env.CONSOLE_WORKERS || '{}').grok || {}).model || 'grok-4.6'; } catch (_) { return 'grok-4.6'; } })();

let isBusy = false;
let currentTask = '';
const activeChildren = new Set();

function readJson(file, fallback) {
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {}
  return fallback;
}

function writeJson(file, data) {
  try {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmp, file);
  } catch (_) {
    try { fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8'); } catch (_) {}
  }
}

function getMessages() {
  const list = readJson(MESSAGES_FILE, []);
  return Array.isArray(list) ? list : [];
}

function appendMessage(role, text) {
  const list = getMessages();
  list.push({
    id: Date.now() + Math.floor(Math.random() * 1000),
    role: role,
    text: text,
    time: new Date().toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul' })
  });
  writeJson(MESSAGES_FILE, list.slice(-100));
}

// ── 대화 연속성 ─────────────────────────────────────────
function getSessionId() {
  try {
    if (fs.existsSync(SESSION_FILE)) {
      const v = fs.readFileSync(SESSION_FILE, 'utf8').trim();
      if (/^[0-9a-f-]{36}$/i.test(v)) return { id: v, existing: true };
    }
  } catch (_) {}
  const uuid = require('crypto').randomUUID();
  try { fs.writeFileSync(SESSION_FILE, uuid, 'utf8'); } catch (_) {}
  return { id: uuid, existing: false };
}

function resetSession() {
  try { if (fs.existsSync(SESSION_FILE)) fs.unlinkSync(SESSION_FILE); } catch (_) {}
  try { writeJson(MESSAGES_FILE, []); } catch (_) {}
  return true;
}

function getStatus() {
  return {
    success: true,
    isWorking: isBusy,
    currentTask: currentTask,
    sessionId: (function () { try { return fs.readFileSync(SESSION_FILE, 'utf8').trim(); } catch (_) { return ''; } })(),
    count: getMessages().length,
    messages: getMessages()
  };
}

function killCurrentProcess() {
  activeChildren.forEach(child => {
    try {
      if (child && child.pid) {
        if (process.platform === 'win32') {
          require('child_process').execSync(`taskkill /pid ${child.pid} /T /F 2>nul || exit 0`, { shell: true });
        } else {
          child.kill('SIGKILL');
        }
      }
    } catch (_) {}
  });
  activeChildren.clear();
  isBusy = false;
  currentTask = '';
  appendMessage('ai', '🛑 [긴급 정지] 실행 중이던 작업이 강제 종료되었습니다.');
  return true;
}

function executeGrokPrompt(prompt) {
  return new Promise((resolve) => {
    const cleanPrompt = (prompt || '').trim();
    if (!cleanPrompt) return resolve({ success: false, error: 'Empty prompt' });

    appendMessage('user', cleanPrompt);
    isBusy = true;
    currentTask = cleanPrompt;

    const sess = getSessionId();
    const sessionArgs = sess.existing ? ['--resume', sess.id] : ['--session-id', sess.id];

    // ⚠️ 두 가지 함정을 동시에 피해야 한다.
    //   1) shell:true 를 쓰면 공백 있는 프롬프트가 여러 인자로 쪼개진다
    //      ("unexpected argument '암호는' found")
    //   2) Windows 에서 .cmd 를 shell 없이 spawn 하면 EINVAL 이 난다
    //   → npm 전역 설치의 실제 진입점(node 트램폴린 스크립트)을 node 로 직접 실행한다
    const grokEntry = path.join(process.env.APPDATA || '', 'npm', 'node_modules',
                                '@xai-official', 'grok', 'bin', 'grok');
    const useEntry = fs.existsSync(grokEntry);
    const cmd = useEntry ? process.execPath : (process.platform === 'win32' ? 'grok.cmd' : 'grok');
    const pre = useEntry ? [grokEntry] : [];
    const child = spawn(cmd, [
      ...pre,
      '-p', cleanPrompt,
      '-m', MODEL,
      ...sessionArgs,
      '--always-approve',
      '--cwd', WORK_DIR
    ], {
      cwd: WORK_DIR,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe']
    });

    activeChildren.add(child);

    const timer = setTimeout(() => {
      if (activeChildren.has(child)) {
        try {
          if (process.platform === 'win32') {
            require('child_process').execSync(`taskkill /pid ${child.pid} /T /F 2>nul || exit 0`, { shell: true });
          } else {
            child.kill('SIGKILL');
          }
        } catch (_) {}
        activeChildren.delete(child);
        isBusy = activeChildren.size > 0;
        if (!isBusy) currentTask = '';
        appendMessage('ai', '⏱️ [작업 제한 시간 초과] 15분 안에 끝나지 않아 종료했습니다.');
        resolve({ success: false, error: 'Timeout 15m' });
      }
    }, 900000);

    let out = '';
    let errOut = '';
    child.stdout.on('data', d => { out += d.toString(); });
    child.stderr.on('data', d => { errOut += d.toString(); });

    child.on('close', (code) => {
      clearTimeout(timer);
      activeChildren.delete(child);
      isBusy = activeChildren.size > 0;
      if (!isBusy) currentTask = '';

      // ANSI 색상코드 제거
      let reply = (out.trim() || errOut.trim()).replace(/\x1b\[[0-9;]*m/g, '').trim();
      if (!reply) reply = (code === 0 ? '작업이 완료되었습니다.' : `오류 발생 (코드 ${code})`);
      appendMessage('ai', reply);
      resolve({ success: true, reply, code });
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      activeChildren.delete(child);
      isBusy = activeChildren.size > 0;
      if (!isBusy) currentTask = '';
      appendMessage('ai', `❌ [실행 실패] ${err.message}`);
      resolve({ success: false, error: err.message });
    });
  });
}

module.exports = {
  getStatus,
  getMessages,
  resetSession,
  executeGrokPrompt,
  killCurrentProcess
};
