/**
 * 기동 헬스체크 (2026-09-21)
 *  - 각 AI CLI 에 무해한 1줄 지시("답으로 OK만 출력")를 보내 실제로 답이 오는지·출력 형식(JSON/텍스트)이 어댑터로 읽히는지 확인한다.
 *  - start_all.js 가 기동 20초 뒤(비동기 — 기동을 막지 않음)와 6시간마다 부른다. 결과는 health_state.json(콘솔 본체 폴더).
 *  - 실패한 AI 는 폰 탭에 "업데이트 후 점검 중 — Claude Code에게 맡기세요" 로 표시되고, delegate.js all/both 에서 자동 제외된다.
 *  - 작업 폴더는 임시 폴더(프로젝트 transcript 를 더럽히지 않음). 비밀은 기록하지 않는다.
 *  CLI: node healthcheck.js [codex,agy,...]
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const adapters = require('./adapters');
const { runCli } = require('./bridge_retry');
const { classifyFailure, LABEL } = require('./fail_msg');

const STATE_DIR = process.env.CONSOLE_HOME || __dirname;
const STATE_FILE = path.join(STATE_DIR, 'health_state.json');
const PROBE = '답으로 OK만 출력';
const TIMEOUT_MS = 3 * 60 * 1000;
const INTERVAL_MS = 6 * 60 * 60 * 1000;

function probeDir() {
  const d = path.join(os.tmpdir(), 'onemacs_health');
  try { fs.mkdirSync(d, { recursive: true }); } catch (_) {}
  return d;
}

/** console_config.json workers 에서 꺼진 AI 는 건너뛴다 (claude 는 항상) */
function enabledAis() {
  let w = {};
  try { w = JSON.parse(process.env.CONSOLE_WORKERS || 'null') || {}; } catch (_) {}
  if (!Object.keys(w).length) { try { w = (JSON.parse(fs.readFileSync(path.join(__dirname, 'console_config.json'), 'utf8').replace(/^﻿/, '')).workers) || {}; } catch (_) {} }
  return adapters.names.filter(k => k === 'claude' || !(w[k] && w[k].enabled === false));
}

function buildProbe(ai, cwd) {
  const ad = adapters.get(ai);
  const opts = { cwd };
  if (ai === 'claude') opts.json = true;
  if (ai === 'agy') { opts.printTimeout = '2m'; opts.model = process.env.AGY_MODEL || undefined; }
  return ad.buildArgs(PROBE, opts);
}

async function checkOne(ai) {
  const ad = adapters.get(ai);
  const t0 = Date.now();
  const res = { ai, label: LABEL[ai] || ai, ok: false, format: '', ms: 0, cause: '', message: '', checkedAt: new Date().toISOString() };
  try {
    const spec = buildProbe(ai, probeDir());
    const r = await runCli(spec, { timeoutMs: TIMEOUT_MS });
    res.ms = Date.now() - t0;
    if (r.spawnError) { const f = classifyFailure({ ai, kind: 'spawn', stderr: r.spawnError }); res.cause = f.cause; res.message = f.title; return res; }
    if (r.timedOut) { const f = classifyFailure({ ai, kind: 'timeout', minutes: TIMEOUT_MS / 60000 }); res.cause = f.cause; res.message = f.title; return res; }
    const p = ad.parseOutput(r.stdout, r.stderr, r.code, {});
    res.format = p.format || '';
    if (p.ok && /\bOK\b/i.test(p.reply || '')) { res.ok = true; return res; }
    if (p.ok) { res.ok = true; res.message = '답은 왔지만 내용이 예상과 다릅니다: ' + String(p.reply || '').slice(0, 60); return res; }
    const f = classifyFailure({ ai, kind: r.code === 0 ? 'parse' : 'exit', code: r.code, stderr: r.stderr, stdout: r.stdout, error: p.error });
    res.cause = f.cause; res.message = f.title;
    return res;
  } catch (e) {
    res.ms = Date.now() - t0; res.cause = '알 수 없음'; res.message = (LABEL[ai] || ai) + ' 점검 중 오류: ' + String(e.message || e).slice(0, 100);
    return res;
  }
}

let running = null;
async function runHealthcheck(ais) {
  if (running) return running;
  running = (async () => {
    const list = (ais && ais.length ? ais : enabledAis());
    const results = {};
    const prev = readHealth();
    const arr = await Promise.all(list.map(a => checkOne(a)));
    for (const r of arr) results[r.ai] = r;
    // 이번에 점검 안 한 AI(꺼진 것)는 이전 결과를 유지하지 않고 지운다 → 폰에 낡은 상태가 안 남게
    const state = { at: new Date().toISOString(), results, failing: Object.keys(results).filter(k => !results[k].ok), previousAt: prev.at || null };
    try { fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8'); } catch (_) {}
    return state;
  })().finally(() => { running = null; });
  return running;
}

function readHealth() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch (_) { return { at: null, results: {}, failing: [] }; }
}

/** start_all 에서 호출: 기동 뒤 delayMs 에 1회, 이후 6시간마다. log(msg) 로 결과 한 줄씩 남긴다 */
function schedule(log, delayMs) {
  const run = () => runHealthcheck().then((s) => {
    for (const k of Object.keys(s.results)) { const r = s.results[k]; (log || console.log)('헬스체크 ' + r.label + ': ' + (r.ok ? '정상 (' + (r.format || '-') + ', ' + r.ms + 'ms)' : '실패 — ' + (r.message || r.cause))); }
  }).catch(e => (log || console.log)('헬스체크 오류: ' + e.message));
  const t = setTimeout(run, delayMs == null ? 20000 : delayMs);
  const iv = setInterval(run, INTERVAL_MS);
  if (t.unref) t.unref(); if (iv.unref) iv.unref();
  return { timer: t, interval: iv };
}

module.exports = { runHealthcheck, readHealth, schedule, enabledAis, checkOne, STATE_FILE, PROBE, INTERVAL_MS };

if (require.main === module) {
  const ais = process.argv[2] ? process.argv[2].split(',').map(s => s.trim()).filter(Boolean) : null;
  runHealthcheck(ais).then((s) => {
    for (const k of Object.keys(s.results)) { const r = s.results[k]; console.log((r.label + ' ').padEnd(14) + (r.ok ? 'OK ' : 'FAIL ') + (r.format || '-').padEnd(5) + ' ' + r.ms + 'ms' + (r.message ? '  ' + r.message : '')); }
    process.exit(s.failing.length ? 2 : 0);
  });
}
