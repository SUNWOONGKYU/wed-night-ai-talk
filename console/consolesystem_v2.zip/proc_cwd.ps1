# claude.exe 프로세스별 현재 작업 폴더(cwd)를 PEB에서 읽어 "PID|생성시각|cwd|명령줄" 로 출력
# (WMI는 cwd를 주지 않으므로 NtQueryInformationProcess → PEB → RTL_USER_PROCESS_PARAMETERS.CurrentDirectory 를 직접 읽는다)
$ErrorActionPreference = 'SilentlyContinue'
Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class PebCwd {
  [DllImport("ntdll.dll")] static extern int NtQueryInformationProcess(IntPtr h, int cls, ref PBI info, int len, out int ret);
  [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
  [DllImport("kernel32.dll", SetLastError=true)] static extern bool ReadProcessMemory(IntPtr h, IntPtr addr, byte[] buf, int size, out IntPtr read);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
  [StructLayout(LayoutKind.Sequential)] public struct PBI { public IntPtr r1; public IntPtr PebBaseAddress; public IntPtr r2; public IntPtr r3; public IntPtr pid; public IntPtr r4; }
  static long ReadPtr(IntPtr h, IntPtr addr) { byte[] b = new byte[8]; IntPtr n; if (!ReadProcessMemory(h, addr, b, 8, out n)) return 0; return BitConverter.ToInt64(b, 0); }
  public static string Get(int pid) {
    IntPtr h = OpenProcess(0x0010 | 0x0400, false, pid); // VM_READ | QUERY_INFORMATION
    if (h == IntPtr.Zero) return "";
    try {
      PBI pbi = new PBI(); int ret;
      if (NtQueryInformationProcess(h, 0, ref pbi, Marshal.SizeOf(pbi), out ret) != 0) return "";
      long paramsAddr = ReadPtr(h, (IntPtr)(pbi.PebBaseAddress.ToInt64() + 0x20)); // PEB.ProcessParameters (x64)
      if (paramsAddr == 0) return "";
      // RTL_USER_PROCESS_PARAMETERS.CurrentDirectory.DosPath (UNICODE_STRING) at offset 0x38 (x64)
      byte[] us = new byte[16]; IntPtr n;
      if (!ReadProcessMemory(h, (IntPtr)(paramsAddr + 0x38), us, 16, out n)) return "";
      ushort len = BitConverter.ToUInt16(us, 0); long bufAddr = BitConverter.ToInt64(us, 8);
      if (len == 0 || bufAddr == 0) return "";
      byte[] s = new byte[len];
      if (!ReadProcessMemory(h, (IntPtr)bufAddr, s, len, out n)) return "";
      return Encoding.Unicode.GetString(s).TrimEnd('\\');
    } catch { return ""; } finally { CloseHandle(h); }
  }
}
"@
Get-CimInstance Win32_Process -Filter "Name='claude.exe'" | ForEach-Object {
  $cwd = [PebCwd]::Get([int]$_.ProcessId)
  "$($_.ProcessId)|$($_.CreationDate.ToString('yyyy-MM-dd HH:mm:ss'))|$cwd|$($_.CommandLine)"
}
