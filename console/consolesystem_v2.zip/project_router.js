/**
 * 프로젝트 라우터 — PC 한 대에서 프로젝트(폴더) 여러 개를 콘솔 하나(포트 하나)로 서비스
 *
 *  - console_config.json 의 projects: [{ name, dir }] 마다 그 폴더의 _mobile_remote/server.js 를 자식 프로세스로 띄운다 (포트 자동 배정)
 *  - 폰은 라우터(7890) 하나만 본다. 쿠키 cproj=<프로젝트명> 로 어느 자식에게 넘길지 정한다 (기본 = 첫 프로젝트)
 *  - 라우터가 직접 처리: /api/login(모든 자식이 같은 PIN 을 쓰므로 m_sid=PIN 쿠키 발급) · /api/projects · /api/project-select · /api/project-add
 *  - 나머지 요청은 현재 프로젝트 자식에게 그대로 프록시
 *  - 프로젝트 추가: 폴더 생성 → 이 폴더의 코드 파일 복사(상태 파일 제외) → 자식 기동 → config 저장
 *
 * 단독 실행: node project_router.js   (start_all.js 는 config 에 projects 가 있으면 server.js 대신 이 파일을 로드)
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');

const CFG_FILE = path.join(__dirname, 'console_config.json');
function readCfg() { try { return JSON.parse(fs.readFileSync(CFG_FILE, 'utf8').replace(/^﻿/, '')); } catch (_) { return {}; } }
function writeCfg(c) { fs.writeFileSync(CFG_FILE, JSON.stringify(c, null, 2), 'utf8'); }

const cfg = readCfg();
const PORT = Number(process.env.PORT || cfg.port || 7890);
const PIN = String(process.env.PIN || cfg.pin || '0000');
const BASE_DIR = path.resolve(__dirname, '..');
const CODE_FILES = ['server.js', 'main_worker_bridge.js', 'claude_daemon_bridge.js', 'daemon_ask.js', 'console_inject.ps1', 'proc_cwd.ps1', 'codex_bridge.js', 'antigravity_bridge.js', 'grok_bridge.js', 'delegate.js', 'quota.js', 'package.json'];
const COOKIE = 'cproj';
const loginFails = new Map(); // ip -> { n, until }

function log(m) { console.log('[router ' + new Date().toLocaleTimeString('ko-KR') + '] ' + m); }
function cleanEnv(extra) {
  const env = { ...process.env };
  for (const k of Object.keys(env)) if (/^CLAUDE/.test(k)) delete env[k];
  return Object.assign(env, extra);
}

// ---------- 프로젝트 목록 ----------
let projects = Array.isArray(cfg.projects) && cfg.projects.length ? cfg.projects.map(p => ({ name: String(p.name), dir: path.resolve(String(p.dir)) })) : [{ name: path.basename(BASE_DIR), dir: BASE_DIR }];
const children = new Map(); // name -> { port, proc, restarts }

function nextPort() {
  const used = new Set([PORT, ...[...children.values()].map(c => c.port)]);
  let p = PORT + 1; while (used.has(p)) p++; return p;
}

function syncCode(dir) {
  const target = path.join(dir, '_mobile_remote');
  fs.mkdirSync(target, { recursive: true });
  if (path.resolve(target) === path.resolve(__dirname)) return target;
  for (const f of CODE_FILES) { const src = path.join(__dirname, f); if (fs.existsSync(src)) fs.copyFileSync(src, path.join(target, f)); }
  const cfgPath = path.join(target, 'console_config.json');
  if (!fs.existsSync(cfgPath)) fs.writeFileSync(cfgPath, JSON.stringify({ pin: PIN }, null, 2), 'utf8');
  return target;
}

async function adoptIfRunning(p, port) {
  // 라우터만 재시작된 경우: 같은 폴더를 서비스 중인 자식이 이미 그 포트에 살아 있으면 새로 띄우지 않고 이어 쓴다
  const info = await probe(port, '/api/info?pin=' + encodeURIComponent(PIN), 1500);
  if (info && info.body && info.body.workDir && path.resolve(info.body.workDir) === path.resolve(p.dir)) {
    children.set(p.name, { port, proc: null, restarts: 0, dir: p.dir });
    log('프로젝트 "' + p.name + '" → 포트 ' + port + ' (기존 프로세스 인계)');
    return true;
  }
  return false;
}

function startChild(p) {
  const target = syncCode(p.dir);
  const port = (children.get(p.name) && children.get(p.name).port) || nextPort();
  // 1번 프로젝트(projects[0])만 대화형 PC 창(primary), 2번째 이후는 창 없는 데몬(daemon) — PC1 19:05 지시 (2026-09-20)
  const role = projects[0] && projects[0].name === p.name ? 'primary' : 'daemon';
  const proc = spawn(process.execPath, ['server.js'], { cwd: target, env: cleanEnv({ PORT: String(port), PIN, PROJECT_NAME: p.name, PROJECT_ROLE: role, CONSOLE_HOME: __dirname }), stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  const rec = { port, proc, restarts: (children.get(p.name) || {}).restarts || 0, dir: p.dir, startedAt: Date.now() };
  children.set(p.name, rec);
  proc.stdout.on('data', d => { const t = String(d).trim(); if (t) log('[' + p.name + ':' + port + '] ' + t.split('\n')[0].slice(0, 160)); });
  proc.stderr.on('data', d => log('[' + p.name + ':' + port + ' ERR] ' + String(d).trim().slice(0, 300)));
  proc.on('exit', (code) => {
    log('[' + p.name + '] 종료 code=' + code);
    // 60초 이상 살았던 자식은 정상 종료(수동 재시작 등)로 보고 재시작 횟수를 초기화 — 반복 크래시만 5회에서 멈춘다
    if (Date.now() - rec.startedAt > 60 * 1000) rec.restarts = 0;
    if (children.get(p.name) === rec && rec.restarts < 5) { rec.restarts++; setTimeout(() => { if (projects.find(x => x.name === p.name)) startChild(p); }, 3000); }
    else if (children.get(p.name) === rec) log('[' + p.name + '] 반복 크래시 → 재시작 중단');
  });
  log('프로젝트 "' + p.name + '" → 포트 ' + port + ' (' + p.dir + ') [' + role + ']');
  return rec;
}

(async () => {
  for (const p of projects) {
    const port = nextPort();
    children.set(p.name, { port, proc: null, restarts: 0, dir: p.dir }); // 포트 선점
    if (!(await adoptIfRunning(p, port))) startChild(p);
  }
})();

// ---------- 유틸 ----------
function getCookie(req, name) {
  const m = (req.headers.cookie || '').match(new RegExp('(?:^|;\\s*)' + name + '=([^;]*)'));
  return m ? decodeURIComponent(m[1]) : '';
}
function isHttps(req) { return (req.headers['x-forwarded-proto'] || '').includes('https') || /trycloudflare\.com$/i.test(req.headers.host || ''); }
function cookieHeader(req, name, value) { return `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=2592000; ` + (isHttps(req) ? 'SameSite=None; Secure' : 'SameSite=Lax'); }
function json(res, code, obj, extraHeaders) { res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, extraHeaders || {})); res.end(JSON.stringify(obj)); }
function authed(req, url) {
  const q = url.searchParams.get('pin') || url.searchParams.get('token') || '';
  const c = getCookie(req, 'm_sid');
  const a = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '').trim();
  return [q, c, a].includes(PIN);
}
// /proj/<프로젝트명>/… 경로로 들어온 요청은 그 프로젝트로 (PC2 22:25: 폰 iframe 은 쿠키가 막혀 경로에 프로젝트를 싣는다)
function projectFromPath(pathname) {
  const m = /^\/proj\/([^\/]+)(\/.*)?$/.exec(pathname || '');
  if (!m) return null;
  let name = m[1]; try { name = decodeURIComponent(name); } catch (_) {}
  const p = projects.find(x => x.name === name);
  return p ? { project: p, rest: m[2] || '/' } : null;
}

function currentProject(req, url) {
  // 허브 iframe 안에서는 서드파티 쿠키가 차단될 수 있으므로: 쿼리 ?project= → 헤더 X-Console-Project → 쿠키 → 기본
  let want = '';
  const byPath = projectFromPath((url || new URL(req.url, 'http://x')).pathname);
  if (byPath) return byPath.project; // 경로 지정이 최우선
  try { want = (url || new URL(req.url, 'http://x')).searchParams.get('project') || ''; } catch (_) {}
  if (!want && req.headers['x-console-project']) { try { want = decodeURIComponent(req.headers['x-console-project']); } catch (_) { want = req.headers['x-console-project']; } }
  if (!want) want = getCookie(req, COOKIE);
  return projects.find(p => p.name === want) || projects[0];
}
function readBody(req) { return new Promise((resolve) => { let b = ''; req.on('data', d => b += d); req.on('end', () => resolve(b)); }); }
function probe(port, pathname, timeoutMs) {
  return new Promise((resolve) => {
    const r = http.request({ host: '127.0.0.1', port, path: pathname, method: 'GET', timeout: timeoutMs || 2500 }, (res) => { let b = ''; res.on('data', d => b += d); res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(b) }); } catch (_) { resolve({ status: res.statusCode, body: null }); } }); });
    r.on('timeout', () => { r.destroy(); resolve(null); }); r.on('error', () => resolve(null)); r.end();
  });
}

// ---------- HTTP ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const pathname = url.pathname;

  // 로그인: 라우터가 처리 → 모든 자식이 받아들이는 m_sid=PIN 쿠키. IP당 5회 실패 시 10분 잠금(무차별 대입 방지)
  if (pathname === '/api/login' && req.method === 'POST') {
    const ip = (req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
    const f = loginFails.get(ip) || { n: 0, until: 0 };
    if (f.until > Date.now()) return json(res, 429, { success: false, error: '로그인 잠금 중 (' + Math.ceil((f.until - Date.now()) / 60000) + '분 후 재시도)' });
    let pin = ''; try { pin = String(JSON.parse(await readBody(req)).pin || ''); } catch (_) {}
    if (pin !== PIN) {
      f.n++; if (f.n >= 5) { f.until = Date.now() + 10 * 60 * 1000; f.n = 0; log('⛔ 로그인 5회 실패 → 10분 잠금: ' + ip); }
      loginFails.set(ip, f);
      return json(res, 401, { success: false, error: 'PIN 불일치' });
    }
    loginFails.delete(ip);
    return json(res, 200, { success: true, token: PIN }, { 'Set-Cookie': `m_sid=${encodeURIComponent(PIN)}; Path=/; HttpOnly; Max-Age=86400; ` + (isHttps(req) ? 'SameSite=None; Secure' : 'SameSite=Lax') });
  }

  if (pathname === '/api/projects') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    const cur = currentProject(req, url);
    const list = await Promise.all(projects.map(async (p) => {
      const c = children.get(p.name);
      const alive = c ? await probe(c.port, '/api/devices', 2000) : null;
      const lt = alive ? await probe(c.port, '/api/live-transcript?limit=1&pin=' + encodeURIComponent(PIN), 4000) : null;
      return { name: p.name, dir: p.dir, port: c ? c.port : null, alive: !!alive, windowPid: lt && lt.body ? (lt.body.windowPid || null) : null, current: p.name === cur.name, isDefault: p === projects[0] };
    }));
    return json(res, 200, { success: true, current: cur.name, projects: list });
  }

  if (pathname === '/api/project-select') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    const name = url.searchParams.get('name') || '';
    const p = projects.find(x => x.name === name);
    if (!p) return json(res, 404, { success: false, error: '없는 프로젝트' });
    return json(res, 200, { success: true, current: p.name }, { 'Set-Cookie': cookieHeader(req, COOKIE, p.name) });
  }

  if (pathname === '/api/project-add' && req.method === 'POST') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    let body = {}; try { body = JSON.parse(await readBody(req)); } catch (_) {}
    const name = String(body.name || '').trim().replace(/[\\/:*?"<>|]/g, '').slice(0, 40);
    if (!name) return json(res, 400, { success: false, error: '이름 필요' });
    if (projects.find(x => x.name === name)) return json(res, 409, { success: false, error: '이미 있는 이름' });
    const root = cfg.projects_root ? path.resolve(String(cfg.projects_root)) : path.join(path.dirname(BASE_DIR), '콘솔프로젝트');
    const dir = body.dir ? path.resolve(String(body.dir)) : path.join(root, name);
    try { fs.mkdirSync(dir, { recursive: true }); } catch (e) { return json(res, 500, { success: false, error: '폴더 생성 실패: ' + e.message }); }
    const p = { name, dir }; projects.push(p);
    const c = readCfg(); c.projects = projects.map(x => ({ name: x.name, dir: x.dir })); writeCfg(c);
    startChild(p);
    // 자식이 뜰 때까지 잠깐 대기 후 Claude Code 창 확보
    let ok = false; for (let i = 0; i < 20 && !ok; i++) { await new Promise(r => setTimeout(r, 500)); ok = !!(await probe(children.get(name).port, '/api/devices', 1500)); }
    if (ok) { const r = http.request({ host: '127.0.0.1', port: children.get(name).port, path: '/api/main-restart?pin=' + encodeURIComponent(PIN), method: 'POST' }, (rr) => rr.resume()); r.on('error', () => {}); r.end(); }
    return json(res, 200, { success: true, name, dir, port: children.get(name).port, alive: ok }, { 'Set-Cookie': cookieHeader(req, COOKIE, name) });
  }

  // 나머지: 현재 프로젝트 자식으로 프록시
  const p = currentProject(req, url); const c = p && children.get(p.name);
  if (!c) return json(res, 503, { error: '프로젝트 서버 없음' });
  const headers = Object.assign({}, req.headers, { host: '127.0.0.1:' + c.port, 'x-forwarded-proto': isHttps(req) ? 'https' : 'http', 'x-forwarded-host': req.headers.host || '', 'x-console-project': encodeURIComponent(p.name) });
  // /proj/<이름>/… 로 들어온 요청은 접두사를 떼고 자식에게 넘긴다(자식은 자기 경로만 안다)
  const stripped = projectFromPath(url.pathname);
  const fwdPath = stripped ? (stripped.rest + (url.search || '')) : req.url;
  const up = http.request({ host: '127.0.0.1', port: c.port, path: fwdPath, method: req.method, headers }, (ur) => {
    res.writeHead(ur.statusCode, ur.headers); ur.pipe(res);
  });
  up.on('error', (e) => { if (!res.headersSent) json(res, 502, { error: '프로젝트 서버 응답 없음: ' + e.message }); else res.end(); });
  req.pipe(up);
});

server.listen(PORT, () => log('프로젝트 라우터 대기: 포트 ' + PORT + ' / 프로젝트 ' + projects.map(p => p.name).join(', ')));
process.on('exit', () => { for (const c of children.values()) { try { c.proc.kill(); } catch (_) {} } });
process.on('SIGINT', () => process.exit(0));
process.on('SIGTERM', () => process.exit(0));

module.exports = { projects, children };
