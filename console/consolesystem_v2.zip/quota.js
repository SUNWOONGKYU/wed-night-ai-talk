/**
 * 구독 한도(5시간 / 7일 창) 잔여율 조회 — 콘솔 상단 표시용
 *  - Claude Code : ~/.claude/.credentials.json OAuth → GET api.anthropic.com/api/oauth/usage (five_hour / seven_day utilization)
 *  - Codex       : `codex app-server` JSON-RPC account/rateLimits/read (primary=5h, secondary=7d usedPercent)
 *  - Antigravity : 공개 조회 수단 없음 (내부 retrieveUserQuotaSummary 는 403) → supported:false
 *  - Grok        : CLI 에 구독 한도 조회 없음 → supported:false
 * 값은 "남은 %" 로 통일 (100 - 사용률). 60초 캐시. 토큰 값은 절대 밖으로 내보내지 않는다.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const { spawn } = require('child_process');

const CACHE_MS = 60 * 1000;
let cache = { at: 0, data: null, pending: null };

function cleanEnv() {
  const env = { ...process.env };
  for (const k of Object.keys(env)) if (/^CLAUDE/.test(k)) delete env[k];
  return env;
}

function claudeUsage() {
  return new Promise((resolve) => {
    let tok = null;
    try {
      const cred = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.claude', '.credentials.json'), 'utf8'));
      tok = cred.claudeAiOauth && cred.claudeAiOauth.accessToken;
    } catch (_) {}
    if (!tok) return resolve({ supported: true, ok: false, error: '로그인 정보 없음' });
    const req = https.request({
      hostname: 'api.anthropic.com', path: '/api/oauth/usage', method: 'GET', timeout: 10000,
      headers: { Authorization: 'Bearer ' + tok, 'anthropic-beta': 'oauth-2025-04-20', 'User-Agent': 'mobile-console-quota' }
    }, (res) => {
      let b = ''; res.on('data', d => b += d);
      res.on('end', () => {
        try {
          const j = JSON.parse(b);
          if (!j.five_hour) return resolve({ supported: true, ok: false, error: 'HTTP ' + res.statusCode });
          resolve({
            supported: true, ok: true,
            h5: { left: Math.max(0, Math.round(100 - (j.five_hour.utilization || 0))), resetAt: j.five_hour.resets_at },
            d7: { left: Math.max(0, Math.round(100 - (j.seven_day.utilization || 0))), resetAt: j.seven_day.resets_at }
          });
        } catch (e) { resolve({ supported: true, ok: false, error: '응답 해석 실패' }); }
      });
    });
    req.on('timeout', () => { req.destroy(); resolve({ supported: true, ok: false, error: '시간 초과' }); });
    req.on('error', (e) => resolve({ supported: true, ok: false, error: e.message }));
    req.end();
  });
}

function codexRateLimits() {
  return new Promise((resolve) => {
    let p; let done = false; let buf = '';
    const finish = (v) => { if (done) return; done = true; try { p && p.kill(); } catch (_) {} resolve(v); };
    try {
      p = spawn('cmd', ['/c', 'codex app-server'], { env: cleanEnv(), windowsHide: true });
    } catch (e) { return finish({ supported: true, ok: false, error: e.message }); }
    p.on('error', (e) => finish({ supported: true, ok: false, error: e.message }));
    p.stdout.on('data', (d) => {
      buf += d;
      let idx;
      while ((idx = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, idx).trim(); buf = buf.slice(idx + 1);
        if (!line.startsWith('{')) continue;
        let m; try { m = JSON.parse(line); } catch (_) { continue; }
        if (m.id === 2 && m.result && m.result.rateLimits) {
          const rl = m.result.rateLimits;
          const toIso = (s) => s ? new Date(s * 1000).toISOString() : null;
          return finish({
            supported: true, ok: true, plan: rl.planType || null,
            h5: rl.primary ? { left: Math.max(0, 100 - (rl.primary.usedPercent || 0)), resetAt: toIso(rl.primary.resetsAt) } : null,
            d7: rl.secondary ? { left: Math.max(0, 100 - (rl.secondary.usedPercent || 0)), resetAt: toIso(rl.secondary.resetsAt) } : null
          });
        }
        if (m.id === 2 && m.error) return finish({ supported: true, ok: false, error: (m.error.message || 'rpc error').slice(0, 80) });
      }
    });
    const send = (o) => { try { p.stdin.write(JSON.stringify(o) + '\n'); } catch (_) {} };
    send({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { clientInfo: { name: 'mobile-console', version: '1.0' } } });
    setTimeout(() => send({ jsonrpc: '2.0', method: 'initialized', params: {} }), 300);
    setTimeout(() => send({ jsonrpc: '2.0', id: 2, method: 'account/rateLimits/read', params: {} }), 800);
    setTimeout(() => finish({ supported: true, ok: false, error: '시간 초과(codex 미설치/미로그인?)' }), 20000);
  });
}

async function fetchAll() {
  const [claude, codex] = await Promise.all([claudeUsage(), codexRateLimits()]);
  return {
    at: Date.now(),
    basis: 'left', // 남은 %
    claude, codex,
    agy: { supported: false, note: '조회 수단 없음' },
    grok: { supported: false, note: '조회 수단 없음' }
  };
}

function getQuota(force) {
  const now = Date.now();
  if (!force && cache.data && now - cache.at < CACHE_MS) return Promise.resolve(cache.data);
  if (cache.pending) return cache.pending;
  cache.pending = fetchAll().then((d) => { cache = { at: Date.now(), data: d, pending: null }; return d; })
    .catch((e) => { cache.pending = null; return cache.data || { at: Date.now(), error: e.message }; });
  return cache.pending;
}

module.exports = { getQuota };

if (require.main === module) {
  getQuota(true).then((d) => { console.log(JSON.stringify(d, null, 2)); process.exit(0); });
}
