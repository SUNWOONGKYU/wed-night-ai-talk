/**
 * 모바일 원격 제어 웹 콘솔 서버 (Mobile Remote Web Console)
 * Node.js 내장 모듈만 사용 (Zero External Dependency)
 */

const http = require('http');
const { exec, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const agyBridge = require('./antigravity_bridge.js'); // 서브 워커 2: Antigravity (agy)
const grokBridge = require('./grok_bridge.js');       // 서브 워커 3: Grok (grok-4.6, CLI 로그인)

let _srvCfg = {};
try { _srvCfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'console_config.json'), 'utf8').replace(/^﻿/, '')); } catch (_) {}
// 메인 워커 역할 (2026-09-20 PC1 지시): 1번 프로젝트 = 'primary'(PC 대화형 Claude Code 창 미러링), 2번째 이후 = 'daemon'(창 없이 claude -p --resume).
//  - 라우터가 PROJECT_ROLE 을 주면 그대로. 없으면: 라우터 자식(PROJECT_NAME 있음)이면서 라우터 본체 폴더(config 에 projects 목록)가 아니면 daemon, 그 외(단독 실행 포함) primary.
const PROJECT_ROLE = process.env.PROJECT_ROLE || _srvCfg.role || ((process.env.PROJECT_NAME && !(Array.isArray(_srvCfg.projects) && _srvCfg.projects.length)) ? 'daemon' : 'primary');
const mainBridge = PROJECT_ROLE === 'daemon' ? require('./claude_daemon_bridge.js') : require('./main_worker_bridge.js'); // 메인 워커: Claude Code (Opus 5)
const PORT = Number(process.env.PORT || _srvCfg.port || 7890);
const PIN_CODE = String(process.env.PIN || _srvCfg.pin || '0000'); // 모바일 접속 비밀번호
const BASE_DIR = path.resolve(__dirname, '..'); // 기본 작업 디렉토리 (프로젝트 루트)
// AI 워커 구성 (console_config.json workers — 설치 마법사가 채움). 없으면 전부 켜짐·기본 모델.
let WORKERS = {};
try { WORKERS = JSON.parse(process.env.CONSOLE_WORKERS || 'null') || _srvCfg.workers || {}; } catch (_) { WORKERS = _srvCfg.workers || {}; }
function workerOn(k) { const w = WORKERS[k]; return !(w && w.enabled === false); }
function prettyModel(m) { if (!m) return ''; return String(m).replace(/^gemini-(\d+\.\d+)-(flash|pro)(?:-(high|low|medium))?$/i, (_, v, t, l) => 'Gemini ' + v + ' ' + t[0].toUpperCase() + t.slice(1) + (l ? ' (' + l[0].toUpperCase() + l.slice(1) + ')' : '')).replace(/^gpt-/i, 'GPT-'); }
const WLBL = {
  claude: (WORKERS.claude && WORKERS.claude.model) || 'Opus 5',
  codex: prettyModel(WORKERS.codex && WORKERS.codex.model) || 'GPT-5.6-terra',
  agy: prettyModel((WORKERS.agy && WORKERS.agy.model) || process.env.AGY_MODEL) || 'Gemini 3.8 Flash',
  grok: (WORKERS.grok && WORKERS.grok.model) || 'grok-4.6',
};
let WORK_DIR = BASE_DIR;

// 세션 토큰 관리
const validTokens = new Set([PIN_CODE]);
function generateToken() {
  const token = Math.random().toString(36).substring(2) + Date.now().toString(36);
  validTokens.add(token);
  return token;
}

// 🛡️ 디렉토리 탈출(Path Traversal) 원천 차단 헬퍼
function safeResolvePath(userPath) {
  if (!userPath) return null;
  const abs = path.resolve(BASE_DIR, userPath);
  const rel = path.relative(BASE_DIR, abs);
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    return null; // 작업 디렉토리 외부 탈출 원천 차단
  }
  return abs;
}

// 🛡️ 요청 본문 크기 상한(DDoS/OOM 방어) 헬퍼
function readRequestBody(req, maxBytes, callback) {
  let body = '';
  let bytes = 0;
  let done = false;
  req.on('data', chunk => {
    if (done) return;
    bytes += chunk.length;
    if (bytes > maxBytes) {
      done = true;
      req.destroy();
      return callback(new Error('PAYLOAD_TOO_LARGE'));
    }
    body += chunk;
  });
  req.on('end', () => {
    if (!done) { done = true; callback(null, body); }
  });
  req.on('error', err => {
    if (!done) { done = true; callback(err); }
  });
}

// 🛡️ 실질적 보안 인증 검증 (PIN 및 토큰 유효성 검사)
function getCookie(req, name) {
  const raw = req.headers['cookie'] || '';
  for (const part of raw.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return decodeURIComponent(v.join('='));
  }
  return '';
}
// 세션 쿠키 발급 (URL에 토큰을 싣지 않기 위함 — /term·/term/ws 는 쿠키로 인증)
// 허브(vercel) iframe 안에서 쓰이므로 https 터널이면 SameSite=None; Secure
function sessionCookieHeader(req, tokenValue) {
  const https = (req.headers['x-forwarded-proto'] || '').includes('https') || /trycloudflare\.com$/i.test(req.headers.host || '');
  return `m_sid=${encodeURIComponent(tokenValue)}; Path=/; HttpOnly; Max-Age=86400; ` + (https ? 'SameSite=None; Secure' : 'SameSite=Lax');
}
function isRequestAuthorized(req, parsedUrl) {
  const auth = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '').trim();
  const query = parsedUrl ? (parsedUrl.searchParams.get('token') || parsedUrl.searchParams.get('pin')) : '';
  const cookie = getCookie(req, 'm_sid');
  const checkToken = auth || query || cookie;
  if (!checkToken) return false;
  return validTokens.has(checkToken) || checkToken === PIN_CODE;
}

// 로컬 IPv4 주소 추출
function getLocalIpAddresses() {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push(iface.address);
      }
    }
  }
  return addresses;
}

// 명령어 실행 큐/프로세스 풀
let currentProcess = null;
const activeExecChildren = new Set();

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;
  console.log(`[REQ ${new Date().toLocaleTimeString()}] ${req.method} ${pathname}`);

  // CORS 및 헤더 설정
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // 1. API: 로그인 (PIN 검증)
  if (pathname === '/api/login' && req.method === 'POST') {
    readRequestBody(req, 65536, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const data = JSON.parse(body);
        if (data.pin === PIN_CODE) {
          const token = generateToken();
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Set-Cookie': sessionCookieHeader(req, token) });
          res.end(JSON.stringify({ success: true, token, workDir: WORK_DIR }));
        } else {
          res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ success: false, message: 'PIN 번호가 일치하지 않습니다.' }));
        }
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ success: false, message: '잘못된 요청 형식입니다.' }));
      }
    });
    return;
  }

  // 🛡️ 실질적 인증 미들웨어 (PIN 인증을 거친 요청만 통과)
  const isAuthenticated = isRequestAuthorized(req, parsedUrl);

  // 2. API: 시스템 정보
  // 구독 잔여 한도 (5h/7d, 남은 %) — quota.js, 60초 캐시
  if (pathname === '/api/quota') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    return require('./quota.js').getQuota(false).then((q) => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify(q));
    }).catch((e) => {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ error: e.message }));
    });
  }

  // 프로젝트 도구 실행 — console_config.json 의 project_tab.mode === 'run' 일 때만.
  // 실행 대상은 설정 파일의 cmd 하나뿐이고, 항상 그 프로젝트 폴더에서 돈다(요청 본문은 쓰지 않는다).
  if (pathname === '/api/project-run' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const json = (code, o) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(o)); };
    const tab = PROJECT_TABS[parseInt(parsedUrl.searchParams.get('i'), 10) || 0];
    if (!tab || tab.mode !== 'run' || !tab.cmd) return json(400, { success: false, error: '실행 설정 없음' });
    const target = path.resolve(BASE_DIR, tab.cmd);
    if (!fs.existsSync(target)) return json(400, { success: false, error: '실행 파일 없음: ' + tab.cmd });
    try {
      const child = spawn('cmd', ['/c', 'start', '', target], { cwd: BASE_DIR, detached: true, stdio: 'ignore', windowsHide: false });
      child.unref();
      return json(200, { success: true, started: tab.cmd, at: new Date().toLocaleTimeString('ko-KR') });
    } catch (e) { return json(500, { success: false, error: e.message }); }
  }

  if (pathname === '/api/info') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const info = {
      hostname: os.hostname(),
      platform: os.platform(),
      arch: os.arch(),
      uptimeHours: (os.uptime() / 3600).toFixed(1),
      freeMemMB: Math.round(os.freemem() / (1024 * 1024)),
      totalMemMB: Math.round(os.totalmem() / (1024 * 1024)),
      workDir: WORK_DIR,
      mainRole: PROJECT_ROLE,
      localIps: getLocalIpAddresses()
    };
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(info));
  }

  // 2-1. API: 모바일 화면으로 PC AI 답변 실시간 스트리밍 전달
  if (pathname === '/api/ai-poll') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const lastId = parseInt(parsedUrl.searchParams.get('lastId') || '0', 10);
    const respFile = path.join(WORK_DIR, '_mobile_remote', 'ai_responses_to_mobile.json');
    let responses = [];
    try {
      if (fs.existsSync(respFile)) {
        const all = JSON.parse(fs.readFileSync(respFile, 'utf8'));
        responses = all.filter(item => item.id > lastId);
      }
    } catch (_) {}
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ responses }));
  }



  // 2-4. API: 메인 워커(Claude Code) 실시간 대화 트랜스크립트 동기화
  if (pathname === '/api/live-transcript') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const data = mainBridge.getStatus();
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(data));
  }

  // 2-5. API: 모바일에서 메인 워커(Claude Code)로 실시간 질문/지시 즉각 전송 (큐 순차 실행)
  // 선택 위젯 조작: 폰 버튼 → PC 창에 방향키/Enter 주입
  if (pathname === '/api/main-keys' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    return readRequestBody(req, 65536, (err, body) => {
      let keys = []; try { keys = JSON.parse(body || '{}').keys || []; } catch (_) {}
      mainBridge.injectKeys(keys).then((r) => {
        res.writeHead(r.ok ? 200 : 500, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify(Object.assign({ success: !!r.ok }, r)));
      });
    });
  }

  if (pathname === '/api/send-mobile-input' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 1048576, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const { text } = JSON.parse(body);
        if (!text || !text.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '지시 내용이 없습니다.' }));
        }
        const taskFile = path.join(BASE_DIR, '_mobile_remote', 'tasks_from_mobile.json');
        let tasks = [];
        try {
          if (fs.existsSync(taskFile)) tasks = JSON.parse(fs.readFileSync(taskFile, 'utf8'));
        } catch (_) {}
        const entry = {
          time: new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }),
          task: text.trim()
        };
        tasks.push(entry);
        fs.writeFileSync(taskFile, JSON.stringify(tasks.slice(-100), null, 2), 'utf8');

        mainBridge.executeMainPrompt(text.trim());

        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, entry, queued: mainBridge.getStatus().queued }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2-5-B. API: 메인 워커 세션 초기화 (대화 맥락 새로 시작)
  if (pathname === '/api/main-reset-session' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    if (PROJECT_ROLE === 'daemon') {
      return mainBridge.resetSession().then((sid) => { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ success: true, sessionId: sid })); });
    }
    res.writeHead(410, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ success: false, error: '미러링 모드에서는 세션 리셋을 지원하지 않습니다 (PC 창의 대화가 정본)' }));
  }

  // 2-5-C. API: 메인 워커 창 확인/기동 (PC에 Claude Code 창이 없으면 --resume 으로 하나 띄움)
  if (pathname === '/api/main-restart' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    mainBridge.ensureWindow().then((pid) => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ success: !!pid, windowPid: pid, sessionId: mainBridge.getStatus().conversationId }));
    });
    return;
  }

  // 2-6. API: Codex 실시간 상태 및 대화내역 조회
  if (pathname === '/api/codex-status') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const codexBridge = require('./codex_bridge.js');
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(codexBridge.getStatus()));
  }

  // 2-7. API: 모바일에서 Codex로 실시간 코딩 지시 전송
  if (pathname === '/api/codex-send' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 1048576, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const { text } = JSON.parse(body);
        if (!text || !text.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '지시 내용이 없습니다.' }));
        }
        const codexBridge = require('./codex_bridge.js');
        codexBridge.executeCodexPrompt(text.trim());
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, message: 'Codex 실행 개시' }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2-8. API: Antigravity(서브 워커 2) 실시간 상태 및 대화내역 조회
  if (pathname === '/api/agy-status') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(agyBridge.getStatus()));
  }

  // 2-9. API: 모바일에서 Antigravity(서브 워커 2)로 실시간 코딩 지시 전송
  if (pathname === '/api/agy-send' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 1048576, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const { text } = JSON.parse(body);
        if (!text || !text.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '지시 내용이 없습니다.' }));
        }
        agyBridge.executeAgyPrompt(text.trim());
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, message: 'Antigravity 실행 개시' }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2-8G. API: Grok(서브 워커 3) 실시간 상태 및 대화내역 조회
  if (pathname === '/api/grok-status') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(grokBridge.getStatus()));
  }

  // 2-9G. API: 모바일에서 Grok(서브 워커 3)로 실시간 코딩 지시 전송
  if (pathname === '/api/grok-send' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 1048576, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const { text } = JSON.parse(body);
        if (!text || !text.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '지시 내용이 없습니다.' }));
        }
        grokBridge.executeGrokPrompt(text.trim());
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, message: 'Grok 실행 개시' }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2-10. API: 긴급 정지 (Emergency Stop / Kill Switch)
  if (pathname === '/api/emergency-stop' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    try {
      const codexBridge = require('./codex_bridge.js');

      // 메인·서브 워커 프로세스 정밀 타깃 강제 종료 (외부 사용자 터미널 보호)
      mainBridge.killCurrentProcess();
      if (typeof codexBridge.killCurrentProcess === 'function') codexBridge.killCurrentProcess();
      agyBridge.killCurrentProcess();
      if (typeof grokBridge.killCurrentProcess === 'function') grokBridge.killCurrentProcess();

      // exec 명령어 실행 하위 프로세스 일괄 트리 강제 종료
      if (activeExecChildren.size > 0) {
        activeExecChildren.forEach(p => {
          try {
            if (p && p.pid) {
              if (process.platform === 'win32') {
                const { execSync } = require('child_process');
                execSync(`taskkill /pid ${p.pid} /T /F 2>nul || exit 0`, { shell: true });
              } else {
                p.kill('SIGKILL');
              }
            }
          } catch (_) {}
        });
        activeExecChildren.clear();
      }
      currentProcess = null;

      // 모바일 태스크 기록에 정지 알림 기록
      const tasksFile = path.join(BASE_DIR, '_mobile_remote', 'tasks_from_mobile.json');
      try {
        let tasks = [];
        if (fs.existsSync(tasksFile)) tasks = JSON.parse(fs.readFileSync(tasksFile, 'utf8'));
        tasks.push({
          time: new Date().toLocaleString('ko-KR'),
          task: '🛑 [긴급 정지 발동] 사용자가 모바일 콘솔에서 긴급 정지(Kill Switch)를 눌러 모든 실행 중인 작업을 즉시 중단시켰습니다.'
        });
        fs.writeFileSync(tasksFile, JSON.stringify(tasks, null, 2), 'utf8');
      } catch (_) {}

      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ 
        success: true, 
        message: '🛑 모든 AI 프로세스 및 백그라운드 연산이 즉시 강제 중단되었습니다.' 
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ success: false, error: err.message }));
    }
  }

  // 2-10-B. API: 스캐너 상태 조회 프록시
  // 전략 목록·통과 종목·겹침 (scanner_web /api/strategies 프록시) + 켜기/끄기
  if (pathname === '/api/scanner-strategies' || pathname.startsWith('/api/scanner-strategy-toggle/')) {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const httpMod = require('http');
    const toggle = pathname.startsWith('/api/scanner-strategy-toggle/');
    const sid = toggle ? pathname.slice('/api/scanner-strategy-toggle/'.length) : '';
    const target = toggle ? ('http://127.0.0.1:5050/api/strategies/' + sid + '/enabled') : 'http://127.0.0.1:5050/api/strategies';
    const proxyReq = httpMod.request(target, { method: toggle ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json' } }, (proxyRes) => {
      res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
      proxyRes.pipe(res);
    });
    proxyReq.on('error', () => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ strategies: [], overlap: {}, error: '스캐너 백엔드 대기 중' }));
    });
    if (toggle) req.pipe(proxyReq); else proxyReq.end();
    return;
  }

  if (pathname === '/api/scanner-status') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const httpMod = require('http');
    const proxyReq = httpMod.request('http://127.0.0.1:5050/api/status', (proxyRes) => {
      res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
      proxyRes.pipe(res);
    });
    proxyReq.on('error', () => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ running: false, stage1: [], stage2: [], error: '스캐너 백엔드 대기 중' }));
    });
    proxyReq.end();
    return;
  }

  // 2-10-C. API: 스캐너 재스캔 실행 프록시
  if (pathname === '/api/scanner-scan' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const httpMod = require('http');
    const proxyReq = httpMod.request('http://127.0.0.1:5050/api/scan', { method: 'POST' }, (proxyRes) => {
      res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
      proxyRes.pipe(res);
    });
    proxyReq.on('error', (e) => {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ error: '스캐너 서버 통신 오류: ' + e.message }));
    });
    proxyReq.end();
    return;
  }

  // 2-10. API: 기기 장부 조회 (듀얼 PC 탭 전환용)
  if (pathname === '/api/devices' && req.method === 'GET') {
    const devicesFile = path.join(BASE_DIR, '_mobile_remote', 'devices.json');
    let devices = {};
    if (fs.existsSync(devicesFile)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(devicesFile, 'utf8'));
        if (parsed && parsed.active_devices) devices = parsed.active_devices;
      } catch (_) {}
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ success: true, devices }));
  }

  // 2-11. API: 모바일 파일/사진 업로드 (Upload)
  if (pathname === '/api/upload' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증이 필요합니다. 올바른 PIN 코드로 접속하세요.' }));
    }

    readRequestBody(req, 104857600, (err, body) => { // 100MB 상한
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: '업로드 파일 크기 초과 (최대 100MB)' }));
      }
      try {
        const { filename, base64, targetAi, uploadType } = JSON.parse(body);
        if (!filename || !base64) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '파일명 또는 데이터가 없습니다.' }));
        }

        const uploadDir = path.join(BASE_DIR, 'uploads');
        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true });
        }

        // Base64 데이터 파싱 (data:image/png;base64, 접두사 제거)
        const pureBase64 = base64.replace(/^data:[^;]+;base64,/, '');
        const fileBuffer = Buffer.from(pureBase64, 'base64');
        const safeName = Date.now() + '_' + path.basename(filename).replace(/[^a-zA-Z0-9_\.\-\uAC00-\uD7A3]/g, '_');
        const targetPath = safeResolvePath(path.join('uploads', safeName));
        if (!targetPath) {
          res.writeHead(403, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '안전하지 않은 파일 경로입니다.' }));
        }

        fs.writeFileSync(targetPath, fileBuffer);

        const bytes = fileBuffer.length;
        const sizeStr = bytes > 1024 * 1024 ? (bytes / (1024 * 1024)).toFixed(2) + ' MB' : Math.round(bytes / 1024) + ' KB';
        const relPath = 'uploads/' + safeName;
        const isPhoto = uploadType === 'image' || /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(safeName);
        const itemLabel = isPhoto ? '사진' : '파일';
        const itemIcon = isPhoto ? '🖼️' : '📁';

        // 모바일 태스크 목록에 등록
        const tasksFile = path.join(BASE_DIR, '_mobile_remote', 'tasks_from_mobile.json');
        try {
          let tasks = [];
          if (fs.existsSync(tasksFile)) tasks = JSON.parse(fs.readFileSync(tasksFile, 'utf8'));
          tasks.push({
            time: new Date().toLocaleString('ko-KR'),
            task: `${itemIcon} [모바일 ${itemLabel} 수신] 파일명: ${safeName} (${sizeStr}) - 경로: ${relPath}`
          });
          fs.writeFileSync(tasksFile, JSON.stringify(tasks, null, 2), 'utf8');
        } catch (_) {}

        // 타깃 AI에 따라 대화창에 파일 등록 및 즉시 알림
        if (targetAi === 'codex') {
          const codexBridge = require('./codex_bridge.js');
          const prompt = `대표님께서 모바일에서 ${itemLabel}(${safeName}, ${sizeStr})을 업로드하셨습니다. 위치는 ${relPath} 입니다. ${itemLabel}의 내용을 확인하고 분석해 주세요.`;
          codexBridge.executeCodexPrompt(prompt);
        } else if (targetAi === 'agy') {
          const prompt = `대표님께서 모바일에서 ${itemLabel}(${safeName}, ${sizeStr})을 업로드하셨습니다. 위치는 ${relPath} 입니다. ${itemLabel}의 내용을 확인하고 정밀 분석해 주세요.`;
          agyBridge.executeAgyPrompt(prompt);
        } else if (targetAi === 'grok') {
          const prompt = `대표님께서 모바일에서 ${itemLabel}(${safeName}, ${sizeStr})을 업로드하셨습니다. 위치는 ${relPath} 입니다. ${itemLabel}의 내용을 확인하고 정밀 분석해 주세요.`;
          grokBridge.executeGrokPrompt(prompt);
        } else if (targetAi === 'assistant') {
          const prompt = `모바일에서 ${itemLabel}(${safeName}, ${sizeStr})을 업로드했다. 위치는 ${relPath} 이다. 내용을 확인하고 핵심을 분석해 보고해줘.`;
          mainBridge.executeMainPrompt(prompt);
        }

        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ 
          success: true, 
          filename: safeName, 
          filePath: relPath, 
          sizeStr,
          message: `${itemLabel}(${safeName})이 성공적으로 업로드되었습니다.`
        }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 3. API: 파일 목록 조회
  if (pathname === '/api/files') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    try {
      const items = fs.readdirSync(BASE_DIR, { withFileTypes: true }).map(item => {
        let size = 0;
        try {
          if (!item.isDirectory()) {
            size = fs.statSync(path.join(BASE_DIR, item.name)).size;
          }
        } catch (_) {}
        return {
          name: item.name,
          isDir: item.isDirectory(),
          size
        };
      });
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ workDir: BASE_DIR, files: items }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: err.message }));
    }
  }

  // 3-1. API: 특정 파일 내용 읽기
  if (pathname === '/api/file-content' && req.method === 'GET') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const relFile = parsedUrl.searchParams.get('file');
    if (!relFile) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: '파일 경로 누락' }));
    }
    const absPath = safeResolvePath(relFile);
    if (!absPath || !fs.existsSync(absPath)) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: '파일을 찾을 수 없거나 접근 권한이 없습니다.' }));
    }
    try {
      const content = fs.readFileSync(absPath, 'utf8');
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ file: relFile, content }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // 3-2. API: 모바일에서 파일 수정 후 즉시 저장
  if (pathname === '/api/save-file' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 10485760, (err, body) => { // 10MB 상한
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: '파일 크기 초과' }));
      }
      try {
        const { file, content } = JSON.parse(body);
        if (!file) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '파일명 누락' }));
        }
        const absPath = safeResolvePath(file);
        if (!absPath) {
          res.writeHead(403, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '프로젝트 작업 디렉토리 외부 경로는 수정할 수 없습니다.' }));
        }
        fs.writeFileSync(absPath, content, 'utf8');
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, file, message: '파일이 PC에 정상 저장되었습니다!' }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 스마트 자연어 의도 해석기 (한국어 대화 및 명령어 자동 처리)
  function handleSmartIntent(input, workDir) {
    const text = input.trim();
    if (!text) return null;

    // 1. 인사 및 환영
    if (/^(안녕|하이|반가|hello|hi|헤이|누구|뭐해)/i.test(text)) {
      return {
        type: 'chat',
        reply: `안녕하세요, 대표님! 👋\n멀티 AI 에이전트(Claude Code, Codex, Antigravity) 모바일 콘솔입니다.\n\n어떤 작업을 지시하시겠습니까?\n아래 버튼을 터치하시거나 편하게 명령을 입력해 주세요!`,
        actions: [
          { label: '📁 프로젝트 파일', cmd: '파일' },
          { label: '💻 PC 시스템 상태', cmd: '상태' },
          { label: '⚡ 핵심 요약', cmd: '현재 작업 핵심만 3줄 요약해줘' },
          { label: '▶ 계속 진행', cmd: '작업 계속 진행해' }
        ]
      };
    }

    // 2. 파일 목록 조회
    if (/^(파일|폴더|디렉토리|file|dir|내용)/i.test(text)) {
      try {
        const items = fs.readdirSync(workDir);
        const filtered = items.filter(f => !f.startsWith('.') && f !== 'node_modules');
        const formatted = filtered.map(f => {
          try {
            const stat = fs.statSync(path.join(workDir, f));
            const icon = stat.isDirectory() ? '📁' : '📄';
            return `${icon} ${f}`;
          } catch (_) {
            return `📄 ${f}`;
          }
        }).slice(0, 20).join('\n');
        return {
          type: 'files',
          reply: `📁 [프로젝트 파일 목록]\n${formatted}\n\n(총 ${filtered.length}개 파일/폴더)`,
          actions: [
            { label: '📁 파일 탐색 탭 열기', tab: 'system' }
          ]
        };
      } catch (e) {
        return { type: 'chat', reply: `파일 목록 확인 오류: ${e.message}` };
      }
    }

    // 3. PC 시스템 상태 점검
    if (/상태|메모리|컴퓨터|pc|ram|사양|리소스/i.test(text)) {
      const freeMB = Math.round(os.freemem() / (1024 * 1024));
      const totalMB = Math.round(os.totalmem() / (1024 * 1024));
      const uptimeH = (os.uptime() / 3600).toFixed(1);
      return {
        type: 'system',
        reply: `💻 [PC 시스템 실시간 상태]\n• 컴퓨터 이름: ${os.hostname()}\n• 가동 시간: ${uptimeH}시간\n• CPU 코어: ${os.cpus().length} Cores\n• RAM 메모리: ${freeMB} MB 여유 / ${totalMB} MB 전체\n• 작업 디렉토리: ${workDir}`
      };
    }

    // 4. 도움말 및 기능 안내
    if (/도움|help|사용법|어떻게|뭐할수|무슨.*작업|할.*수.*있|기능|역할|명령/i.test(text)) {
      return {
        type: 'help',
        reply: `💡 [모바일 콘솔 핵심 기능 안내]\n\n1. Claude Code (Opus 5): 프로젝트 총괄 지휘·심층 분석·리팩터링 (대화 맥락 유지)\n2. Codex (GPT-5.6-terra): 고속 스크립트 작성 및 백그라운드 자동 코딩\n3. Antigravity (Gemini 3.8 Flash): 보조 코딩·파일 수정 (무인 자동 승인)\n4. 📁 파일 & 시스템: 작업 디렉토리 실시간 탐색, 모바일 코드 편집, PC 자원 모니터링\n5. 🖼️📎 사진/파일 업로드: 스마트폰 촬영 사진 및 문서를 PC로 즉시 전송\n\n명령창에 원하시는 작업 지시를 자유롭게 입력해 주세요!`,
        actions: [
          { label: '📁 파일 목록', cmd: '파일' },
          { label: '💻 시스템 상태', cmd: '상태' },
          { label: '⚡ 3줄 요약', cmd: '현재 작업 핵심만 3줄 요약해줘' },
          { label: '🛑 긴급 정지', cmd: '정지' }
        ]
      };
    }

    // 11. 임의의 한글 문장인 경우 → 메인 워커(Claude Code)로 전달
    if (/[가-힣]/.test(text)) {
      const taskFile = path.join(workDir, '_mobile_remote', 'tasks_from_mobile.json');
      try {
        let tasks = [];
        if (fs.existsSync(taskFile)) tasks = JSON.parse(fs.readFileSync(taskFile, 'utf8'));
        tasks.push({ time: new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }), task: text });
        fs.writeFileSync(taskFile, JSON.stringify(tasks.slice(-100), null, 2), 'utf8');
      } catch (_) {}
      mainBridge.executeMainPrompt(text);
      return {
        type: 'chat',
        reply: `🤖 [Claude Code (Opus 5)에 전달 완료]\n\n지시 내용: "${text}"\n\n🎯 Claude Code 탭에서 실시간 진행 상황과 결과를 확인하세요.`,
        actions: [ { label: '🤖 Claude Code 탭 열기', tab: 'assistant' } ]
      };
    }

    // 12. 한글이 없으면 일반 CLI 터미널 명령어로 통과
    return null;
  }

  // 4. API: 명령어 / 자연어 실행
  if (pathname === '/api/exec' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증이 필요합니다. 올바른 PIN 코드로 접속하세요.' }));
    }

    readRequestBody(req, 1048576, async (err, body) => { // 1MB 상한
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: '명령어 크기 초과' }));
      }
      try {
        const { cmd } = JSON.parse(body);
        if (!cmd || typeof cmd !== 'string') {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '명령어가 없습니다.' }));
        }

        const trimmed = cmd.trim();

        // 🛡️ 위험 파괴 명령어 차단 가드 (포맷, 전체 삭제, 시스템 종료 등)
        const dangerousPatterns = [
          /format\s+[a-z]:/i,
          /del\s+(\/|\-)f\s+(\/|\-)s\s+(\/|\-)q/i,
          /rmdir\s+(\/|\-)s\s+(\/|\-)q\s+[a-z]:\\/i,
          /remove-item\s+.*-recurse.*[a-z]:\\/i,
          /shutdown/i,
          /diskpart/i
        ];
        if (dangerousPatterns.some(p => p.test(trimmed))) {
          res.writeHead(403, { 'Content-Type': 'application/json; charset=utf-8' });
          return res.end(JSON.stringify({ 
            error: '🛡️ 시스템 보안 정책에 의해 해당 위험 명령어 실행이 안전하게 차단되었습니다.', 
            exitCode: 1 
          }));
        }

        // 1) 스마트 자연어 인텐트 및 메인 워커 전달 검사
        const smartResult = await handleSmartIntent(trimmed, WORK_DIR);
        if (smartResult) {
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          return res.end(JSON.stringify({
            isSmart: true,
            smart: smartResult,
            workDir: WORK_DIR,
            exitCode: 0
          }));
        }

        // 2) 디렉토리 변경(cd) 특수 처리 (프로젝트 폴더 외부 탈출 원천 차단)
        if (trimmed.startsWith('cd ')) {
          const targetDir = trimmed.substring(3).trim();
          const targetPath = safeResolvePath(targetDir);
          if (targetPath && fs.existsSync(targetPath) && fs.statSync(targetPath).isDirectory()) {
            WORK_DIR = targetPath;
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
            return res.end(JSON.stringify({
              output: `디렉토리 변경: ${WORK_DIR}`,
              workDir: WORK_DIR,
              exitCode: 0
            }));
          } else {
            WORK_DIR = BASE_DIR; // 외부 이동 시도 시 기본 프로젝트 폴더로 보호
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
            return res.end(JSON.stringify({
              output: `경로를 찾을 수 없거나 프로젝트 작업 폴더 외부로 이동할 수 없습니다. (위치: ${WORK_DIR})`,
              workDir: WORK_DIR,
              exitCode: 0
            }));
          }
        }

        // 3) PowerShell 안전 실행 (UTF-8 인코딩 및 -EncodedCommand 사용으로 특수문자/한글 완벽 지원)
        const psCommand = `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; [Console]::InputEncoding = [System.Text.Encoding]::UTF8; $OutputEncoding = [System.Text.Encoding]::UTF8; ${trimmed}`;
        const encodedScript = Buffer.from(psCommand, 'utf16le').toString('base64');

        const proc = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encodedScript], {
          cwd: WORK_DIR,
          shell: false
        });

        activeExecChildren.add(proc);
        let output = '';
        currentProcess = proc;

        proc.stdout.on('data', data => { output += data.toString('utf8'); });
        proc.stderr.on('data', data => { output += data.toString('utf8'); });

        const timer = setTimeout(() => {
          if (activeExecChildren.has(proc)) {
            try {
              if (process.platform === 'win32') {
                const { execSync } = require('child_process');
                execSync(`taskkill /pid ${proc.pid} /T /F 2>nul || exit 0`, { shell: true });
              } else {
                proc.kill('SIGKILL');
              }
            } catch (_) {}
            activeExecChildren.delete(proc);
            output += '\n[시간 초과: 45초 경과로 프로세스를 중단했습니다]';
          }
        }, 45000);

        proc.on('close', code => {
          clearTimeout(timer);
          activeExecChildren.delete(proc);
          if (currentProcess === proc) currentProcess = null;
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({
            output: output.length ? output : '(출력 결과 없음)',
            workDir: WORK_DIR,
            exitCode: code
          }));
        });

      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // 5. 프론트엔드 모바일 웹 콘솔 UI 제공
  if (pathname === '/' || pathname === '/index.html') {
    const headers = { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store, max-age=0', 'Pragma': 'no-cache' }; // 폰 브라우저·허브 iframe 이 옛 화면을 캐시하지 않게
    // ?pin= / ?token= 으로 정상 진입하면 세션 쿠키 발급 → 이후 /term·/term/ws 는 쿠키로 인증 (URL 토큰 불필요)
    const q = parsedUrl.searchParams.get('token') || parsedUrl.searchParams.get('pin') || '';
    if (q && (validTokens.has(q) || q === PIN_CODE)) headers['Set-Cookie'] = sessionCookieHeader(req, q);
    res.writeHead(200, headers);
    res.end(getMobileHtml());
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not Found');
});

// 모바일 웹앱 HTML
const SHOW_SCANNER = fs.existsSync(path.join(BASE_DIR, 'scanner_web.py')); // 스캐너 버튼은 trader-bot 프로젝트에서만
let PROJECT_TAB = null;
let PROJECT_TABS = []; // 도구 버튼 여러 개(project_tabs). project_tab(단수)는 그 첫 칸으로 취급한다.
try {
  const _c = JSON.parse(fs.readFileSync(path.join(__dirname, 'console_config.json'), 'utf8').replace(/^﻿/, ''));
  PROJECT_TABS = [].concat(_c.project_tab || [], _c.project_tabs || []).filter(t => t && (t.url || t.cmd));
  PROJECT_TAB = PROJECT_TABS[0] || null;
} catch (_) {}
function escapeAttr(v) { return String(v || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

function getMobileHtml() {
  return getMobileHtmlRaw().replace(/Opus 5/g, WLBL.claude).replace(/GPT-5\.6-terra/g, WLBL.codex).replace(/Gemini 3\.8 Flash/g, WLBL.agy).replace(/grok-4\.6/g, WLBL.grok);
}
function getMobileHtmlRaw() {
  return `<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>원맥스 One MACS</title>
<link href="https://fonts.googleapis.com/css2?family=Pretendard:wght@400;600;700;800&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
<style>
:root {
  --bg: #0b0e17;
  --surface: #131826;
  --card: #1c2237;
  --border: #2a3350;
  --accent: #4f7fff;
  --accent-light: #7097ff;
  --win: #10b981;
  --danger: #ef4444;
  --warn: #f59e0b;
  --text: #f1f5f9;
  --dim: #94a3b8;
}
* { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
html, body {
  background: var(--bg);
  color: var(--text);
  font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, sans-serif;
  height: 100%;
  height: 100dvh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* 최상단 듀얼 PC 원터치 탭 스위처 바 */
.pc-switch-bar {
  display: flex;
  background: var(--surface);
  border-bottom: 1.5px solid var(--border);
  padding: 6px 10px;
  gap: 6px;
  flex-shrink: 0;
  z-index: 100;
}
.pc-nav-tab {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background: rgba(255,255,255,0.04);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 7px 10px;
  color: var(--dim);
  font-size: 12.5px;
  font-weight: 700;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.15s ease;
}
.pc-nav-tab.active {
  background: rgba(37,99,235,0.22);
  border-color: var(--accent-light);
  color: #fff;
  box-shadow: 0 0 10px rgba(37,99,235,0.3);
}
.pc-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--dim);
  flex-shrink: 0;
}
.pc-dot.online {
  background: var(--win);
  box-shadow: 0 0 6px var(--win);
}

/* 상단 헤더 */
.top-bar {
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  padding: 0 12px;
  height: 44px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-shrink: 0;
}
.brand {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 14px;
  font-weight: 800;
  color: #fff;
  white-space: nowrap;
}
.brand-tag {
  font-size: 11px;
  color: var(--accent-light);
  font-weight: 700;
  letter-spacing: 0.2px;
}
.status-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--win);
  display: inline-block;
  box-shadow: 0 0 6px var(--win);
}
.top-bar-right {
  display: flex;
  align-items: center;
  gap: 6px;
}
.btn-pc-switch {
  background: rgba(255,255,255,0.08);
  border: 1px solid var(--border);
  color: #cbd5e1;
  text-decoration: none;
  font-size: 11px;
  font-weight: 700;
  padding: 3px 8px;
  border-radius: 8px;
}
.btn-pc-switch:active {
  background: var(--accent);
  color: #fff;
}

/* 탭 메뉴 — 버튼형 (눌리는 느낌) */
.tabs {
  display: flex;
  gap: 5px;
  padding: 7px 6px 8px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}
.tab-btn {
  flex: 1 1 0; min-width: 0;
  padding: 7px 2px 6px;
  text-align: center;
  font-size: 12px;
  font-weight: 800;
  color: #cbd5e1;
  background: linear-gradient(180deg, #273049 0%, #1a2136 100%);
  border: 1px solid #3a4667;
  border-bottom: 3px solid #0d1120;
  border-radius: 10px;
  box-shadow: 0 3px 0 #0b0f1c, 0 4px 8px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.08);
  cursor: pointer;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.08s, box-shadow 0.08s, background 0.15s, color 0.15s;
  line-height: 1.25;
}
.tab-btn:active {
  transform: translateY(3px);
  box-shadow: 0 0 0 #0b0f1c, 0 1px 3px rgba(0,0,0,0.4), inset 0 2px 4px rgba(0,0,0,0.45);
  border-bottom-width: 1px;
}
.tab-btn.active {
  color: #fff;
  background: linear-gradient(180deg, #3d6bff 0%, #2f55d6 100%);
  border-color: #6b93ff;
  border-bottom: 1px solid #1d3a99;
  transform: translateY(3px);
  box-shadow: 0 0 0 #0b0f1c, inset 0 2px 5px rgba(0,0,0,0.35), 0 0 0 1px rgba(79,127,255,0.35);
}
.tab-btn.active .tab-sub { color: #dbe4ff !important; }
.tab-sub {
  font-size: 9.5px;
  font-weight: 700;
  margin-top: 2px;
  letter-spacing: -0.2px;
}

/* 헤더 우측 프로젝트 버튼 (탭 버튼과 동일 입체감, 소형) */
.brand { min-width: 0; overflow: hidden; }
.brand > span:not(.brand-tag) { flex-shrink: 0; }
.brand-tag { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.top-bar-right { flex-shrink: 0; }
.top-bar-left { display: flex; align-items: center; flex-shrink: 0; gap: 8px; }
/* 브랜드 마크: 원맥스 One MACS — 표시 전용(버튼 아님) */
.brand-mark { display: inline-flex; align-items: center; justify-content: center; width: 30px; height: 30px; border-radius: 9px; font-family: 'Fira Code', monospace; font-weight: 700; font-size: 12px; letter-spacing: -0.5px; color: #fff; background: linear-gradient(135deg, #D97757 0%, #4F7FFF 55%, #3ED2A8 100%); flex-shrink: 0; user-select: none; }
.top-bar { height: auto; min-height: 44px; padding: 5px 10px; }
.top-bar-right { gap: 5px; }
.tab-btn.hdr-btn { flex: 0 0 auto; min-width: 60px; min-height: 34px; padding: 5px 10px 4px; font-size: 12px; line-height: 1.2; display: inline-flex; flex-direction: column; align-items: center; justify-content: center; }
.tab-btn.hdr-btn .tab-sub { font-size: 9px; margin-top: 2px; }
.tab-btn.hdr-btn:not(.active) { background: linear-gradient(180deg, #1f3a33 0%, #162a26 100%); border-color: #2f6b5b; color: #a7f3d0; }
.tab-btn.hdr-btn.active { background: linear-gradient(180deg, #10b981 0%, #0b8f63 100%); border-color: #34d399; border-bottom-color: #065f46; box-shadow: 0 0 0 #0b0f1c, inset 0 2px 5px rgba(0,0,0,0.35), 0 0 0 1px rgba(16,185,129,0.35); }
.tab-btn.hdr-btn.active .tab-sub { color: #d1fae5 !important; }
@media (max-width: 380px) { .brand { font-size: 13px; gap: 5px; } .tab-btn.hdr-btn { min-width: 54px; padding: 4px 8px 3px; font-size: 11px; } }

/* 프로젝트 선택기 (라우터 모드) */
#projSel { display: none; position: relative; align-items: center; gap: 5px; }
#projSel.on { display: inline-flex; }
.proj-menu { position: absolute; top: 110%; left: 0; z-index: 9999; min-width: 240px; background: var(--card); border: 1px solid var(--border); border-radius: 12px; box-shadow: 0 12px 30px rgba(0,0,0,0.55); padding: 6px; display: none; }
.proj-menu.open { display: block; }
.proj-item { display: flex; align-items: center; gap: 10px; padding: 15px 12px; min-height: 48px; border-radius: 10px; font-size: 14px; font-weight: 700; color: #e2e8f0; cursor: pointer; }
.proj-item:active { background: rgba(79,127,255,0.25); }
.proj-item.cur { background: rgba(79,127,255,0.14); color: #fff; }
.proj-item .pdot { width: 8px; height: 8px; border-radius: 50%; background: #475569; flex-shrink: 0; }
.proj-item .pdot.on { background: #10b981; box-shadow: 0 0 6px #10b981; }
.proj-item .psub { margin-left: auto; font-size: 10px; color: var(--dim); font-weight: 600; }
.proj-add { border-top: 1px solid var(--border); margin-top: 4px; padding-top: 6px; color: #93c5fd; }

/* AI 탭 브랜드 색 (선택 탭 배경 = 그 회사 색, 모델명 = 그 회사 색의 밝은 톤) */
.tab-btn.w-claude .tab-sub { color: #F2A48A; }
.tab-btn.w-codex .tab-sub { color: #3ED2A8; }
.tab-btn.w-agy .tab-sub { color: #8AB4F8; }
.tab-btn.w-grok .tab-sub { color: #D1D5DB; }
.tab-btn.w-claude.active { background: linear-gradient(180deg, #E48D6E 0%, #C9643F 100%); border-color: #F2A48A; border-bottom-color: #8F4426; box-shadow: 0 0 0 #0b0f1c, inset 0 2px 5px rgba(0,0,0,0.3), 0 0 0 1px rgba(217,119,87,0.4); }
.tab-btn.w-codex.active { background: linear-gradient(180deg, #17B58C 0%, #0B8A69 100%); border-color: #3ED2A8; border-bottom-color: #085C46; box-shadow: 0 0 0 #0b0f1c, inset 0 2px 5px rgba(0,0,0,0.3), 0 0 0 1px rgba(16,163,127,0.4); }
.tab-btn.w-agy.active { background: linear-gradient(135deg, #4285F4 0%, #9B72CB 100%); border-color: #8AB4F8; border-bottom-color: #2B4FA0; box-shadow: 0 0 0 #0b0f1c, inset 0 2px 5px rgba(0,0,0,0.3), 0 0 0 1px rgba(66,133,244,0.4); }
.tab-btn.w-grok.active { background: linear-gradient(180deg, #F9FAFB 0%, #D1D5DB 100%); border-color: #FFFFFF; border-bottom-color: #6B7280; color: #111827; box-shadow: 0 0 0 #0b0f1c, inset 0 2px 5px rgba(0,0,0,0.15), 0 0 0 1px rgba(255,255,255,0.35); }
.tab-btn.w-grok.active .tab-sub { color: #374151 !important; }
.tab-btn.active:not(.w-grok) .tab-sub { color: #fff !important; opacity: 0.92; }

/* 도구 버튼(스캐너·프로젝트 사이트): 프로젝트 선택기(초록)와 구분 — 하늘색 계열 */
.tab-btn.hdr-btn.hdr-tool:not(.active) { background: linear-gradient(180deg, #1c3550 0%, #14283d 100%); border-color: #2f6b93; color: #bae6fd; }
.tab-btn.hdr-btn.hdr-tool .tab-sub { color: #7dd3fc !important; }
.tab-btn.hdr-btn.hdr-tool.active { background: linear-gradient(180deg, #38bdf8 0%, #0284c7 100%); border-color: #7dd3fc; border-bottom-color: #075985; color: #fff; box-shadow: 0 0 0 #0b0f1c, inset 0 2px 5px rgba(0,0,0,0.35), 0 0 0 1px rgba(56,189,248,0.35); }
.tab-btn.hdr-btn.hdr-tool.active .tab-sub { color: #e0f2fe !important; }

/* 스캐너 전략 탭 */
.strat-tab { flex: 0 0 auto; padding: 7px 11px; border-radius: 10px; font-size: 12px; font-weight: 800; color: #cbd5e1; background: linear-gradient(180deg, #273049 0%, #1a2136 100%); border: 1px solid #3a4667; border-bottom: 3px solid #0d1120; cursor: pointer; white-space: nowrap; display: inline-flex; align-items: center; gap: 6px; }
.strat-tab.active { color: #fff; background: linear-gradient(180deg, #10b981 0%, #0b8f63 100%); border-color: #34d399; border-bottom: 1px solid #065f46; transform: translateY(2px); }
.strat-tab.off { opacity: 0.45; }
.strat-tab .cnt { font-size: 10.5px; padding: 1px 6px; border-radius: 8px; background: rgba(255,255,255,0.14); }
.strat-row { display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 8px; padding: 8px 10px; font-size: 12.5px; }
.strat-switch { white-space: nowrap; flex-shrink: 0; margin-left: 8px; font-size: 11px; font-weight: 700; padding: 4px 9px; border-radius: 8px; border: 1px solid var(--border); background: rgba(255,255,255,0.06); color: #cbd5e1; cursor: pointer; }
.strat-switch.on { background: rgba(16,185,129,0.18); border-color: #10b981; color: #6ee7b7; }

/* 선택형 질문 보기 버튼 */
.ask-opt { text-align: left; font-family: -apple-system, BlinkMacSystemFont, 'Pretendard', 'Segoe UI', sans-serif; font-size: 12px; color: #e2e8f0; background: linear-gradient(180deg, #273049 0%, #1a2136 100%); border: 1px solid #3a4667; border-bottom: 3px solid #0d1120; border-radius: 9px; padding: 8px 10px; cursor: pointer; display: flex; flex-direction: column; gap: 2px; }
.ask-opt span { color: var(--dim); font-size: 10.5px; font-weight: 500; }
.ask-opt:active { transform: translateY(2px); border-bottom-width: 1px; background: var(--accent); color: #fff; }
.ask-opt:disabled { opacity: 0.45; cursor: default; }
.ask-opt.ask-mini { flex: 1; align-items: center; padding: 6px 4px; font-weight: 700; }

/* 메인 뷰 컨테이너 */
.view { flex: 1; min-height: 0; display: none; flex-direction: column; overflow: hidden; }
.view.active { display: flex; }

/* 1. 대화형 AI 뷰 (Claude Code & Codex & Antigravity 공통 적용) */
#chatContainer, #codexChatContainer, #agyChatContainer, #grokChatContainer {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.msg-bubble {
  max-width: 88%;
  padding: 12px 15px;
  border-radius: 16px;
  font-size: 14px;
  line-height: 1.55;
  word-break: break-word;
}
.msg-user {
  align-self: flex-end;
  background: linear-gradient(135deg, #3b82f6, #1d4ed8);
  color: #fff;
  border-bottom-right-radius: 4px;
}
.msg-ai {
  align-self: flex-start;
  background: var(--card);
  border: 1px solid var(--border);
  color: var(--text);
  border-bottom-left-radius: 4px;
}
:root { --c-claude: #F2A48A; --c-codex: #3ED2A8; --c-agy: #8AB4F8; --c-grok: #D1D5DB; }
.msg-title {
  font-weight: 700;
  font-size: 14px;
  color: var(--c-claude);
  margin-bottom: 6px;
}
.msg-body {
  white-space: pre-wrap;
}
.msg-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 10px;
}
.action-btn {
  background: rgba(79,127,255,0.15);
  border: 1px solid var(--accent);
  color: #fff;
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.action-btn.primary {
  background: var(--accent);
}

/* 단순화 모드 & 메시지 접기 스타일 */
.fold-btn {
  font-size: 11px;
  color: var(--accent-light);
  font-weight: 700;
  cursor: pointer;
  background: rgba(79,127,255,0.14);
  padding: 3px 8px;
  border-radius: 12px;
  border: 1px solid rgba(79,127,255,0.25);
  transition: all 0.2s;
  user-select: none;
}
.fold-btn:active {
  background: var(--accent);
  color: #fff;
}
.collapsed-body {
  max-height: 125px;
  overflow: hidden;
  position: relative;
  mask-image: linear-gradient(to bottom, black 60%, transparent 100%);
  -webkit-mask-image: linear-gradient(to bottom, black 60%, transparent 100%);
}
.history-banner {
  text-align: center;
  padding: 6px 0 12px;
  flex-shrink: 0;
}
.history-toggle-btn {
  background: rgba(255,255,255,0.06);
  border: 1px solid var(--border);
  color: var(--dim);
  font-size: 11.5px;
  font-weight: 600;
  padding: 5px 14px;
  border-radius: 20px;
  cursor: pointer;
}
.history-toggle-btn:active {
  background: rgba(79,127,255,0.18);
  color: #fff;
}
.mode-switch-btn {
  font-size: 11px;
  padding: 3px 9px;
  border-radius: 12px;
  border: 1px solid var(--border);
  background: rgba(255,255,255,0.06);
  color: var(--dim);
  cursor: pointer;
  font-weight: 700;
  transition: all 0.2s;
}
.mode-switch-btn.active {
  background: rgba(16,185,129,0.18);
  color: #10b981;
  border-color: #10b981;
}

/* 3단계 보기 모드 버튼 (요약 / 상세 / 전체) - 사진과 100% 동일한 디자인 */
.chat-mode-btn {
  flex: 1;
  text-align: center;
  background: rgba(255, 255, 255, 0.07);
  border: 1px solid rgba(255, 255, 255, 0.16);
  color: #cbd5e1;
  font-size: 12.5px;
  font-weight: 800;
  padding: 7px 0;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.15s ease;
  user-select: none;
  touch-action: manipulation;
}
.chat-mode-btn:active {
  transform: scale(0.97);
}
.chat-mode-btn.active {
  background: #2563eb !important;
  border-color: #3b82f6 !important;
  color: #ffffff !important;
  font-weight: 800 !important;
  box-shadow: 0 4px 14px rgba(37, 99, 235, 0.45) !important;
}

/* 빠른 추천 칩 (Chips) 바 */
.chips-bar {
  background: var(--surface);
  border-top: 1px solid var(--border);
  padding: 8px 12px;
  display: flex;
  gap: 8px;
  overflow-x: auto;
  white-space: nowrap;
  flex-shrink: 0;
}
.chip {
  background: var(--card);
  border: 1px solid var(--border);
  color: var(--dim);
  font-size: 12px;
  padding: 6px 12px;
  border-radius: 18px;
  cursor: pointer;
  font-weight: 600;
  flex-shrink: 0;
}
.chip:active { background: var(--accent); color: #fff; }

/* 🛑 긴급 정지 칩 — 평소엔 다른 칩과 같은 중립 모양(상태처럼 보이지 않게), 누를 때만 빨강 */
.chip-stop {
  margin-left: auto;
  background: var(--card);
  border: 1px solid var(--border);
  color: var(--dim);
  font-weight: 600;
}
.chip-stop:active {
  background: #dc2626;
  border-color: #dc2626;
  color: #fff;
}

/* ⏩ 계속 진행 칩 — 중립 모양, 아이콘만 하늘색. 누를 때만 파랑 */
.chip-continue {
  background: var(--card);
  border: 1px solid var(--border);
  color: var(--dim);
  font-weight: 600;
  box-shadow: none;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.chip-continue svg {
  fill: #38bdf8;
  display: inline-block;
  vertical-align: middle;
  flex-shrink: 0;
}
.chip-continue:active {
  background: var(--accent);
  border-color: var(--accent);
  color: #fff;
}
.chip-continue:active svg {
  fill: #fff;
}

/* 입력창 */
.chat-input-row {
  background: var(--surface);
  border-top: 1px solid var(--border);
  padding: 8px 10px;
  padding-bottom: calc(8px + env(safe-area-inset-bottom, 0px));
  display: flex;
  gap: 7px;
  align-items: center;
  flex-shrink: 0;
  position: relative;
  z-index: 99;
}
.composer-input {
  flex: 1;
  height: 38px;
  min-height: 38px;
  max-height: 160px;
  resize: none;
  overflow-y: auto;
  background: #111827;
  border: 1px solid rgba(148,163,184,0.28);
  border-radius: 12px;
  color: #ffffff;
  padding: 9px 12px;
  font-size: 14px !important;
  line-height: 20px !important;
  outline: none;
  white-space: pre-wrap;
  font-family: inherit;
  box-sizing: border-box;
  -webkit-appearance: none;
  appearance: none;
  user-select: text !important;
  -webkit-user-select: text !important;
  pointer-events: auto !important;
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);
  transition: border-color 0.16s ease;
}
.composer-input::placeholder {
  color: rgba(203,213,225,0.5);
  font-size: 13px;
}
.composer-input:focus {
  border-color: rgba(96,165,250,0.72);
  background: #151d2f;
}
.btn-send {
  background: #2563eb;
  color: #fff;
  border: none;
  padding: 10px 14px;
  border-radius: 12px;
  font-weight: 700;
  font-size: 13px;
  cursor: pointer;
  flex-shrink: 0;
  touch-action: manipulation;
}
.chat-input-row .btn-send {
  width: 38px;
  height: 38px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  border-radius: 12px;
  font-size: 0;
  box-shadow: 0 4px 12px rgba(37,99,235,0.34);
}
.chat-input-row .btn-send::before {
  content: '↑';
  font-size: 19px;
  line-height: 1;
  font-weight: 900;
}
.chat-input-row .btn-send:active {
  transform: scale(0.96);
}

/* 📎 스마트폰 파일/사진 통합 올리기 단일 클립 버튼 */
.btn-file-label {
  width: 38px;
  height: 38px;
  padding: 0;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  flex-shrink: 0;
  touch-action: manipulation;
  font-size: 18px;
  line-height: 1;
  user-select: none;
  transition: all 0.15s ease;
}
.btn-file-label:active {
  background: rgba(79, 127, 255, 0.3);
  border-color: #3b82f6;
  transform: scale(0.95);
}

/* 📎 클립 팝업 (사진 vs 파일 2개만 선택 모달) */
.clip-modal-backdrop {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.75);
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  z-index: 9999;
  align-items: flex-end;
  justify-content: center;
}
.clip-modal-backdrop.show {
  display: flex !important;
}
.clip-modal-content {
  background: #141c2e;
  border: 1px solid #28334e;
  border-radius: 16px 16px 0 0;
  width: 100%;
  max-width: 480px;
  padding: 12px 14px 16px;
  padding-bottom: calc(16px + env(safe-area-inset-bottom, 0px));
  box-shadow: 0 -8px 24px rgba(0, 0, 0, 0.7);
  animation: clipSlideUp 0.15s ease-out;
}
@keyframes clipSlideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.clip-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  padding-bottom: 6px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  color: #fff;
  font-size: 13.5px;
  font-weight: 700;
}
.clip-modal-close {
  background: none;
  border: none;
  color: #94a3b8;
  font-size: 20px;
  cursor: pointer;
  padding: 0 4px;
  line-height: 1;
}
.clip-modal-grid {
  display: flex;
  gap: 8px;
}
.clip-pick-btn {
  flex: 1;
  height: 42px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 7px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid var(--border);
  border-radius: 10px;
  color: #fff;
  font-size: 13px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.15s ease;
  touch-action: manipulation;
}
.clip-pick-btn:active {
  background: var(--accent);
  border-color: var(--accent);
  transform: scale(0.97);
}

/* 업로드 미리보기 배너 */
.upload-preview-bar {
  display: none;
  background: rgba(37,99,235,0.12);
  border: 1px dashed rgba(96,165,250,0.5);
  border-radius: 10px;
  padding: 6px 12px;
  margin: 0 10px 6px 10px;
  font-size: 11.5px;
  color: #93c5fd;
  justify-content: space-between;
  align-items: center;
}

/* 2. 원클릭 제어 카드 뷰 */
.card-scroll {
  padding: 16px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.m-card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 18px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.25);
}
.m-card h3 { font-size: 16px; color: #fff; margin-bottom: 8px; font-weight: 700; display: flex; align-items: center; gap: 8px; }
.m-card p { font-size: 13px; color: var(--dim); line-height: 1.6; margin-bottom: 14px; }
.card-btns { display: flex; gap: 8px; flex-wrap: wrap; }
.btn-link {
  display: inline-flex;
  align-items: center;
  background: rgba(255,255,255,0.06);
  border: 1px solid var(--border);
  color: #fff;
  text-decoration: none;
  font-size: 13px;
  font-weight: 600;
  padding: 9px 15px;
  border-radius: 8px;
  cursor: pointer;
}
.btn-link.primary {
  background: var(--accent);
  border-color: var(--accent);
}

/* 3. 터미널 뷰 */
#termOutput {
  flex: 1;
  background: #06080e;
  padding: 14px;
  overflow-y: auto;
  font-family: 'Fira Code', monospace;
  font-size: 12.5px;
  line-height: 1.55;
  white-space: pre-wrap;
  word-break: break-all;
  color: #cfd8dc;
}
.prompt-line { color: var(--accent-light); font-weight: 600; margin: 4px 0; }
.err-line { color: var(--danger); }
.sys-line { color: var(--win); font-style: italic; }

/* 모바일 툴바 */
.mobile-toolbar {
  background: var(--surface);
  border-top: 1px solid var(--border);
  padding: 6px 8px;
  display: flex;
  gap: 6px;
  overflow-x: auto;
  white-space: nowrap;
  flex-shrink: 0;
}
.tool-btn {
  background: var(--card);
  border: 1px solid var(--border);
  color: var(--text);
  font-size: 12px;
  font-family: 'Fira Code', monospace;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
}

/* 로그인 모달 */
#loginOverlay {
  position: fixed;
  inset: 0;
  background: rgba(11,14,23,0.98);
  z-index: 999;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 24px;
}
.login-box {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 18px;
  padding: 30px 24px;
  width: 100%;
  max-width: 340px;
  text-align: center;
}
.login-box h2 { font-size: 20px; font-weight: 800; margin-bottom: 8px; }
.login-box p { font-size: 13px; color: var(--dim); margin-bottom: 22px; }
#pinInput {
  width: 100%;
  background: var(--surface);
  border: 1.5px solid var(--border);
  border-radius: 12px;
  color: #fff;
  font-size: 26px;
  font-weight: 800;
  text-align: center;
  letter-spacing: 8px;
  padding: 12px;
  margin-bottom: 18px;
  outline: none;
}
#pinInput:focus { border-color: var(--accent); }
@media (max-width: 430px) { .tabs { gap: 4px; padding: 6px 5px 7px; } .tab-btn { font-size: 11px; letter-spacing: -0.3px; padding-left: 1px; padding-right: 1px; } .tab-sub { font-size: 9px; } }
@media (max-width: 380px) { .tabs { gap: 3px; padding: 6px 4px 7px; } .tab-btn { font-size: 10px; letter-spacing: -0.4px; } .tab-sub { font-size: 8.5px; } }
.tab-btn { overflow: hidden; }
.tabs:has(> .tab-btn:nth-child(6)) .tab-btn { font-size: 10px; letter-spacing: -0.4px; }
.tabs:has(> .tab-btn:nth-child(6)) .tab-sub { font-size: 8.5px; }
@media (max-width: 380px) { .tabs:has(> .tab-btn:nth-child(6)) .tab-btn { font-size: 9px; letter-spacing: -0.5px; } .tabs:has(> .tab-btn:nth-child(6)) .tab-sub { font-size: 8px; } }
</style>
</head>
<body>

<!-- 비밀번호 없이 1초 즉시 접속 -->

<!-- 최상단 듀얼 PC 원터치 탭 스위처 바 (단독/직통 접속 시 자동 노출) -->
<div id="pcDirectSwitchBar" class="pc-switch-bar" style="display:none;">
  <button id="pcDirectBtn-pc1" class="pc-nav-tab" onclick="navigateToPc1()">
    <span class="pc-dot" id="pcDirectDot-pc1"></span>
    <span id="pcDirectLabel-pc1">💻 PC 1번 (노트북 · M&A)</span>
  </button>
  <button id="pcDirectBtn-pc2" class="pc-nav-tab active" onclick="navigateToPc2()">
    <span class="pc-dot online"></span>
    <span>🖥️ PC 2번 (trader-bot)</span>
  </button>
</div>

<!-- 상단 헤더 -->
<div class="top-bar">
  <div class="top-bar-left">
    <span id="projSel"></span>
  </div>
  <div class="top-bar-right">
    ${PROJECT_TABS.map((t, i) => `<button class="tab-btn hdr-btn hdr-tool" id="projToolBtn${i}" onclick="${t.mode === 'run' ? ('runProjectTool(' + i + ')') : (t.mode === 'newtab' ? ("window.open('" + escapeAttr(t.url) + "', '_blank')") : "switchTab('project', this)")}">${escapeAttr(t.label)}<div class="tab-sub" id="projToolSub${i}" style="color:#34d399;">${escapeAttr(t.sub || '사이트')}</div></button>`).join('')}
    ${SHOW_SCANNER ? `<button class="tab-btn hdr-btn hdr-tool" id="tab-scanner" onclick="switchTab('scanner', this)">스캐너<div class="tab-sub" style="color:#38bdf8;">262종목</div></button>` : ''}
  </div>
</div>

<!-- 탭 메뉴 (플랩) -->
<div class="tabs">
  <button class="tab-btn w-claude active" onclick="switchTab('assistant', this)">Claude Code<div class="tab-sub">Opus 5</div></button>
  ${workerOn('codex') ? `<button class="tab-btn w-codex" onclick="switchTab('codex', this)">Codex<div class="tab-sub">GPT-5.6-terra</div></button>` : ''}
  ${workerOn('agy') ? `<button class="tab-btn w-agy" onclick="switchTab('agy', this)">Antigravity<div class="tab-sub">Gemini 3.8 Flash</div></button>` : ''}
  ${workerOn('grok') ? `<button class="tab-btn w-grok" onclick="switchTab('grok', this)">Grok<div class="tab-sub">grok-4.6</div></button>` : ''}
</div>

<!-- 1. Claude Code 뷰 (메인 워커: Opus 5 헤드리스 세션, 대화 맥락 영구 유지) -->
<div id="view-assistant" class="view active">
  <div style="background: rgba(16,185,129,0.1); border-bottom: 1px solid rgba(16,185,129,0.25); padding: 6px 14px; font-size: 11.5px; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;">
    <span id="syncSessionStatus" style="color: #F2A48A; font-weight: 700; display: flex; align-items: center; gap: 6px;">
      <span class="status-dot" style="width: 6px; height: 6px; background: #F2A48A;"></span>
      <span>대기</span>
    </span>
    <span style="display:flex; align-items:center; gap:6px;">
    <span id="quota-assistant" style="font-size:10.5px; color:#94a3b8; font-weight:600; white-space:nowrap;"></span>
    <span id="transMsgCountBadge" style="font-size: 11px; color: #94a3b8; font-weight: 700;">0개 메시지</span>
    </span>
  </div>
  <!-- 3단계 보기 모드 바 (요약 / 상세 / 전체) - 사진과 100% 동일한 디자인 -->
  <div style="background: rgba(11, 14, 23, 0.95); border-bottom: 1px solid var(--border); padding: 6px 12px; display: flex; gap: 6px; flex-shrink: 0;">
    <button id="modeBtn-summary" class="chat-mode-btn active" onclick="setChatViewMode('summary')">요약</button>
    <button id="modeBtn-detail" class="chat-mode-btn" onclick="setChatViewMode('detail')">상세</button>
    <button id="modeBtn-full" class="chat-mode-btn" onclick="setChatViewMode('full')">전체</button>
  </div>
  <div id="chatContainer">
    <div style="color: var(--dim); text-align: center; padding: 30px;">Claude Code (Opus 5) 세션을 실시간으로 불러오는 중...</div>
  </div>

  <!-- 추천 칩 (Chips) 바 -->
  <div class="chips-bar">
    <div class="chip" onclick="sendQuickInput('한 줄 결론만 말해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="10.7" width="14" height="2.8" rx="1.4" fill="#fbbf24"/><circle cx="20" cy="12.1" r="1.9" fill="#fbbf24"/></svg>한 줄 결론</div>
    <div class="chip" onclick="sendQuickInput('현재 작업 핵심만 3줄 요약해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="5" width="18" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="10.7" width="14" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="16.4" width="10" height="2.6" rx="1.3" fill="#38bdf8"/></svg>3줄 핵심 요약</div>
    <div class="chip chip-continue" onclick="sendQuickInput('작업 계속 진행해')"><svg width="13" height="13" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg><span>계속 진행</span></div>
    <div class="chip chip-stop" onclick="triggerEmergencyStop()" title="🛑 긴급 정지">🛑 긴급 정지</div>
  </div>

  <!-- 입력창 (단일 행 고정 입력창 + 📎 클립 팝업) -->
  <div id="uploadPreview-assistant" class="upload-preview-bar"></div>
  <div class="chat-input-row">
    <button type="button" class="btn-file-label" onclick="triggerPickOption('file', 'assistant')" title="사진/파일 올리기">📎</button>
    <input type="file" id="filePicker-assistant-file" onchange="handleMobileFileUpload(this, 'assistant', 'file')" accept="image/*,video/*,application/*,text/*" multiple style="display:none;">
    <textarea id="chatInput" class="composer-input" rows="1" placeholder="Claude Code (Opus 5)에 지시 입력..." enterkeyhint="send" autocomplete="off" autocorrect="off" autocapitalize="none"></textarea>
    <button class="btn-send" onclick="sendChatFromInput()" title="전송">전송</button>
    <!-- ★ PO 지시(2026-09-20): 입력창 옆에 정지/긴급 버튼 절대 추가 금지 — 긴급 정지는 칩 줄 하나뿐. 배포 빌드(build_dist.js)가 고정 정지 버튼 식별자를 발견하면 빌드 실패 -->
  </div>
</div>

<!-- 2. Codex 전용 뷰 (서브 워커 1: GPT-5.6-terra Medium 연동, 무인 자율 데몬) -->
<div id="view-codex" class="view">
  <div style="background: rgba(79,127,255,0.1); border-bottom: 1px solid rgba(79,127,255,0.25); padding: 6px 14px; font-size: 11.5px; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;">
    <span id="codexStatus" style="color: #3ED2A8; font-weight: 700; display: flex; align-items: center; gap: 6px;">
      <span class="status-dot" style="width: 6px; height: 6px; background: #3ED2A8;"></span>
      <span>대기</span>
    </span>
    <span id="quota-codex" style="font-size:10.5px; color:#94a3b8; font-weight:600; white-space:nowrap;"></span>
  </div>
  <div id="codexChatContainer">
    <div style="color: var(--dim); text-align: center; padding: 30px;">Codex (GPT-5.6-terra) 대기 중입니다. 코딩 명령을 내려보세요.</div>
  </div>

  <!-- 추천 칩 (Chips) 바 -->
  <div class="chips-bar">
    <div class="chip" onclick="sendCodexQuick('한 줄 결론만 말해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="10.7" width="14" height="2.8" rx="1.4" fill="#fbbf24"/><circle cx="20" cy="12.1" r="1.9" fill="#fbbf24"/></svg>한 줄 결론</div>
    <div class="chip" onclick="sendCodexQuick('현재 작업 핵심만 3줄 요약해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="5" width="18" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="10.7" width="14" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="16.4" width="10" height="2.6" rx="1.3" fill="#38bdf8"/></svg>3줄 핵심 요약</div>
    <div class="chip chip-continue" onclick="sendCodexQuick('작업 계속 진행해')"><svg width="13" height="13" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg><span>계속 진행</span></div>
    <div class="chip chip-stop" onclick="triggerEmergencyStop()" title="🛑 긴급 정지">🛑 긴급 정지</div>
  </div>

  <!-- 입력창 (단일 행 고정 입력창 + 📎 클립 팝업) -->
  <div id="uploadPreview-codex" class="upload-preview-bar"></div>
  <div class="chat-input-row">
    <button type="button" class="btn-file-label" onclick="triggerPickOption('file', 'codex')" title="사진/파일 올리기">📎</button>
    <input type="file" id="filePicker-codex-file" onchange="handleMobileFileUpload(this, 'codex', 'file')" accept="image/*,video/*,application/*,text/*" multiple style="display:none;">
    <textarea id="codexInput" class="composer-input" rows="1" placeholder="Codex (GPT-5.6-terra)에 명령 입력..." enterkeyhint="send" autocomplete="off" autocorrect="off" autocapitalize="none"></textarea>
    <button class="btn-send" onclick="sendCodexFromInput()" title="전송">전송</button>
  </div>
</div>

<!-- 3. Antigravity 전용 뷰 (서브 워커 2: agy -p 헤드리스, 무인 자동 승인) -->
<div id="view-agy" class="view">
  <div style="background: rgba(217,119,6,0.1); border-bottom: 1px solid rgba(217,119,6,0.25); padding: 6px 14px; font-size: 11.5px; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;">
    <span id="agyStatus" style="color: #8AB4F8; font-weight: 700; display: flex; align-items: center; gap: 6px;">
      <span class="status-dot" style="width: 6px; height: 6px; background: #8AB4F8;"></span>
      <span>대기</span>
    </span>
    <span id="quota-agy" style="font-size:10.5px; color:#94a3b8; font-weight:600; white-space:nowrap;"></span>
  </div>
  <div id="agyChatContainer">
    <div style="color: var(--dim); text-align: center; padding: 30px;">Antigravity (Gemini 3.8 Flash) 대기 중입니다. 코딩·분석 명령을 내려보세요.</div>
  </div>

  <!-- 추천 칩 (Chips) 바 -->
  <div class="chips-bar">
    <div class="chip" onclick="sendAgyQuick('한 줄 결론만 말해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="10.7" width="14" height="2.8" rx="1.4" fill="#fbbf24"/><circle cx="20" cy="12.1" r="1.9" fill="#fbbf24"/></svg>한 줄 결론</div>
    <div class="chip" onclick="sendAgyQuick('현재 작업 핵심만 3줄 요약해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="5" width="18" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="10.7" width="14" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="16.4" width="10" height="2.6" rx="1.3" fill="#38bdf8"/></svg>3줄 핵심 요약</div>
    <div class="chip chip-continue" onclick="sendAgyQuick('작업 계속 진행해')"><svg width="13" height="13" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg><span>계속 진행</span></div>
    <div class="chip chip-stop" onclick="triggerEmergencyStop()" title="🛑 긴급 정지">🛑 긴급 정지</div>
  </div>

  <!-- 입력창 (단일 행 고정 입력창 + 📎 클립 팝업) -->
  <div id="uploadPreview-agy" class="upload-preview-bar"></div>
  <div class="chat-input-row">
    <button type="button" class="btn-file-label" onclick="triggerPickOption('file', 'agy')" title="사진/파일 올리기">📎</button>
    <input type="file" id="filePicker-agy-file" onchange="handleMobileFileUpload(this, 'agy', 'file')" accept="image/*,video/*,application/*,text/*" multiple style="display:none;">
    <textarea id="agyInput" class="composer-input" rows="1" placeholder="Antigravity (Gemini 3.8 Flash)에 명령 입력..." enterkeyhint="send" autocomplete="off" autocorrect="off" autocapitalize="none"></textarea>
    <button class="btn-send" onclick="sendAgyFromInput()" title="전송">전송</button>
  </div>
</div>
<!-- 3G. Grok 전용 뷰 (서브 워커 3: grok -p 헤드리스, 무인 자동 승인) -->
<div id="view-grok" class="view">
  <div style="background: rgba(168,85,247,0.1); border-bottom: 1px solid rgba(168,85,247,0.25); padding: 6px 14px; font-size: 11.5px; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;">
    <span id="grokStatus" style="color: #D1D5DB; font-weight: 700; display: flex; align-items: center; gap: 6px;">
      <span class="status-dot" style="width: 6px; height: 6px; background: #D1D5DB;"></span>
      <span>대기</span>
    </span>
    <span id="quota-grok" style="font-size:10.5px; color:#94a3b8; font-weight:600; white-space:nowrap;"></span>
  </div>
  <div id="grokChatContainer">
    <div style="color: var(--dim); text-align: center; padding: 30px;">Grok (grok-4.6) 대기 중입니다. 코딩·분석 명령을 내려보세요.</div>
  </div>

  <!-- 추천 칩 (Chips) 바 -->
  <div class="chips-bar">
    <div class="chip" onclick="sendGrokQuick('한 줄 결론만 말해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="10.7" width="14" height="2.8" rx="1.4" fill="#fbbf24"/><circle cx="20" cy="12.1" r="1.9" fill="#fbbf24"/></svg>한 줄 결론</div>
    <div class="chip" onclick="sendGrokQuick('현재 작업 핵심만 3줄 요약해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="5" width="18" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="10.7" width="14" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="16.4" width="10" height="2.6" rx="1.3" fill="#38bdf8"/></svg>3줄 핵심 요약</div>
    <div class="chip chip-continue" onclick="sendGrokQuick('작업 계속 진행해')"><svg width="13" height="13" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg><span>계속 진행</span></div>
    <div class="chip chip-stop" onclick="triggerEmergencyStop()" title="🛑 긴급 정지">🛑 긴급 정지</div>
  </div>

  <!-- 입력창 (단일 행 고정 입력창 + 📎 클립 팝업) -->
  <div id="uploadPreview-grok" class="upload-preview-bar"></div>
  <div class="chat-input-row">
    <button type="button" class="btn-file-label" onclick="triggerPickOption('file', 'grok')" title="사진/파일 올리기">📎</button>
    <input type="file" id="filePicker-grok-file" onchange="handleMobileFileUpload(this, 'grok', 'file')" accept="image/*,video/*,application/*,text/*" multiple style="display:none;">
    <textarea id="grokInput" class="composer-input" rows="1" placeholder="Grok (grok-4.6)에 명령 입력..." enterkeyhint="send" autocomplete="off" autocorrect="off" autocapitalize="none"></textarea>
    <button class="btn-send" onclick="sendGrokFromInput()" title="전송">전송</button>
  </div>
</div>
${PROJECT_TAB ? `<!-- 3P. 프로젝트 사이트 탭 (console_config.json project_tab) -->
<div id="view-project" class="view" style="padding:0;">
  <div style="display:flex; align-items:center; justify-content:space-between; padding:6px 12px; background:rgba(16,185,129,0.08); border-bottom:1px solid rgba(16,185,129,0.25); font-size:11.5px; color:#34d399; font-weight:700;"><span>${escapeAttr(PROJECT_TAB.label)} · ${escapeAttr(PROJECT_TAB.url)}</span><a href="${escapeAttr(PROJECT_TAB.url)}" target="_blank" style="color:#93c5fd; text-decoration:none;">화면이 비면 새 창으로 열기 ↗</a></div>
  <iframe id="projectFrame" data-src="${escapeAttr(PROJECT_TAB.url)}" src="about:blank" style="flex:1; width:100%; border:none; background:#fff;" allow="clipboard-read; clipboard-write"></iframe>
</div>
` : ''}<!-- 4. 실시간 스캐너 전용 뷰 (262종목 5대장 2쫄병 필터) -->
<div id="view-scanner" class="view">
  <div style="background:var(--surface); border-bottom:1px solid var(--border); padding:10px 14px; display:flex; justify-content:space-between; align-items:center; flex-shrink:0;">
    <div style="display:flex; align-items:center; gap:8px;">
      <span style="font-size:13px; font-weight:800; color:#fff; white-space:nowrap;">📊 스캐너 262</span>
      <span id="scannerRunningBadge" style="font-size:10.5px; color:#10b981; font-weight:700;">● 정상 가동 중</span>
    </div>
    <div style="display:flex; gap:6px;">
      <button onclick="triggerScannerScan()" style="background:var(--accent); color:#fff; border:none; border-radius:8px; padding:6px 10px; font-size:12px; font-weight:700; cursor:pointer; white-space:nowrap;">▶ 재스캔</button>
      <button onclick="refreshScannerTab()" style="background:rgba(255,255,255,0.08); color:#cbd5e1; border:1px solid var(--border); border-radius:8px; padding:6px 10px; font-size:12px; font-weight:700; cursor:pointer;">🔄</button>
    </div>
  </div>
  <div id="scannerContentArea" style="flex:1; overflow-y:auto; padding:12px; display:flex; flex-direction:column; gap:12px;">
    <!-- 전략 (strategies/*.json) — 전략별 통과 종목 · 겹침 · 켜기/끄기 -->
    <div style="background:var(--card); border:1.5px solid rgba(16,185,129,0.45); border-radius:14px; padding:12px 14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span style="font-size:13.5px; font-weight:800; color:#34d399;">🧭 전략</span>
        <span id="stratMeta" style="font-size:11px; color:var(--dim); font-weight:600;"></span>
      </div>
      <div id="stratKis" style="font-size:11.5px; color:#fbbf24; margin-bottom:6px; line-height:1.4;"></div>
      <div id="stratTabs" style="display:flex; gap:6px; overflow-x:auto; padding-bottom:6px; margin-bottom:8px;"></div>
      <div id="stratDetail" style="display:flex; flex-direction:column; gap:6px;">
        <p style="color:var(--dim); font-size:12px; text-align:center; padding:8px;">전략 로딩 중...</p>
      </div>
      <div id="stratOverlap" style="margin-top:8px; font-size:11.5px; color:#fbbf24;"></div>
    </div>

    <!-- Stage 2 5대장 2쫄병 최종 통과 종목 -->
    <div style="background:var(--card); border:1.5px solid rgba(56,189,248,0.45); border-radius:14px; padding:14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <span style="font-size:13.5px; font-weight:800; color:#38bdf8;">👑 Stage 2 통과 종목 (5대장·2쫄병 일치)</span>
        <span id="scannerStage2Count" style="font-size:11px; color:#38bdf8; font-weight:700;">0종목</span>
      </div>
      <div id="scannerStage2List" style="display:flex; flex-direction:column; gap:6px;">
        <p style="color:var(--dim); font-size:12px; text-align:center; padding:10px;">통과 종목 로딩 중...</p>
      </div>
    </div>

    <!-- Stage 1 CALL 우세 종목 -->
    <div style="background:var(--card); border:1.5px solid var(--border); border-radius:14px; padding:14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <span style="font-size:13.5px; font-weight:800; color:#10b981;">🔥 Stage 1 CALL 포착 종목</span>
        <span id="scannerCallCount" style="font-size:11.5px; color:var(--dim);"></span>
      </div>
      <div id="scannerTopCallsList" style="display:flex; flex-direction:column; gap:6px;">
        <p style="color:var(--dim); font-size:12px; text-align:center; padding:15px;">스캐너 결과 로딩 중...</p>
      </div>
    </div>

    <!-- 실시간 진단 로그 -->
    <div style="background:var(--card); border:1.5px solid var(--border); border-radius:14px; padding:14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span style="font-size:13.5px; font-weight:800; color:#cbd5e1;">📋 실시간 진단 로그</span>
      </div>
      <div id="scannerLogsArea" style="background:#06080e; border:1px solid rgba(255,255,255,0.06); border-radius:8px; padding:10px; font-family:monospace; font-size:11.5px; color:#94a3b8; max-height:160px; overflow-y:auto; line-height:1.5;"></div>
    </div>
  </div>
</div>

<!-- 로그인 인증 모달 (PIN Authentication Modal) -->
<div id="loginOverlay" style="display: none; position: fixed; inset: 0; background: rgba(11, 14, 23, 0.98); z-index: 99999; flex-direction: column; justify-content: center; align-items: center; padding: 24px; backdrop-filter: blur(16px);">
  <div style="width: 100%; max-width: 340px; background: var(--surface); border: 1px solid var(--border); border-radius: 18px; padding: 26px 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.6); text-align: center;">
    <div style="font-size: 36px; margin-bottom: 10px;">🔐</div>
    <h3 style="font-size: 17px; font-weight: 800; color: #fff; margin-bottom: 6px;">원맥스 One MACS 접속</h3>
    <p style="font-size: 12.5px; color: var(--dim); margin-bottom: 16px;">console_config.json 에 설정한 PIN 번호를 입력해 주세요.</p>
    <input id="pinInput" type="text" maxlength="8" inputmode="numeric" placeholder="PIN 번호 입력" style="width: 100%; background: var(--card); border: 1.5px solid var(--border); border-radius: 12px; padding: 13px; color: #fff; font-size: 20px; font-weight: 800; text-align: center; letter-spacing: 6px; outline: none; margin-bottom: 12px; box-sizing: border-box;" onkeydown="if(event.key==='Enter') submitPinLogin()">
    <div id="pinError" style="font-size: 12px; color: var(--danger); margin-bottom: 12px; min-height: 16px; font-weight: 600;"></div>
    <button onclick="submitPinLogin()" style="width: 100%; background: var(--accent); color: #fff; border: none; border-radius: 12px; padding: 13px; font-size: 15px; font-weight: 800; cursor: pointer; margin-bottom: 10px; box-shadow: 0 4px 14px rgba(37,99,235,0.4);">접속 승인</button>
  </div>
</div>


<!-- 파일 탐색기 모달 (File Manager Modal) -->
<div id="fileModalOverlay" style="display: none; position: fixed; inset: 0; background: rgba(11, 14, 23, 0.96); z-index: 9998; flex-direction: column; padding: 12px 14px; backdrop-filter: blur(12px);">
  <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 4px 12px; border-bottom: 1px solid var(--border);">
    <div style="font-size: 15px; font-weight: 800; color: #fff; display: flex; align-items: center; gap: 6px;">
      <span>📂 프로젝트 파일 탐색기</span>
    </div>
    <button onclick="closeFileManager()" style="background: rgba(255,255,255,0.1); color: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 6px 12px; font-size: 12px; font-weight: 700; cursor: pointer;">✕ 닫기</button>
  </div>
  <div style="padding: 10px 0 6px;">
    <input id="fileSearchInput" type="text" placeholder="🔍 파일명 실시간 필터링..." oninput="filterFilesList()" style="width: 100%; background: var(--card); border: 1px solid var(--border); border-radius: 8px; padding: 8px 12px; color: #fff; font-size: 13px; outline: none; box-sizing: border-box;">
  </div>
  <div id="fileList" style="flex: 1; overflow-y: auto; padding: 6px 0 20px; display: flex; flex-direction: column; gap: 6px;">
    <p style="color: var(--dim); text-align: center; padding: 20px;">파일 목록 로딩 중...</p>
  </div>
</div>

<!-- 파일 편집기 오버레이 (File Editor Modal) -->
<div id="editorOverlay" style="display: none; position: fixed; inset: 0; background: rgba(11, 14, 23, 0.98); z-index: 9999; flex-direction: column; padding: 12px 14px; backdrop-filter: blur(12px);">
  <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 4px 12px; border-bottom: 1px solid var(--border);">
    <div style="font-size: 13.5px; font-weight: 800; color: var(--accent-light); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 60%;" id="editFileName">파일 편집</div>
    <div style="display: flex; gap: 6px;">
      <button onclick="saveCurrentFile()" style="background: var(--accent); color: #fff; border: none; border-radius: 8px; padding: 6px 12px; font-size: 12px; font-weight: 700; cursor: pointer;">💾 저장</button>
      <button onclick="closeEditor()" style="background: rgba(255,255,255,0.1); color: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 6px 12px; font-size: 12px; font-weight: 700; cursor: pointer;">✕ 닫기</button>
    </div>
  </div>
  <div style="flex: 1; padding: 10px 0; display: flex;">
    <textarea id="fileEditorArea" style="width: 100%; height: 100%; background: #070a12; border: 1px solid var(--border); border-radius: 8px; padding: 10px; color: #e2e8f0; font-family: monospace; font-size: 12.5px; line-height: 1.5; resize: none; outline: none; box-sizing: border-box;"></textarea>
  </div>
</div>

<script>
var NL = String.fromCharCode(10);
// 🛡️ 보안 토큰 동적 관리 (하드코딩 제거)
let token = localStorage.getItem('m_auth_token') || '';
let currentEditFile = '';

// URL 파라미터에서 pin/token 자동 감지 및 저장 (편의 지원)
(function() {
  try {
    var params = new URLSearchParams(window.location.search);
    var qToken = params.get('token') || params.get('pin');
    if (qToken) {
      token = qToken;
      localStorage.setItem('m_auth_token', token);
    }
    var qProj = params.get('project');
    if (qProj) localStorage.setItem('c_project', qProj);
  } catch (_) {}
})();

function showLoginOverlay(errMsg) {
  var overlay = document.getElementById('loginOverlay');
  var errEl = document.getElementById('pinError');
  if (overlay) {
    if (overlay.style.display === 'flex') {
      if (errMsg && errEl && !errEl.innerText) errEl.innerText = errMsg;
      return;
    }
    overlay.style.display = 'flex';
  }
  if (errEl) errEl.innerText = errMsg || '';
  var input = document.getElementById('pinInput');
  if (input) { input.value = ''; setTimeout(function() { input.focus(); }, 100); }
}


function hideLoginOverlay() {
  var overlay = document.getElementById('loginOverlay');
  if (overlay) overlay.style.display = 'none';
}

function closeFileManager() {
  var overlay = document.getElementById('fileModalOverlay');
  if (overlay) overlay.style.display = 'none';
}

async function submitPinLogin() {
  var input = document.getElementById('pinInput');
  var errEl = document.getElementById('pinError');
  var pin = (input ? input.value : '').trim();
  if (!pin) {
    if (errEl) errEl.innerText = 'PIN 번호를 입력해 주세요.';
    return;
  }
  try {
    var res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: pin })
    });
    var data = await res.json();
    if (data.success && data.token) {
      token = data.token;
      localStorage.setItem('m_auth_token', token);
      hideLoginOverlay();
      if (typeof initApp === 'function') initApp();
      if (typeof syncLiveTranscript === 'function') syncLiveTranscript();
      if (typeof syncCodexStatus === 'function') syncCodexStatus();
      if (typeof syncAgyStatus === 'function') syncAgyStatus();
    if (typeof syncGrokStatus === 'function') syncGrokStatus();
    } else {
      if (errEl) errEl.innerText = data.message || '인증 실패';
    }
  } catch (err) {
    if (errEl) errEl.innerText = '서버 통신 오류가 발생했습니다.';
  }
}

// 🛡️ 모바일 모든 API 요청에 보안 인증 토큰 자동 주입 및 401 감지 인터셉터
(function() {
  var _origFetch = window.fetch;
  window.fetch = async function(url, options) {
    options = options || {};
    options.headers = options.headers || {};
    var _proj = ''; try { _proj = localStorage.getItem('c_project') || ''; } catch (_) {}
    if (typeof options.headers.set === 'function') {
      if (!options.headers.get('Authorization') && token) options.headers.set('Authorization', token);
      if (_proj && !options.headers.get('X-Console-Project')) options.headers.set('X-Console-Project', encodeURIComponent(_proj));
    } else {
      if (!options.headers['Authorization'] && token) options.headers['Authorization'] = token;
      if (_proj && !options.headers['X-Console-Project']) options.headers['X-Console-Project'] = encodeURIComponent(_proj);
    }
    var res = await _origFetch.call(this, url, options);
    if (res.status === 401 && String(url).indexOf('/api/login') === -1) {
      showLoginOverlay('보안 인증이 필요합니다. PIN을 입력하세요.');
    }
    return res;
  };
})();

var pc1LiveUrl = '';

async function checkPcDevices() {
  try {
    var res = await fetch('/api/devices');
    if (res.ok) {
      var data = await res.json();
      var devMap = data.active_devices || {};
      var p1 = null;
      if (p1 && p1.url) {
        pc1LiveUrl = p1.url + (p1.url.indexOf('?') !== -1 ? '&' : '?') + 'pin=' + encodeURIComponent(token) + '';
        var lbl = document.getElementById('pcDirectLabel-pc1');
        if (lbl) lbl.innerText = '💻 PC 1번 (' + (p1.project || 'M&A') + ')';
        var dot = document.getElementById('pcDirectDot-pc1');
        if (dot) dot.classList.add('online');
      }
    }
  } catch (_) {}
}

function navigateToPc1() {
  if (pc1LiveUrl) {
    window.location.href = pc1LiveUrl;
  } else {
    alert('허브 미설정');
  }
}

function navigateToPc2() {
  // 이미 PC 2번 화면
}

window.addEventListener('DOMContentLoaded', function() {
  if (!token) {
    showLoginOverlay();
  }
  checkPcDevices();
  setInterval(checkPcDevices, 5000);
  refreshQuota(); setInterval(refreshQuota, 60000);
  loadProjects(); setInterval(loadProjects, 15000);
});

// 프로젝트 도구 실행 버튼(project_tab.mode === 'run') — PC 에서 설정된 실행 파일을 띄운다
async function runProjectTool(i) {
  var sub = document.getElementById('projToolSub' + (i || 0));
  var prev = sub ? sub.textContent : '';
  if (sub) sub.textContent = '실행 중...';
  try {
    var res = await fetch('/api/project-run?i=' + (i || 0), { method: 'POST' });
    var d = await res.json();
    if (sub) sub.textContent = d.success ? '실행됨 ' + d.at : (d.error || '실패');
  } catch (e) {
    if (sub) sub.textContent = '통신 오류';
  }
  setTimeout(function () { if (sub) sub.textContent = prev; }, 6000);
}

function switchTab(name, el) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  var targetView = document.getElementById('view-' + name);
  if (targetView) targetView.classList.add('active');
  if (el) el.classList.add('active');
  if (name === 'codex') syncCodexStatus();
  if (name === 'agy') syncAgyStatus();
  if (name === 'grok') syncGrokStatus();
  if (name === 'scanner') refreshScannerTab();
  if (name === 'project') { var pf = document.getElementById('projectFrame'); if (pf && pf.src === 'about:blank') pf.src = pf.dataset.src; }
}

// 프로젝트 선택기 — 라우터 모드(/api/projects 200)일 때만 켜짐
var projList = [];
async function loadProjects() {
  var box = document.getElementById('projSel'); if (!box) return;
  try {
    var r = await fetch('/api/projects'); if (!r.ok) { box.classList.remove('on'); return; }
    var d = await r.json(); projList = d.projects || []; if (!projList.length) return;
    var cur = projList.find(function (p) { return p.current; }) || projList[0];
    var items = projList.map(function (p) {
      return '<div class="proj-item' + (p.current ? ' cur' : '') + '" onclick="selectProject(&quot;' + escapeHtml(p.name) + '&quot;)"><span class="pdot' + (p.windowPid ? ' on' : '') + '"></span><span>' + escapeHtml(p.name) + '</span><span class="psub">' + (p.isDefault ? '기본' : (p.windowPid === 'daemon' ? '데몬' : (p.windowPid ? '' : (p.alive ? '창 없음' : '준비 중')))) + '</span></div>';
    }).join('');
    // 이 프로젝트 전용 화면(스캐너 등)은 헤더 버튼 대신 메뉴 항목으로 — 헤더에는 [현재 프로젝트 ▾] [＋] 만
    // 프로젝트 전용 도구(스캐너 등)는 헤더에 선택기 옆 버튼으로 남긴다 — 그 프로젝트의 서버가 렌더하므로 다른 프로젝트에선 자동으로 없음
    var tools = '';
    box.innerHTML = '<button class="tab-btn hdr-btn" onclick="toggleProjMenu(event)">' + escapeHtml(cur.name) + ' ▾</button>'
      + '<div class="proj-menu" id="projMenu">' + items + tools + '<div class="proj-item proj-add" onclick="addProject()">＋ 프로젝트 추가</div></div>'; // 추가는 메뉴 안 한 곳만
    box.classList.add('on');
  } catch (_) { box.classList.remove('on'); }
}
function toggleProjMenu(ev) { if (ev) ev.stopPropagation(); var m = document.getElementById('projMenu'); if (m) m.classList.toggle('open'); }
document.addEventListener('click', function () { var m = document.getElementById('projMenu'); if (m) m.classList.remove('open'); });
function gotoProject(name) {
  try { localStorage.setItem('c_project', name); } catch (_) {}
  var u = new URL(location.href); u.searchParams.set('project', name); if (token) u.searchParams.set('pin', token);
  location.replace(u.toString());
}
async function selectProject(name) {
  try {
    var r = await fetch('/api/project-select?name=' + encodeURIComponent(name) + '&project=' + encodeURIComponent(name)); var d = await r.json();
    if (!d.success) { showToast('전환 실패: ' + (d.error || '')); return; }
    showToast('프로젝트 → ' + name);
    try { localStorage.setItem('c_project', name); await fetch('/api/main-restart?project=' + encodeURIComponent(name), { method: 'POST' }); } catch (_) {}
    setTimeout(function () { gotoProject(name); }, 300);
  } catch (e) { showToast('전환 오류'); }
}
async function addProject() {
  var name = prompt('새 프로젝트 이름 (PC에 같은 이름의 폴더가 만들어집니다)'); if (!name) return;
  showToast('프로젝트 만드는 중…');
  try {
    var r = await fetch('/api/project-add', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: name.trim() }) });
    var d = await r.json();
    if (!d.success) { showToast('추가 실패: ' + (d.error || '')); return; }
    showToast('추가됨: ' + d.name + (d.alive ? '' : ' (기동 중)'));
    setTimeout(function () { gotoProject(d.name); }, 800);
  } catch (e) { showToast('추가 오류'); }
}

// 선택형 질문 보기 버튼 → PC 창 위젯 조작 (DOWN × n → ENTER)
var askBusy = false;
async function askKeys(keys) {
  if (askBusy) return; askBusy = true;
  try { var r = await fetch('/api/main-keys', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ keys: keys }) }); var d = await r.json(); if (!d.success) showToast('전송 실패: ' + (d.error || '')); }
  catch (_) { showToast('전송 오류'); } finally { askBusy = false; }
}
function askPick(i, n, multi) {
  // PC 창 선택 위젯: 단일 선택은 ENTER 가 곧 답. 복수 선택은 ENTER 가 체크/해제(토글)이고, 제출은 → 로 Submit 에 간 뒤 ENTER.
  // 복수 선택은 커서가 마지막 토글 위치에 남으므로 UP×n 으로 맨 위로 올린 뒤 DOWN×i 로 절대 위치를 잡는다.
  var keys = [];
  if (multi) { for (var u = 0; u < n + 1; u++) keys.push('UP'); }
  for (var k = 0; k < i; k++) keys.push('DOWN'); keys.push('ENTER');
  showToast(multi ? ((i + 1) + '번 체크/해제 → 다 고르면 [제출]') : ((i + 1) + '번 선택 → PC 창'));
  askKeys(keys);
}
function askSubmitMulti() { showToast('제출 → PC 창'); askKeys(['RIGHT', 'ENTER']); }

// 구독 잔여 한도(5h/7d) 표시 — 남은 % 기준. 조회 불가 워커는 빈칸
function fmtReset(iso) {
  if (!iso) return '';
  var d = new Date(iso); if (isNaN(d)) return '';
  var hh = ('0' + d.getHours()).slice(-2), mm = ('0' + d.getMinutes()).slice(-2);
  var today = new Date();
  var sameDay = d.getFullYear() === today.getFullYear() && d.getMonth() === today.getMonth() && d.getDate() === today.getDate();
  return sameDay ? (hh + ':' + mm) : ((d.getMonth() + 1) + '/' + d.getDate() + ' ' + hh + ':' + mm);
}
function quotaText(w) {
  if (!w || w.supported === false) return '';
  if (!w.ok) return '한도 조회 실패';
  var col = function (p) { return p <= 10 ? '#f87171' : (p <= 30 ? '#fbbf24' : '#a7f3d0'); };
  var part = function (name, o) { return o ? name + ' <b style="color:' + col(o.left) + ';">' + o.left + '%</b>' : ''; };
  var t = '남은 ' + part('5h', w.h5) + (w.h5 && w.d7 ? ' · ' : '') + part('7d', w.d7);
  // 리셋 시각은 폭 절약을 위해 표시 생략 (fmtReset 은 필요 시 사용)
  return t;
}
async function refreshQuota() {
  try {
    var res = await fetch('/api/quota');
    var q = await res.json();
    var map = { assistant: q.claude, codex: q.codex, agy: q.agy, grok: q.grok };
    Object.keys(map).forEach(function (k) { var el = document.getElementById('quota-' + k); if (el) el.innerHTML = quotaText(map[k]); });
  } catch (_) {}
}

async function triggerScannerScan() {
  var badge = document.getElementById('scannerRunningBadge');
  if (badge) {
    badge.innerText = '⚡ 스캔 중...';
    badge.style.borderColor = '#f59e0b';
    badge.style.color = '#f59e0b';
  }
  try {
    await fetch('/api/scanner-scan', { method: 'POST' });
    setTimeout(refreshScannerTab, 1500);
  } catch (_) {}
}

// ---- 스캐너 전략 탭 (strategies/*.json) ----
var stratState = { data: null, sel: null };
function stratTag(st) { return st.sample ? '샘플' : (st.live ? '실매매' : ''); }
async function loadStrategies() {
  try {
    var r = await fetch('/api/scanner-strategies'); var d = await r.json();
    stratState.data = d;
    var list = d.strategies || [];
    var meta = document.getElementById('stratMeta'); if (meta) meta.innerText = list.length ? (list.filter(function (x) { return x.enabled; }).length + '/' + list.length + '개 켜짐' + (d.finished_at ? ' · ' + String(d.finished_at).slice(11, 16) + ' 스캔' : '')) : '';
    var kisEl = document.getElementById('stratKis'); if (kisEl) kisEl.innerHTML = (d.kis_configured === false) ? '⚠️ 증권사(KIS) 앱키 미등록 — 1단계(네이버 분봉) 스캔만 동작하고 2단계 정밀 신호·실매매는 꺼져 있습니다. <b>.env</b> 에 KIS_APP_KEY / KIS_APP_SECRET / KIS_ACCOUNT 를 넣으면 켜집니다.' : '';
    if (!stratState.sel || !list.some(function (x) { return x.id === stratState.sel; })) stratState.sel = list.length ? list[0].id : null;
    var tabs = document.getElementById('stratTabs');
    if (tabs) tabs.innerHTML = list.map(function (st) {
      return '<div class="strat-tab' + (st.id === stratState.sel ? ' active' : '') + (st.enabled ? '' : ' off') + '" onclick="selectStrategy(&quot;' + escapeHtml(st.id) + '&quot;)">' + escapeHtml(st.name || st.id) + '<span class="cnt">' + (st.hits ? st.hits.length : 0) + '</span></div>';
    }).join('');
    renderStrategyDetail();
    var ov = document.getElementById('stratOverlap');
    if (ov) { var keys = Object.keys(d.overlap || {}); ov.innerHTML = keys.length ? '⭐ 겹침 ' + keys.length + '종목: ' + keys.map(function (k) { var o = d.overlap[k]; return escapeHtml(o.name || k) + '(' + o.strategies.map(escapeHtml).join('+') + ')'; }).join(', ') : ''; }
  } catch (_) {}
}
function selectStrategy(id) { stratState.sel = id; loadStrategies(); }
function renderStrategyDetail() {
  var box = document.getElementById('stratDetail'); if (!box || !stratState.data) return;
  var st = (stratState.data.strategies || []).find(function (x) { return x.id === stratState.sel; });
  if (!st) { box.innerHTML = '<p style="color:var(--dim); font-size:12px; text-align:center; padding:8px;">strategies/ 폴더에 전략 파일이 없습니다. Claude Code에게 "전략 만들어줘"라고 말하세요.</p>'; return; }
  var head = '<div class="strat-row" style="background:rgba(16,185,129,0.06);"><div><b style="color:#fff;">' + escapeHtml(st.name || st.id) + '</b> <span style="color:var(--dim); font-size:11px;">' + escapeHtml(st.direction || '') + ' · 대장 ' + st.n_bosses + ' · 쫄병 ' + st.n_soldiers + ' · ' + st.min_score + '점↑' + (stratTag(st) ? ' · ' + stratTag(st) : '') + '</span>'
    + (st.description ? '<div style="color:var(--dim); font-size:11px; margin-top:3px;">' + escapeHtml(st.description) + '</div>' : '')
    + (st.errors && st.errors.length ? '<div style="color:#f87171; font-size:11px; margin-top:3px;">오류: ' + escapeHtml(st.errors.join(' / ')) + '</div>' : '') + '</div>'
    + '<button class="strat-switch' + (st.enabled ? ' on' : '') + '" onclick="toggleStrategy(&quot;' + escapeHtml(st.id) + '&quot;, ' + (st.enabled ? 'false' : 'true') + ')">' + (st.enabled ? '켜짐' : '꺼짐') + '</button></div>';
  var hits = st.hits || [];
  var rows = hits.length ? hits.map(function (h) {
    var rc = (h.rate || 0) > 0 ? '#ef4444' : ((h.rate || 0) < 0 ? '#3b82f6' : '#94a3b8');
    return '<div class="strat-row"><div><b style="color:#fff;">' + escapeHtml(h.name || h.code) + '</b> <span style="color:var(--dim); font-size:11px;">' + escapeHtml(h.code || '') + '</span></div><div style="text-align:right;"><div style="font-weight:800; color:#34d399;">' + h.score + '점</div><div style="font-size:11px; color:' + rc + ';">' + (h.price ? Number(h.price).toLocaleString() + '원 ' : '') + ((h.rate || 0) > 0 ? '+' : '') + (h.rate || 0) + '%</div></div></div>';
  }).join('') : '<p style="color:var(--dim); font-size:12px; text-align:center; padding:8px;">' + (st.enabled ? '최근 스캔에서 이 전략을 통과한 종목 없음' : '꺼진 전략 — 켜면 다음 스캔부터 평가') + '</p>';
  box.innerHTML = head + rows;
}
async function toggleStrategy(id, on) {
  try {
    var r = await fetch('/api/scanner-strategy-toggle/' + encodeURIComponent(id), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: on }) });
    var d = await r.json(); showToast(d.success ? ('전략 ' + id + (d.enabled ? ' 켜짐' : ' 꺼짐') + ' (다음 스캔부터)') : ('실패: ' + (d.error || '')));
    loadStrategies();
  } catch (_) { showToast('전환 오류'); }
}

async function refreshScannerTab() {
  loadStrategies();
  var listEl = document.getElementById('scannerTopCallsList');
  var stage2ListEl = document.getElementById('scannerStage2List');
  var stage2CountEl = document.getElementById('scannerStage2Count');
  var badge = document.getElementById('scannerRunningBadge');
  var logsEl = document.getElementById('scannerLogsArea');
  var countEl = document.getElementById('scannerCallCount');
  try {
    var res = await fetch('/api/scanner-status');
    var data = await res.json();
    if (!data) return;

    if (badge) {
      if (data.running) {
        badge.innerText = '⚡ 스캔 분석 진행 중...';
        badge.style.borderColor = '#f59e0b';
        badge.style.color = '#f59e0b';
      } else {
        badge.innerText = '● 정상 가동 (스캔 완료)';
        badge.style.borderColor = '#10b981';
        badge.style.color = '#10b981';
      }
    }

    if (logsEl && data.logs && data.logs.length > 0) {
      logsEl.innerHTML = data.logs.map(l => '<div>' + escapeHtml(l) + '</div>').join('');
      logsEl.scrollTop = logsEl.scrollHeight;
    }

    // 1. Stage 2 5대장 2쫄병 통과 종목 렌더링
    if (stage2ListEl) {
      var s2 = data.stage2 || [];
      if (stage2CountEl) stage2CountEl.innerText = s2.length + '종목';
      if (s2.length === 0) {
        stage2ListEl.innerHTML = '<p style="color:var(--dim); font-size:12px; text-align:center; padding:10px;">현재 5대장/2쫄병 조건을 모두 충족한 Stage 2 종목이 없습니다.</p>';
      } else {
        var s2Html = '';
        s2.forEach((item, idx) => {
          var rateColor = item.rate > 0 ? '#ef4444' : (item.rate < 0 ? '#3b82f6' : '#94a3b8');
          var rateSign = item.rate > 0 ? '+' : '';
          s2Html += '<div style="background:rgba(56,189,248,0.06); border:1px solid rgba(56,189,248,0.3); border-radius:8px; padding:10px 12px; display:flex; justify-content:space-between; align-items:center;">';
          s2Html += '  <div>';
          s2Html += '    <div style="font-weight:800; font-size:13.5px; color:#fff; display:flex; align-items:center; gap:6px;">';
          s2Html += '      <span style="color:#38bdf8;">' + (idx+1) + '. ' + escapeHtml(item.name || item.code) + '</span>';
          s2Html += '      <span style="font-size:10px; color:var(--dim); font-family:monospace;">' + item.code + '</span>';
          s2Html += '    </div>';
          s2Html += '    <div style="font-size:11px; color:#94a3b8; margin-top:3px;">5대장: <b style="color:#38bdf8;">' + (item.boss || 0) + '/5</b> | 2쫄병: <b style="color:#38bdf8;">' + (item.soldier || 0) + '/2</b> | 점수: <b style="color:#10b981;">' + (item.score || 0) + '점</b></div>';
          s2Html += '  </div>';
          s2Html += '  <div style="text-align:right;">';
          s2Html += '    <div style="font-weight:800; font-size:13px; color:#fff;">' + Number(item.price || 0).toLocaleString() + '원</div>';
          s2Html += '    <div style="font-weight:700; font-size:11.5px; color:' + rateColor + ';">' + rateSign + (item.rate || 0).toFixed(2) + '%</div>';
          s2Html += '  </div>';
          s2Html += '</div>';
        });
        stage2ListEl.innerHTML = s2Html;
      }
    }

    // 2. Stage 1 CALL 우세 종목 렌더링
    var calls = [];
    if (data.stage1 && data.stage1.length > 0) {
      calls = data.stage1.filter(s => (s.call_score >= 40 || s.passed));
      calls.sort((a,b) => (b.call_score - a.call_score) || (b.rate - a.rate));
    }

    if (countEl) countEl.innerText = '총 ' + calls.length + '종목 포착';

    if (listEl) {
      if (calls.length === 0) {
        listEl.innerHTML = '<p style="color:var(--dim); font-size:12px; text-align:center; padding:15px;">현재 조건을 만족하는 CALL 종목이 없습니다.</p>';
      } else {
        var html = '';
        calls.slice(0, 20).forEach((c, idx) => {
          var rateColor = c.rate > 0 ? '#ef4444' : (c.rate < 0 ? '#3b82f6' : '#94a3b8');
          var rateSign = c.rate > 0 ? '+' : '';
          html += '<div style="background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:8px; padding:9px 12px; display:flex; justify-content:space-between; align-items:center;">';
          html += '  <div>';
          html += '    <div style="font-weight:800; font-size:13px; color:#fff; display:flex; align-items:center; gap:6px;">';
          html += '      <span>' + (idx+1) + '. ' + escapeHtml(c.name || c.code) + '</span>';
          html += '      <span style="font-size:10px; color:var(--dim); font-family:monospace;">' + c.code + '</span>';
          html += '    </div>';
          html += '    <div style="font-size:11px; color:#10b981; margin-top:2px; font-weight:700;">★ CALL 점수: ' + (c.call_score || 50) + '점</div>';
          html += '  </div>';
          html += '  <div style="text-align:right;">';
          html += '    <div style="font-weight:800; font-size:13px; color:#fff;">' + Number(c.price || 0).toLocaleString() + '원</div>';
          html += '    <div style="font-weight:700; font-size:11.5px; color:' + rateColor + ';">' + rateSign + (c.rate || 0).toFixed(2) + '%</div>';
          html += '  </div>';
          html += '</div>';
        });
        listEl.innerHTML = html;
      }
    }
  } catch (e) {
    if (listEl) listEl.innerHTML = '<p style="color:var(--danger); font-size:12px; text-align:center; padding:15px;">스캐너 조회 중 오류가 발생했습니다.</p>';
  }
}

async function loadSystemView() {
  refreshHostSystemStats();
  refreshSysFilesList();
}

async function refreshHostSystemStats() {
  try {
    var res = await fetch('/api/info');
    var data = await res.json();
    if (data) {
      if (document.getElementById('statHostname')) document.getElementById('statHostname').innerText = data.hostname || 'Windows';
      if (document.getElementById('statUptime')) document.getElementById('statUptime').innerText = (data.uptimeHours || 0) + '시간';
      if (document.getElementById('statRam')) document.getElementById('statRam').innerText = (data.freeMemMB || 0) + 'MB / ' + (data.totalMemMB || 0) + 'MB';
      if (document.getElementById('statCores')) document.getElementById('statCores').innerText = (navigator.hardwareConcurrency || 8) + ' Cores';
      if (document.getElementById('statWorkDir')) document.getElementById('statWorkDir').innerText = data.workDir || '';
    }
  } catch (_) {}
}

let allSysFiles = [];
async function refreshSysFilesList() {
  var listEl = document.getElementById('sysFileList');
  if (!listEl) return;
  listEl.innerHTML = '<p style="color: var(--dim); text-align: center; padding: 15px;">파일 로딩 중...</p>';
  try {
    var res = await fetch('/api/files');
    var data = await res.json();
    if (data.success && data.files) {
      allSysFiles = data.files;
      renderSysFiles(allSysFiles);
    } else {
      listEl.innerHTML = '<p style="color: var(--dim); text-align: center; padding: 15px;">파일이 없습니다.</p>';
    }
  } catch (err) {
    listEl.innerHTML = '<p style="color: var(--danger); text-align: center; padding: 15px;">파일 조회 오류</p>';
  }
}

function renderSysFiles(files) {
  var listEl = document.getElementById('sysFileList');
  if (!listEl) return;
  if (!files || files.length === 0) {
    listEl.innerHTML = '<p style="color: var(--dim); text-align: center; padding: 15px;">파일이 없습니다.</p>';
    return;
  }
  var html = '';
  files.forEach(function(f) {
    var isDir = f.isDir || f.isDirectory;
    var icon = isDir ? '📁' : '📄';
    var clickAction = isDir ? '' : 'data-fname="' + encodeURIComponent(f.name) + '" onclick="openFileFromSystemTab(this.getAttribute(&quot;data-fname&quot;))" style="cursor:pointer;"';
    html += '<div class="m-card" ' + clickAction + ' style="margin-bottom: 4px; padding: 8px 10px; display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 8px;">';
    html += '  <div style="display: flex; align-items: center; gap: 8px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">';
    html += '    <span>' + icon + '</span>';
    html += '    <span style="font-size: 12px; font-weight: 600; color: #e2e8f0;">' + escapeHtml(f.name) + '</span>';
    html += '  </div>';
    html += '  <span style="font-size: 10px; color: var(--dim);">' + (isDir ? '폴더' : (f.size ? Math.round(f.size/1024) + ' KB' : '')) + '</span>';
    html += '</div>';
  });
  listEl.innerHTML = html;
}

function filterSysFilesList() {
  var q = (document.getElementById('sysFileSearch')?.value || '').toLowerCase().trim();
  if (!q) {
    renderSysFiles(allSysFiles);
    return;
  }
  var filtered = allSysFiles.filter(function(f) {
    return f.name.toLowerCase().indexOf(q) !== -1;
  });
  renderSysFiles(filtered);
}

function openFileFromSystemTab(encodedName) {
  var fileName = decodeURIComponent(encodedName);
  openFileEditor(fileName);
}

var isAppInitialized = false;
async function initApp() {
  if (isAppInitialized) return;
  isAppInitialized = true;
  try {
    var res = await fetch('/api/info', { headers: { 'Authorization': token } });
    var info = await res.json();
    if (info.hostname) {
      var hostEl = document.getElementById('hostName'); if (hostEl) hostEl.innerText = info.hostname;
      document.getElementById('memStatus').innerText = 'RAM: ' + info.freeMemMB + 'MB free';
    }
  } catch (_) {}

  // 실시간 대화 트랜스크립트 1.2초 주기 자동 동기화 가동
  syncLiveTranscript();
  setInterval(syncLiveTranscript, 1200);

  // Codex 실시간 상태 및 대화내역 1.5초 주기 자동 동기화 가동
  syncCodexStatus();
  setInterval(syncCodexStatus, 1500);

  // Antigravity(서브 워커 2) 실시간 상태 및 대화내역 1.5초 주기 자동 동기화 가동
  syncAgyStatus();
  setInterval(syncAgyStatus, 1500);
  syncGrokStatus();
  setInterval(syncGrokStatus, 1500);

  // 실시간 스캐너 상태 및 포착 종목 3초 주기 자동 동기화 가동
  refreshScannerTab();
  setInterval(refreshScannerTab, 3000);
}

function escapeHtml(text) {
  var map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
  return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
}

function resizeComposer(input) {
  if (!input) return;
  input.style.height = '38px';
}

function autoGrow(el) {
  if (!el) return;
  if (!el.value) { el.style.height = '38px'; return; }
  el.style.height = 'auto';
  el.style.height = Math.min(160, Math.max(38, el.scrollHeight)) + 'px';
}
function resetComposer(input) {
  if (!input) return;
  input.value = '';
  autoGrow(input);
}

function bindComposer(id, submitFn) {
  var input = document.getElementById(id);
  if (!input) return;
  input.addEventListener('input', function() { autoGrow(input); });
  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submitFn();
    }
  });
  autoGrow(input);
}

function formatMarkdownToHtml(md) {
  if (!md) return '';
  var text = escapeHtml(md);
  var tick3 = String.fromCharCode(96, 96, 96);
  var tick1 = String.fromCharCode(96);

  // Mermaid 다이어그램 변환
  var mParts = text.split(tick3 + 'mermaid');
  if (mParts.length > 1) {
    var mergedM = mParts[0];
    for (var mi = 1; mi < mParts.length; mi++) {
      var endM = mParts[mi].indexOf(tick3);
      if (endM !== -1) {
        mergedM += '<div style="background:rgba(79,127,255,0.12); border:1px solid rgba(79,127,255,0.3); padding:6px 10px; border-radius:8px; font-size:11.5px; color:var(--accent-light); margin:6px 0; font-weight:600;">📊 [구조 다이어그램 요약]</div>' + mParts[mi].substring(endM + 3);
      } else {
        mergedM += mParts[mi];
      }
    }
    text = mergedM;
  }

  // 코드 블록 변환
  var cParts = text.split(tick3);
  if (cParts.length > 1) {
    var mergedC = '';
    for (var ci = 0; ci < cParts.length; ci++) {
      if (ci % 2 === 1) {
        var rawCode = cParts[ci];
        var firstBreak = rawCode.indexOf(NL);
        if (firstBreak !== -1 && firstBreak < 15) {
          rawCode = rawCode.substring(firstBreak + 1);
        }
        mergedC += '<pre style="background:#090d16; border:1px solid #202a42; border-radius:8px; padding:8px; overflow-x:auto; font-size:11.5px; font-family:monospace; margin:6px 0; color:#e2e8f0; max-height:220px;"><code>' + rawCode.trim() + '</code></pre>';
      } else {
        mergedC += cParts[ci];
      }
    }
    text = mergedC;
  }

  // 인라인 코드
  var iParts = text.split(tick1);
  if (iParts.length > 1) {
    var mergedI = '';
    for (var ii = 0; ii < iParts.length; ii++) {
      if (ii % 2 === 1) {
        mergedI += '<code style="background:rgba(255,255,255,0.08); padding:1px 5px; border-radius:4px; font-size:11.5px; color:#93c5fd; font-family:monospace;">' + iParts[ii] + '</code>';
      } else {
        mergedI += iParts[ii];
      }
    }
    text = mergedI;
  }

  // 볼드체 (**text**)
  var bParts = text.split('**');
  if (bParts.length > 1) {
    var mergedB = '';
    for (var bi = 0; bi < bParts.length; bi++) {
      if (bi % 2 === 1) {
        mergedB += '<b style="color:#fff;">' + bParts[bi] + '</b>';
      } else {
        mergedB += bParts[bi];
      }
    }
    text = mergedB;
  }

  // 마크다운 링크: [title](url)
  var lParts = text.split('[');
  if (lParts.length > 1) {
    var mergedL = lParts[0];
    for (var li = 1; li < lParts.length; li++) {
      var closeB = lParts[li].indexOf('](');
      var closeP = lParts[li].indexOf(')');
      if (closeB !== -1 && closeP > closeB) {
        var label = lParts[li].substring(0, closeB);
        var url = lParts[li].substring(closeB + 2, closeP);
        var rest = lParts[li].substring(closeP + 1);
        if (url.indexOf('http://') === 0 || url.indexOf('https://') === 0) {
          mergedL += '<a href="' + url + '" target="_blank" style="color:var(--accent-light); font-weight:700; text-decoration:underline;">' + label + '</a>' + rest;
        } else {
          mergedL += '<span style="color:var(--accent-light); font-weight:600;">' + label + '</span>' + rest;
        }
      } else {
        mergedL += '[' + lParts[li];
      }
    }
    text = mergedL;
  }

  // 줄 단위 헤더, 불릿, 구분선 처리
  var lines = text.split(NL);
  var outLines = [];
  for (var li = 0; li < lines.length; li++) {
    var l = lines[li];
    var trimL = l.trim();
    if (trimL.indexOf('### ') === 0) {
      outLines.push('<div style="font-weight:700; color:var(--accent-light); margin:6px 0 2px; font-size:12.5px;">' + trimL.substring(4) + '</div>');
    } else if (trimL.indexOf('## ') === 0) {
      outLines.push('<div style="font-weight:800; color:#fff; margin:8px 0 4px; font-size:13.5px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:2px;">' + trimL.substring(3) + '</div>');
    } else if (trimL.indexOf('# ') === 0) {
      outLines.push('<div style="font-weight:800; color:#fff; margin:10px 0 6px; font-size:14.5px;">' + trimL.substring(2) + '</div>');
    } else if (trimL.indexOf('* ') === 0 || trimL.indexOf('- ') === 0) {
      outLines.push('<div style="padding-left:6px; margin:2px 0; font-size:12px;">• ' + trimL.substring(2) + '</div>');
    } else if (trimL === '---') {
      outLines.push('<hr style="border:none; border-top:1px solid var(--border); margin:6px 0;">');
    } else {
      outLines.push(l);
    }
  }
  return outLines.join('<br>');
}

var lastActiveStep = -1;
var lastLiveStateKey = '';
var isSyncing = false;
var isSimplifiedMode = true;
var showAllLiveHistory = false;
var showAllCodexHistory = false;
var showAllAgyHistory = false;
var showAllGrokHistory = false;
var foldedMessages = {};
var lastLiveData = null;
var lastCodexData = null;
var lastAgyData = null;
var lastGrokData = null;

function toggleSimplifyMode() {
  isSimplifiedMode = !isSimplifiedMode;
  var btn = document.getElementById('btnSimplifyMode');
  if (btn) {
    btn.className = 'mode-switch-btn' + (isSimplifiedMode ? ' active' : '');
    btn.innerText = isSimplifiedMode ? '⚡ 단순화 모드 ON' : '📋 전체 상세 모드';
  }
  if (lastLiveData) renderLiveMessages(lastLiveData.messages, lastLiveData.isWorking, lastLiveData.lastAction);
  if (lastCodexData) renderCodexMessages(lastCodexData.messages, lastCodexData.isWorking, lastCodexData.currentTask);
  if (lastAgyData) renderAgyMessages(lastAgyData.messages, lastAgyData.isWorking, lastAgyData.currentTask);
}

function toggleMsgFold(msgId) {
  var body = document.getElementById('body-' + msgId);
  var btn = document.getElementById('btn-' + msgId);
  if (!body) return;
  if (body.classList.contains('collapsed-body')) {
    body.classList.remove('collapsed-body');
    foldedMessages[msgId] = false;
    if (btn) btn.innerText = '접기 ▴';
  } else {
    body.classList.add('collapsed-body');
    foldedMessages[msgId] = true;
    if (btn) btn.innerText = '펼치기 ▾';
  }
}

function toggleLiveHistory() {
  showAllLiveHistory = !showAllLiveHistory;
  if (lastLiveData) renderLiveMessages(lastLiveData.messages, lastLiveData.isWorking, lastLiveData.lastAction);
}

function toggleCodexHistory() {
  showAllCodexHistory = !showAllCodexHistory;
  lastCodexMsgHash = '';
  if (lastCodexData) renderCodexMessages(lastCodexData.messages, lastCodexData.isWorking, lastCodexData.currentTask);
}

function toggleAgyHistory() {
  showAllAgyHistory = !showAllAgyHistory;
  lastAgyMsgHash = '';
  if (lastAgyData) renderAgyMessages(lastAgyData.messages, lastAgyData.isWorking, lastAgyData.currentTask);
}

function toggleGrokHistory() {
  showAllGrokHistory = !showAllGrokHistory;
  lastGrokMsgHash = '';
  if (lastGrokData) renderGrokMessages(lastGrokData.messages, lastGrokData.isWorking, lastGrokData.currentTask);
}

async function syncLiveTranscript() {
  if (isSyncing) return;
  isSyncing = true;
  try {
    var res = await fetch('/api/live-transcript');
    var data = await res.json();
    if (!data.success) {
      isSyncing = false;
      return;
    }

    lastLiveData = data;

    var statusEl = document.getElementById('syncSessionStatus');
    if (statusEl) {
      if (data.isWorking) {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#f59e0b;box-shadow:0 0 6px #f59e0b;"></span><span>작업 중' + (data.queued ? ' (대기 ' + data.queued + '건)' : '') + '...</span>';
        statusEl.style.color = '#f59e0b';
      } else {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#F2A48A;"></span><span>대기</span>';
        statusEl.style.color = '#10b981';
      }
    }

    var liveStateKey = data.activeStep + '_' + (data.isWorking ? '1' : '0') + '_' + (data.messages ? data.messages.length : 0) + '_' + (data.lastAction || '');
    if (liveStateKey !== lastLiveStateKey) {
      lastLiveStateKey = liveStateKey;
      lastActiveStep = data.activeStep;
      renderLiveMessages(data.messages, data.isWorking, data.lastAction);
    }
  } catch (err) {
    console.error('syncLiveTranscript error:', err);
  }
  isSyncing = false;
}

var chatViewMode = 'summary'; // 'summary' | 'detail' | 'full'

function setChatViewMode(mode) {
  ['summary', 'detail', 'full'].forEach(function(m) {
    var btn = document.getElementById('modeBtn-' + m);
    if (btn) {
      if (m === mode) btn.classList.add('active');
      else btn.classList.remove('active');
    }
  });
  chatViewMode = mode;
  lastLiveStateKey = '';
  if (lastLiveData) {
    renderLiveMessages(lastLiveData.messages, lastLiveData.isWorking, lastLiveData.lastAction);
  }
}

// ===== 채팅창 공통 렌더 헬퍼 (스크롤 튐 방지) =====
// - 내용이 안 바뀌면 innerHTML을 건드리지 않는다 (폴링마다 통째로 갈아끼우던 것이 스크롤 튐의 원인)
// - 손가락으로 스크롤 중이면 렌더를 보류한다 (다음 폴링에서 재시도)
// - 맨 아래 근처(≤90px)에 있을 때만 새 메시지를 따라 내려간다
function markUserScrolling(el) {
  el._userScrollUntil = Date.now() + 1500;
}
function bindChatScrollGuards() {
  ['chatContainer', 'codexChatContainer', 'agyChatContainer', 'grokChatContainer'].forEach(function(id) {
    var el = document.getElementById(id);
    if (!el || el._scrollGuardBound) return;
    el._scrollGuardBound = true;
    ['touchstart', 'touchmove', 'wheel'].forEach(function(ev) {
      el.addEventListener(ev, function() { markUserScrolling(el); }, { passive: true });
    });
    el.addEventListener('touchend', function() { el._userScrollUntil = Date.now() + 800; }, { passive: true });
    el.addEventListener('scroll', function() {
      // 프로그램적 스크롤이 아닌 사용자 스크롤만 감지 (직전 300ms 내 우리가 움직인 경우 제외)
      if (!el._progScrollAt || Date.now() - el._progScrollAt > 300) markUserScrolling(el);
    }, { passive: true });
  });
}
function applyChatHtml(container, html, isInitial) {
  if (container._lastHtml === html) return;               // 변경 없음 → 아무것도 안 함
  var userScrolling = container._userScrollUntil && Date.now() < container._userScrollUntil;
  var isNearBottom = (container.scrollHeight - container.scrollTop - container.clientHeight) <= 90;
  if (userScrolling && !isInitial) return;               // 손가락 스크롤 중 → 이번 주기는 보류
  var prevScrollTop = container.scrollTop;
  container.innerHTML = html;
  container._lastHtml = html;
  container._progScrollAt = Date.now();
  if (isNearBottom || isInitial) {
    container.scrollTop = container.scrollHeight;
  } else {
    container.scrollTop = prevScrollTop;
  }
}
document.addEventListener('DOMContentLoaded', bindChatScrollGuards);
if (document.readyState !== 'loading') bindChatScrollGuards();

function renderLiveMessages(messages, isWorking, lastAction) {
  var container = document.getElementById('chatContainer');
  if (!container) return;

  var countBadge = document.getElementById('transMsgCountBadge');
  if (countBadge && messages) {
    if (chatViewMode === 'summary') {
      var userAiCount = messages.filter(function(m) { return m.role === 'user' || m.role === 'ai'; }).length;
      countBadge.innerText = userAiCount + '개 메시지';
    } else if (chatViewMode === 'detail') {
      countBadge.innerText = messages.length + '개 이벤트';
    } else {
      countBadge.innerText = messages.length + '개 전체 기록';
    }
  }

  var html = '';
  if (!messages || messages.length === 0) {
    html = '<div style="color:var(--dim); text-align:center; padding:30px;">대화 기록이 없습니다. 아래 입력창에 첫 지시를 입력하세요!</div>';
  } else {
    var filteredList = messages;

    if (chatViewMode === 'summary') {
      // 1. 요약 모드: 도구 호출 제외, 최근 6개 대화만 표시, 긴 글 접기
      // 요약 모드에서도 선택형 질문 카드는 남긴다 (폰에서 보기를 눌러 답해야 하므로)
      filteredList = messages.filter(function(m) { return m.role === 'user' || m.role === 'ai' || (m.role === 'tool' && m.toolName === 'AskUserQuestion'); });
      var total = filteredList.length;
      var limit = 6;
      if (total > limit && !showAllLiveHistory) {
        var hiddenCount = total - limit;
        html += '<div class="history-banner">';
        html += '  <button class="history-toggle-btn" onclick="toggleLiveHistory()">';
        html += '    ⚡ [요약 모드] 이전 대화 ' + hiddenCount + '개 더보기';
        html += '  </button>';
        html += '</div>';
        filteredList = filteredList.slice(-limit);
      } else if (total > limit && showAllLiveHistory) {
        html += '<div class="history-banner">';
        html += '  <button class="history-toggle-btn" onclick="toggleLiveHistory()">';
        html += '    👇 최근 대화만 보기 (' + limit + '개로 축소)';
        html += '  </button>';
        html += '</div>';
      }
    } else if (chatViewMode === 'detail') {
      // 2. 상세 모드: 도구 실행/터미널 명령 포함, 최근 30개 이벤트, 자동 펼침
      var total = messages.length;
      var limit = 30;
      if (total > limit && !showAllLiveHistory) {
        var hiddenCount = total - limit;
        html += '<div class="history-banner">';
        html += '  <button class="history-toggle-btn" onclick="toggleLiveHistory()">';
        html += '    📋 [상세 모드] 이전 실행 로그 ' + hiddenCount + '개 더보기';
        html += '  </button>';
        html += '</div>';
        filteredList = messages.slice(-limit);
      } else {
        html += '<div style="text-align:center; padding:5px; font-size:11px; color:#38bdf8; font-weight:700;">📋 상세 실행 모드 (도구 및 터미널 액션 포함)</div>';
        filteredList = messages;
      }
    } else if (chatViewMode === 'full') {
      // 3. 전체 모드: 세션의 모든 대화 및 실행 로그 100% 전체 무제한 펼침 표시
      html += '<div style="text-align:center; padding:6px; font-size:11px; color:#10b981; font-weight:700; background:rgba(16,185,129,0.08); border-radius:8px; margin-bottom:8px;">🌐 세션 전체 무제한 보기 (총 ' + messages.length + '개 항목 전체 출력 중)</div>';
      filteredList = messages;
    }

    var lastAskIdx = -1;
    filteredList.forEach(function (m, i) { if (m.role === 'tool' && m.toolName === 'AskUserQuestion') lastAskIdx = i; });
    // 질문 뒤에 이미 사용자/AI 메시지가 이어졌으면 답한 것 → 버튼 비활성
    if (lastAskIdx >= 0 && lastAskIdx < filteredList.length - 1 && filteredList.slice(lastAskIdx + 1).some(function (x) { return x.role === 'user' || x.role === 'ai'; })) lastAskIdx = -1;
    filteredList.forEach(function(m, idx) {
      if (m.role === 'user') {
        var badge = m.isMobile ? ' <span style="font-size:10px; opacity:0.75; margin-left:4px;">📱 모바일</span>' : '';
        html += '<div class="msg-bubble msg-user">' + escapeHtml(m.text).split(NL).join('<br>') + badge + '</div>';
      } else if (m.role === 'tool') {
        // 도구 실행 및 터미널 작업 카드
        html += '<div class="msg-bubble" style="background:rgba(15,23,42,0.75); border:1px solid rgba(56,189,248,0.25); border-left:3.5px solid #38bdf8; padding:8px 12px; font-family:monospace; font-size:11.5px; align-self:stretch; max-width:96%;">';
        html += '  <div style="display:flex; justify-content:space-between; color:#38bdf8; font-weight:700; margin-bottom:3px;">';
        html += '    <span>⚙️ [' + escapeHtml(m.toolName || 'Action') + '] ' + escapeHtml(m.summary || '') + '</span>';
        html += '    <span style="color:var(--dim); font-size:9.5px;">' + (m.time ? m.time.substring(11, 19) : '') + '</span>';
        html += '  </div>';
        if (m.toolName === 'AskUserQuestion' && m.questions && m.questions.length) {
          var isLatestAsk = (idx === lastAskIdx);
          m.questions.forEach(function (q, qi) {
            html += '  <div style="margin:6px 0 4px; color:#fff; font-family:-apple-system,BlinkMacSystemFont,Pretendard,sans-serif; font-size:12.5px; font-weight:700; white-space:pre-wrap;">' + (m.questions.length > 1 ? (qi + 1) + '. ' : '') + escapeHtml(q.question) + '</div>';
            html += '  <div style="display:flex; flex-direction:column; gap:5px;">';
            q.options.forEach(function (o, oi) {
              html += '<button class="ask-opt" ' + (isLatestAsk ? 'onclick="askPick(' + oi + ', ' + q.options.length + ', ' + (q.multi ? 'true' : 'false') + ')"' : 'disabled') + '><b>' + (q.multi ? '☐ ' : '') + (oi + 1) + ') ' + escapeHtml(o.label) + '</b>' + (o.description ? '<span>' + escapeHtml(o.description) + '</span>' : '') + '</button>';
            });
            html += '  </div>';
            if (isLatestAsk && q.multi) html += '  <button class="ask-opt" style="margin-top:6px; align-items:center; background:var(--accent); color:#fff;" onclick="askSubmitMulti()"><b>✔ 제출 (고른 것 확정)</b><span style="color:#dbe4ff;">복수 선택 — 항목을 눌러 체크/해제한 뒤 이 버튼</span></button>';
          });
          if (isLatestAsk) html += '  <div style="display:flex; gap:6px; margin-top:6px;"><button class="ask-opt ask-mini" onclick="askKeys([&quot;UP&quot;])">↑</button><button class="ask-opt ask-mini" onclick="askKeys([&quot;DOWN&quot;])">↓</button><button class="ask-opt ask-mini" onclick="askKeys([&quot;TAB&quot;])">Tab</button><button class="ask-opt ask-mini" onclick="askKeys([&quot;ENTER&quot;])">↵ 확인</button><button class="ask-opt ask-mini" onclick="askKeys([&quot;ESC&quot;])">Esc</button></div><div style="color:var(--dim); font-size:10.5px; margin-top:4px;">보기를 누르면 PC 창에서 그 항목이 선택됩니다. 직접 쓰려면 채팅창에 답을 입력하세요.</div>';
        } else if (m.detail) {
          html += '  <div style="color:#cbd5e1; word-break:break-all; white-space:pre-wrap; font-size:11px; line-height:1.45; max-height:110px; overflow-y:auto; background:rgba(0,0,0,0.35); padding:5px 8px; border-radius:4px;">' + escapeHtml(m.detail) + '</div>';
        }
        html += '</div>';
      } else {
        var msgId = 'live-' + (m.id || idx);
        var formatted = formatMarkdownToHtml(m.text);
        var isLastMsg = (idx === filteredList.length - 1);
        var isLong = (chatViewMode === 'summary') && ((m.text && m.text.length > 260) || (m.text && m.text.split(NL).length > 6));
        var isFolded = isLong && (!isLastMsg ? (foldedMessages[msgId] !== false) : (foldedMessages[msgId] === true));

        var modeBadgeText = (chatViewMode === 'full') ? '전체 전문' : (chatViewMode === 'detail' ? '상세 모드' : '요약본');
        var modeBadgeColor = (chatViewMode === 'full') ? '#10b981' : (chatViewMode === 'detail' ? '#38bdf8' : '#a855f7');
        var modeBadgeBg = (chatViewMode === 'full') ? 'rgba(16,185,129,0.15)' : (chatViewMode === 'detail' ? 'rgba(56,189,248,0.15)' : 'rgba(168,85,247,0.15)');
        var modeBadgeBorder = (chatViewMode === 'full') ? 'rgba(16,185,129,0.3)' : (chatViewMode === 'detail' ? 'rgba(56,189,248,0.3)' : 'rgba(168,85,247,0.3)');

        html += '<div class="msg-bubble msg-ai">';
        html += '  <div class="msg-title" style="display:flex; justify-content:space-between; align-items:center;">';
        html += '    <div style="display:flex; align-items:center; gap:6px;">';
        html += '      <span>Claude Code (Opus 5)</span>';
        html += '      <span style="font-size:10px; font-weight:700; color:' + modeBadgeColor + '; opacity:0.85;">· ' + modeBadgeText + '</span>';
        html += '    </div>';
        if (isLong) {
          html += '    <span class="fold-btn" onclick="toggleMsgFold(&quot;' + msgId + '&quot;)" id="btn-' + msgId + '">' + (isFolded ? '펼치기 ▾' : '접기 ▴') + '</span>';
        }
        html += '  </div>';

        if (isLong && isFolded) {
          html += '  <div id="body-' + msgId + '" class="msg-body collapsed-body">' + formatted + '</div>';
        } else {
          html += '  <div id="body-' + msgId + '" class="msg-body">' + formatted + '</div>';
        }
        html += '</div>';
      }
    });
  }

  if (isWorking) {
    html += '<div class="msg-bubble msg-ai" style="border:none; border-left:3px solid #F2A48A; border-radius:6px; background:rgba(242,164,138,0.07);">';
    html += '  <div class="msg-title" style="color:#F2A48A;">⚡ 실시간 PC 연산 및 작업 진행 중...</div>';
    html += '  <div class="msg-body" style="color:var(--dim); font-size:12.5px;">' + (lastAction ? escapeHtml(lastAction) : '자율 완주 중입니다...') + '</div>';
    html += '</div>';
  }

  applyChatHtml(container, html, (container.innerHTML.indexOf('세션을 실시간으로') !== -1 || container.innerHTML.indexOf('대화 기록이 없습니다') !== -1));
}

// 앱(안드로이드 셸)이 첫 지시 카드로 문장을 넣을 때 쓰는 진입점 — 메인(Claude Code) 탭 입력창에 채워 전송
function sendChatText(text) {
  try { if (typeof switchTab === 'function') { var mb = document.querySelector('.tab-btn.w-claude'); if (mb) switchTab('assistant', mb); } } catch (_) {}
  var i = document.getElementById('chatInput'); if (!i) return false;
  i.value = String(text || ''); sendChatFromInput(); return true;
}
async function sendChatFromInput() {
  var input = document.getElementById('chatInput');
  var text = input.value.trim();
  if (!text) return;
  resetComposer(input);
  sendQuickInput(text);
}

async function sendQuickInput(text) {
  if (!text) return;
  var container = document.getElementById('chatContainer');
  var bubble = document.createElement('div');
  bubble.className = 'msg-bubble msg-user';
  bubble.innerHTML = escapeHtml(text).split(NL).join('<br>') + ' <span style="font-size:10px; opacity:0.75; margin-left:4px;">📱 모바일</span>';
  container.appendChild(bubble);
  container._lastHtml = null;
  container._progScrollAt = Date.now();
  container.scrollTop = container.scrollHeight;

  try {
    await fetch('/api/send-mobile-input', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    });
    setTimeout(syncLiveTranscript, 200);
  } catch (_) {}
}

bindComposer('chatInput', sendChatFromInput);


// Codex 연동 함수
var isCodexSyncing = false;
var lastCodexMsgHash = '';

async function syncCodexStatus() {
  if (isCodexSyncing) return;
  isCodexSyncing = true;
  try {
    var res = await fetch('/api/codex-status');
    var data = await res.json();
    lastCodexData = data;
    var statusEl = document.getElementById('codexStatus');
    if (statusEl) {
      if (data.isWorking) {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#f59e0b;box-shadow:0 0 6px #f59e0b;"></span><span>작업 중...</span>';
        statusEl.style.color = '#f59e0b';
      } else {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#3ED2A8;"></span><span>대기</span>';
        statusEl.style.color = '#60a5fa';
      }
    }
    var msgHash = (data.messages ? data.messages.length : 0) + '_' + (data.isWorking ? '1' : '0') + '_' + (data.currentTask || '') + '_' + (showAllCodexHistory ? 'all' : 'limit') + '_' + (isSimplifiedMode ? 'sim' : 'full');
    if (msgHash !== lastCodexMsgHash) {
      lastCodexMsgHash = msgHash;
      renderCodexMessages(data.messages, data.isWorking, data.currentTask);
    }
  } catch (_) {}
  isCodexSyncing = false;
}

function renderCodexMessages(messages, isWorking, currentTask) {
  var container = document.getElementById('codexChatContainer');
  if (!container) return;
  var isInitial = (container.innerHTML.indexOf('대기 중입니다') !== -1);

  var html = '';
  if (!messages || messages.length === 0) {
    html = '<div style="color:var(--dim); text-align:center; padding:30px;">Codex 대기 중입니다. 코딩 명령을 내려보세요.</div>';
  } else {
    var total = messages.length;
    var visibleLimit = 5;
    var hiddenCount = total - visibleLimit;

    if (isSimplifiedMode && hiddenCount > 0 && !showAllCodexHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleCodexHistory()">';
      html += '    👆 이전 대화 ' + hiddenCount + '개 더보기';
      html += '  </button>';
      html += '</div>';
    } else if (isSimplifiedMode && hiddenCount > 0 && showAllCodexHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleCodexHistory()">';
      html += '    👇 최근 대화만 보기 (' + visibleLimit + '개로 축소)';
      html += '  </button>';
      html += '</div>';
    }

    var displayMessages = (isSimplifiedMode && hiddenCount > 0 && !showAllCodexHistory)
      ? messages.slice(-visibleLimit)
      : messages;

    displayMessages.forEach(function(m, idx) {
      if (m.role === 'user') {
        html += '<div class="msg-bubble msg-user">' + escapeHtml(m.text).split(NL).join('<br>') + '</div>';
      } else {
        var msgId = 'codex-' + (m.id || idx);
        var formatted = formatMarkdownToHtml(m.text);
        var isLastMsg = (idx === displayMessages.length - 1);
        var isLong = isSimplifiedMode && ((m.text && m.text.length > 260) || (m.text && m.text.split(NL).length > 6));
        var isFolded = isLong && (!isLastMsg ? (foldedMessages[msgId] !== false) : (foldedMessages[msgId] === true));

        html += '<div class="msg-bubble msg-ai" style="border-color: rgba(96,165,250,0.3);">';
        html += '  <div class="msg-title" style="color:#3ED2A8; display:flex; justify-content:space-between; align-items:center;">';
        html += '    <span>Codex (GPT-5.6-terra)</span>';
        if (isLong) {
          html += '    <span class="fold-btn" onclick="toggleMsgFold(&quot;' + msgId + '&quot;)" id="btn-' + msgId + '">' + (isFolded ? '펼치기 ▾' : '접기 ▴') + '</span>';
        }
        html += '  </div>';

        if (isLong && isFolded) {
          html += '  <div id="body-' + msgId + '" class="msg-body collapsed-body">' + formatted + '</div>';
        } else {
          html += '  <div id="body-' + msgId + '" class="msg-body">' + formatted + '</div>';
        }
        html += '</div>';
      }
    });
  }

  if (isWorking) {
    html += '<div class="msg-bubble msg-ai" style="border-color:#2563eb; background:rgba(37,99,235,0.08);">';
    html += '  <div class="msg-title" style="color:#3ED2A8;">⚡ Codex 자율 작업 진행 중...</div>';
    html += '  <div class="msg-body" style="color:var(--dim); font-size:12.5px;">' + (currentTask ? escapeHtml(currentTask) : '실행 중...') + '</div>';
    html += '</div>';
  }

  applyChatHtml(container, html, isInitial);
}

async function sendCodexFromInput() {
  var input = document.getElementById('codexInput');
  var text = input.value.trim();
  if (!text) return;
  resetComposer(input);
  sendCodexQuick(text);
}

async function sendCodexQuick(text) {
  if (!text) return;
  var container = document.getElementById('codexChatContainer');
  var bubble = document.createElement('div');
  bubble.className = 'msg-bubble msg-user';
  bubble.innerHTML = escapeHtml(text).split(NL).join('<br>');
  container.appendChild(bubble);
  container._lastHtml = null;
  container._progScrollAt = Date.now();
  container.scrollTop = container.scrollHeight;

  try {
    await fetch('/api/codex-send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    });
    lastCodexMsgHash = ''; // 전송 직후 강제 갱신
    setTimeout(syncCodexStatus, 500);
  } catch (_) {}
}

var codexIn = document.getElementById('codexInput');
if (codexIn) {
  bindComposer('codexInput', sendCodexFromInput);
}

// Antigravity(서브 워커 2) 연동 함수
var isAgySyncing = false;
var lastAgyMsgHash = '';

async function syncAgyStatus() {
  if (isAgySyncing) return;
  isAgySyncing = true;
  try {
    var res = await fetch('/api/agy-status');
    var data = await res.json();
    lastAgyData = data;
    var statusEl = document.getElementById('agyStatus');
    if (statusEl) {
      if (data.isWorking) {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#f59e0b;box-shadow:0 0 6px #f59e0b;"></span><span>작업 중...</span>';
        statusEl.style.color = '#f59e0b';
      } else {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#8AB4F8;"></span><span>대기</span>';
        statusEl.style.color = '#f59e0b';
      }
    }
    var msgHash = (data.messages ? data.messages.length : 0) + '_' + (data.isWorking ? '1' : '0') + '_' + (data.currentTask || '') + '_' + (showAllAgyHistory ? 'all' : 'limit') + '_' + (isSimplifiedMode ? 'sim' : 'full');
    if (msgHash !== lastAgyMsgHash) {
      lastAgyMsgHash = msgHash;
      renderAgyMessages(data.messages, data.isWorking, data.currentTask);
    }
  } catch (_) {}
  isAgySyncing = false;
}

function renderAgyMessages(messages, isWorking, currentTask) {
  var container = document.getElementById('agyChatContainer');
  if (!container) return;
  var isInitial = (container.innerHTML.indexOf('대기 중입니다') !== -1);

  var html = '';
  if (!messages || messages.length === 0) {
    html = '<div style="color:var(--dim); text-align:center; padding:30px;">Antigravity (Gemini 3.8 Flash) 대기 중입니다. 코딩·분석 명령을 내려보세요.</div>';
  } else {
    var total = messages.length;
    var visibleLimit = 5;
    var hiddenCount = total - visibleLimit;

    if (isSimplifiedMode && hiddenCount > 0 && !showAllAgyHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleAgyHistory()">';
      html += '    👆 이전 대화 ' + hiddenCount + '개 더보기';
      html += '  </button>';
      html += '</div>';
    } else if (isSimplifiedMode && hiddenCount > 0 && showAllAgyHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleAgyHistory()">';
      html += '    👇 최근 대화만 보기 (' + visibleLimit + '개로 축소)';
      html += '  </button>';
      html += '</div>';
    }

    var displayMessages = (isSimplifiedMode && hiddenCount > 0 && !showAllAgyHistory)
      ? messages.slice(-visibleLimit)
      : messages;

    displayMessages.forEach(function(m, idx) {
      if (m.role === 'user') {
        html += '<div class="msg-bubble msg-user">' + escapeHtml(m.text).split(NL).join('<br>') + '</div>';
      } else {
        var msgId = 'agy-' + (m.id || idx);
        var formatted = formatMarkdownToHtml(m.text);
        var isLastMsg = (idx === displayMessages.length - 1);
        var isLong = isSimplifiedMode && ((m.text && m.text.length > 260) || (m.text && m.text.split(NL).length > 6));
        var isFolded = isLong && (!isLastMsg ? (foldedMessages[msgId] !== false) : (foldedMessages[msgId] === true));

        html += '<div class="msg-bubble msg-ai" style="border-color: rgba(245,158,11,0.3);">';
        html += '  <div class="msg-title" style="color:#8AB4F8; display:flex; justify-content:space-between; align-items:center;">';
        html += '    <span>Antigravity (Gemini 3.8 Flash)</span>';
        if (isLong) {
          html += '    <span class="fold-btn" onclick="toggleMsgFold(&quot;' + msgId + '&quot;)" id="btn-' + msgId + '">' + (isFolded ? '펼치기 ▾' : '접기 ▴') + '</span>';
        }
        html += '  </div>';

        if (isLong && isFolded) {
          html += '  <div id="body-' + msgId + '" class="msg-body collapsed-body">' + formatted + '</div>';
        } else {
          html += '  <div id="body-' + msgId + '" class="msg-body">' + formatted + '</div>';
        }
        html += '</div>';
      }
    });
  }

  if (isWorking) {
    html += '<div class="msg-bubble msg-ai" style="border-color:#d97706; background:rgba(217,119,6,0.08);">';
    html += '  <div class="msg-title" style="color:#8AB4F8;">Antigravity (Gemini 3.8 Flash) · 자율 작업 진행 중...</div>';
    html += '  <div class="msg-body" style="color:var(--dim); font-size:12.5px;">' + (currentTask ? escapeHtml(currentTask) : '실행 중...') + '</div>';
    html += '</div>';
  }

  applyChatHtml(container, html, isInitial);
}

async function sendAgyFromInput() {
  var input = document.getElementById('agyInput');
  var text = input.value.trim();
  if (!text) return;
  resetComposer(input);
  sendAgyQuick(text);
}

async function sendAgyQuick(text) {
  if (!text) return;
  var container = document.getElementById('agyChatContainer');
  var bubble = document.createElement('div');
  bubble.className = 'msg-bubble msg-user';
  bubble.innerHTML = escapeHtml(text).split(NL).join('<br>');
  container.appendChild(bubble);
  container._lastHtml = null;
  container._progScrollAt = Date.now();
  container.scrollTop = container.scrollHeight;

  try {
    await fetch('/api/agy-send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    });
    lastAgyMsgHash = '';
    setTimeout(syncAgyStatus, 500);
  } catch (_) {}
}

var agyIn = document.getElementById('agyInput');
if (agyIn) {
  bindComposer('agyInput', sendAgyFromInput);
}

// ===== Grok(서브 워커 3) — Antigravity 블록 복제 =====
var isGrokSyncing = false;
var lastGrokMsgHash = '';

async function syncGrokStatus() {
  if (isGrokSyncing) return;
  isGrokSyncing = true;
  try {
    var res = await fetch('/api/grok-status');
    var data = await res.json();
    lastGrokData = data;
    var statusEl = document.getElementById('grokStatus');
    if (statusEl) {
      if (data.isWorking) {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#f59e0b;box-shadow:0 0 6px #f59e0b;"></span><span>작업 중...</span>';
        statusEl.style.color = '#f59e0b';
      } else {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#D1D5DB;"></span><span>대기</span>';
        statusEl.style.color = '#f59e0b';
      }
    }
    var msgHash = (data.messages ? data.messages.length : 0) + '_' + (data.isWorking ? '1' : '0') + '_' + (data.currentTask || '') + '_' + (showAllGrokHistory ? 'all' : 'limit') + '_' + (isSimplifiedMode ? 'sim' : 'full');
    if (msgHash !== lastGrokMsgHash) {
      lastGrokMsgHash = msgHash;
      renderGrokMessages(data.messages, data.isWorking, data.currentTask);
    }
  } catch (_) {}
  isGrokSyncing = false;
}

function renderGrokMessages(messages, isWorking, currentTask) {
  var container = document.getElementById('grokChatContainer');
  if (!container) return;
  var isInitial = (container.innerHTML.indexOf('대기 중입니다') !== -1);

  var html = '';
  if (!messages || messages.length === 0) {
    html = '<div style="color:var(--dim); text-align:center; padding:30px;">Grok (grok-4.6) 대기 중입니다. 코딩·분석 명령을 내려보세요.</div>';
  } else {
    var total = messages.length;
    var visibleLimit = 5;
    var hiddenCount = total - visibleLimit;

    if (isSimplifiedMode && hiddenCount > 0 && !showAllGrokHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleGrokHistory()">';
      html += '    👆 이전 대화 ' + hiddenCount + '개 더보기';
      html += '  </button>';
      html += '</div>';
    } else if (isSimplifiedMode && hiddenCount > 0 && showAllGrokHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleGrokHistory()">';
      html += '    👇 최근 대화만 보기 (' + visibleLimit + '개로 축소)';
      html += '  </button>';
      html += '</div>';
    }

    var displayMessages = (isSimplifiedMode && hiddenCount > 0 && !showAllGrokHistory)
      ? messages.slice(-visibleLimit)
      : messages;

    displayMessages.forEach(function(m, idx) {
      if (m.role === 'user') {
        html += '<div class="msg-bubble msg-user">' + escapeHtml(m.text).split(NL).join('<br>') + '</div>';
      } else {
        var msgId = 'grok-' + (m.id || idx);
        var formatted = formatMarkdownToHtml(m.text);
        var isLastMsg = (idx === displayMessages.length - 1);
        var isLong = isSimplifiedMode && ((m.text && m.text.length > 260) || (m.text && m.text.split(NL).length > 6));
        var isFolded = isLong && (!isLastMsg ? (foldedMessages[msgId] !== false) : (foldedMessages[msgId] === true));

        html += '<div class="msg-bubble msg-ai" style="border-color: rgba(245,158,11,0.3);">';
        html += '  <div class="msg-title" style="color:#D1D5DB; display:flex; justify-content:space-between; align-items:center;">';
        html += '    <span>Grok (grok-4.6)</span>';
        if (isLong) {
          html += '    <span class="fold-btn" onclick="toggleMsgFold(&quot;' + msgId + '&quot;)" id="btn-' + msgId + '">' + (isFolded ? '펼치기 ▾' : '접기 ▴') + '</span>';
        }
        html += '  </div>';

        if (isLong && isFolded) {
          html += '  <div id="body-' + msgId + '" class="msg-body collapsed-body">' + formatted + '</div>';
        } else {
          html += '  <div id="body-' + msgId + '" class="msg-body">' + formatted + '</div>';
        }
        html += '</div>';
      }
    });
  }

  if (isWorking) {
    html += '<div class="msg-bubble msg-ai" style="border-color:#d97706; background:rgba(217,119,6,0.08);">';
    html += '  <div class="msg-title" style="color:#D1D5DB;">Grok (grok-4.6) · 자율 작업 진행 중...</div>';
    html += '  <div class="msg-body" style="color:var(--dim); font-size:12.5px;">' + (currentTask ? escapeHtml(currentTask) : '실행 중...') + '</div>';
    html += '</div>';
  }

  applyChatHtml(container, html, isInitial);
}

async function sendGrokFromInput() {
  var input = document.getElementById('grokInput');
  var text = input.value.trim();
  if (!text) return;
  resetComposer(input);
  sendGrokQuick(text);
}

async function sendGrokQuick(text) {
  if (!text) return;
  var container = document.getElementById('grokChatContainer');
  var bubble = document.createElement('div');
  bubble.className = 'msg-bubble msg-user';
  bubble.innerHTML = escapeHtml(text).split(NL).join('<br>');
  container.appendChild(bubble);
  container._lastHtml = null;
  container._progScrollAt = Date.now();
  container.scrollTop = container.scrollHeight;

  try {
    await fetch('/api/grok-send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    });
    lastGrokMsgHash = '';
    setTimeout(syncGrokStatus, 500);
  } catch (_) {}
}

var grokIn = document.getElementById('grokInput');
if (grokIn) {
  bindComposer('grokInput', sendGrokFromInput);
}

// 터미널 관련 함수
function printTerm(text, className) {
  const out = document.getElementById('termOutput');
  const div = document.createElement('div');
  if (className) div.className = className;
  div.innerText = text;
  out.appendChild(div);
  out.scrollTop = out.scrollHeight;
}

function clearTerm() {
  document.getElementById('termOutput').innerHTML = '';
}

async function quickTerm(cmd) {
  document.getElementById('termInput').value = cmd;
  resizeComposer(document.getElementById('termInput'));
  sendTermFromInput();
}

async function sendTermFromInput() {
  const input = document.getElementById('termInput');
  const cmd = input.value.trim();
  if (!cmd) return;
  resetComposer(input);
  printTerm('PS > ' + cmd, 'prompt-line');
  try {
    const res = await fetch('/api/exec', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': token },
      body: JSON.stringify({ cmd })
    });
    const data = await res.json();
    if (data.isSmart && data.smart) {
      printTerm(data.smart.reply);
    } else if (data.output) {
      printTerm(data.output);
    } else if (data.error) {
      printTerm(data.error, 'err-line');
    }
  } catch (e) {
    printTerm('통신 오류: ' + e.message, 'err-line');
  }
}

bindComposer('termInput', sendTermFromInput);

let allProjectFiles = [];

function openFileManager() {
  document.getElementById('fileModalOverlay').style.display = 'flex';
  loadFiles();
}

function closeFileManager() {
  document.getElementById('fileModalOverlay').style.display = 'none';
}

function filterFilesList() {
  const q = (document.getElementById('fileSearchInput').value || '').trim().toLowerCase();
  renderFileListHtml(q ? allProjectFiles.filter(f => f.name.toLowerCase().includes(q)) : allProjectFiles);
}

async function loadFiles() {
  const container = document.getElementById('fileList');
  container.innerHTML = '<p style="color: var(--dim); text-align: center; padding: 20px;">파일 로딩 중...</p>';
  try {
    const res = await fetch('/api/files', { headers: { 'Authorization': token } });
    const data = await res.json();
    if (data.files) {
      allProjectFiles = data.files;
      renderFileListHtml(data.files);
    }
  } catch (e) {
    container.innerHTML = '<p style="color:var(--danger);padding:20px;">파일 목록 로드 실패: ' + e.message + '</p>';
  }
}

function renderFileListHtml(files) {
  const container = document.getElementById('fileList');
  if (!files || files.length === 0) {
    container.innerHTML = '<p style="color:var(--dim);text-align:center;padding:20px;">일치하는 파일이 없습니다.</p>';
    return;
  }
  let html = '';
  files.forEach(f => {
    const icon = f.isDir ? '📁' : (f.name.endsWith('.html') ? '🌐' : (f.name.endsWith('.md') ? '📝' : (f.name.endsWith('.json') ? '📊' : '📄')));
    const sizeStr = f.isDir ? '폴더' : (f.size > 1024 ? Math.round(f.size/1024) + ' KB' : f.size + ' B');
    const actionBtn = !f.isDir ? '<button class="action-btn" style="padding:4px 9px; font-size:11px; background:rgba(37,99,235,0.25); color:#93c5fd; border:1px solid rgba(37,99,235,0.4); cursor:pointer;" onclick="openEditor(&quot;' + f.name + '&quot;)">✏️ 편집/보기</button>' : '';
    html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:9px 12px;background:var(--card);border:1px solid var(--border);border-radius:10px;font-size:12px;">' +
            '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:62%;font-weight:600;">' + icon + ' ' + f.name + '</span>' +
            '<div style="display:flex;align-items:center;gap:8px;">' +
            '<span style="color:var(--dim);font-size:11px;">' + sizeStr + '</span>' +
            actionBtn +
            '</div>' +
            '</div>';
  });
  container.innerHTML = html;
}

async function openEditor(fileName) {
  currentEditFile = fileName;
  document.getElementById('editFileName').innerText = fileName;
  document.getElementById('fileEditorArea').value = '파일 내용을 불러오는 중...';
  document.getElementById('editorOverlay').style.display = 'flex';
  try {
    const res = await fetch('/api/file-content?file=' + encodeURIComponent(fileName), {
      headers: { 'Authorization': token }
    });
    const data = await res.json();
    if (data.content !== undefined) {
      document.getElementById('fileEditorArea').value = data.content;
    } else {
      document.getElementById('fileEditorArea').value = '파일을 불러오지 못했습니다: ' + (data.error || '');
    }
  } catch (e) {
    document.getElementById('fileEditorArea').value = '오류 발생: ' + e.message;
  }
}

function closeEditor() {
  document.getElementById('editorOverlay').style.display = 'none';
  currentEditFile = '';
}

async function saveCurrentFile(andDeploy) {
  if (!currentEditFile) return;
  const content = document.getElementById('fileEditorArea').value;
  try {
    const res = await fetch('/api/save-file', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': token },
      body: JSON.stringify({ file: currentEditFile, content })
    });
    const data = await res.json();
    if (data.success) {
      if (andDeploy) {
        alert('✅ PC에 저장 완료! Vercel 배포를 자동 실행합니다.');
        closeEditor();
        switchTab('assistant');
        sendUserMsg('vercel --prod --yes');
      } else {
        alert('✅ PC에 성공적으로 저장되었습니다!');
      }
    } else {
      alert('저장 실패: ' + (data.error || ''));
    }
  } catch (e) {
    alert('저장 통신 오류: ' + e.message);
  }
}

// 🍞 토스트 알림
function showToast(msg) {
  var t = document.getElementById('globalToast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'globalToast';
    t.style.cssText = 'position:fixed;bottom:78px;left:50%;transform:translateX(-50%);background:rgba(15,23,42,0.92);color:#fff;border:1px solid rgba(255,255,255,0.2);padding:8px 16px;border-radius:20px;font-size:12.5px;z-index:99999;box-shadow:0 6px 20px rgba(0,0,0,0.5);pointer-events:none;transition:opacity 0.2s ease;backdrop-filter:blur(8px);';
    document.body.appendChild(t);
  }
  t.innerHTML = msg;
  t.style.opacity = '1';
  clearTimeout(t._timer);
  t._timer = setTimeout(function() {
    t.style.opacity = '0';
  }, 3000);
}

// 🛑 긴급 정지 (Kill Switch)
async function triggerEmergencyStop() {
  if (!confirm('🛑 [긴급 정지]\\n\\nPC에서 실행 중인 모든 AI 작업 및 스크립트를 즉시 강제 중단하시겠습니까?')) {
    return;
  }
  showToast('🛑 긴급 정지 명령 하달 중...');
  try {
    var res = await fetch('/api/emergency-stop', { method: 'POST' });
    var data = await res.json();
    alert(data.message || '🛑 모든 프로세스가 긴급 중단되었습니다.');
    if (typeof syncLiveTranscript === 'function') syncLiveTranscript();
    if (typeof syncCodexStatus === 'function') syncCodexStatus();
    if (typeof syncAgyStatus === 'function') syncAgyStatus();
    if (typeof syncGrokStatus === 'function') syncGrokStatus();
  } catch (err) {
    alert('긴급 정지 통신 오류: ' + err.message);
  }
}

// 📱 모바일 네이티브 파일 탐색기 ("내 파일" / 갤러리) 호출 함수
function triggerFilePicker(targetAi, type) {
  var id = 'filePicker-' + targetAi + '-' + type;
  var input = document.getElementById(id);
  if (!input) return;
  // 기존 선택값 초기화 (동일 파일 재선택 시에도 onchange 정상 발화)
  input.value = '';
  // 모바일 네이티브 Intent (Samsung 내 파일 / iOS 파일 탐색기 / 갤러리) 즉시 호출
  input.click();
}

// 📎 스마트폰 파일/사진 통합 모바일 업로드 처리 함수 (단일 📎 클립)
async function handleMobileFileUpload(inputEl, targetAi, uploadType) {
  var fileList = Array.from(inputEl.files || []);
  if (fileList.length === 0) return;
  var hasImg = fileList.some(function(f) { return /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(f.name); });
  var allImg = fileList.every(function(f) { return /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(f.name); });
  var icon = allImg ? '🖼️' : '📁';
  var typeName = allImg ? '사진' : (hasImg ? '파일/사진' : '파일');

  var previewEl = document.getElementById('uploadPreview-' + targetAi);
  if (previewEl) {
    previewEl.style.display = 'flex';
    previewEl.innerHTML = '<span style="color:#60a5fa;">⏳ ' + icon + ' [핸드폰 ' + typeName + ' ' + fileList.length + '개] 전송 중...</span>';
  }

  showToast(icon + ' [핸드폰 ' + typeName + ' ' + fileList.length + '개] PC 전송 시작!');

  var authToken = token || localStorage.getItem('m_auth_token') || '';
  var uploadedFiles = [];
  var failedCount = 0;

  for (var i = 0; i < fileList.length; i++) {
    var f = fileList[i];
    var isFImg = /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(f.name);
    var sizeKb = Math.round(f.size / 1024);
    var sizeStr = sizeKb > 1024 ? (sizeKb / 1024).toFixed(1) + ' MB' : sizeKb + ' KB';
    if (previewEl) {
      previewEl.innerHTML = '<span>⏳ ' + (isFImg ? '🖼️' : '📁') + ' [' + (i + 1) + '/' + fileList.length + ' 전송 중]: <b>' + escapeHtml(f.name) + '</b> (' + sizeStr + ')</span>';
    }
    try {
      var base64Data = await new Promise(function(resolve, reject) {
        var reader = new FileReader();
        reader.onload = function(e) { resolve(e.target.result); };
        reader.onerror = reject;
        reader.readAsDataURL(f);
      });

      var res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': authToken
        },
        body: JSON.stringify({
          filename: f.name,
          base64: base64Data,
          targetAi: targetAi,
          uploadType: isFImg ? 'image' : 'file'
        })
      });
      var data = await res.json();
      if (data.success) {
        uploadedFiles.push(data);
      } else {
        failedCount++;
      }
    } catch (err) {
      failedCount++;
    }
  }

  if (uploadedFiles.length > 0) {
    var finalAllImg = uploadedFiles.every(function(u) { return /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(u.filename); });
    var finalHasImg = uploadedFiles.some(function(u) { return /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(u.filename); });
    var finalIcon = finalAllImg ? '🖼️' : '📁';
    var finalLabel = finalAllImg ? '사진' : (finalHasImg ? '파일/사진' : '파일');

    showToast('✅ ' + finalIcon + ' ' + uploadedFiles.length + '개 ' + finalLabel + ' PC 저장 완료!');
    if (previewEl) {
      previewEl.innerHTML = '<span style="color:#34d399;font-weight:700;">✅ ' + finalIcon + ' [' + uploadedFiles.length + '개 ' + finalLabel + ' PC 저장 완료]</span> <button onclick="clearUploadPreview(this)" style="background:none;border:none;color:#94a3b8;font-size:11.5px;cursor:pointer;padding:2px 6px;">[닫기]</button>';
      setTimeout(function() { if (previewEl) previewEl.style.display = 'none'; }, 7000);
    }

    // 채팅창에 즉시 시각적 성공 확인 버블 추가
    var containerId = targetAi === 'assistant' ? 'chatContainer' : (targetAi === 'codex' ? 'codexChatContainer' : (targetAi === 'grok' ? 'grokChatContainer' : 'agyChatContainer'));
    var container = document.getElementById(containerId);
    if (container) {
      var bubble = document.createElement('div');
      bubble.className = 'msg-bubble msg-user';
      bubble.style.borderLeft = '3.5px solid #10b981';
      bubble.style.background = 'rgba(16,185,129,0.12)';
      var filesHtml = uploadedFiles.map(function(u, idx) {
        var subIcon = /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(u.filename) ? '🖼️' : '📁';
        return subIcon + ' ' + (idx + 1) + '. <b>' + escapeHtml(u.filename) + '</b> (' + u.sizeStr + ')';
      }).join('<br>');
      bubble.innerHTML = '<div>' + finalIcon + ' <b>[핸드폰 ' + finalLabel + ' 전송 성공]</b></div><div style="margin-top:5px;font-size:12.5px;line-height:1.5;">' + filesHtml + '</div><div style="color:var(--dim);font-size:11px;margin-top:4px;">💻 PC 저장 위치: uploads/ 폴더에 안전하게 저장되었습니다.</div>';
      container.appendChild(bubble);
      container.scrollTop = container.scrollHeight;
    }

    // 분석 지시는 서버(/api/upload)가 업로드 직후 한 번 보낸다 — 입력창 자동 채움은 같은 지시가 두 번 가게 하므로 제거

    if (targetAi === 'codex' && typeof syncCodexStatus === 'function') syncCodexStatus();
    if (targetAi === 'agy' && typeof syncAgyStatus === 'function') syncAgyStatus();
    if (targetAi === 'grok' && typeof syncGrokStatus === 'function') syncGrokStatus();
    if (targetAi === 'assistant' && typeof syncLiveTranscript === 'function') syncLiveTranscript();
  } else {
    alert('파일 전송 실패: 서버 오류가 발생했습니다.');
    if (previewEl) previewEl.style.display = 'none';
  }

  inputEl.value = '';
}

function clearUploadPreview(btn) {
  var p = btn ? (btn.closest ? btn.closest('.upload-preview-bar') : btn) : null;
  if (p) {
    p.style.display = 'none';
    p.innerHTML = '';
  }
}

function openFileEditor(fileName) {
  if (typeof openEditor === 'function') {
    openEditor(fileName);
  }
}

var currentClipTargetAi = 'assistant';

function openClipModal(targetAi) {
  currentClipTargetAi = targetAi;
  // 라벨의 for 를 현재 채팅창의 input 으로 연결 (브라우저 네이티브로 선택기 오픈 → JS click() 차단 회피)
  ['image', 'camera', 'file'].forEach(function(t) {
    var lb = document.getElementById('clipLabel-' + t);
    if (lb) lb.setAttribute('for', 'filePicker-' + targetAi + '-' + t);
  });
  var modal = document.getElementById('clipChoiceModal');
  if (modal) modal.classList.add('show');
}

// 팝업 항목 탭: 선택기는 label 기본동작으로 열리고, 여기서는 초기화·닫기·안내만 한다
function onClipPick(type) {
  var input = document.getElementById('filePicker-' + currentClipTargetAi + '-' + type);
  if (input) input.value = '';
  var modal = document.getElementById('clipChoiceModal');
  if (modal) setTimeout(function() { modal.classList.remove('show'); }, 150);
  if (typeof showToast === 'function') showToast({ image: '🖼️ 갤러리 여는 중...', camera: '📷 카메라 여는 중...', file: '📁 파일 선택 여는 중...' }[type]);
}

function closeClipModal(e) {
  if (e && e.target && e.target.id !== 'clipChoiceModal' && !e.target.classList.contains('clip-modal-close') && !e.target.classList.contains('clip-pick-cancel-btn')) {
    return;
  }
  var modal = document.getElementById('clipChoiceModal');
  if (modal) modal.classList.remove('show');
}

function triggerPickOption(type, targetAi) {
  if (targetAi) currentClipTargetAi = targetAi;
  var modal = document.getElementById('clipChoiceModal');
  if (modal) modal.classList.remove('show');
  var inputId = 'filePicker-' + currentClipTargetAi + '-' + type;
  var input = document.getElementById(inputId);
  if (input) {
    input.value = '';
    input.click();
  }
}

// 아이프레임(Hub 내부)에서 동작 중일 때 중복 PC 전환 버튼 자동 숨김
if (window.self !== window.top) {
  var switchBtns = document.querySelectorAll('.btn-pc-switch');
  switchBtns.forEach(function(b) { b.style.display = 'none'; });
}

if (token) {
  initApp();
} else {
  showLoginOverlay();
}
</script>

</body>
</html>`;
}

server.on('error', (err) => {
  console.error('❌ [Server Error]', err);
  try {
    fs.writeFileSync(path.join(__dirname, 'server_error.txt'), 'ERROR: ' + err.stack);
  } catch (_) {}
  if (err.code === 'EADDRINUSE') {
    console.error(`⚠️ 포트 ${PORT}가 이미 사용 중입니다. 1.5초 후 재시도합니다...`);
    setTimeout(() => {
      try { server.close(); } catch (_) {}
      server.listen(PORT);
    }, 1500);
  }
});

// 메인 워커 = PC의 진짜 Claude Code 창. 없으면 하나 띄운다 (있으면 그 창을 그대로 미러링)
mainBridge.ensureWindow().then((pid) => console.log(PROJECT_ROLE === 'daemon' ? `🤖 메인 워커 = 창 없는 데몬 (claude -p --resume, 세션 ${mainBridge.getStatus().conversationId})` : (pid ? `🪟 메인 워커 창(claude.exe PID ${pid}) 연결` : '⚠️ 메인 워커 창을 찾지/띄우지 못했습니다'))).catch(() => {});

server.listen(PORT, () => {
  try {
    fs.writeFileSync(path.join(__dirname, 'server_started.txt'), 'RUNNING_AT_' + new Date().toISOString() + '_PORT_' + PORT);
  } catch (_) {}
  const ips = getLocalIpAddresses();
  console.log('=====================================================');
  console.log(`🚀 [Mobile Remote Console] 서버가 시작되었습니다!`);
  console.log(`🔑 기본 보안 PIN 코드: ${PIN_CODE}`);
  console.log('-----------------------------------------------------');
  console.log(`📱 [같은 Wi-Fi 접속용 로컬 주소]:`);
  ips.forEach(ip => {
    console.log(`   👉 http://${ip}:${PORT}`);
  });
  console.log(`💻 [PC 로컬 주소]: http://localhost:${PORT}`);
  console.log('=====================================================');
});
