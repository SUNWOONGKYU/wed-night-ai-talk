/**
 * 일일 스모크 (2026-09-21) — 4개 AI CLI 에 짧은 실제 작업 1건씩을 시켜 결과를 날짜 파일로 남긴다.
 *  node smoke_daily.js [--out <결과 폴더>] [--notify <통지 폴더>] [--ais codex,agy]
 *   - 결과: <out>/YYYY-MM-DD.md   (기본 out = 이 폴더의 _smoke/)
 *   - 실패가 있으면 <notify>/YYYY_MM_DD__HH.MM_PC회신_스모크실패_<PC명>.md 통지 파일 (기본 notify = out)
 *   - 버전 실측(cli_versions)·검증표 대조 결과도 같이 적는다. 비밀은 기록하지 않는다.
 *  Windows 작업 스케줄러: OneMACS-DailySmoke (매일 07:30) — 등록 명령은 보고서/운영 문서 참고
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const adapters = require('./adapters');
const { runCli } = require('./bridge_retry');
const { classifyFailure, LABEL } = require('./fail_msg');
const { detectVersions } = require('./cli_versions');

const args = process.argv.slice(2);
function opt(name, dflt) { const i = args.indexOf(name); return i !== -1 && args[i + 1] ? args[i + 1] : dflt; }
const OUT_DIR = path.resolve(opt('--out', path.join(__dirname, '_smoke')));
const NOTIFY_DIR = path.resolve(opt('--notify', OUT_DIR));
const AIS = opt('--ais', '') ? opt('--ais', '').split(',').map(s => s.trim()).filter(Boolean) : adapters.names;
const TIMEOUT_MS = 5 * 60 * 1000;

// AI 마다 "짧지만 실제 작업" — 답이 정해져 있어 맞았는지 바로 판정
const TASKS = {
  claude: { prompt: '17 곱하기 3 을 계산해 숫자만 답해', expect: /\b51\b/ },
  codex: { prompt: '17 곱하기 3 을 계산해 숫자만 답해', expect: /\b51\b/ },
  agy: { prompt: '17 곱하기 3 을 계산해 숫자만 답해', expect: /\b51\b/ },
  grok: { prompt: '17 곱하기 3 을 계산해 숫자만 답해', expect: /\b51\b/ }
};

function workDir() { const d = path.join(os.tmpdir(), 'onemacs_smoke'); try { fs.mkdirSync(d, { recursive: true }); } catch (_) {} return d; }
function pad(n) { return String(n).padStart(2, '0'); }
function stamp(d) { return d.getFullYear() + '_' + pad(d.getMonth() + 1) + '_' + pad(d.getDate()) + '__' + pad(d.getHours()) + '.' + pad(d.getMinutes()); }

async function smokeOne(ai) {
  const ad = adapters.get(ai); const t = TASKS[ai];
  const t0 = Date.now();
  const r = { ai, label: LABEL[ai] || ai, ok: false, ms: 0, format: '', reply: '', cause: '', message: '' };
  try {
    const o = { cwd: workDir() }; if (ai === 'claude') o.json = true; if (ai === 'agy') { o.printTimeout = '4m'; o.model = process.env.AGY_MODEL || undefined; }
    const spec = ad.buildArgs(t.prompt, o);
    const x = await runCli(spec, { timeoutMs: TIMEOUT_MS });
    r.ms = Date.now() - t0;
    if (x.spawnError) { const f = classifyFailure({ ai, kind: 'spawn', stderr: x.spawnError }); r.cause = f.cause; r.message = f.title; return r; }
    if (x.timedOut) { const f = classifyFailure({ ai, kind: 'timeout', minutes: TIMEOUT_MS / 60000 }); r.cause = f.cause; r.message = f.title; return r; }
    const p = ad.parseOutput(x.stdout, x.stderr, x.code, {});
    r.format = p.format || ''; r.reply = String(p.reply || '').replace(/\s+/g, ' ').slice(0, 120);
    if (p.ok && t.expect.test(p.reply || '')) { r.ok = true; return r; }
    if (p.ok) { r.cause = '답 불일치'; r.message = '답은 왔지만 기대값(51)이 아닙니다'; return r; }
    const f = classifyFailure({ ai, kind: x.code === 0 ? 'parse' : 'exit', code: x.code, stderr: x.stderr, stdout: x.stdout, error: p.error });
    r.cause = f.cause; r.message = f.title; return r;
  } catch (e) { r.ms = Date.now() - t0; r.cause = '알 수 없음'; r.message = String(e.message || e).slice(0, 100); return r; }
}

(async () => {
  const now = new Date();
  const day = now.toISOString().slice(0, 10);
  const host = os.hostname();
  const ver = await detectVersions(AIS);
  const results = await Promise.all(AIS.map(smokeOne));
  const failed = results.filter(r => !r.ok);

  const lines = [];
  lines.push('# 원맥스 일일 스모크 ' + day + ' (' + host + ')');
  lines.push('');
  lines.push('실행: ' + now.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }) + ' · 결과: ' + (failed.length ? '실패 ' + failed.length + '건' : '전부 정상'));
  lines.push('');
  lines.push('| AI | 설치 버전 | 검증표 | 응답 | 형식 | 걸린 시간 | 답 / 원인 |');
  lines.push('|---|---|---|---|---|---|---|');
  for (const r of results) {
    const v = ver.versions[r.ai] || {};
    lines.push('| ' + r.label + ' | ' + (v.installed || '없음') + ' | ' + (v.status === 'verified' ? '확인됨' : (v.status === 'newer_unverified' ? '새 버전(미확인)' : (v.status || '-'))) + ' | ' + (r.ok ? '정상' : '실패') + ' | ' + (r.format || '-') + ' | ' + Math.round(r.ms / 1000) + '초 | ' + (r.ok ? r.reply : (r.message || r.cause)) + ' |');
  }
  lines.push('');
  if (ver.unverified.length) lines.push('※ 미확인 버전: ' + ver.unverified.map(k => (ver.versions[k].label + ' ' + ver.versions[k].installed)).join(', ') + ' — 어댑터(adapters/*.js) 점검 후 cli_compat.json 의 verified 를 올릴 것.');
  if (failed.length) lines.push('※ 실패한 AI 는 PC 의 Claude Code 에 "원맥스 진단해줘" 로 원인을 확인한다.');
  const md = lines.join('\n') + '\n';

  try { fs.mkdirSync(OUT_DIR, { recursive: true }); } catch (_) {}
  const outFile = path.join(OUT_DIR, day + '.md');
  fs.writeFileSync(outFile, md, 'utf8');
  console.log(md);
  console.log('→ ' + outFile);

  if (failed.length) {
    try { fs.mkdirSync(NOTIFY_DIR, { recursive: true }); } catch (_) {}
    const nf = path.join(NOTIFY_DIR, stamp(now) + '_PC회신_스모크실패_' + host + '.md');
    const body = ['# 일일 스모크 실패 통지 (' + host + ', ' + day + ')', '', '실패: ' + failed.map(r => r.label + ' — ' + (r.message || r.cause)).join(' / '), '', '상세: ' + outFile, '', '조치: PC 의 Claude Code 에 "원맥스 진단해줘". 새 버전이면 adapters/<ai>.js 점검 → cli_compat.json 갱신 → 헬스체크 재실행.', ''].join('\n');
    fs.writeFileSync(nf, body, 'utf8');
    console.log('→ 통지: ' + nf);
  }
  process.exit(failed.length ? 2 : 0);
})();
