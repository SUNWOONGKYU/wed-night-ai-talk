/**
 * 원스톱 멀티 에이전트 모바일 콘솔 — 올인원 러너 (배포판)
 * server.js(포트) + Cloudflare 빠른 터널 → 폰 접속 주소를 화면·파일·QR 페이지로 알려준다.
 * 설정: console_config.json (pin, port, agy_model, projects, pair_code, pair_hub_url)
 */
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CFG_FILE = path.join(__dirname, 'console_config.json');
let cfg = { pin: '1234', port: 7890, agy_model: 'gemini-3.8-flash-high', scanner_tab: false };
try { cfg = Object.assign(cfg, JSON.parse(fs.readFileSync(CFG_FILE, 'utf8').replace(/^\uFEFF/, ''))); } catch (e) { console.log('⚠️ console_config.json 읽기 실패(기본값 사용): ' + e.message); }
// PIN 은 사용자가 정하지 않는다 — 없거나, 6자리가 아니거나, 약한 값(1234·0000·111111·123456…)이면 무작위 6자리를 새로 만들어 저장하고 알린다 (2026-09-21 보안)
const WEAK_PIN = /^(1234|0000|1111|123456|654321|000000|111111|222222|333333|444444|555555|666666|777777|888888|999999|121212|112233|123123)$/;
if (!cfg.pin || !/^\d{6}$/.test(String(cfg.pin)) || WEAK_PIN.test(String(cfg.pin)) || /^(\d)\1+$/.test(String(cfg.pin))) {
  cfg.pin = String(Math.floor(100000 + Math.random() * 900000));
  try { const raw = JSON.parse(fs.readFileSync(CFG_FILE, 'utf8').replace(/^\uFEFF/, '')); raw.pin = cfg.pin; fs.writeFileSync(CFG_FILE, JSON.stringify(raw, null, 2), 'utf8'); } catch (_) {}
  console.log('🔐 PIN 이 기본값이라 새로 만들었습니다: ' + cfg.pin + '  (console_config.json 에 저장됨 — 폰에서 PC 를 처음 열 때 이 6자리를 넣으세요)');
}
process.env.PIN = String(cfg.pin);
process.env.PORT = String(cfg.port);
process.env.AGY_MODEL = (cfg.workers && cfg.workers.agy && cfg.workers.agy.model) || cfg.agy_model;
process.env.CONSOLE_WORKERS = JSON.stringify(cfg.workers || {}); // 설치 마법사가 정한 AI 구성(켜기/끄기·모델) → server.js/브릿지
process.env.SCANNER_TAB = cfg.scanner_tab ? '1' : '';
// 보안(2026-09-21): 권한 모드(기본 safe)·PC 창 미러링(기본 끔)·한도 표시(기본 끔) → 자식 서버·브릿지
process.env.CONSOLE_PERM_MODE = String(cfg.perm_mode || 'safe').toLowerCase() === 'full' ? 'full' : 'safe';
process.env.CONSOLE_MIRROR = cfg.mirror_window === true ? '1' : '0';
process.env.CONSOLE_SHOW_QUOTA = cfg.show_quota === true ? '1' : '0';
if (process.env.CONSOLE_PERM_MODE === 'full') console.log('⚠️ 전체 권한 모드입니다 — AI 가 확인 없이 명령을 실행합니다. 안전 모드로 돌리려면 console_config.json 의 perm_mode 를 "safe" 로.');
process.env.CONSOLE_HOME = process.env.CONSOLE_HOME || __dirname; // 상태 파일(cli_versions/health_state/last_failure)은 콘솔 폴더 한 곳에 (2026-09-21)

const LOG_FILE = path.join(__dirname, 'start_all.log');
function log(msg) { const line = '[' + new Date().toLocaleTimeString('ko-KR') + '] ' + msg; console.log(line); try { fs.appendFileSync(LOG_FILE, line + '\n', 'utf8'); } catch (_) {} }
fs.writeFileSync(LOG_FILE, '=== 콘솔 기동 ' + new Date().toISOString() + ' ===\n', 'utf8');

log('1단계: 콘솔 서버 기동 (포트 ' + cfg.port + ')');
// config 에 projects 목록이 있으면 프로젝트 라우터(PC 한 대에 프로젝트 여러 개)가 포트를 맡는다
const MULTI = Array.isArray(cfg.projects) && cfg.projects.length > 0;
try { require(MULTI ? './project_router.js' : './server.js'); } catch (e) { log('❌ 콘솔 로드 실패: ' + e.message); process.exit(1); }

// 1-b 단계 (2026-09-21, 기동을 막지 않는 비동기): AI CLI 버전 실측·검증표(cli_compat.json) 대조 → 미확인 버전은 로그와 폰 상태줄에 안내.
//   20초 뒤 헬스체크(각 AI 에 "답으로 OK만 출력") 1회 + 6시간마다. 원격 호환 공지(compat_notice.js)는 하루 1회 확인.
setTimeout(() => {
  try {
    require('./cli_versions.js').detectVersions().then((s) => {
      for (const k of Object.keys(s.versions)) { const v = s.versions[k]; log('AI 프로그램 ' + v.label + ': ' + (v.installed || '없음') + (v.status === 'verified' ? ' (확인된 버전)' : (v.message ? ' — ' + v.message : ''))); }
      if (s.unverified.length) log('⚠️ 확인되지 않은 버전이 있습니다. 문제가 생기면 PC 의 Claude Code 에 "원맥스 진단해줘" 라고 시키세요.');
    }).catch(e => log('버전 확인 실패: ' + e.message));
  } catch (e) { log('cli_versions 모듈 오류: ' + e.message); }
  try { require('./healthcheck.js').schedule(log, 20000); } catch (e) { log('healthcheck 모듈 오류: ' + e.message); }
  try { require('./compat_notice.js').schedule(log); } catch (e) { log('compat_notice 모듈 오류: ' + e.message); }
}, 3000);


// ---------- 페어링 허브 등록 (콘솔 시스템 앱·허브 페이지가 이 PC 를 찾는 방법) ----------
// pair_hub_url: 기본 https://console-hub.consolesystem.workers.dev · pair_code: 없으면 8자리 자동 생성해 console_config.json 에 저장
const https = require('https');
const os = require('os');
const PAIR_HUB_URL = String(cfg.pair_hub_url || 'https://console-hub.consolesystem.workers.dev').replace(/\/+$/, '');
function ensurePairCode() {
  const re = /^[A-HJ-NP-Z2-9]{8}$/;
  if (cfg.pair_code && re.test(String(cfg.pair_code).toUpperCase())) return String(cfg.pair_code).toUpperCase();
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = require('crypto').randomBytes(8);
  let code = ''; for (let i = 0; i < 8; i++) code += alphabet[bytes[i] % alphabet.length];
  try {
    const raw = JSON.parse(fs.readFileSync(CFG_FILE, 'utf8').replace(/^﻿/, ''));
    raw.pair_code = code; fs.writeFileSync(CFG_FILE, JSON.stringify(raw, null, 2), 'utf8');
  } catch (e) { log('⚠️ pair_code 저장 실패: ' + e.message); }
  cfg.pair_code = code;
  return code;
}
const PAIR_CODE = (cfg.pair_hub_url === false) ? null : ensurePairCode();
function registerPairHub(publicUrl) {
  if (!PAIR_CODE) return;
  const projName = (Array.isArray(cfg.projects) && cfg.projects.length) ? String(cfg.projects[0].name) : path.basename(path.resolve(__dirname, '..'));
  const body = JSON.stringify({ code: PAIR_CODE, hostname: os.hostname(), project: projName, label: String(cfg.pc_label || ''), url: publicUrl });
  const u = new URL(PAIR_HUB_URL + '/register');
  const req = https.request({ hostname: u.hostname, path: u.pathname, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }, timeout: 8000 }, (res) => {
    let b = ''; res.on('data', d => b += d); res.on('end', () => { if (res.statusCode !== 200) log('⚠️ 페어링 허브 등록 실패 ' + res.statusCode + ' ' + b.slice(0, 120)); });
  });
  req.on('timeout', () => req.destroy()); req.on('error', (e) => log('⚠️ 페어링 허브 연결 실패: ' + e.message)); req.end(body);
}
const CF = path.join(__dirname, 'cloudflared.exe');
setTimeout(() => {
  if (!fs.existsSync(CF)) { log('❌ cloudflared.exe 없음 — 같은 폴더에 있어야 합니다'); return; }
  log('2단계: 인터넷 터널 연결 중...');
  const cf = spawn(CF, ['tunnel', '--url', 'http://127.0.0.1:' + cfg.port], { windowsHide: true });
  let found = false;
  const onData = (d) => {
    const m = d.toString().match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/);
    if (m && !found) {
      found = true;
      const url = m[0] + '/?pin=' + encodeURIComponent(cfg.pin);
      fs.writeFileSync(path.join(__dirname, '모바일_접속링크.txt'), url + '\n', 'utf8');
      const html = '<!doctype html><meta charset="utf-8"><title>폰 접속 QR</title><body style="font-family:sans-serif;text-align:center;padding:30px"><h2>폰 카메라로 QR을 찍으세요</h2><img src="https://api.qrserver.com/v1/create-qr-code/?size=280x280&data=' + encodeURIComponent(url) + '"><p style="word-break:break-all;font-size:14px">' + url + '</p><p style="color:#666">주소는 콘솔을 켤 때마다 바뀝니다. 폰에서 열린 페이지를 홈 화면에 추가해 두면 편합니다.</p></body>';
      const qr = path.join(__dirname, '모바일_접속_QR.html');
      fs.writeFileSync(qr, html, 'utf8');
      log('🎉 폰 접속 주소: ' + url);
      log('   → 모바일_접속링크.txt / 모바일_접속_QR.html 에 저장됨 (QR 페이지를 자동으로 엽니다)');
      if (PAIR_CODE) {
        registerPairHub(m[0]);
        setInterval(() => registerPairHub(m[0]), 60 * 1000);
        fs.writeFileSync(path.join(__dirname, '페어링코드.txt'), PAIR_CODE + '\n' + PAIR_HUB_URL + '/?code=' + PAIR_CODE + '\n', 'utf8');
        log('');
        log('🔑 페어링 코드: ' + PAIR_CODE + '   ← 콘솔 시스템 앱에 이 8자리를 넣으세요 (페어링코드.txt 에도 저장)');
        log('📱 앱 없이 브라우저: ' + PAIR_HUB_URL + '/?code=' + PAIR_CODE);
        log('');
      }
      try { spawn('cmd.exe', ['/c', 'start', '', qr], { windowsHide: true, detached: true }).unref(); } catch (_) {}
    }
  };
  cf.stdout.on('data', onData); cf.stderr.on('data', onData);
  cf.on('close', (c) => log('⚠️ 터널 종료 (code ' + c + ') — 창을 닫았거나 네트워크 문제. 다시 실행하세요.'));
  process.on('SIGINT', () => { try { cf.kill(); } catch (_) {} process.exit(); });
}, 1500);
