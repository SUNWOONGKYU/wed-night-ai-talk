# 원맥스 One MACS — 배포판 v3 (먼저 읽기)

폰에서 내 PC 의 AI 4종(Claude Code·Codex·Antigravity·Grok)을 지휘하는 콘솔. **PC 가 서버, 폰은 화면.**

## 설치 (3단계)
1. 이 zip 을 아무 폴더에 푼다.
2. 그 폴더에서 Claude Code 를 열고 `docs\CLAUDE_CODE_설치지시문.md` 를 읽힌다 — 문답 몇 개 뒤 Claude Code 가 `install.ps1` 을 실행해 `C:\OneMACS` 에 설치·기동한다.
3. 폰에서 허브 → 내 PC → PIN → 프로젝트 `원맥스` 에 인사를 보내 답이 오면 끝.

사람이 읽는 설명은 `docs\설치가이드.md`, 허브를 직접 만들려면 `docs\허브_직접_만들기.md`, 이용권은 `docs\허브_이용권_안내.md`.

## 폴더
- `console\` 콘솔 코드 (install.ps1 이 `C:\OneMACS\console` 로 복사)  · `install.ps1` 설치/업데이트  · `CLAUDE.md` 원맥스 채널 규칙
- `hub_selfhost\` 허브 직접 구축용  · `addons\` 선택 패키지  · `docs\` 문서

## 업데이트
새 zip 을 받아 같은 폴더 구조로 풀고 `install.ps1 -Update` — 설정·세션·로그는 그대로, 코드만 바뀐다.
