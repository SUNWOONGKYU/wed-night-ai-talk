# addons — 선택 설치 패키지

여기에 든 패키지는 콘솔과 별개로, 원하면 설치한다. 각 폴더의 `CLAUDE_CODE_*설치지시문.md` 를 Claude Code 에 읽히면 그 폴더의 지시대로 설치한다.

| 폴더 | 내용 | 전제 |
|---|---|---|
| `trading-bot\` | 주식매매 자동화 봇 실행기 (신호만 보는 `live:false` 가 기본) | Python, 본인 증권사 API 키, 콘솔의 `트레이딩 시그널` 프로젝트 |
| `report-agent\` | 보고서 작성 에이전트 | Python 3.14 + requirements, claude·codex CLI 로그인 |

패키지가 아직 없으면(빈 폴더) 다음 배포판에서 제공된다.
