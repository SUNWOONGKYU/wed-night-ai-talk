/**
 * 콘솔 설정 저장소 (2026-09-21) — 폰 ⚙ 설정 패널의 8항목을 console_config.json 에 저장하고 즉시 반영한다.
 *  server.js(/api/settings·탭 소제목)·bridges(모델·제한 시간·재시도)가 전부 이 모듈로 읽는다 — 파일 mtime 이 바뀌면 다시 읽는다.
 *
 *  console_config.json 키 (없으면 기본값):
 *    workers.<claude|codex|agy|grok>.model   — 그 CLI 가 실제 받는 모델 이름 (아래 CATALOG 의 id 만 허용)
 *    chat_view_mode   'summary'|'detail'|'full'      답 표시 방식 기본값
 *    notify_on_done   true|false                     작업 끝나면 알림 (앱이 읽는다)
 *    delegate_default 'both'|'all'                   동시에 시키기 기본 대상 (both=Codex+Antigravity, all=셋 다)
 *    timeout_min      { claude:30, codex:20, agy:20, grok:20 }  작업 제한 시간(분) — 기본값보다 줄일 수 없다
 *    auto_retry       true|false                     실패 시 1회 자동 재시도
 *    show_quota       true|false                     남은 한도 표시
 *    theme            'light'|'dark'|'system'        화면 테마
 *  권한 모드·PIN 은 여기서 다루지 않는다 (PC 에서만).
 */
const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'console_config.json');

/** 모델 목록 — 각 CLI 가 실제 받는 이름만. 근거는 evidence (도움말/목록 명령 출력 발췌, 2026-09-21 PC3 확인) */
const CATALOG = {
  claude: {
    flag: '--model', evidence: "claude --help: --model <model>  Model for the current session. Provide an alias for the latest model (e.g. 'fable', 'opus', or 'sonnet') or a model's full name (e.g. 'claude-fable-5').",
    items: [
      { id: 'claude-opus-5', label: 'Opus 5' },
      { id: 'claude-sonnet-5', label: 'Sonnet 5' },
      { id: 'claude-haiku-4-5-20251001', label: 'Haiku 4.5' },
    ], default: 'claude-opus-5' },
  codex: {
    flag: '-m', evidence: 'codex --help / codex exec --help: -m, --model <MODEL>  Model the agent should use. 이름은 ~/.codex/models_cache.json slug: gpt-5.6-sol · gpt-5.6-terra · gpt-5.6-luna · gpt-5.5 (config.toml 기본 gpt-5.6-luna)',
    items: [
      { id: 'gpt-5.6-terra', label: 'GPT-5.6 Terra' },
      { id: 'gpt-5.6-sol', label: 'GPT-5.6 Sol' },
      { id: 'gpt-5.6-luna', label: 'GPT-5.6 Luna' },
      { id: 'gpt-5.5', label: 'GPT-5.5' },
    ], default: 'gpt-5.6-terra' },
  agy: {
    flag: '--model', evidence: 'agy --help: --model  Model for the current CLI session / agy models: gemini-3.8-flash-high|medium|low, gemini-3.7-flash-*, gemini-3.6-flash-*, gemini-3.1-pro-high|low, claude-sonnet-4-6, claude-opus-4-6-thinking, gpt-oss-120b-medium',
    items: [
      { id: 'gemini-3.8-flash-high', label: 'Gemini 3.8 Flash (High)' },
      { id: 'gemini-3.8-flash-medium', label: 'Gemini 3.8 Flash (Medium)' },
      { id: 'gemini-3.8-flash-low', label: 'Gemini 3.8 Flash (Low)' },
      { id: 'gemini-3.7-flash-high', label: 'Gemini 3.7 Flash (High)' },
      { id: 'gemini-3.6-flash-high', label: 'Gemini 3.6 Flash (High)' },
      { id: 'gemini-3.1-pro-high', label: 'Gemini 3.1 Pro (High)' },
      { id: 'gemini-3.1-pro-low', label: 'Gemini 3.1 Pro (Low)' },
      { id: 'claude-sonnet-4-6', label: 'Claude Sonnet 4.6 (Thinking)' },
      { id: 'claude-opus-4-6-thinking', label: 'Claude Opus 4.6 (Thinking)' },
      { id: 'gpt-oss-120b-medium', label: 'GPT-OSS 120B (Medium)' },
    ], default: 'gemini-3.8-flash-high' },
  grok: {
    flag: '-m', evidence: 'grok --help: -m, --model <MODEL>  Model ID to use / grok models: grok-4.6 (default), grok-4.5',
    items: [
      { id: 'grok-4.6', label: 'grok-4.6' },
      { id: 'grok-4.5', label: 'grok-4.5' },
    ], default: 'grok-4.6' },
};
const AIS = ['claude', 'codex', 'agy', 'grok'];
const TIMEOUT_DEFAULT = { claude: 30, codex: 20, agy: 20, grok: 20 };
const TIMEOUT_MAX = 180;
const DEFAULTS = { chat_view_mode: 'summary', notify_on_done: true, delegate_default: 'both', auto_retry: true, show_quota: false, theme: 'dark' }; // 기본 테마 dark(PO 2026-09-22)

let _cache = { mtime: -1, raw: {} };
function readRaw() {
  try {
    const st = fs.statSync(FILE);
    if (st.mtimeMs !== _cache.mtime) _cache = { mtime: st.mtimeMs, raw: JSON.parse(fs.readFileSync(FILE, 'utf8').replace(/^﻿/, '')) || {} };
  } catch (_) { _cache = { mtime: -1, raw: _cache.raw || {} }; }
  return _cache.raw;
}

function modelLabel(ai, id) {
  const c = CATALOG[ai]; if (!c) return id || '';
  const hit = c.items.find(x => x.id === id);
  return hit ? hit.label : (id || '');
}

/** 현재 설정(기본값 병합). 환경변수 CONSOLE_WORKERS(기동 시 스냅샷)보다 파일이 우선 — 폰에서 바꾼 값이 즉시 반영되게 */
function get() {
  const raw = readRaw();
  const workers = raw.workers || {};
  let envWorkers = {}; try { envWorkers = JSON.parse(process.env.CONSOLE_WORKERS || '{}') || {}; } catch (_) {}
  const models = {};
  for (const ai of AIS) {
    const fromFile = workers[ai] && workers[ai].model;
    const fromEnv = envWorkers[ai] && envWorkers[ai].model;
    const fromAgyEnv = ai === 'agy' ? process.env.AGY_MODEL : '';
    models[ai] = String(fromFile || fromEnv || fromAgyEnv || CATALOG[ai].default);
  }
  const t = Object.assign({}, TIMEOUT_DEFAULT, raw.timeout_min || {});
  for (const ai of AIS) t[ai] = Math.max(TIMEOUT_DEFAULT[ai], Math.min(TIMEOUT_MAX, parseInt(t[ai], 10) || TIMEOUT_DEFAULT[ai]));
  const envQuota = process.env.CONSOLE_SHOW_QUOTA;
  return {
    models,
    model_labels: Object.fromEntries(AIS.map(ai => [ai, modelLabel(ai, models[ai])])),
    chat_view_mode: ['summary', 'detail', 'full'].includes(raw.chat_view_mode) ? raw.chat_view_mode : DEFAULTS.chat_view_mode,
    notify_on_done: raw.notify_on_done === undefined ? DEFAULTS.notify_on_done : !!raw.notify_on_done,
    delegate_default: raw.delegate_default === 'all' ? 'all' : 'both',
    timeout_min: t,
    auto_retry: raw.auto_retry === undefined ? DEFAULTS.auto_retry : !!raw.auto_retry,
    show_quota: envQuota === '1' ? true : (envQuota === '0' ? false : (raw.show_quota === undefined ? DEFAULTS.show_quota : !!raw.show_quota)),
    theme: ['light', 'dark', 'system'].includes(raw.theme) ? raw.theme : DEFAULTS.theme,
  };
}

/** 부분 갱신. 검증 실패 항목은 errors 로 돌려주고 나머지만 저장. 다른 키(pin·projects 등)는 손대지 않는다 */
function set(patch) {
  patch = patch || {};
  const raw = readRaw();
  const out = JSON.parse(JSON.stringify(raw));
  const errors = [];
  if (patch.models && typeof patch.models === 'object') {
    out.workers = out.workers || {};
    for (const ai of AIS) {
      const id = patch.models[ai]; if (id === undefined) continue;
      if (!CATALOG[ai].items.some(x => x.id === id)) { errors.push('models.' + ai + ': 목록에 없는 모델 (' + String(id).slice(0, 40) + ')'); continue; }
      out.workers[ai] = Object.assign({}, out.workers[ai] || {}, { model: id });
    }
  }
  if (patch.chat_view_mode !== undefined) { if (['summary', 'detail', 'full'].includes(patch.chat_view_mode)) out.chat_view_mode = patch.chat_view_mode; else errors.push('chat_view_mode'); }
  if (patch.notify_on_done !== undefined) out.notify_on_done = !!patch.notify_on_done;
  if (patch.delegate_default !== undefined) { if (['both', 'all'].includes(patch.delegate_default)) out.delegate_default = patch.delegate_default; else errors.push('delegate_default'); }
  if (patch.timeout_min && typeof patch.timeout_min === 'object') {
    out.timeout_min = Object.assign({}, out.timeout_min || {});
    for (const ai of AIS) {
      const v = patch.timeout_min[ai]; if (v === undefined) continue;
      const n = parseInt(v, 10);
      if (!(n >= TIMEOUT_DEFAULT[ai])) { errors.push('timeout_min.' + ai + ': 기본값(' + TIMEOUT_DEFAULT[ai] + '분)보다 줄일 수 없습니다'); continue; }
      out.timeout_min[ai] = Math.min(TIMEOUT_MAX, n);
    }
  }
  if (patch.auto_retry !== undefined) out.auto_retry = !!patch.auto_retry;
  if (patch.show_quota !== undefined) out.show_quota = !!patch.show_quota;
  if (patch.theme !== undefined) { if (['light', 'dark', 'system'].includes(patch.theme)) out.theme = patch.theme; else errors.push('theme'); }
  try {
    fs.writeFileSync(FILE, JSON.stringify(out, null, 2), 'utf8');
    _cache = { mtime: -1, raw: {} }; // 다음 get() 에서 다시 읽기
  } catch (e) { errors.push('저장 실패: ' + e.message); }
  return { settings: get(), errors };
}

function catalog() {
  return Object.fromEntries(AIS.map(ai => [ai, { flag: CATALOG[ai].flag, items: CATALOG[ai].items, default: CATALOG[ai].default, evidence: CATALOG[ai].evidence }]));
}

/** 브릿지용 단축 — 매 지시마다 호출해 "다음 지시부터 적용" */
function modelFor(ai) { return get().models[ai]; }
function timeoutMsFor(ai) { return get().timeout_min[ai] * 60 * 1000; }
function maxRetryFor() { return get().auto_retry ? 1 : 0; }

module.exports = { get, set, catalog, modelFor, timeoutMsFor, maxRetryFor, modelLabel, CATALOG, AIS, TIMEOUT_DEFAULT, TIMEOUT_MAX, FILE };
