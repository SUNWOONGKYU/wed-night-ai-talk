/**
 * 프로젝트 라우터 — PC 한 대에서 프로젝트(폴더) 여러 개를 콘솔 하나(포트 하나)로 서비스
 *
 *  - console_config.json 의 projects: [{ name, dir }] 마다 그 폴더의 _mobile_remote/server.js 를 자식 프로세스로 띄운다 (포트 자동 배정)
 *  - 폰은 라우터(7890) 하나만 본다. 쿠키 cproj=<프로젝트명> 로 어느 자식에게 넘길지 정한다 (기본 = 첫 프로젝트)
 *  - 라우터가 직접 처리: /api/login(모든 자식이 같은 PIN 을 쓰므로 m_sid=PIN 쿠키 발급) · /api/projects · /api/project-select · /api/project-add
 *  - 나머지 요청은 현재 프로젝트 자식에게 그대로 프록시
 *  - 프로젝트 추가: 폴더 생성 → 이 폴더의 코드 파일 복사(상태 파일 제외) → 자식 기동 → config 저장
 *
 * 단독 실행: node project_router.js   (start_all.js 는 config 에 projects 가 있으면 server.js 대신 이 파일을 로드)
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');

const CFG_FILE = path.join(__dirname, 'console_config.json');
function readCfg() { try { return JSON.parse(fs.readFileSync(CFG_FILE, 'utf8').replace(/^﻿/, '')); } catch (_) { return {}; } }
function writeCfg(c) { fs.writeFileSync(CFG_FILE, JSON.stringify(c, null, 2), 'utf8'); }

const cfg = readCfg();
const PORT = Number(process.env.PORT || cfg.port || 7890);
let PIN = String(process.env.PIN || cfg.pin || '0000'); // 핸드폰 설정에서 바꿀 수 있음 (PO 2026-09-22) — 라우터가 자식 전부에 같은 PIN 을 전파
function postChild(port, pathname, bodyObj, timeoutMs) {
  return new Promise((resolve) => {
    const body = JSON.stringify(bodyObj || {});
    const r = http.request({ host: '127.0.0.1', port, path: pathname, method: 'POST', timeout: timeoutMs || 5000, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) } },
      (res) => { let b = ''; res.on('data', d => b += d); res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(b) }); } catch (_) { resolve({ status: res.statusCode, body: null }); } }); });
    r.on('timeout', () => { r.destroy(); resolve(null); }); r.on('error', () => resolve(null)); r.write(body); r.end();
  });
}
const BASE_DIR = path.resolve(__dirname, '..');
const CODE_FILES = ['server.js', 'main_worker_bridge.js', 'claude_bridge.js', 'claude_daemon_bridge.js', 'daemon_ask.js', 'console_inject.ps1', 'proc_cwd.ps1', 'codex_bridge.js', 'antigravity_bridge.js', 'grok_bridge.js', 'delegate.js', 'quota.js', 'package.json',
  // 2026-09-21 운영 안정화: 실패 문구·재시도·헬스·버전 (상태 파일은 CONSOLE_HOME 한 곳에 쓰므로 자식은 코드만 복사)
  'fail_msg.js', 'bridge_retry.js', 'cli_compat.json', 'cli_versions.js', 'healthcheck.js', 'compat_notice.js', 'check_setup.js', 'audit.js', 'perm.js',
  // 2026-09-21 콘솔 설정 패널(21:16 자식 기동 실패 원인: 누락). 새 모듈을 추가하면 이 목록도 세트로 갱신할 것
  'console_settings.js', 'no_stop_button_guard.js'];
const CODE_DIRS = ['adapters', 'hooks']; // 하위 폴더째 복사(*.js 만, 없는 폴더는 건너뜀)
const COOKIE = 'cproj';
const loginFails = new Map(); // ip -> { n, until }   실패 5회 → 1분, 20회 → 1시간 (2026-09-21 보안)
let authLog = () => {}, audit = () => {};
try { ({ authLog, audit } = require('./audit.js')); } catch (_) {}
// 라우터 세션 토큰: 폰에는 무작위 토큰 쿠키를 주고, 자식에게 넘길 때만 PIN 으로 바꿔 준다(자식은 PIN 만 안다). 만료 7일, /api/logout-all 로 세대 교체
const TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000;
let sessionGen = 1;
const tokens = new Map(); // token -> { at, gen }
function newToken() { const t = require('crypto').randomBytes(18).toString('base64url') + Date.now().toString(36); tokens.set(t, { at: Date.now(), gen: sessionGen }); return t; }
function tokenOk(t) { if (!t) return false; if (t === PIN) return true; const i = tokens.get(t); if (!i) return false; if (i.gen !== sessionGen || Date.now() - i.at > TOKEN_TTL_MS) { tokens.delete(t); return false; } return true; }
function clientIp(req) { return String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(); }

function log(m) { console.log('[router ' + new Date().toLocaleTimeString('ko-KR') + '] ' + m); }
function cleanEnv(extra) {
  const env = { ...process.env };
  for (const k of Object.keys(env)) if (/^CLAUDE/.test(k)) delete env[k];
  return Object.assign(env, extra);
}

// ---------- 프로젝트 목록 ----------
// 2026-09-22 원맥스 프로젝트: 콘솔 홈(C:\OneMACS\console)이 첫 프로젝트 폴더 안이 아니라 독립 — home:true 인 프로젝트는 코드 사본을 만들지 않고 이 폴더(__dirname)에서 그대로 자식을 띄운다.
//   1번(PC 창 미러링)은 배열 순서가 아니라 config.primary 로 정한다 (없으면 첫 프로젝트). 그래야 어떤 프로젝트든 순서와 무관하게 1번 지정·해제가 된다.
let projects = Array.isArray(cfg.projects) && cfg.projects.length ? cfg.projects.map(p => ({ name: String(p.name), dir: path.resolve(String(p.dir)), home: !!p.home })) : [{ name: path.basename(BASE_DIR), dir: BASE_DIR, home: true }];
let PRIMARY = (cfg.primary && projects.find(x => x.name === cfg.primary)) ? String(cfg.primary) : projects[0].name;
const children = new Map(); // name -> { port, proc, restarts }

// 2026-09-22 원맥스(④ 프로젝트 관리): 목록·1번을 설정에 되쓰는 헬퍼. home 플래그와 primary 를 같이 저장한다 (전엔 primary 를 읽기만 했음)
function homeProject() { return projects.find(x => x.home) || projects[0]; }
function persistProjects() {
  const c = readCfg();
  c.projects = projects.map(x => Object.assign({ name: x.name, dir: x.dir }, x.home ? { home: true } : {}));
  c.primary = PRIMARY;
  writeCfg(c);
}
/** 자식 서버 프로세스 트리 종료 (server.js → 브릿지가 띄운 claude -p 등). 창(대화형 claude.exe)은 explorer 로 떠서 트리 밖 — 세션이 이어지므로 놔둔다 */
function killTree(pid) {
  return new Promise((resolve) => {
    if (!pid) return resolve();
    const cmd = '$ids=@(' + pid + '); $q=@(' + pid + '); while($q.Count){ $p=$q[0]; $q=@($q | Select-Object -Skip 1); $kids=@(Get-CimInstance Win32_Process -Filter "ParentProcessId=$p" | ForEach-Object { $_.ProcessId }); $ids+=$kids; $q+=$kids }; [array]::Reverse($ids); foreach($i in $ids){ Stop-Process -Id $i -Force -ErrorAction SilentlyContinue }';
    require('child_process').execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', cmd], { windowsHide: true, timeout: 30000 }, () => resolve());
  });
}
/** 자식을 세워서 라우터의 exit 핸들러가 새 역할(primary/daemon)·새 이름으로 다시 띄우게 한다 */
async function restartChild(name) {
  const c = children.get(name); if (!c) return;
  if (c.proc && c.proc.pid) { await killTree(c.proc.pid); }
  else { const p = projects.find(x => x.name === name); if (p) startChild(p); } // 인계받은(프로세스 핸들 없는) 자식은 그냥 새로 띄움
}
// 폴더 연결 검증: 절대경로·존재·시스템 폴더·다른 프로젝트와 같거나 상하위 관계이면 거부
const SYSTEM_DIRS = [process.env.SystemRoot || 'C:\\Windows', process.env.ProgramFiles || 'C:\\Program Files', process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', process.env.ProgramData || 'C:\\ProgramData'].map(canon);
function isInside(child, parent) { const r = path.relative(parent, child); return !!r && !r.startsWith('..') && !path.isAbsolute(r); }
/** 비교용 정규화: 8.3 짧은 이름(VIEWLI~1)·대소문자·심볼릭 링크를 실제 경로로 (없는 경로면 resolve 만) */
function canon(p) { const abs = path.resolve(String(p || '')); try { return fs.realpathSync.native(abs).toLowerCase(); } catch (_) { return abs.toLowerCase(); } }
function validateDir(dir, opts) {
  const abs = path.resolve(String(dir || ''));
  if (!path.isAbsolute(abs) || !/^[a-zA-Z]:\\/.test(abs)) return '절대 경로(예: C:\\폴더)만 됩니다';
  const low = canon(abs);
  if (SYSTEM_DIRS.some(sd => low === sd || isInside(low, sd))) return '시스템 폴더는 연결할 수 없습니다';
  if (/^[a-zA-Z]:\\?$/.test(abs)) return '드라이브 루트는 연결할 수 없습니다';
  if (canon(__dirname) === low || isInside(low, canon(__dirname))) return '콘솔 폴더 자체는 연결할 수 없습니다';
  for (const x of projects) {
    if (opts && opts.skipName === x.name) continue;
    const xd = canon(x.dir);
    if (xd === low) return '이미 "' + x.name + '" 프로젝트로 연결된 폴더입니다';
    if (isInside(low, xd)) return '"' + x.name + '" 프로젝트 폴더(' + x.dir + ') 안에 있는 폴더입니다';
    if (isInside(xd, low)) return '"' + x.name + '" 프로젝트 폴더(' + x.dir + ')를 포함하는 상위 폴더입니다';
  }
  if (opts && opts.mustExist && !(fs.existsSync(abs) && fs.statSync(abs).isDirectory())) return '폴더가 없습니다: ' + abs;
  return null;
}

function nextPort() {
  const used = new Set([PORT, ...[...children.values()].map(c => c.port)]);
  let p = PORT + 1; while (used.has(p)) p++; return p;
}

function syncCode(dir) {
  const target = path.join(dir, '_mobile_remote');
  fs.mkdirSync(target, { recursive: true });
  if (path.resolve(target) === path.resolve(__dirname)) return target;
  for (const f of CODE_FILES) { const src = path.join(__dirname, f); if (fs.existsSync(src)) fs.copyFileSync(src, path.join(target, f)); }
  for (const d of CODE_DIRS) {
    const sd = path.join(__dirname, d); if (!fs.existsSync(sd)) continue;
    const td = path.join(target, d); fs.mkdirSync(td, { recursive: true });
    for (const f of fs.readdirSync(sd)) if (f.endsWith('.js')) fs.copyFileSync(path.join(sd, f), path.join(td, f));
  }
  const cfgPath = path.join(target, 'console_config.json');
  if (!fs.existsSync(cfgPath)) fs.writeFileSync(cfgPath, JSON.stringify({ pin: PIN }, null, 2), 'utf8');
  return target;
}

async function adoptIfRunning(p, port) {
  // 라우터만 재시작된 경우: 같은 폴더를 서비스 중인 자식이 이미 그 포트에 살아 있으면 새로 띄우지 않고 이어 쓴다
  const info = await probe(port, '/api/info?pin=' + encodeURIComponent(PIN), 1500);
  if (info && info.body && info.body.workDir && path.resolve(info.body.workDir) === path.resolve(p.dir)) {
    children.set(p.name, { port, proc: null, restarts: 0, dir: p.dir });
    log('프로젝트 "' + p.name + '" → 포트 ' + port + ' (기존 프로세스 인계)');
    return true;
  }
  return false;
}

function startChild(p) {
  const target = p.home ? __dirname : syncCode(p.dir);
  const port = (children.get(p.name) && children.get(p.name).port) || nextPort();
  // 1번 프로젝트(projects[0])만 대화형 PC 창(primary), 2번째 이후는 창 없는 데몬(daemon) — PC1 19:05 지시 (2026-09-20)
  const role = p.name === PRIMARY ? 'primary' : 'daemon';
  const proc = spawn(process.execPath, ['server.js'], { cwd: target, env: cleanEnv({ PORT: String(port), PIN, PROJECT_NAME: p.name, PROJECT_ROLE: role, CONSOLE_HOME: __dirname, PROJECT_HOME: p.home ? '1' : '0' }), stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
  const rec = { port, proc, restarts: (children.get(p.name) || {}).restarts || 0, dir: p.dir, startedAt: Date.now() };
  children.set(p.name, rec);
  proc.stdout.on('data', d => { const t = String(d).trim(); if (t) log('[' + p.name + ':' + port + '] ' + t.split('\n')[0].slice(0, 160)); });
  proc.stderr.on('data', d => log('[' + p.name + ':' + port + ' ERR] ' + String(d).trim().slice(0, 300)));
  proc.on('exit', (code) => {
    log('[' + p.name + '] 종료 code=' + code);
    // 60초 이상 살았던 자식은 정상 종료(수동 재시작 등)로 보고 재시작 횟수를 초기화 — 반복 크래시만 5회에서 멈춘다
    if (Date.now() - rec.startedAt > 60 * 1000) rec.restarts = 0;
    if (children.get(p.name) === rec && rec.restarts < 5) { rec.restarts++; setTimeout(() => { if (projects.find(x => x.name === p.name)) startChild(p); }, 3000); }
    else if (children.get(p.name) === rec) {
      rec.failed = true; rec.failReason = '반복 크래시(code=' + code + ')';
      log('[' + p.name + '] 반복 크래시 → 재시작 중단');
      // 2026-09-21 21:16 교훈: 새 모듈이 CODE_FILES 에 빠지면 자식이 "Cannot find module" 로 조용히 죽는다 → 한 줄 경고 + /api/projects 에 실패 표시
      const failed = [...children.values()].filter(c => c.failed).length;
      log('⚠️ 프로젝트 ' + failed + '개 기동 실패 — start_all.log 의 "ERR" 줄을 확인하세요 (새 파일이 CODE_FILES 에 빠졌을 때 흔함)');
    }
  });
  log('프로젝트 "' + p.name + '" → 포트 ' + port + ' (' + p.dir + ') [' + role + ']');
  return rec;
}

(async () => {
  for (const p of projects) {
    const port = nextPort();
    children.set(p.name, { port, proc: null, restarts: 0, dir: p.dir }); // 포트 선점
    if (!(await adoptIfRunning(p, port))) startChild(p);
  }
})();

// ---------- 유틸 ----------
function getCookie(req, name) {
  const m = (req.headers.cookie || '').match(new RegExp('(?:^|;\\s*)' + name + '=([^;]*)'));
  return m ? decodeURIComponent(m[1]) : '';
}
function isHttps(req) { return (req.headers['x-forwarded-proto'] || '').includes('https') || /trycloudflare\.com$/i.test(req.headers.host || ''); }
function cookieHeader(req, name, value) { return `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=2592000; ` + (isHttps(req) ? 'SameSite=None; Secure' : 'SameSite=Lax'); }
function json(res, code, obj, extraHeaders) { res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, extraHeaders || {})); res.end(JSON.stringify(obj)); }
function presentedToken(req, url) {
  const q = url.searchParams.get('pin') || url.searchParams.get('token') || '';
  const c = getCookie(req, 'm_sid');
  const a = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '').trim();
  return [a, q, c].find(tokenOk) || '';
}
function authed(req, url) { return !!presentedToken(req, url); }
// /proj/<프로젝트명>/… 경로로 들어온 요청은 그 프로젝트로 (PC2 22:25: 폰 iframe 은 쿠키가 막혀 경로에 프로젝트를 싣는다)
function projectFromPath(pathname) {
  const m = /^\/proj\/([^\/]+)(\/.*)?$/.exec(pathname || '');
  if (!m) return null;
  let name = m[1]; try { name = decodeURIComponent(name); } catch (_) {}
  const p = projects.find(x => x.name === name);
  return p ? { project: p, rest: m[2] || '/' } : null;
}

function currentProject(req, url) {
  // 허브 iframe 안에서는 서드파티 쿠키가 차단될 수 있으므로: 쿼리 ?project= → 헤더 X-Console-Project → 쿠키 → 기본
  let want = '';
  const byPath = projectFromPath((url || new URL(req.url, 'http://x')).pathname);
  if (byPath) return byPath.project; // 경로 지정이 최우선
  try { want = (url || new URL(req.url, 'http://x')).searchParams.get('project') || ''; } catch (_) {}
  if (!want && req.headers['x-console-project']) { try { want = decodeURIComponent(req.headers['x-console-project']); } catch (_) { want = req.headers['x-console-project']; } }
  if (!want) want = getCookie(req, COOKIE);
  return projects.find(p => p.name === want) || homeProject(); // 없는 이름(해제됨)이면 홈(원맥스)으로
}
function readBody(req) { return new Promise((resolve) => { let b = ''; req.on('data', d => b += d); req.on('end', () => resolve(b)); }); }
function probe(port, pathname, timeoutMs) {
  return new Promise((resolve) => {
    const r = http.request({ host: '127.0.0.1', port, path: pathname, method: 'GET', timeout: timeoutMs || 2500 }, (res) => { let b = ''; res.on('data', d => b += d); res.on('end', () => { try { resolve({ status: res.statusCode, body: JSON.parse(b) }); } catch (_) { resolve({ status: res.statusCode, body: null }); } }); });
    r.on('timeout', () => { r.destroy(); resolve(null); }); r.on('error', () => resolve(null)); r.end();
  });
}

// ---------- HTTP ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const pathname = url.pathname;

  // 로그인: 라우터가 처리 → 모든 자식이 받아들이는 m_sid=PIN 쿠키. IP당 5회 실패 시 10분 잠금(무차별 대입 방지)
  if (pathname === '/api/login' && req.method === 'POST') {
    const ip = clientIp(req);
    const f = loginFails.get(ip) || { n: 0, until: 0 };
    if (f.until > Date.now()) {
      authLog(ip, 'LOCKED', 'until=' + new Date(f.until).toISOString());
      const sec = Math.ceil((f.until - Date.now()) / 1000);
      return json(res, 423, { success: false, locked: true, retryAfterSec: sec, error: '로그인 시도가 너무 많아 잠시 잠겼습니다. ' + Math.ceil(sec / 60) + '분 뒤 다시 해 주세요.' }, { 'Retry-After': String(sec) });
    }
    let pin = ''; try { pin = String(JSON.parse(await readBody(req)).pin || ''); } catch (_) {}
    if (pin !== PIN) {
      f.n++;
      if (f.n >= 20) f.until = Date.now() + 60 * 60 * 1000; else if (f.n >= 5) f.until = Date.now() + 60 * 1000;
      loginFails.set(ip, f);
      authLog(ip, 'FAIL', 'n=' + f.n + (f.until > Date.now() ? ' lock_until=' + new Date(f.until).toISOString() : ''));
      if (f.until > Date.now()) log('⛔ 로그인 ' + f.n + '회 실패 → 잠금(' + (f.n >= 20 ? '1시간' : '1분') + '): ' + ip);
      return json(res, 401, { success: false, error: 'PIN 불일치' + (f.n >= 3 ? ' (' + f.n + '회 실패 — 5회면 1분, 20회면 1시간 잠깁니다)' : '') });
    }
    loginFails.delete(ip);
    authLog(ip, 'OK');
    const t = newToken();
    return json(res, 200, { success: true, token: t, expiresInDays: 7 }, { 'Set-Cookie': `m_sid=${encodeURIComponent(t)}; Path=/; HttpOnly; Max-Age=${Math.floor(TOKEN_TTL_MS / 1000)}; ` + (isHttps(req) ? 'SameSite=None; Secure' : 'SameSite=Lax') });
  }

  // PIN 바꾸기 (핸드폰 설정, PO 2026-09-22): 라우터가 검증 → 살아있는 자식 전부에 새 PIN 전파 → 라우터 PIN·config 갱신 → 다른 기기 세션 전부 무효 → 이 기기 새 토큰
  if (pathname === '/api/pin-change' && req.method === 'POST') {
    if (!authed(req, url)) return json(res, 401, { success: false, error: '인증 필요' });
    const ip = clientIp(req);
    const f = loginFails.get(ip) || { n: 0, until: 0 };
    if (f.until > Date.now()) return json(res, 423, { success: false, error: 'PIN 을 너무 많이 틀려 잠시 잠겼습니다. ' + Math.ceil((f.until - Date.now()) / 60000) + '분 뒤 다시 해 주세요.' });
    let d = {}; try { d = JSON.parse(await readBody(req) || '{}'); } catch (_) { return json(res, 400, { success: false, error: '잘못된 요청 형식입니다.' }); }
    if (d.pin_current !== undefined && String(d.pin_current) !== PIN) {
      f.n++; if (f.n >= 20) f.until = Date.now() + 60 * 60 * 1000; else if (f.n >= 5) f.until = Date.now() + 60 * 1000; loginFails.set(ip, f);
      authLog(ip, 'PIN_CHANGE_FAIL', 'n=' + f.n);
      return json(res, 403, { success: false, error: '지금 PIN 이 맞지 않습니다.' + (f.n >= 3 ? ' (' + f.n + '회 실패 — 5회면 1분 잠깁니다)' : '') });
    }
    const np = String(d.pin_new || '');
    const weak = /^(1234|0000|1111|123456|654321|000000|111111|222222|333333|444444|555555|666666|777777|888888|999999|121212|112233)$/;
    if (!/^\d{6}$/.test(np) || weak.test(np) || /^(\d)\1+$/.test(np)) return json(res, 400, { success: false, error: '새 PIN 은 숫자 6자리여야 하고, 123456·000000 처럼 쉬운 번호는 안 됩니다.' });
    if (np === PIN) return json(res, 400, { success: false, error: '지금 PIN 과 같습니다. 다른 번호를 넣어 주세요.' });
    loginFails.delete(ip);
    // 자식 전부에 전파 (자식은 런타임 PIN 만 바꾸고 같은 config 파일에 저장)
    const failedKids = [];
    for (const [nm, c] of children) {
      const r = await postChild(c.port, '/api/pin-change?pin=' + encodeURIComponent(PIN), { pin_current: PIN, pin_new: np }, 6000);
      if (!r || !r.body || !r.body.success) failedKids.push(nm);
    }
    const old = PIN; PIN = np; process.env.PIN = np;
    try { const raw = readCfg(); raw.pin = np; fs.writeFileSync(CFG_FILE, JSON.stringify(raw, null, 2), 'utf8'); } catch (e) { PIN = old; return json(res, 500, { success: false, error: 'PIN 저장에 실패했습니다: ' + e.message }); }
    const before = tokens.size; sessionGen++; tokens.clear();
    const t = newToken();
    audit('pin_change', { ip, invalidated: before, children_failed: failedKids });
    authLog(ip, 'PIN_CHANGED', 'invalidated=' + before + (failedKids.length ? ' children_failed=' + failedKids.join(',') : ''));
    if (failedKids.length) log('⚠ PIN 전파 실패 프로젝트: ' + failedKids.join(', ') + ' (다음 기동 때 config 로 맞춰짐)');
    return json(res, 200, { success: true, token: t, invalidated: before, expiresInDays: 7, children_failed: failedKids },
      { 'Set-Cookie': `m_sid=${encodeURIComponent(t)}; Path=/; HttpOnly; Max-Age=${Math.floor(TOKEN_TTL_MS / 1000)}; ` + (isHttps(req) ? 'SameSite=None; Secure' : 'SameSite=Lax') });
  }

  // 설정 저장 중 권한 모드·미러링은 자식 전부에 전파 (같은 PC 의 프로젝트가 서로 다른 권한으로 돌지 않게). 응답은 현재 프로젝트 것
  if (pathname === '/api/settings' && req.method === 'POST') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    let body = ''; try { body = await readBody(req); } catch (_) {}
    let patch = {}; try { patch = JSON.parse(body || '{}'); } catch (_) { return json(res, 400, { success: false, errors: ['잘못된 요청 형식입니다.'] }); }
    const p0 = currentProject(req, url); const c0 = p0 && children.get(p0.name);
    if (!c0) return json(res, 503, { error: '프로젝트 서버 없음' });
    const broadcast = patch.perm_mode !== undefined || patch.mirror_window !== undefined;
    const main = await postChild(c0.port, '/api/settings?pin=' + encodeURIComponent(PIN), patch, 8000);
    if (broadcast && main && main.body && main.body.success) {
      const sub = {}; if (patch.perm_mode !== undefined) { sub.perm_mode = patch.perm_mode; sub.pin = patch.pin; } if (patch.mirror_window !== undefined) sub.mirror_window = patch.mirror_window;
      for (const [nm, c] of children) { if (c.port === c0.port) continue; await postChild(c.port, '/api/settings?pin=' + encodeURIComponent(PIN), sub, 5000); }
    }
    if (!main) return json(res, 502, { success: false, errors: ['프로젝트 서버가 응답하지 않습니다'] });
    return json(res, main.status || 200, main.body || { success: false, errors: ['응답 없음'] }, { 'Cache-Control': 'no-store' });
  }

  // 현재 세션 외 전부 로그아웃 (세대 번호 증가). PIN 직접 접속(?pin=)은 영향 없음
  if (pathname === '/api/logout-all' && req.method === 'POST') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    const mine = presentedToken(req, url);
    const before = tokens.size;
    sessionGen++; tokens.clear();
    const t = (mine && mine !== PIN) ? mine : newToken();
    tokens.set(t, { at: Date.now(), gen: sessionGen });
    audit('logout_all', { ip: clientIp(req), invalidated: before });
    authLog(clientIp(req), 'LOGOUT_ALL', 'invalidated=' + before);
    return json(res, 200, { success: true, invalidated: before, token: t, message: '다른 기기의 접속을 모두 끊었습니다. 이 기기만 남습니다.' }, { 'Set-Cookie': `m_sid=${encodeURIComponent(t)}; Path=/; HttpOnly; Max-Age=${Math.floor(TOKEN_TTL_MS / 1000)}; ` + (isHttps(req) ? 'SameSite=None; Secure' : 'SameSite=Lax') });
  }

  if (pathname === '/api/projects') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    const cur = currentProject(req, url);
    const ordered = [...projects].sort((a, b) => (b.home ? 1 : 0) - (a.home ? 1 : 0)); // 홈(원맥스)은 항상 맨 위
    const list = await Promise.all(ordered.map(async (p) => {
      const c = children.get(p.name);
      const alive = c ? await probe(c.port, '/api/devices', 2000) : null;
      const lt = alive ? await probe(c.port, '/api/live-transcript?limit=1&pin=' + encodeURIComponent(PIN), 4000) : null;
      return { name: p.name, dir: p.dir, home: !!p.home, primary: p.name === PRIMARY, port: c ? c.port : null, alive: !!alive, failed: !!(c && c.failed), failReason: (c && c.failReason) || null, windowPid: lt && lt.body ? (lt.body.windowPid || null) : null, current: p.name === cur.name, isDefault: p === projects[0] };
    }));
    const failedCount = list.filter(x => x.failed).length;
    const recentRemoved = Array.isArray(readCfg().recent_removed) ? readCfg().recent_removed.slice(0, 5) : [];
    return json(res, 200, { success: true, current: cur.name, primary: PRIMARY, home: homeProject().name, projects: list, recentRemoved, failedCount, notice: failedCount ? ('프로젝트 ' + failedCount + '개 기동 실패 — PC 의 Claude Code 에 "원맥스 진단해줘" 라고 해 주세요') : '' });
  }

  if (pathname === '/api/project-select') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    const name = url.searchParams.get('name') || '';
    const p = projects.find(x => x.name === name);
    if (!p) return json(res, 404, { success: false, error: '없는 프로젝트' });
    return json(res, 200, { success: true, current: p.name }, { 'Set-Cookie': cookieHeader(req, COOKIE, p.name) });
  }

  // 2026-09-22 ④ 프로젝트 추가 — 두 갈래: 기존 폴더 연결(dir) / 새 폴더 만들기(parent + name). 검증 통과 후 config 저장 → 자식 기동
  //   (전: 이름만 받아 projects_root 에 무조건 mkdir — 분기 없음·폴더 중복검사 없음·실패 사유 없음)
  if (pathname === '/api/project-add' && req.method === 'POST') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    let body = {}; try { body = JSON.parse(await readBody(req)); } catch (_) {}
    const name = String(body.name || '').trim().replace(/[\\/:*?"<>|]/g, '').slice(0, 40);
    if (!name) return json(res, 400, { success: false, error: '이름 필요' });
    if (projects.find(x => x.name === name)) return json(res, 409, { success: false, error: '이미 있는 이름' });
    let dir, created = false;
    if (body.dir) {
      dir = path.resolve(String(body.dir));
      const bad = validateDir(dir, { mustExist: true }); if (bad) return json(res, 400, { success: false, error: bad });
    } else {
      const root = body.parent ? path.resolve(String(body.parent)) : (cfg.projects_root ? path.resolve(String(cfg.projects_root)) : '');
      if (!root || !fs.existsSync(root)) return json(res, 400, { success: false, error: '새 폴더를 만들 위치가 없습니다' + (root ? ': ' + root : '') + ' — 위치를 골라 주세요', needParent: true });
      dir = path.join(root, name);
      if (fs.existsSync(dir)) return json(res, 409, { success: false, error: '같은 이름의 폴더가 이미 있습니다: ' + dir + ' — "기존 폴더 연결"로 붙이세요' });
      const bad = validateDir(dir); if (bad) return json(res, 400, { success: false, error: bad });
      try { fs.mkdirSync(dir, { recursive: true }); created = true; } catch (e) { return json(res, 500, { success: false, error: '폴더 생성 실패: ' + e.message }); }
    }
    const p = { name, dir }; projects.push(p); persistProjects();
    audit('project-add', { name, dir, created });
    startChild(p);
    // 자식이 뜰 때까지 잠깐 대기 후 Claude Code 창 확보
    let ok = false; for (let i = 0; i < 20 && !ok; i++) { await new Promise(r => setTimeout(r, 500)); ok = !!(await probe(children.get(name).port, '/api/devices', 1500)); }
    if (ok) { const r = http.request({ host: '127.0.0.1', port: children.get(name).port, path: '/api/main-restart?pin=' + encodeURIComponent(PIN), method: 'POST' }, (rr) => rr.resume()); r.on('error', () => {}); r.end(); }
    const c = children.get(name);
    return json(res, 200, { success: true, name, dir, created, port: c.port, alive: ok, error: ok ? '' : ((c.failReason) || '서버가 아직 안 떴습니다 — 잠시 후 목록에서 확인하세요') }, { 'Set-Cookie': cookieHeader(req, COOKIE, name) });
  }

  // 연결 해제: 목록에서만 뺀다(폴더·세션은 그대로 → 다시 연결하면 대화 이어짐). 홈(원맥스)·1번(PC 창)은 불가
  if (pathname === '/api/project-remove' && req.method === 'POST') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    let body = {}; try { body = JSON.parse(await readBody(req)); } catch (_) {}
    const name = String(body.name || '').trim();
    const p = projects.find(x => x.name === name);
    if (!p) return json(res, 404, { success: false, error: '없는 프로젝트' });
    if (p.home) return json(res, 409, { success: false, error: '원맥스(홈)는 해제할 수 없습니다' });
    if (p.name === PRIMARY) return json(res, 409, { success: false, error: '1번(PC 창) 프로젝트는 해제할 수 없습니다 — 먼저 다른 프로젝트를 1번으로 지정하세요', needPrimaryChange: true });
    const c = children.get(name);
    children.delete(name);
    if (c && c.proc && c.proc.pid) await killTree(c.proc.pid);
    projects.splice(projects.indexOf(p), 1);
    const conf = readCfg();
    conf.recent_removed = [{ name: p.name, dir: p.dir, at: new Date().toISOString() }, ...(Array.isArray(conf.recent_removed) ? conf.recent_removed.filter(x => x && x.name !== p.name) : [])].slice(0, 5);
    writeCfg(conf); persistProjects();
    if (body.deleteConsoleFiles === true) { try { fs.rmSync(path.join(p.dir, '_mobile_remote'), { recursive: true, force: true }); } catch (_) {} }
    audit('project-remove', { name: p.name, dir: p.dir, deleteConsoleFiles: body.deleteConsoleFiles === true });
    log('프로젝트 "' + p.name + '" 연결 해제 (' + p.dir + ')');
    const cur = getCookie(req, COOKIE);
    return json(res, 200, { success: true, name: p.name, dir: p.dir, current: cur === name ? homeProject().name : cur }, cur === name ? { 'Set-Cookie': cookieHeader(req, COOKIE, homeProject().name) } : {});
  }

  // 1번(PC 창) 지정: primary 저장 → 옛 1번은 데몬으로, 새 1번은 PC 창으로 각각 재기동 (세션ID 는 각 폴더에 남아 대화 유지)
  if (pathname === '/api/project-primary' && req.method === 'POST') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    let body = {}; try { body = JSON.parse(await readBody(req)); } catch (_) {}
    const name = String(body.name || '').trim();
    const p = projects.find(x => x.name === name);
    if (!p) return json(res, 404, { success: false, error: '없는 프로젝트' });
    if (p.name === PRIMARY) return json(res, 200, { success: true, primary: PRIMARY, changed: false });
    const old = PRIMARY; PRIMARY = p.name; persistProjects();
    audit('project-primary', { from: old, to: PRIMARY });
    log('1번(PC 창) 변경: ' + old + ' → ' + PRIMARY + ' (두 프로젝트 재기동)');
    await restartChild(old); await restartChild(PRIMARY);
    return json(res, 200, { success: true, primary: PRIMARY, previous: old, changed: true });
  }

  // 이름 바꾸기: 목록·자식 키·쿠키 갱신 후 자식 재기동(PROJECT_NAME 이 바뀜). 폴더·세션은 그대로
  if (pathname === '/api/project-rename' && req.method === 'POST') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    let body = {}; try { body = JSON.parse(await readBody(req)); } catch (_) {}
    const name = String(body.name || '').trim();
    const newName = String(body.newName || '').trim().replace(/[\\/:*?"<>|]/g, '').slice(0, 40);
    const p = projects.find(x => x.name === name);
    if (!p) return json(res, 404, { success: false, error: '없는 프로젝트' });
    if (!newName) return json(res, 400, { success: false, error: '새 이름 필요' });
    if (newName === name) return json(res, 200, { success: true, name, changed: false });
    if (projects.find(x => x.name === newName)) return json(res, 409, { success: false, error: '이미 있는 이름' });
    if (p.home) return json(res, 409, { success: false, error: '원맥스(홈) 이름은 바꿀 수 없습니다' });
    const c = children.get(name); children.delete(name); if (c) children.set(newName, c);
    p.name = newName; if (PRIMARY === name) PRIMARY = newName; persistProjects();
    audit('project-rename', { from: name, to: newName });
    log('프로젝트 이름 변경: ' + name + ' → ' + newName);
    await restartChild(newName);
    const cur = getCookie(req, COOKIE);
    return json(res, 200, { success: true, name: newName, previous: name, changed: true }, cur === name ? { 'Set-Cookie': cookieHeader(req, COOKIE, newName) } : {});
  }

  // 폴더 탐색 (폰에서 "기존 폴더 연결"·"새 폴더 위치" 고르기): 폴더만, 파일 내용 접근 없음. path 없으면 즐겨찾기+드라이브
  if (pathname === '/api/fs-browse') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    const want = String(url.searchParams.get('path') || '').trim();
    const info = (abs) => {
      let files = 0, hasGit = false, hasClaudeMd = false, hasConsole = false;
      try { const ents = fs.readdirSync(abs, { withFileTypes: true }); files = ents.filter(e => e.isFile()).length; hasGit = ents.some(e => e.name === '.git'); hasClaudeMd = ents.some(e => /^claude\.md$/i.test(e.name)); hasConsole = ents.some(e => e.name === '_mobile_remote' && e.isDirectory()); } catch (_) {}
      const linked = projects.find(x => canon(x.dir) === canon(abs));
      return { name: path.basename(abs) || abs, path: abs, files, hasGit, hasClaudeMd, hasConsole, linked: linked ? linked.name : null, blocked: validateDir(abs, { mustExist: true }) };
    };
    if (!want) {
      const home = require('os').homedir();
      const favs = [path.join(home, 'Desktop'), path.join(home, 'Documents'), 'C:\\Dev', cfg.projects_root ? path.resolve(String(cfg.projects_root)) : ''].filter(d => d && fs.existsSync(d));
      const drives = []; for (let i = 67; i <= 90; i++) { const d = String.fromCharCode(i) + ':\\'; try { if (fs.existsSync(d)) drives.push({ name: d, path: d }); } catch (_) {} }
      return json(res, 200, { success: true, favorites: favs.map(info), drives, projectsRoot: cfg.projects_root || '' });
    }
    const abs = path.resolve(want);
    if (!/^[a-zA-Z]:\\/.test(abs)) return json(res, 400, { success: false, error: '절대 경로만 됩니다' });
    let ents; try { ents = fs.readdirSync(abs, { withFileTypes: true }); } catch (e) { return json(res, 400, { success: false, error: '열 수 없는 폴더: ' + e.message }); }
    const dirs = ents.filter(e => e.isDirectory() && !e.name.startsWith('.') && !e.name.startsWith('$') && e.name !== 'node_modules' && e.name !== '_mobile_remote').map(e => info(path.join(abs, e.name))).slice(0, 300);
    const parent = path.dirname(abs) !== abs ? path.dirname(abs) : null;
    return json(res, 200, { success: true, path: abs, parent, here: info(abs), dirs });
  }

  // /api/status: 자식 응답에 라우터의 로그인 실패·잠금 현황을 덮어쓴다 (로그인은 라우터가 처리하므로)
  if (pathname === '/api/status' || pathname === '/api/health') {
    if (!authed(req, url)) return json(res, 401, { error: '인증 필요' });
    const p0 = currentProject(req, url); const c0 = p0 && children.get(p0.name);
    if (!c0) return json(res, 503, { error: '프로젝트 서버 없음' });
    const r0 = await probe(c0.port, pathname + '?pin=' + encodeURIComponent(PIN), 5000);
    const body = (r0 && r0.body) || { at: new Date().toISOString(), notices: [] };
    const now = Date.now(); const list = [];
    for (const [ip, f] of loginFails) if (f.n > 0) list.push({ ip: String(ip).replace(/(\d+\.\d+)\.\d+\.\d+$/, '$1.*.*'), fails: f.n, locked_until: f.until > now ? new Date(f.until).toISOString() : null });
    body.login_failures = { ips: list.length, locked: list.filter(x => x.locked_until).length, list: list.slice(0, 20) };
    body.sessions = tokens.size;
    return json(res, r0 ? r0.status : 200, body, { 'Cache-Control': 'no-store' });
  }

  // 나머지: 현재 프로젝트 자식으로 프록시
  const p = currentProject(req, url); const c = p && children.get(p.name);
  if (!c) return json(res, 503, { error: '프로젝트 서버 없음' });
  const headers = Object.assign({}, req.headers, { host: '127.0.0.1:' + c.port, 'x-forwarded-proto': isHttps(req) ? 'https' : 'http', 'x-forwarded-host': req.headers.host || '', 'x-console-project': encodeURIComponent(p.name) });
  // 라우터 토큰 → 자식용 PIN 치환 (자식은 PIN 만 인증으로 받아들인다). 만료·무효 토큰은 지워서 자식이 401 을 주게 한다
  const tok = presentedToken(req, url);
  if (tok && tok !== PIN) {
    headers.cookie = (req.headers.cookie || '').replace(/(?:^|;\s*)m_sid=[^;]*/g, '').replace(/^;\s*/, '');
    headers.cookie = (headers.cookie ? headers.cookie + '; ' : '') + 'm_sid=' + encodeURIComponent(PIN);
    if (req.headers['authorization'] && req.headers['authorization'].includes(tok)) headers.authorization = PIN;
  } else if (!tok && getCookie(req, 'm_sid')) {
    headers.cookie = (req.headers.cookie || '').replace(/(?:^|;\s*)m_sid=[^;]*/g, '').replace(/^;\s*/, '');
  }
  // /proj/<이름>/… 로 들어온 요청은 접두사를 떼고 자식에게 넘긴다(자식은 자기 경로만 안다)
  const stripped = projectFromPath(url.pathname);
  // 쿼리의 token/pin 이 라우터 토큰이면 자식용 PIN 으로 치환
  let search = url.search || '';
  if (tok && tok !== PIN && (url.searchParams.get('token') === tok || url.searchParams.get('pin') === tok)) { const sp = new URLSearchParams(url.search); if (sp.get('token') === tok) sp.set('token', PIN); if (sp.get('pin') === tok) sp.set('pin', PIN); search = '?' + sp.toString(); }
  const fwdPath = stripped ? (stripped.rest + search) : (url.pathname + search);
  const up = http.request({ host: '127.0.0.1', port: c.port, path: fwdPath, method: req.method, headers }, (ur) => {
    res.writeHead(ur.statusCode, ur.headers); ur.pipe(res);
  });
  up.on('error', (e) => { if (!res.headersSent) json(res, 502, { error: '프로젝트 서버 응답 없음: ' + e.message }); else res.end(); });
  req.pipe(up);
});

server.listen(PORT, () => log('프로젝트 라우터 대기: 포트 ' + PORT + ' / 프로젝트 ' + projects.map(p => p.name).join(', ')));
process.on('exit', () => { for (const c of children.values()) { try { c.proc.kill(); } catch (_) {} } });
process.on('SIGINT', () => process.exit(0));
process.on('SIGTERM', () => process.exit(0));

module.exports = { projects, children };
