@echo off
rem
call "%~dp0stop_console.cmd"
ping -n 4 127.0.0.1 >nul
call "%~dp0start_console.cmd"
