@echo off
rem stop console started from THIS home only (console.pid) - see stop_console.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop_console.ps1" -Home_ "%~dp0."
