# 이 홈(스크립트가 있는 폴더)에서 뜬 콘솔 트리만 종료한다 (2026-09-22)
#  1순위 console.pid (start_all.js 가 기동 때 씀) → 그 프로세스가 살아 있고 start_all.js 이면 자식까지 종료
#  2순위(옛 콘솔, pid 파일 없음) 이 PC 의 모든 node start_all.js — 경고를 남긴다 (다음 기동부터는 pid 파일이 생겨 1순위로 간다)
#  보조 W4 결함 #1(2026-09-22 19:14, 테스트 설치본의 -Update 가 운영 콘솔을 죽임) 재발 방지
param([string]$Home_ = $PSScriptRoot, [switch]$PidOnly)
$ErrorActionPreference = 'SilentlyContinue'
function KillTree($pid_) {
  $ids = @($pid_); $q = @($pid_)
  while ($q.Count) { $x = $q[0]; $q = @($q | Select-Object -Skip 1); $kids = @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$x" | ForEach-Object { $_.ProcessId }); $ids += $kids; $q += $kids }
  [array]::Reverse($ids); foreach ($i in $ids) { Stop-Process -Id $i -Force -ErrorAction SilentlyContinue }
  return $ids.Count
}
$killed = 0
$pidFile = Join-Path $Home_ 'console.pid'
if (Test-Path $pidFile) {
  $p = 0; try { $p = [int](Get-Content $pidFile -Raw).Trim() } catch {}
  $proc = if ($p) { Get-CimInstance Win32_Process -Filter "ProcessId=$p" } else { $null }
  if ($proc -and $proc.CommandLine -match 'start_all\.js') { $killed += KillTree $p; Write-Output ("stopped pid " + $p + " tree (" + $killed + " processes) for " + $Home_) }
  else { Write-Output ("console.pid " + $p + " is not a running console (already stopped)") }
  Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
} elseif (-not $PidOnly) {
  $all = @(Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -match 'start_all\.js' })
  if ($all.Count) { Write-Output ("WARNING: no console.pid in " + $Home_ + " - stopping ALL " + $all.Count + " start_all.js process(es) on this PC (legacy)"); foreach ($o in $all) { $killed += KillTree $o.ProcessId } }
  else { Write-Output "no console running" }
} else { Write-Output ("no console.pid in " + $Home_ + " - nothing stopped (PidOnly)") }
