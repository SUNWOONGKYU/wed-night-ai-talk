# hub_selfhost — 허브(장부) 직접 만들기용 워커 소스

원맥스 허브 이용권 대신 **내 Cloudflare 계정**에 같은 허브를 올릴 때 쓴다. 절차와 사용자가 직접 해야 하는 것(로그인·2FA)은 `docs\허브_직접_만들기.md` 참조.

- `worker.js` — 등록 API(`POST /register`, `GET /devices?code=`, `POST /unregister`, `GET /health`) + 허브 페이지
- `hub_page.js` — 폰이 여는 PC 목록 화면
- `wrangler.toml` — `wrangler kv namespace create HUB` 로 만든 KV id 를 채운다 (SUPABASE 를 쓰지 않으면 KV 로 동작)

배포: `wrangler login` (본인) → `wrangler deploy` → 나온 주소를 `install.ps1 -HubMode self -HubUrl https://<이름>.<계정>.workers.dev` 에 준다. 페어링 코드는 콘솔이 첫 기동 때 8자리로 자동 생성한다.
