# -*- coding: utf-8 -*-
"""
기술적 분석 엔진
Trading_Stock indicator_engine.py 기반
7-Factor Signal System (5대장 + 2졸병)
"""
import pandas as pd
import numpy as np
import logging

log = logging.getLogger(__name__)


class IndicatorEngine:
    """7개 지표 계산 및 신호 감지 (Trading_Stock 실전 검증 완료)"""

    def __init__(self):
        # CALL 6대장 임계값
        self.call_di_minus_max = 42    # 원복: 35 → 42
        self.call_adx_min = 15         # 완화: 20 → 15
        self.call_adx_max = 45         # 완화: 35 → 45
        self.call_rsi_min = 30         # 원복: 40 → 30
        self.call_rsi_max = 70         # 신규: 과매수(RSI>70) CALL 진입 차단
        self.call_stoch_min = 20       # 원복: 35 → 20

        # CALL 2졸병 임계값
        self.call_volume_min = 1.0     # 졸병 기준: 20일 평균 1.0x 이상
        self.call_vol_hard_min = 0.3   # 하드 최소: 0.3x 미만이면 신호 무효 (졸병 여부 무관)
        self.call_willr_min = -90      # 원복: 졸병 기준, 졸병 점수용이라 엄격화 불필요

        # PUT 5대장 임계값 (PUT 과다 억제)
        self.put_di_plus_max = 30      # 유지
        self.put_adx_min = 20          # 유지
        self.put_adx_max = 40          # 완화: 35 → 40
        self.put_rsi_max = 55          # 유지
        self.put_stoch_max = 65        # 유지

        # PUT 2졸병 임계값
        self.put_macd_max = 0.5        # 유지

    def calculate_all(self, df):
        """모든 지표 계산 (OHLCV DataFrame 필요)"""
        h, l, c, v = df['high'], df['low'], df['close'], df['volume']

        # 소나 (Stochastic Momentum Index)
        k_period = 14
        lowest_low = l.rolling(k_period).min()
        highest_high = h.rolling(k_period).max()
        mid_point = (highest_high + lowest_low) / 2
        hl_range = (highest_high - lowest_low) / 2
        sonar_raw = ((c - mid_point) / hl_range.replace(0, np.nan)) * 100
        df['sonar_k'] = sonar_raw.rolling(3).mean()
        df['sonar_d'] = df['sonar_k'].rolling(3).mean()

        # RSI (14)
        delta = c.diff()
        gain = delta.where(delta > 0, 0).rolling(14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(14).mean()
        rs = gain / loss.replace(0, np.nan)
        df['rsi'] = 100 - (100 / (1 + rs))

        # DI+, DI-, ADX (14)
        plus_dm = h.diff()
        minus_dm = -l.diff()
        plus_dm = plus_dm.copy()
        minus_dm = minus_dm.copy()
        plus_dm[plus_dm < 0] = 0
        minus_dm[minus_dm < 0] = 0
        plus_dm[plus_dm < minus_dm] = 0
        minus_dm[minus_dm < plus_dm] = 0

        tr = pd.concat([h - l, abs(h - c.shift()), abs(l - c.shift())], axis=1).max(axis=1)
        atr = tr.rolling(14).mean()
        df['plus_di'] = 100 * (plus_dm.rolling(14).mean() / atr)
        df['minus_di'] = 100 * (minus_dm.rolling(14).mean() / atr)
        dx = 100 * abs(df['plus_di'] - df['minus_di']) / (df['plus_di'] + df['minus_di']).replace(0, np.nan)
        df['adx'] = dx.rolling(14).mean()

        # 스토캐스틱 K (14, 3)
        stoch_k = 100 * ((c - lowest_low) / (highest_high - lowest_low))
        df['stoch_k'] = stoch_k.rolling(3).mean()

        # MACD (12, 26, 9)
        ema12 = c.ewm(span=12).mean()
        ema26 = c.ewm(span=26).mean()
        df['macd'] = ema12 - ema26
        df['macd_sig'] = df['macd'].ewm(span=9).mean()
        df['macd_hist'] = df['macd'] - df['macd_sig']

        # 볼륨 비율 (20일 평균 대비)
        df['vol_ratio'] = v / v.rolling(20).mean()

        # Williams %R (14)
        df['willr'] = -100 * ((highest_high - c) / (highest_high - lowest_low))

        # MA20 (추세 방향 확인)
        df['ma20'] = c.rolling(20).mean()

        return df

    def check_call_signal(self, df):
        """CALL 신호 체크: 5대장 + 2졸병"""
        if len(df) < 20:
            return None

        df = self.calculate_all(df)
        cur = df.iloc[-1]
        prev = df.iloc[-2]

        # 하드 최소 필터: vol_ratio < 0.3이면 신호 자체 무효
        if pd.isna(cur['vol_ratio']) or cur['vol_ratio'] < self.call_vol_hard_min:
            return None

        # 6대장 (기존 5 + MA20 추세 확인)
        bosses = {
            'sonar_golden': (prev['sonar_k'] <= prev['sonar_d'] and
                             cur['sonar_k'] > cur['sonar_d'] and
                             cur['sonar_k'] < 50),  # 상승장: 중간값 이하면 골든크로스 허용
            'di_minus': not pd.isna(cur['minus_di']) and cur['minus_di'] < self.call_di_minus_max,
            'adx': not pd.isna(cur['adx']) and self.call_adx_min <= cur['adx'] < self.call_adx_max,
            'rsi': (not pd.isna(cur['rsi']) and
                    self.call_rsi_min < cur['rsi'] < self.call_rsi_max),  # 30 < RSI < 70
            'stoch': not pd.isna(cur['stoch_k']) and cur['stoch_k'] > self.call_stoch_min,
            'ma_trend': not pd.isna(cur['ma20']) and cur['close'] > cur['ma20'],
        }

        # 2졸병
        soldiers = {
            'volume': not pd.isna(cur['vol_ratio']) and cur['vol_ratio'] >= self.call_volume_min,
            'willr': not pd.isna(cur['willr']) and cur['willr'] > self.call_willr_min,
        }

        return {
            'type': 'CALL',
            'bosses_pass': all(bosses.values()),
            'bosses': bosses,
            'soldiers_pass': all(soldiers.values()),
            'soldiers': soldiers,
            'values': self._current_values(cur),
        }

    def check_put_signal(self, df):
        """PUT 신호 체크: 5대장 + 2졸병"""
        if len(df) < 20:
            return None

        df = self.calculate_all(df)
        cur = df.iloc[-1]
        prev = df.iloc[-2]

        # 6대장 (기존 5 + MA20 추세 확인)
        bosses = {
            'sonar_dead': (prev['sonar_k'] >= prev['sonar_d'] and
                           cur['sonar_k'] < cur['sonar_d'] and
                           cur['sonar_k'] > 30),   # 상승장: 오버바우트 구간(>30)서만 데드크로스
            'di_plus': not pd.isna(cur['plus_di']) and cur['plus_di'] < self.put_di_plus_max,
            'adx': not pd.isna(cur['adx']) and self.put_adx_min <= cur['adx'] < self.put_adx_max,
            'rsi': not pd.isna(cur['rsi']) and cur['rsi'] < self.put_rsi_max,
            'stoch': not pd.isna(cur['stoch_k']) and cur['stoch_k'] < self.put_stoch_max,
            'ma_trend': not pd.isna(cur['ma20']) and cur['close'] < cur['ma20'],
        }

        # 2졸병
        soldiers = {
            'macd1': not pd.isna(cur['macd_hist']) and cur['macd_hist'] < self.put_macd_max,
            'macd2': not pd.isna(cur['macd_hist']) and cur['macd_hist'] < 2.0,
        }

        return {
            'type': 'PUT',
            'bosses_pass': all(bosses.values()),
            'bosses': bosses,
            'soldiers_pass': all(soldiers.values()),
            'soldiers': soldiers,
            'values': self._current_values(cur),
        }

    def get_full_signal(self, df):
        """CALL + PUT 통합 신호 상태"""
        call = self.check_call_signal(df)
        put = self.check_put_signal(df)
        return {'CALL': call, 'PUT': put}

    def _current_values(self, cur):
        def safe(v): return round(float(v), 2) if not pd.isna(v) else 0
        return {
            'sonar_k': safe(cur['sonar_k']),
            'sonar_d': safe(cur['sonar_d']),
            'rsi': safe(cur['rsi']),
            'di_plus': safe(cur['plus_di']),
            'di_minus': safe(cur['minus_di']),
            'adx': safe(cur['adx']),
            'stoch_k': safe(cur['stoch_k']),
            'willr': safe(cur['willr']),
            'macd_hist': safe(cur['macd_hist']),
            'vol_ratio': safe(cur['vol_ratio']),
        }


