"""
과매도 반등 전략 (일봉 트랙) — 2026-09-21 정식 검증 결과를 그대로 규칙화
정본: wiki/연구/project_oversold_rebound_validation_20260921.md (§11 사전 등록 규칙)

규칙(사전 등록, 2026-09-21):
  [게이트] 하락장: KODEX200(069500) 종가 < 200일선  OR  250일 고점 대비 -15% 이하   (확장 게이트)
  [종목]   60일선 대비 괴리 ≤ -15%  AND  20일 변동성이 후보 중 하위 30%(저변동)
  [진입]   다음날 시가(09:00 첫 스캔) — 텔레그램 승인 후 주식선물 1계약 매수
  [청산]   20영업일 뒤 시가 청산(시간 청산). 손절 없음(파국 방어 -15%만, Position 'momentum' 트랙이 담당)
  [우선]   같은 날 여러 건이면 20일 변동성 낮은 순, 최대 OVERSOLD_TOP_N

검증 통계(시점별 유니버스, 비용 0.25%): 학습 2018-07~2024-12 62.7% / +3.95% (t 5.75), 검증 2025 90.7% / +9.88%,
2포지션 연도별 전부 +, 2022 +35%(시장 -24%), MDD -29.6%. 2026 미공개 테스트는 200일선 게이트 0일 성립 → 판정 불가
→ 확장 게이트로 모의·소액 전진검증 중(실주문은 승인 후 1계약).

일봉은 pykrx(종목) + KIS 일봉차트(KODEX200). 캐시 6시간.
"""
import logging
import time
import datetime as dt

import pandas as pd

log = logging.getLogger('oversold')

DEV60_MAX = -0.15          # 60일선 괴리 상한 (이하일 때 후보)
LOWVOL_PCT = 0.30          # 20일 변동성 횡단면 하위 비율
TOP_N = 3                  # 하루 후보 상위 N
HOLD_DAYS = 20             # 보유 영업일 (시간 청산)
GATE_MA = 200              # 지수 이동평균
GATE_DD = -0.15            # 250일 고점 대비 낙폭 기준
MIN_PRICE = 2000           # 저가주 제외

_cache = {}
_CACHE_SEC = 3600 * 6


def _daily(code, days=400):
    """종목 일봉(pykrx). momentum_strategy._daily 와 동일 규칙, 별도 캐시."""
    now = time.time()
    hit = _cache.get(code)
    if hit and (now - hit[0]) < _CACHE_SEC:
        return hit[1]
    try:
        from pykrx import stock
        end = dt.datetime.now().strftime('%Y%m%d')
        start = (dt.datetime.now() - dt.timedelta(days=days)).strftime('%Y%m%d')
        df = stock.get_market_ohlcv(start, end, code)
        if df is None or len(df) < 80:
            return None
        df = df.rename(columns={'시가': 'open', '고가': 'high', '저가': 'low', '종가': 'close', '거래량': 'volume'})
        df = df[['open', 'high', 'low', 'close', 'volume']]
        _cache[code] = (now, df)
        return df
    except Exception as e:
        log.debug(f'[Oversold] {code} 일봉 조회 실패: {e}')
        return None


def _kodex_daily(days=320):
    """KODEX200 일봉 종가 시리즈 — KIS 일봉차트(100행/호출)를 날짜 창으로 이어 붙임. 실패 시 None."""
    now = time.time()
    hit = _cache.get('__kodex__')
    if hit and (now - hit[0]) < _CACHE_SEC:
        return hit[1]
    try:
        import kis
        frames = []
        end = dt.date.today()
        for _ in range(4):
            start = end - dt.timedelta(days=140)
            data = kis._get('/uapi/domestic-stock/v1/quotations/inquire-daily-itemchartprice', 'FHKST03010100', {
                'FID_COND_MRKT_DIV_CODE': 'J', 'FID_INPUT_ISCD': '069500',
                'FID_INPUT_DATE_1': start.strftime('%Y%m%d'), 'FID_INPUT_DATE_2': end.strftime('%Y%m%d'),
                'FID_PERIOD_DIV_CODE': 'D', 'FID_ORG_ADJ_PRC': '0',
            })
            rows = (data or {}).get('output2', []) or []
            rows = [r for r in rows if r.get('stck_bsop_date')]
            if not rows:
                break
            frames.append(pd.DataFrame(rows))
            end = start - dt.timedelta(days=1)
            time.sleep(0.3)
        if not frames:
            return None
        df = pd.concat(frames)
        df = df.rename(columns={'stck_bsop_date': 'date', 'stck_clpr': 'close'})
        df['close'] = pd.to_numeric(df['close'], errors='coerce')
        df = df.dropna(subset=['close']).drop_duplicates('date').sort_values('date').reset_index(drop=True)
        s = df.set_index('date')['close'].tail(days)
        _cache['__kodex__'] = (now, s)
        return s
    except Exception as e:
        log.warning(f'[Oversold] KODEX200 일봉 조회 실패: {e}')
        return None


def market_gate():
    """확장 하락장 게이트. 반환 (통과 여부, 설명)."""
    s = _kodex_daily()
    if s is None or len(s) < 60:
        return False, 'KODEX200 일봉 부족 → 게이트 판정 불가(진입 보류)'
    close = float(s.iloc[-1])
    ma200 = float(s.tail(GATE_MA).mean()) if len(s) >= GATE_MA else float('nan')
    hi250 = float(s.tail(250).max())
    dd = close / hi250 - 1
    below_ma = (len(s) >= GATE_MA) and close < ma200
    deep_dd = dd <= GATE_DD
    ok = bool(below_ma or deep_dd)
    msg = (f'KODEX200 {close:,.0f} | 200일선 {ma200:,.0f}({"아래" if below_ma else "위"}) | '
           f'250일 고점 {hi250:,.0f} 대비 {dd*100:+.1f}%({"충족" if deep_dd else "미충족"}) → '
           f'{"하락장 게이트 통과" if ok else "게이트 미통과(진입 없음)"}')
    return ok, msg


def get_candidates(universe, top_n=None):
    """universe=[{'code','name'},...] → [{'code','name','price','dev60','vol20','reason'}] 저변동 순 상위 N.
    게이트 미통과면 빈 리스트."""
    top_n = top_n or TOP_N
    ok, msg = market_gate()
    log.info(f'[Oversold] {msg}')
    if not ok:
        return []
    rows = []
    for u in universe:
        df = _daily(u['code'])
        if df is None or len(df) < 80:
            continue
        c = df['close']
        price = float(c.iloc[-1])
        if price < MIN_PRICE:
            continue
        ma60 = float(c.rolling(60).mean().iloc[-1])
        if not ma60 or pd.isna(ma60):
            continue
        dev60 = price / ma60 - 1
        vol20 = float(c.pct_change().tail(20).std())
        if pd.isna(vol20):
            continue
        rows.append({'code': u['code'], 'name': u['name'], 'price': price,
                     'dev60': dev60, 'vol20': vol20})
    if not rows:
        return []
    allv = pd.Series([r['vol20'] for r in rows])
    cut = float(allv.quantile(LOWVOL_PCT))
    cands = [r for r in rows if r['dev60'] <= DEV60_MAX and r['vol20'] <= cut]
    cands.sort(key=lambda r: r['vol20'])
    out = []
    for r in cands[:top_n]:
        r['reason'] = (f'과매도반등: 60일선 {r["dev60"]*100:+.1f}% · 20일변동성 {r["vol20"]*100:.2f}%(하위{int(LOWVOL_PCT*100)}%) '
                       f'· {HOLD_DAYS}영업일 시가청산')
        out.append(r)
    log.info(f'[Oversold] 조건충족 {len(cands)} / 후보 {len(out)}: '
             + ', '.join(f"{c['name']}({c['dev60']*100:+.0f}%)" for c in out))
    return out


if __name__ == '__main__':
    import json, os, sys
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    try:
        import futures_map
        uni = futures_map.get_futures_universe() or []
    except Exception:
        uni = []
    if not uni:
        wl = os.path.join(os.path.dirname(__file__), 'config_data', 'watchlist.json')
        uni = json.load(open(wl, encoding='utf-8')).get('watchlist', [])
    print(f'유니버스 {len(uni)}종목')
    ok, msg = market_gate(); print(msg)
    for c in get_candidates(uni, top_n=int(sys.argv[1]) if len(sys.argv) > 1 else 10):
        print(f"  {c['name']:14s} {c['price']:>9,.0f}원  60일선 {c['dev60']*100:+.1f}%  변동성 {c['vol20']*100:.2f}%")
