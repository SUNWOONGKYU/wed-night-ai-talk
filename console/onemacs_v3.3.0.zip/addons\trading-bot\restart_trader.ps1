﻿# restart_trader.ps1 — 매일 trader.py를 깨끗이 재시작 (stale 프로세스 false-0점 버그 방지)
# TraderBot-Sentry 작업이 매일 장 시작 전 이 스크립트를 실행.
# 기존 trader.py 프로세스를 모두 종료한 뒤 새 인스턴스를 detached로 기동하고 즉시 종료(작업 완료).
#
# 2026-08-29 변경:
#   - 주말/휴장일에는 아예 기동하지 않도록 is_trading_day.ps1 게이트를 통과시킨다.
#     (기존에는 휴일에도 프로세스가 떠서 장이 열릴 때까지 램만 점유했다.)
#   - 무슨 판단으로 떴는지/건너뛰었는지 logs\sentry.log에 남긴다. 예약 작업은
#     결과 코드만 남기므로, 기동 실패를 사후에 추적할 근거가 없었다.
#   - Stop-Process로 강제 종료하면 trader.py의 atexit 락 해제가 실행되지 않아
#     stale 락이 남는다. 종료 직후 락 파일을 직접 지운다.

[CmdletBinding()]
param(
    # 종료/기동을 실제로 하지 않고 판단만 기록한다. 실매매 봇을 띄우지 않고
    # 거래일 경로를 점검할 때 쓴다.
    [switch]$DryRun,
    # 게이트에 넘길 기준일(YYYY-MM-DD). 생략하면 오늘. 검증용.
    [string]$Date
)

$ErrorActionPreference = 'SilentlyContinue'

$proj    = $PSScriptRoot
$logDir  = Join-Path $proj 'logs'
$logFile = Join-Path $logDir 'sentry.log'
$lockFile = Join-Path $proj 'data\.trader.lock'

if (-not (Test-Path -LiteralPath $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }

# 로그가 무한히 자라지 않게 5MB에서 1세대만 보관하고 갈아탄다.
if ((Test-Path -LiteralPath $logFile) -and (Get-Item -LiteralPath $logFile).Length -gt 5MB) {
    Move-Item -LiteralPath $logFile "$logFile.1" -Force
}

function Log($msg) {
    "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" | Add-Content -LiteralPath $logFile -Encoding UTF8
}

# ── 0) 거래일 게이트 ──
# 종료 코드 1 = 주말/휴장일이므로 기동하지 않는다.
# 2 = 판정 불가(holidays.json 문제)인데, 이때 막으면 정상 거래일에도 못 뜨므로 진행시킨다.
$gate = Join-Path $proj 'is_trading_day.ps1'
if (Test-Path -LiteralPath $gate) {
    $gateArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $gate)
    if ($Date) { $gateArgs += @('-Date', $Date) }
    $gateOut = & powershell.exe @gateArgs 2>&1
    $gateCode = $LASTEXITCODE
    foreach ($line in $gateOut) { Log "  $line" }
    if ($gateCode -eq 1) {
        Log '[Sentry] 휴일 - trader.py 기동하지 않고 종료'
        exit 0
    }
    if ($gateCode -eq 2) {
        Log '[Sentry] 거래일 판정 불가 - 평일로 간주하고 계속 진행'
    }
} else {
    Log "[Sentry] 경고: 게이트 스크립트 없음 ($gate) - 휴일 검사 없이 진행"
}

# ── 1) 기존 trader.py 프로세스 종료 (중복/묵은 프로세스 정리) ──
$old = Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='pythonw.exe'" |
    Where-Object { $_.CommandLine -match 'trader\.py' }
if ($old) {
    Log "[Sentry] 기존 trader.py 종료: PID $($old.ProcessId -join ',')"
    if (-not $DryRun) {
        $old | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
        Start-Sleep -Seconds 3
    }
} else {
    Log '[Sentry] 기존 trader.py 없음'
}

# 강제 종료된 프로세스는 atexit이 돌지 않아 락이 남는다. 여기서 정리한다.
if (Test-Path -LiteralPath $lockFile) {
    if (-not $DryRun) { Remove-Item -LiteralPath $lockFile -Force }
    Log '[Sentry] 잔여 락 파일 제거'
}

# ── 1-b) 주식선물 종목 맵 갱신 (2026-09-21 교훈: 9월물 만기(9/10) 뒤 옛 코드로 주문해 '선물옵션종목이 없습니다'(APBK0818) 3건 실패)
#      매일 기동 전에 마스터(fo_stk_code_mts)에서 현재 근월물로 다시 만든다. 실패해도 기존 맵으로 계속 진행.
if (-not $DryRun) {
    try {
        $env:PYTHONUTF8 = '1'
        $out = & python (Join-Path $proj 'build_futures_map.py') 2>&1 | Out-String
        Log ('[Sentry] 선물 종목 맵 갱신: ' + (($out -split "`n" | Where-Object { $_ -match '\S' } | Select-Object -Last 1).Trim()))
    } catch {
        Log "[Sentry] 선물 종목 맵 갱신 실패(기존 맵 사용): $($_.Exception.Message)"
    }
}

# ── 2) 새 인스턴스 기동 (working dir 고정, 창 숨김, 세션과 분리) ──
if ($DryRun) {
    Log '[Sentry] (DryRun) 여기서 trader.py를 기동한다 — 실제 기동 생략'
    exit 0
}
Start-Process -FilePath 'python' -ArgumentList 'C:\trader-bot\trader.py' `
    -WorkingDirectory $proj -WindowStyle Hidden
Log '[Sentry] trader.py 기동 요청 완료'

# 스크립트는 즉시 종료 → 작업이 완료 상태가 되어 다음날 트리거가 다시 발동됨
