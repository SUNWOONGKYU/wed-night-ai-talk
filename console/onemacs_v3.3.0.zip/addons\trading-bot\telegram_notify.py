# -*- coding: utf-8 -*-
"""
텔레그램 승인 봇 — 매수 신호를 핸드폰으로 전송하고 승인/거절 응답 수신
"""
import os
import shutil
import threading
import html as _html
import time
import logging
import requests

log = logging.getLogger(__name__)


def _find_claude() -> str:
    """Windows에서 claude CLI 실행 파일 경로 탐색"""
    found = shutil.which('claude') or shutil.which('claude.cmd')
    if found:
        return found
    appdata = os.environ.get('APPDATA', '')
    for name in ('claude.cmd', 'claude'):
        p = os.path.join(appdata, 'npm', name)
        if os.path.exists(p):
            return p
    return 'claude'

_CLAUDE_BIN = _find_claude()

# config에서 로드 (없으면 환경변수 직접)
try:
    from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
except ImportError:
    TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
    TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')


# 주식선물 증거금 — 명목금액(주가 x 10 x 계약)의 약 29%.
# 2026-09-22 주문 거부로 15%가 아니라는 것을 알았다. 실제 수량은 주문 전에
# 증권사에 다시 물어 확정하므로, 이 값은 '대략 얼마가 묶이나'를 보여주는 용도다.
MARGIN_RATE = 0.29

_OVERRIDES: dict = {}  # 텔레그램 실시간 지시 — trader.py가 읽는 공유 상태


# 텔레그램 [📚 안내 자료] 가 보내는 파일. 배포판에서는 설명서가 봇 폴더에 바로 있고,
# 개발 저장소에서는 tools/build_docs.py 가 docs/ 에 만든다 — 둘 다 찾는다.
DOCS = [
    ('rel',   '🧩 파일 관계도',   '파일관계도.html',        '봇을 이루는 파일 15개와 서로 주고받는 관계'),
    ('flow',  '🔀 신호 흐름도',   '신호체계_흐름도.html',   '후보를 고르고 살 시점을 찾아 승인받기까지의 흐름'),
    ('guide', '📘 설명서',       '주식 매매 자동화 시스템.html', '1부 신호 규칙 · 2부 운영규칙 · 3부 설치와 사용 (그림 포함)'),
]


# 사람이 "지금 정리"를 누르면 여기에 쌓인다. 봇이 매 바퀴 확인해 비운다.
_EXIT_REQUESTS = []


def take_exit_requests():
    """봇이 호출 — 쌓인 정리 요청을 가져가고 비운다."""
    global _EXIT_REQUESTS
    got, _EXIT_REQUESTS = list(_EXIT_REQUESTS), []
    return got


def request_manual_exit(what='all'):
    _EXIT_REQUESTS.append(what)


def get_override(key, default=None):
    """trader.py에서 실시간 텔레그램 지시 조회"""
    return _OVERRIDES.get(key, default)


def _current_rate(code):
    """현물 기준 전일대비 등락률(%) 조회. 실패 시 None.
    선물 단축코드(A로 시작)가 들어오면 현물로 역매핑해서 조회."""
    try:
        from kis import get_stock_price
        c = code
        if isinstance(c, str) and c.startswith('A'):
            from futures_map import get_stock_code
            c = get_stock_code(code) or code
        info = get_stock_price(c)
        return info.get('change_pct') if info else None
    except Exception:
        return None


def _plain(text):
    """봇 내부 용어를 사람 말로 (PO 2026-09-22 '다 바꿔'). 줄이 길면 · 앞에서 줄을 나눈다."""
    t = str(text or '')
    _keep = {}
    for i, nm in enumerate(('3대장 4졸병', '3대장4졸병', '5대장 2졸병', '5대장2졸병', '6대장 2졸병',
                            'CALL(매수)', 'PUT(매도)', '반등형 CALL(매수)', '추세형 CALL(매수)', '반등형 PUT(매도)')):
        if nm in t:
            k = chr(0) + str(i) + chr(0); _keep[k] = nm; t = t.replace(nm, k)
    for a, b in (
        ('[종합] ', ''), ('⚠미검증 ', '⚠ 아직 실전 성적이 쌓이지 않은 규칙 · '),
        ('모멘텀 트레일링 익절', '이익 확정 — 고점에서 되밀려서'),
        ('모멘텀 파국손절', '큰 손실 방어 — 많이 밀려서'),
        ('모멘텀 손절', '손절 — 정해둔 선까지 밀려서'),
        ('모멘텀 만기롤오버', '계약 갈아타기 — 이번 달 만기가 가까워서'),
        ('모멘텀 만기청산', '보유 기간이 다 돼서'),
        ('트레일링익절', '이익 확정 — 고점에서 되밀려서'),
        ('강제청산', '장 마감 정리'), ('손절', '손절'),
        ('A:3m_golden_5_20', '3분봉에서 5개 평균선이 20개 평균선을 위로 뚫음'),
        ('B:open_breakout', '장 초반 강세 — 시작가·어제 마감가 위'),
        ('D:vwap_volume', '오늘 평균 매매가 위 + 거래량 늘어남'),
        ('3m_golden_5_20', '3분봉 5개/20개 평균선 교차'), ('open_breakout', '장 초반 강세'),
        ('vwap_volume', '평균 매매가+거래량'),
        ('타이밍:', '살 시점:'), ('종목:', '고른 이유:'),
        ('대장', '필수 조건'), ('졸병', '보조 조건'),
        ('60일선', '60일 평균선'), ('20일선', '20일 평균선'),
        ('vol20', '변동폭'), ('dev_ma60', '60일 평균선 대비'),
        ('하락장', '시장이 내림세'), ('상승장', '시장이 오름세'),
        ('cross_at=', '교차 '), ('ma5=', '5분선 '), ('ma20=', '20분선 '),
        ('chg_pct=', '어제 대비 '), ('vol_ratio=', '거래량 배수 '), ('vwap=', '평균가 '),
        ('bear_market_bonus', '시장 내림세'), ('bull_market_bonus', '시장 오름세'),
        ('deeper_oversold', '더 깊이 빠짐'), ('monthly_drop', '한 달 급락'),
        ('sharp_3d_drop', '3일 급락'), ('not_new_low', '바닥은 아님'),
        ('deeper_overbought', '더 많이 오름'), ('sharp_3d_rise', '3일 급등'),
        ('monthly_rise', '한 달 급등'), ('not_new_high', '꼭대기는 아님'),
        ('at_high', '최고가 근처'), ('at_low', '최저가 근처'),
        ('strong_month', '한 달 강세'), ('weak_month', '한 달 약세'),
        ('mom20_up', '20일 상승'), ('mom20_down', '20일 하락'),
        ('above_ma60', '60일 평균선 위'), ('below_ma60', '60일 평균선 아래'),
        ('near_high', '최고가 근처'), ('near_low', '최저가 근처'),
        ('oversold_ma60', '60일 평균선 대비 많이 빠짐'), ('overbought_ma60', '60일 평균선 대비 많이 오름'),
        ('low_volatility', '조용한 종목'),
    ):
        t = t.replace(a, b)
    import re as _re
    t = _re.sub(r'CALL(?!\(매수\))', 'CALL(매수)', t)
    t = _re.sub(r'PUT(?!\(매도\))', 'PUT(매도)', t)
    for k, nm in _keep.items():
        t = t.replace(k, nm)
    try:
        t = _html.escape(t, quote=False)
    except Exception:
        pass
    if chr(10) in t:
        return t
    # 읽기 쉽게: 가운뎃점 앞에서 줄바꿈(너무 짧은 조각은 붙여 둔다)
    parts = [x.strip() for x in t.split(' · ') if x.strip()]
    out, buf = [], ''
    for x in parts:
        if len(buf) + len(x) < 34:
            buf = (buf + ' · ' + x) if buf else x
        else:
            if buf:
                out.append(buf)
            buf = x
    if buf:
        out.append(buf)
    return '\n'.join('· ' + x for x in out) if len(out) > 1 else (out[0] if out else t)


def _rate_str(pct):
    """등락률 → '▲ 상승 +1.23%' / '▼ 하락 -0.80%' / '― 보합 0.00%'."""
    if pct is None:
        return '조회불가'
    if pct > 0:
        return f'▲ 상승 +{pct:.2f}%'
    if pct < 0:
        return f'▼ 하락 {pct:.2f}%'
    return '― 보합 0.00%'


class TelegramApprovalBot:
    """텔레그램 인라인 버튼 승인/거절 봇"""

    def __init__(self):
        self.token = TELEGRAM_BOT_TOKEN
        self.chat_id = str(TELEGRAM_CHAT_ID)
        self.enabled = bool(self.token and self.chat_id and
                            self.token != 'YOUR_TOKEN' and self.chat_id != 'YOUR_CHAT_ID')
        self._pending = {}   # key -> {"event": Event, "result": None}
        self._offset = 0
        self._lock = threading.Lock()

        if self.enabled:
            self._register_commands()
            self._start_polling()
            log.info('[Telegram] 봇 활성화 — 폴링 시작')
        else:
            log.warning('[Telegram] 미설정 (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID 확인)')

    # ── 내부 API 호출 ──────────────────────────────

    def _api(self, method, retries=3, **kwargs):
        # 2026-09-21 실거래 교훈: 09:16 일시 네트워크 장애로 승인 요청 1건이 전송 실패 → 짧은 재시도(3회, 5/10초 간격)
        url = f'https://api.telegram.org/bot{self.token}/{method}'
        last = None
        for i in range(max(1, retries)):
            try:
                r = requests.post(url, json=kwargs, timeout=15)
                if r.ok:
                    return r.json()
                last = f'HTTP {r.status_code}'
                if 400 <= r.status_code < 500 and r.status_code != 429:
                    break  # 잘못된 요청은 재시도 무의미
            except Exception as e:
                last = e
            if i < retries - 1:
                time.sleep(5 * (i + 1))
        log.debug(f'[Telegram] API 오류({method}): {last}')
        return None

    # ── 메뉴 등록 ─────────────────────────────────

    def _register_commands(self):
        """입력창 옆 '메뉴' 버튼을 없앤다 — 조작은 아래 버튼판 하나로."""
        # PO 2026-09-23: "메뉴 버튼은 없어도 될 것 같다" — 아래 버튼판에 다 있어 겹친다.
        # 등록된 명령을 비우면 입력창 옆 '메뉴' 버튼 자체가 사라진다.
        # (/start·/balance·/position·/scan·/status·/strategy·/pause·/resume 는 직접 쳐도 그대로 동작한다)
        self._api('deleteMyCommands')
        self._api('setChatMenuButton', menu_button={'type': 'default'})

    def _send_menu(self, intro=''):
        """하단 고정 버튼판과 함께 메뉴 전송"""
        keyboard = {
            'keyboard': [
                [{'text': '💰 잔고'}, {'text': '📊 보유 종목'}],
                [{'text': '🔍 오늘 후보'}, {'text': '⚙️ 상태'}],
                [{'text': '📋 오늘 규칙'}, {'text': '⏸ 매수 멈춤'}, {'text': '▶ 다시 시작'}],
                [{'text': '🔻 지금 정리'}, {'text': '📚 안내 자료'}],
            ],
            'resize_keyboard': True,
            'persistent': True,
        }
        text = intro or '메뉴를 선택하세요.\n\n작전 지시:\n  min_score 70\n  방향 CALL / PUT / 중립\n  강도 공격적 / 보수적 / 일반'
        self._api('sendMessage', chat_id=self.chat_id,
                  text=text, parse_mode='HTML', reply_markup=keyboard)

    # ── 공개 인터페이스 ────────────────────────────

    def send_message(self, text, parse_mode='HTML'):
        """단순 알림 전송 (버튼 없음)"""
        if not self.enabled:
            log.info(f'[Telegram 미활성] {text[:80]}')
            return None
        return self._api('sendMessage', chat_id=self.chat_id,
                         text=text, parse_mode=parse_mode)

    def send_document(self, path: str, caption: str = ''):
        """파일 하나를 그대로 보낸다 (HTML 안내 자료 등)."""
        if not self.enabled or not path or not os.path.exists(path):
            return None
        url = f'https://api.telegram.org/bot{self.token}/sendDocument'
        try:
            with open(path, 'rb') as f:
                r = requests.post(url, data={'chat_id': self.chat_id, 'caption': caption,
                                             'parse_mode': 'HTML'},
                                  files={'document': (os.path.basename(path), f)}, timeout=60)
            return r.json() if r.ok else None
        except Exception as e:
            log.warning(f'[Telegram] 파일 전송 실패: {path} — {e}')
            return None

    def send_photo(self, image_path: str, caption: str = ''):
        """이미지 파일 전송"""
        if not self.enabled or not image_path:
            return None
        url = f'https://api.telegram.org/bot{self.token}/sendPhoto'
        try:
            with open(image_path, 'rb') as f:
                r = requests.post(url, data={'chat_id': self.chat_id,
                                             'caption': caption,
                                             'parse_mode': 'HTML'},
                                  files={'photo': f}, timeout=30)
            return r.json() if r.ok else None
        except Exception as e:
            log.warning(f'[Telegram] 이미지 전송 오류: {e}')
            return None

    def request_approval(self, name, code, side, score, price, qty=2, timeout=180, reason=''):
        """
        승인 요청 전송 + 응답 대기 (최대 timeout초)
        reason: 신호 근거 한 줄(전략명·점수·졸병 충족·보유일·청산 규칙) — 있으면 메시지에 표시
        Returns: True(승인) / False(거절 or 타임아웃)
        """
        if not self.enabled:
            log.warning('[Telegram] 미설정 — 승인 불가, 주문 건너뜀')
            return False

        margin = price * 10 * qty * MARGIN_RATE
        key = f'{code}_{int(time.time())}'
        side_kr = 'CALL(매수)' if side == 'CALL' else 'PUT(매도)'
        rate = _current_rate(code)
        # 사람 말 + 줄 바꿈으로 읽기 쉽게 (PO 2026-09-22)
        text = (
            f'🟢 <b>{_html.escape(str(name))} {side_kr}</b> — 해도 될까요?\n'
            f'<code>────────────────</code>\n'
            f'지금 값 <b>{price:,}원</b>  ({_rate_str(rate)})\n'
            f'수량 {qty}계약 · 필요한 돈 약 {margin:,.0f}원\n'
            f'점수 {score}점 (필수 3개 60점 + 보조 1개당 10점) · 종목번호 {code}\n'
            + (f'<code>────────────────</code>\n<b>왜 이 종목인가</b>\n{_plain(reason)}\n' if reason else '')
            + f'<code>────────────────</code>\n'
            + f'<i>{timeout}초 안에 답이 없으면 오늘은 그냥 넘어갑니다</i>'
            + '\n<i>3대장 4졸병 = 반드시 맞아야 할 조건 3개(각 20점) + 있으면 좋은 조건 4개(각 10점)</i>'
        )
        keyboard = {'inline_keyboard': [[
            {'text': '✅ 승인', 'callback_data': f'approve:{key}'},
            {'text': '❌ 거절', 'callback_data': f'reject:{key}'},
        ]]}

        # 차트 이미지 먼저 전송
        try:
            import importlib, chart_gen as _cg
            importlib.reload(_cg)
            img_path = _cg.generate_chart(code, name, score, side)
            if img_path:
                self.send_photo(img_path,
                    caption=f'<b>{name} ({code})</b>  |  {side} {score}점\n일봉(60개) + 3분봉(60개)')
                import os as _os
                try:
                    _os.remove(img_path)
                except Exception:
                    pass
        except Exception as e:
            log.debug(f'[Telegram] 차트 전송 스킵: {e}')

        event = threading.Event()
        with self._lock:
            self._pending[key] = {'event': event, 'result': None}

        resp = self._api('sendMessage', chat_id=self.chat_id,
                         text=text, parse_mode='HTML', reply_markup=keyboard)
        if not resp or not resp.get('ok'):
            log.warning('[Telegram] 승인 요청 전송 실패')
            with self._lock:
                self._pending.pop(key, None)
            return False

        msg_id = resp['result']['message_id']
        log.info(f'[Telegram] 승인 요청 전송: {name} (대기 {timeout}초)')

        # 응답 대기
        event.wait(timeout=timeout)

        with self._lock:
            result = self._pending.pop(key, {}).get('result')

        # 버튼 비활성화 (응답 후 버튼 제거)
        self._api('editMessageReplyMarkup',
                  chat_id=self.chat_id,
                  message_id=msg_id,
                  reply_markup={'inline_keyboard': []})

        if result is None:
            log.info(f'[Telegram] 타임아웃 — {name} 주문 취소')
            self.send_message(f'⏰ 승인 시간 초과 — {name} 주문 취소')
            return False

        approved = (result == 'approve')
        label = '✅ 승인' if approved else '❌ 거절'
        log.info(f'[Telegram] {label}: {name}')
        if approved:
            _act = '매도' if str(side).upper() == 'PUT' else '매수'
            self.send_message(f'✅ <b>승인되었습니다</b> — {name} {_act}를 진행합니다.')
        else:
            self.send_message(f'❌ <b>거절되었습니다</b> — {name} 은 오늘 넘어갑니다.')
        return approved

    def request_exit_approval(self, name, code, side, qty, price, pnl_pct, reason, timeout=120):
        """청산(매도) 승인 요청 + 응답 대기. Returns: 'approve' / 'reject' / None(타임아웃)"""
        if not self.enabled:
            log.warning('[Telegram] 미설정 — 청산 승인 불가')
            return None
        key = f'exit_{code}_{int(time.time())}'
        side_kr = 'CALL(매수 포지션 → 매도)' if side == 'CALL' else 'PUT(매도 포지션 → 매수)'
        _auto = ('손절' in str(reason)) or ('밀려' in str(reason))
        text = (
            f'🔻 <b>{_html.escape(str(name))} 정리</b> — 해도 될까요?\n'
            f'<code>────────────────</code>\n'
            f'지금 값 <b>{price:,.0f}원</b>\n'
            f'지금까지 <b>{pnl_pct:+.2f}%</b> · {qty}계약 보유\n'
            f'<code>────────────────</code>\n'
            f'<b>왜 정리하나</b>\n{_plain(reason)}\n'
            f'<code>────────────────</code>\n'
            f'<i>{timeout}초 안에 답이 없으면 ' + ('먼저 정리하고 알려드립니다' if _auto else '그대로 두고 10분 뒤 다시 묻습니다') + '</i>'
        )
        keyboard = {'inline_keyboard': [[
            {'text': '✅ 청산 승인', 'callback_data': f'approve:{key}'},
            {'text': '❌ 보류', 'callback_data': f'reject:{key}'},
        ]]}
        event = threading.Event()
        with self._lock:
            self._pending[key] = {'event': event, 'result': None}
        resp = self._api('sendMessage', chat_id=self.chat_id, text=text, parse_mode='HTML', reply_markup=keyboard)
        if not resp or not resp.get('ok'):
            log.warning('[Telegram] 청산 승인 요청 전송 실패')
            with self._lock:
                self._pending.pop(key, None)
            return None
        msg_id = resp['result']['message_id']
        log.info(f'[Telegram] 청산 승인 요청 전송: {name} ({reason}) 대기 {timeout}초')
        event.wait(timeout=timeout)
        with self._lock:
            result = self._pending.pop(key, {}).get('result')
        self._api('editMessageReplyMarkup', chat_id=self.chat_id, message_id=msg_id, reply_markup={'inline_keyboard': []})
        if result is None:
            log.info(f'[Telegram] 청산 승인 타임아웃: {name}')
            return None
        log.info(f'[Telegram] 청산 {"✅ 승인" if result == "approve" else "❌ 보류"}: {name}')
        return result

    def notify_buy(self, name, code, side, price, qty,
                   score=0, grade='', reason='',
                   stop_pct=3.0, take_pct=5.0):
        """매수 체결 알림"""
        if not self.enabled:
            return
        side_kr  = 'CALL(매수)' if side == 'CALL' else 'PUT(매도)'
        margin   = price * 10 * qty * MARGIN_RATE
        stop_prc = price * (1 - stop_pct / 100) if side == 'CALL' else price * (1 + stop_pct / 100)
        take_prc = price * (1 + take_pct / 100) if side == 'CALL' else price * (1 - take_pct / 100)
        rate = _current_rate(code)
        # 신호 내역(점수/대장·졸병)은 승인 요청 메시지에만 — 체결 알림엔 실행 결과만
        text = (
            f'✅ <b>{_html.escape(str(name))} 샀습니다</b>\n'
            f'<code>────────────────</code>\n'
            f'매수가 <b>{price:,}원</b>  ({_rate_str(rate)})\n'
            f'{qty}계약 · 들어간 돈 약 {margin:,.0f}원\n'
            f'<code>────────────────</code>\n'
            f'{stop_prc:,.0f}원까지 밀리면 손절 (-{stop_pct}%)\n'
            f'수익이 +8%까지 갔다가 고점에서 -3% 되밀리면 이익 확정\n'
            f'그 전에 안 걸리면 20거래일 뒤 아침에 정리'
        )
        self.send_message(text)

    def notify_sell(self, name, code, side, entry_price, exit_price,
                    qty, pnl_krw, pnl_pct, reason=''):
        """청산 알림"""
        if not self.enabled:
            return
        emoji    = '✅' if pnl_krw >= 0 else '🔴'
        side_kr  = 'CALL' if side == 'CALL' else 'PUT'
        rate = _current_rate(code)
        text = (
            f'{emoji} <b>{_html.escape(str(name))} 정리했습니다</b>\n'
            f'<code>────────────────</code>\n'
            f'결과 <b>{pnl_krw:+,}원</b>  ({pnl_pct:+.2f}%)\n'
            f'매수가 {entry_price:,}원 → 정리 {exit_price:,}원 · {qty}계약\n'
            f'<code>────────────────</code>\n'
            f'{_plain(reason)}'
        )
        self.send_message(text)

    def notify_order(self, name, code, side, price, qty, pnl=None, reason=''):
        """기존 호환용 (내부에서 notify_buy/notify_sell로 위임)"""
        if not self.enabled:
            return
        if pnl is not None:
            pnl_pct = (price / (price - pnl / (10 * qty)) - 1) * 100 if price else 0
            self.notify_sell(name, code, side, 0, price, qty, pnl, pnl_pct, reason)
        else:
            self.notify_buy(name, code, side, price, qty, reason=reason)

    def notify_position_status(self, positions_info):
        """포지션 현황 알림"""
        if not self.enabled or not positions_info:
            return
        lines = ['<b>현재 포지션 현황</b>\n']
        total_pnl = 0
        for p in positions_info:
            pnl = p.get('pnl', 0)
            total_pnl += pnl
            pct = p.get('pct', 0)
            emoji = '📈' if pnl >= 0 else '📉'
            lines.append(
                f"{emoji} {p['name']} {p['side']} x{p['qty']}\n"
                f"   진입 {p['entry']:,} → 현재 {p['current']:,} ({pct:+.2f}%)\n"
                f"   손익: {pnl:+,}원"
            )
        lines.append(f'\n합산 손익: {total_pnl:+,}원')
        self.send_message('\n'.join(lines))

    # ── 백그라운드 폴링 ────────────────────────────

    def _poll_loop(self):
        """callback_query 실시간 수신 (롱폴링)"""
        while True:
            try:
                data = self._api('getUpdates', offset=self._offset, timeout=25)
                if not data or not data.get('ok'):
                    time.sleep(3)
                    continue

                for update in data.get('result', []):
                    self._offset = update['update_id'] + 1

                    # 일반 텍스트 메시지 응답
                    msg = update.get('message')
                    if msg:
                        text = msg.get('text', '').strip()
                        chat_id = msg.get('chat', {}).get('id')
                        if chat_id and text:
                            threading.Thread(target=self._handle_message_safe, args=(text,),
                                             daemon=True, name='TgCmd').start()

                    # 버튼 콜백 처리
                    cb = update.get('callback_query')
                    if not cb:
                        continue

                    self._api('answerCallbackQuery',
                              callback_query_id=cb['id'],
                              text='응답 처리 중...')

                    data_str = cb.get('data', '')
                    if ':' not in data_str:
                        continue

                    action, key = data_str.split(':', 1)
                    if action == 'doc':
                        threading.Thread(target=self._send_doc, args=(key,),
                                         daemon=True, name='TgDoc').start()
                        continue
                    with self._lock:
                        if key in self._pending:
                            self._pending[key]['result'] = action
                            self._pending[key]['event'].set()

            except Exception as e:
                log.warning(f'[Telegram] 폴링 오류: {type(e).__name__}: {e}')
                time.sleep(5)

    def _send_doc(self, key):
        """안내 자료 하나를 보낸다. 파일이 없으면 만드는 방법을 알려 준다."""
        for k, label, fname, desc in DOCS:
            if k != key:
                continue
            # 배포판에는 docs/ 폴더가 없고 설명서가 봇 폴더에 바로 있다. 둘 다 찾아본다.
            here = os.path.dirname(os.path.abspath(__file__))
            path = None
            for cand in (os.path.join(here, 'docs', fname), os.path.join(here, fname)):
                if os.path.exists(cand):
                    path = cand
                    break
            if not path:
                if k == 'guide':
                    self.send_message('설명서 파일을 찾지 못했습니다.' + '\n'
                                      + '봇 폴더에 「주식 매매 자동화 시스템.html」 이 있는지 확인해 주세요.')
                else:
                    self.send_message(f'{label} 은 설명서 안에 들어 있습니다.' + '\n'
                                      + '[📘 설명서] 를 받아서 보시면 됩니다.')
                return
            ok = self.send_document(path, caption=f'{label} — {desc}')
            if not ok:
                self.send_message(f'{label} 을(를) 보내지 못했습니다. 잠시 뒤 다시 눌러 주세요.')
            return

    def _handle_message_safe(self, text):
        """명령 하나를 따로 처리한다. 오류가 나도 폴링이 멈추지 않고, 사용자에게 이유를 알려 준다."""
        import time as _t
        t0 = _t.time()
        try:
            self._handle_message(text)
            log.info(f'[Telegram] 명령 처리: {text[:20]} ({_t.time() - t0:.1f}초)')
        except Exception as e:
            log.warning(f'[Telegram] 명령 처리 실패: {text[:20]} — {type(e).__name__}: {e}')
            try:
                self.send_message(f'⚠ "{text[:20]}" 처리 중 문제가 생겼습니다.\n잠시 뒤 다시 눌러 주세요')
            except Exception:
                pass

    def _handle_message(self, text):
        """일반 텍스트 명령 처리"""
        # 이모지 포함 버튼 텍스트 정규화
        import unicodedata
        t = ''.join(c for c in text.strip().lower()
                    if unicodedata.category(c) not in ('So', 'Sk'))
        t = t.strip()

        if any(w in t for w in ['안녕', 'hello', 'hi', '/start']):
            self._send_menu('안녕하세요! 매매 자동화 봇입니다.\n아래 버튼을 눌러 명령하세요.')

        elif any(w in t for w in ['잔고', '예수금', '돈', '/balance', 'balance']):
            try:
                from kis import get_futures_balance
                bal = get_futures_balance()
                avail = bal.get('ord_psbl_cash', 0)
                eval_pnl = bal.get('eval_pnl', 0)
                trade_pnl = bal.get('trade_pnl', 0)
                self.send_message(
                    f'💰 <b>계좌</b>\n<code>────────────────</code>\n'
                    f'지금 살 수 있는 돈 <b>{avail:,}원</b>\n'
                    f'보유 종목 평가손익 {eval_pnl:+,}원\n'
                    f'오늘까지 확정된 손익 {trade_pnl:+,}원'
                )
            except Exception as e:
                self.send_message(f'잔고 조회 실패: {e}')

        elif any(w in t for w in ['보유', '포지션', '현황', '/position', 'position']):
            try:
                from kis import get_futures_balance
                from scanner_262_52 import get_stock_info_naver
                bal = get_futures_balance()
                positions = bal.get('positions', [])
                if not positions:
                    self.send_message('지금 가지고 있는 종목이 없습니다.')
                    return
                lines = [f'📊 <b>보유 종목 {len(positions)}개</b>', '<code>────────────────</code>']
                total_pnl = 0
                for p in positions:
                    name = p.get('name', '')
                    code = p.get('code', '')
                    qty = p.get('qty', 0)
                    avg = p.get('avg_price', 0)
                    try:
                        from futures_map import get_stock_code
                        sc = get_stock_code(code)
                        if sc:
                            _, cur, rate = get_stock_info_naver(sc)
                        else:
                            cur = p.get('current', avg)
                            rate = 0
                    except Exception:
                        cur = p.get('current', avg)
                        rate = 0
                    pct = (cur - avg) / avg * 100 if avg else 0
                    pnl = (cur - avg) * 10 * qty
                    total_pnl += pnl
                    emoji = '📈' if pnl >= 0 else '📉'
                    nm = name or code
                    lines.append(f'{emoji} <b>{nm}</b>  {qty}계약')
                    lines.append(f'   매수가 {avg:,.0f}원 → 지금 {cur:,}원 ({pct:+.1f}%)')
                    lines.append(f'   평가손익 <b>{pnl:+,}원</b>')
                lines.append('<code>────────────────</code>')
                lines.append(f'합계 <b>{total_pnl:+,}원</b>')
                self.send_message('\n'.join(lines))
            except Exception as e:
                self.send_message(f'보유 종목을 불러오지 못했습니다 — 잠시 뒤 다시 눌러 주세요')

        elif any(w in t for w in ['오늘 후보', '후보', '스캔', '신호', '종목', '/scan', 'scan']):
            # 오늘 뽑힌 후보와 각 종목이 지금 어느 단계인지 (data/combined_live.json — 봇이 매 스캔 기록)
            try:
                import json as _j, os as _o, datetime as _dt
                p = _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), 'data', 'combined_live.json')
                d = _j.load(open(p, encoding='utf-8'))
                if d.get('date') != _dt.date.today().isoformat():
                    self.send_message('오늘 후보 정보가 아직 없습니다. 08:45 첫 점검 뒤에 다시 눌러 주세요.')
                    return
                rows = d.get('rows') or []
                if not rows:
                    self.send_message('오늘은 조건에 맞는 후보가 없습니다 — 쉬는 날입니다.')
                    return
                ST = {'대기': '지켜보는 중', 'requested': '승인 요청함', 'entered': '매수함',
                      'declined': '거절/무응답', 'no_timing': '시점 못 만남', 'chase': '너무 올라 건너뜀',
                      'price_cap': '값이 비싸 건너뜀', 'risk': '한도 도달', 'margin': '돈 모자라 건너뜀', 'held': '이미 보유'}
                TY = {'A': '3분봉 5/20 평균선 교차', 'B': '장 초반 강세', 'D': '평균가+거래량'}
                lines = [f'🔍 <b>오늘 후보 {len(rows)}개</b> ({d.get("at", "")} 기준)',
                         f'지켜보는 시간 {d.get("window", "")}' + ('  · 지금 감시 중' if d.get('in_window') else '  · 시간 지남'),
                         '<code>────────────────</code>']
                for r in rows:
                    fam = (r.get('family') or '') + (' CALL(매수)' if r.get('direction') == 'CALL' else ' PUT(매도)')
                    st = ST.get(r.get('status'), r.get('status') or '지켜보는 중')
                    lines.append(f'<b>{r.get("name")}</b> {int(r.get("score", 0))}점 — {fam}')
                    lines.append(f'   {st}' + (f' · 지금 {int(r.get("price") or 0):,}원' if r.get('price') else ''))
                    s1 = r.get('stage1') or {}
                    if s1:
                        lines.append('   1단계: ' + ('통과' if s1.get('ok') else str(s1.get('why', ''))))
                    hits = [k for k, v in (r.get('types') or {}).items() if v.get('ok')]
                    if hits:
                        lines.append('   살 시점: ' + ', '.join(f'{k} {TY.get(k, k)}' for k in hits))
                lines.append('<code>────────────────</code>')
                lines.append('<i>살 시점이 오면 승인 요청이 옵니다</i>')
                self.send_message('\n'.join(lines))
            except FileNotFoundError:
                self.send_message('오늘 후보 정보가 아직 없습니다. 08:45 첫 점검 뒤에 다시 눌러 주세요.')
            except Exception as e:
                self.send_message(f'오늘 후보를 불러오지 못했습니다 — 잠시 뒤 다시 눌러 주세요')

        elif any(w in t for w in ['상태', 'status', '/status']):
            import datetime
            now = datetime.datetime.now().strftime('%H:%M:%S')
            self.send_message(
                f'매매 자동화 봇 정상 동작 중\n'
                f'현재 시각: {now}\n'
                f'승인 모드: ON (매수 전 승인 필요)'
            )

        # ── 전략 조회 ──────────────────────────────────
        elif any(w in t for w in ['오늘 규칙', '규칙', '전략', 'strategy', '/strategy']):
            self._handle_strategy_show()

        # ── 매매 일시 정지 ──────────────────────────────
        elif any(w in t for w in ['매수 멈춤', '멈춤', '정지', '멈춰', 'pause', '/pause', '⏸']):
            _OVERRIDES['paused'] = True
            log.info('[Telegram] 매수 멈춤 명령')
            self.send_message('⏸ <b>새로 사는 것을 멈췄습니다</b>\n이미 가진 종목은 규칙대로 지켜봅니다(손절·이익 확정은 그대로).\n다시 사려면 [▶ 다시 시작]을 누르세요.')

        # ── 매매 재개 ───────────────────────────────────
        elif any(w in t for w in ['안내 자료', '안내자료', '관계도', '흐름도', '설치 안내', '/docs', '📚']):
            rows = [[{'text': label, 'callback_data': f'doc:{key}'}] for key, label, _f, _d in DOCS]
            lines = ['📚 <b>안내 자료</b>', '<code>────────────────</code>']
            for _k, label, _f, desc in DOCS:
                lines.append(f'{label} — {desc}')
            lines.append('')
            lines.append('<i>누르면 파일로 보내 드립니다. 폰에서 열면 바로 보입니다</i>')
            self._api('sendMessage', chat_id=self.chat_id, text='\n'.join(lines),
                      parse_mode='HTML', reply_markup={'inline_keyboard': rows})

        elif any(w in t for w in ['지금 정리', '정리해', '/exitnow', '🔻']):
            # 가진 종목을 지금 판다 — 종목마다 승인을 다시 묻는다
            try:
                import kis as _k
                bal = _k.get_futures_balance() or {}
                ps = [p for p in (bal.get('positions') or []) if int(p.get('qty', 0) or 0) > 0]
                if not ps:
                    self.send_message('지금 가지고 있는 종목이 없습니다.')
                    return
                request_manual_exit('all')
                names = ', '.join(str(p.get('name') or p.get('code')) for p in ps)
                self.send_message(
                    '🔻 <b>지금 정리하겠습니다</b>' + '\n' +
                    '<code>────────────────</code>' + '\n' +
                    f'대상: {names}' + '\n' + '\n' +
                    '종목마다 하나씩 다시 여쭙겠습니다.' + '\n' +
                    '<i>그대로 두실 종목은 그때 [❌ 보류]를 누르세요</i>')
            except Exception as e:
                self.send_message(f'정리 지시를 넣지 못했습니다 — 잠시 뒤 다시 눌러 주세요')

        elif any(w in t for w in ['다시 시작', '재개', 'resume', '/resume', '▶']):
            _OVERRIDES.pop('paused', None)
            log.info('[Telegram] 다시 시작 명령')
            self.send_message('▶ <b>다시 시작했습니다</b>\n오늘 후보 중 살 시점이 오면 물어봅니다.')

        # ── min_score 설정 ──────────────────────────────
        elif 'min_score' in t or 'minscore' in t or '최소점수' in t:
            import re
            nums = re.findall(r'\d+', text)
            if nums:
                val = max(50, min(90, int(nums[0])))
                _OVERRIDES['min_score'] = val
                log.info(f'[Telegram] min_score → {val}')
                self.send_message(f'최소점수 → {val}점 적용 (이번 장 한정)')
            else:
                from config import SENTRY_MIN_SCORE
                cur = _OVERRIDES.get('min_score', SENTRY_MIN_SCORE)
                self.send_message(f'현재 최소점수: {cur}점\n변경: min_score 70')

        # ── 방향 편향 설정 ─────────────────────────────
        elif any(w in t for w in ['방향', 'bias', 'direction']):
            if any(w in t for w in ['call', 'c', '매수', '콜']):
                _OVERRIDES['direction_bias'] = 'CALL'
                self.send_message('방향 편향 → CALL (CALL 신호 우선)')
            elif any(w in t for w in ['put', 'p', '매도', '풋']):
                _OVERRIDES['direction_bias'] = 'PUT'
                self.send_message('방향 편향 → PUT (PUT 신호 우선)')
            else:
                _OVERRIDES.pop('direction_bias', None)
                self.send_message('방향 편향 → 중립 (양방향)')

        # ── 매매 강도 설정 ─────────────────────────────
        elif any(w in t for w in ['강도', 'aggr', '공격', '보수', '일반']):
            if any(w in t for w in ['공격', 'aggress', 'aggressive']):
                _OVERRIDES['aggression'] = 'AGGRESSIVE'
                self.send_message('매매 강도 → 공격적 (max_positions +1 효과)')
            elif any(w in t for w in ['보수', 'conserv', 'conservative']):
                _OVERRIDES['aggression'] = 'CONSERVATIVE'
                self.send_message('매매 강도 → 보수적 (min_score +5 효과)')
            else:
                _OVERRIDES.pop('aggression', None)
                self.send_message('매매 강도 → 일반')

        # ── 설정 초기화 ────────────────────────────────
        elif any(w in t for w in ['초기화', 'reset', '리셋']):
            _OVERRIDES.clear()
            log.info('[Telegram] 설정 초기화')
            self.send_message('설정 초기화 — daily_strategy.json 기본값으로 복귀')

        else:
            # 자연어 → Claude CLI로 해석 시도
            self._handle_natural_language(text)

    def _handle_strategy_show(self):
        """오늘 적용 중인 규칙 요약 — 어떻게 고르고, 얼마나 사고, 언제 파는지 (PO 2026-09-23)"""
        try:
            import importlib, config as _c
            importlib.reload(_c)
            L = ['📋 <b>오늘 적용 중인 규칙</b>', '<code>────────────────</code>', '<b>어떻게 고르나</b>']
            try:
                import daily_strategy_engine as _e
                for sp in _e.enabled_strategies():
                    fam = (sp.get('family') or '') + (' CALL(매수)' if sp.get('direction') == 'CALL' else ' PUT(매도)')
                    L.append(f'· {fam}' + ('' if sp.get('live') else ' (신호만)'))
            except Exception:
                L.append('· 규칙 목록을 읽지 못했습니다')
            _ws = getattr(_c, 'TIMING_WINDOW_START', None); _we = getattr(_c, 'TIMING_WINDOW_END', None)
            if _ws and _we:
                L.append(f'· 살 시점은 {_ws.strftime("%H:%M")}~{_we.strftime("%H:%M")} 동안만 찾습니다 (A 평균선 교차 · B 장 초반 강세 · D 평균가+거래량)')
            L.append('<code>────────────────</code>')
            L.append('<b>얼마나 사나</b>')
            L.append(f'· 한 번에 {getattr(_c, "SENTRY_DEFAULT_QTY_STOCK", 1)}계약씩 삽니다 — 한 종목에 최대 {getattr(_c, "MAX_QTY_PER_STOCK", 1)}계약까지')
            L.append(f'· 하루에 새로 사는 종목은 {getattr(_c, "MAX_NEW_STOCKS_PER_DAY", 2)}개까지')
            L.append(f'· 동시에 가지고 있을 수 있는 종목은 {getattr(_c, "SENTRY_MAX_POSITIONS", 5)}개까지')
            L.append(f'· 종목별 주식 가격이 {getattr(_c, "ENTRY_MAX_PRICE", 0):,}원 이하인 종목만')
            L.append(f'· 하루 손실이 {getattr(_c, "MAX_DAILY_LOSS", 0):,}원을 넘으면 그날은 더 사지 않음')
            L.append('<code>────────────────</code>')
            L.append('<b>언제 정리하나</b>')
            _sl = getattr(_c, 'DAILY_STRATEGY_STOP_LOSS_PCT', None)
            _arm = getattr(_c, 'DAILY_STRATEGY_TRAIL_ARM_PCT', None)
            _drop = getattr(_c, 'DAILY_STRATEGY_TRAIL_DROP_PCT', None)
            L.append('<b>묻지 않고 봇이 바로 정리하는 것</b>')
            if _sl:
                L.append(f'· -{float(_sl):.0f}%까지 밀리면 손절')
            if _arm and _drop:
                L.append(f'· 수익이 +{float(_arm):.0f}%까지 갔다가 고점에서 -{float(_drop):.0f}% 되밀리면 이익 확정')
            L.append('· (정리가 아닙니다) 선물 만기 전날에 다음 달 계약으로 갈아탑니다 — 물어보지만, 답이 없으면 만기를 넘길 수 없어 먼저 갈아탑니다')
            L.append('')
            L.append('<b>물어보고 정리하는 것</b>')
            L.append(f'· 정리가 되지 않은 채 {int(getattr(_c, "DAILY_STRATEGY_HOLD_DAYS", 20))}거래일(약 한 달)이 지나면 그날 아침에 정리 여부를 묻습니다')
            if _OVERRIDES:
                L.append('<code>────────────────</code>')
                L.append('<b>지금 내가 바꿔 둔 것</b>')
                _KO = {'paused': '새로 사는 것 멈춤', 'min_score': '최소 점수', 'direction_bias': '방향 제한', 'aggression': '매매 강도'}
                for k, v in _OVERRIDES.items():
                    L.append(f'· {_KO.get(k, k)}: {v}')
            self.send_message('\n'.join(L))
        except Exception as e:
            self.send_message(f'규칙을 읽지 못했습니다 — 잠시 뒤 다시 눌러 주세요')

    def _handle_natural_language(self, text: str):
        """Anthropic API (haiku)로 자연어 명령 해석
        — claude CLI는 agent 모드라 단순 분류에 부적합, API haiku 사용 (비용 < $0.001/회)
        """
        import anthropic, json as _json

        override_summary = _json.dumps(_OVERRIDES, ensure_ascii=False) if _OVERRIDES else '없음'

        user_msg = f"""사용자 메시지: "{text}"
현재 override: {override_summary}

가능한 command:
pause / resume / reset /
set_min_score(50~90) / set_direction(CALL|PUT|NEUTRAL) / set_aggression(AGGRESSIVE|CONSERVATIVE|NORMAL) /
show_strategy / show_balance / show_position / show_scan / none

JSON으로만 응답:
{{"command":"...", "value":"... or null", "reply":"확인 메시지 1줄(한국어)"}}"""

        try:
            from config import ANTHROPIC_API_KEY
            client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
            resp = client.messages.create(
                model='claude-haiku-4-5-20251001',
                max_tokens=200,
                system='당신은 한국 주식 매매 자동화 봇의 텔레그램 명령 해석기. 반드시 JSON만 출력.',
                messages=[{'role': 'user', 'content': user_msg}]
            )
            raw = resp.content[0].text.strip()

            start = raw.find('{')
            end = raw.rfind('}') + 1
            if start < 0 or end <= start:
                raise ValueError('JSON 없음')
            parsed = _json.loads(raw[start:end])

            cmd = parsed.get('command', 'none')
            val = parsed.get('value')
            reply = parsed.get('reply', '')

            # 명령 실행
            if cmd == 'pause':
                _OVERRIDES['paused'] = True
                self.send_message(f'⏸ {reply}')
            elif cmd == 'resume':
                _OVERRIDES.pop('paused', None)
                self.send_message(f'▶ {reply}')
            elif cmd == 'reset':
                _OVERRIDES.clear()
                self.send_message(f'🔄 {reply}')
            elif cmd == 'set_min_score' and val:
                score = max(50, min(90, int(str(val).strip())))
                _OVERRIDES['min_score'] = score
                self.send_message(f'🎯 {reply} (min_score={score})')
            elif cmd == 'set_direction' and val:
                direction = str(val).upper()
                if direction in ('CALL', 'PUT', 'NEUTRAL'):
                    if direction == 'NEUTRAL':
                        _OVERRIDES.pop('direction_bias', None)
                    else:
                        _OVERRIDES['direction_bias'] = direction
                    self.send_message(f'🧭 {reply}')
            elif cmd == 'set_aggression' and val:
                aggr = str(val).upper()
                if aggr in ('AGGRESSIVE', 'CONSERVATIVE', 'NORMAL'):
                    if aggr == 'NORMAL':
                        _OVERRIDES.pop('aggression', None)
                    else:
                        _OVERRIDES['aggression'] = aggr
                    self.send_message(f'⚡ {reply}')
            elif cmd == 'show_strategy':
                self._handle_strategy_show()
            elif cmd == 'show_balance':
                self._handle_message('잔고')
            elif cmd == 'show_position':
                self._handle_message('포지션')
            elif cmd == 'show_scan':
                self._handle_message('스캔')
            else:
                self.send_message(
                    f'"{text[:30]}" — 해석 불가\n\n'
                    '예시: "오늘 조심해" / "잠깐 쉬어" / "점수 올려" / "풋 위주로"'
                )

            log.info(f'[Telegram NL] "{text[:40]}" → {cmd}({val})')

        except Exception as e:
            log.warning(f'[Telegram NL] 자연어 해석 실패: {e}')
            self.send_message(
                f'해석 실패: {str(e)[:80]}\n\n'
                '직접 명령: 정지 / 재개 / min_score 70 / 방향 CALL / 강도 공격적'
            )

    def _start_polling(self):
        t = threading.Thread(target=self._poll_loop, daemon=True, name='TelegramPoller')
        t.start()


# ── 싱글톤 ────────────────────────────────────────

_bot: TelegramApprovalBot | None = None


def get_bot() -> TelegramApprovalBot:
    global _bot
    if _bot is None:
        _bot = TelegramApprovalBot()
    return _bot


# ── 편의 함수 ─────────────────────────────────────

def request_approval(name, code, side, score, price, qty=2, timeout=180, reason=''):
    return get_bot().request_approval(name, code, side, score, price, qty, timeout, reason)


def request_day_start(summary_text, timeout=600):
    """장 시작 전 '오늘 매매 시작' 승인. Returns 'approve' / 'reject' / None"""
    b = get_bot()
    if not b.enabled:
        return None
    key = f'day_{int(time.time())}'
    text = ('📋 <b>오늘 매매 시작할까요?</b>\n<code>────────────────</code>\n'
            + summary_text.replace('\n', '\n')
            + f'\n<code>────────────────</code>\n<i>{timeout}초 안에 답이 없으면 아무것도 사지 않고 기다리다 다시 묻습니다</i>')
    keyboard = {'inline_keyboard': [[
        {'text': '✅ 오늘 매매 시작', 'callback_data': f'approve:{key}'},
        {'text': '⛔ 오늘은 쉼', 'callback_data': f'reject:{key}'},
    ]]}
    event = threading.Event()
    with b._lock:
        b._pending[key] = {'event': event, 'result': None}
    resp = b._api('sendMessage', chat_id=b.chat_id, text=text, parse_mode='HTML', reply_markup=keyboard)
    if not resp or not resp.get('ok'):
        with b._lock:
            b._pending.pop(key, None)
        return None
    msg_id = resp['result']['message_id']
    event.wait(timeout=timeout)
    with b._lock:
        result = b._pending.pop(key, {}).get('result')
    b._api('editMessageReplyMarkup', chat_id=b.chat_id, message_id=msg_id, reply_markup={'inline_keyboard': []})
    if result == 'approve':
        b.send_message('✅ <b>오늘 매매를 시작합니다</b>\n살 때는 종목마다 물어봅니다.\n정리는 두 가지입니다 — 손절·이익 확정은 묻지 않고 바로, 보유 기간이 다 된 것은 물어보고.')
    elif result == 'reject':
        b.send_message('⛔ 오늘은 새로 사지 않고 가진 종목만 지켜봅니다.')
    return result


def request_exit_approval(name, code, side, qty, price, pnl_pct, reason, timeout=120):
    return get_bot().request_exit_approval(name, code, side, qty, price, pnl_pct, reason, timeout)


def notify(text):
    return get_bot().send_message(text)


def notify_order(name, code, side, price, qty, pnl=None, reason=''):
    return get_bot().notify_order(name, code, side, price, qty, pnl, reason)


def notify_buy(name, code, side, price, qty,
               score=0, grade='', reason='', stop_pct=3.0, take_pct=5.0):
    return get_bot().notify_buy(name, code, side, price, qty,
                                score, grade, reason, stop_pct, take_pct)


def notify_sell(name, code, side, entry_price, exit_price,
                qty, pnl_krw, pnl_pct, reason=''):
    return get_bot().notify_sell(name, code, side, entry_price, exit_price,
                                 qty, pnl_krw, pnl_pct, reason)


# ── 설정 테스트 ───────────────────────────────────

if __name__ == '__main__':
    import sys, io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    bot = get_bot()
    if not bot.enabled:
        print('.env에 TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID 설정 필요')
        print('1. https://t.me/BotFather 에서 /newbot')
        print('2. https://t.me/userinfobot 에서 chat_id 확인')
    else:
        print('연결 테스트 중...')
        bot.send_message('텔레그램 봇 연결 테스트 성공! 매매 자동화 봇과 연결됐습니다.')
        print('메시지 전송 완료. 핸드폰을 확인하세요.')
