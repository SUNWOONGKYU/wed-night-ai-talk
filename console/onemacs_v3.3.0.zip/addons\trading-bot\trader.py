# -*- coding: utf-8 -*-
"""
Trader — 매매 자동화 봇
  - 3분 간격 스캔 (scanner_262_52 재사용)
  - 코스피200 선물 + 개별 주식(현물 차트 → 주식선물 매매)
  - 50점 이상 → 주문 실행 (KIS API)
  - 연구 DB(Supabase)에 모든 신호/결과 기록
  - KIS_PAPER_MODE=true → 모의투자
"""
import sys
import os
import time
import json
import logging
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    KIS_PAPER_MODE,
    SENTRY_SCAN_INTERVAL, SENTRY_MIN_SCORE, SENTRY_FUTURES_MIN_SCORE,
    SENTRY_MAX_POSITIONS, SENTRY_STOP_LOSS_PCT, SENTRY_TAKE_PROFIT_PCT,
    SENTRY_TRAILING_PCT, SENTRY_FORCE_CLOSE_TIME,
    SENTRY_MARKET_OPEN, SENTRY_MARKET_CLOSE,
    SENTRY_DEFAULT_QTY_FUTURES, SENTRY_DEFAULT_QTY_STOCK,
    MAX_DAILY_TRADES, MAX_DAILY_LOSS, LOG_DIR, APPROVAL_REQUIRED,
)
from analysis import IndicatorEngine
import requests as _requests
from scanner_262_52 import (
    scan_futures,
    analyze_both, score_signal, validate_signal,
    KOSPI200_FUTURES_CODE, SCORE_BOSS, SCORE_SOLDIER,
    get_minute_bars_kis, get_minute_bars_naver, get_minute_bars_union, get_stock_info_naver,
)

SCANNER_URL = 'http://localhost:5050/api/status'
SCANNER_SCAN_URL = 'http://localhost:5050/api/scan'
SCANNER_UPDATE_URL = 'http://localhost:5050/api/sentry/update'
from kis import (
    get_access_token, get_stock_price, get_futures_price, get_futures_orderable,
    place_order, place_futures_order, get_balance, get_futures_balance,
)
import vault_writer as rdb  # Supabase 대신 vault 직접 기록
import telegram_notify
import algo_db
from futures_map import get_futures_code, has_map

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S',
)
log = logging.getLogger('trader')

_KST = timezone(timedelta(hours=9))


def _kst_now():
    return datetime.now(_KST)


# ═══════════════════════════════════════════
#  MarketClock — 장시간 관리
# ═══════════════════════════════════════════

class MarketClock:
    """장 운영 시간 체크"""

    def __init__(self):
        self.open_time = SENTRY_MARKET_OPEN
        self.close_time = SENTRY_MARKET_CLOSE
        self.force_close_time = SENTRY_FORCE_CLOSE_TIME
        self.holidays = self._load_holidays()

    @staticmethod
    def _load_holidays():
        """knowledge/holidays.json에서 KRX 휴장일(YYYY-MM-DD) 집합을 로드. 실패 시 빈 집합."""
        try:
            import json as _json
            path = os.path.join(os.path.dirname(__file__), 'config_data', 'holidays.json')
            with open(path, encoding='utf-8') as f:
                data = _json.load(f)
            return set(data.get('holidays', {}).keys())
        except Exception as e:
            log.warning(f'[Clock] 휴장일 목록 로드 실패: {e} — 주말만 차단')
            return set()

    def is_holiday(self):
        return _kst_now().strftime('%Y-%m-%d') in self.holidays

    def is_trading_day(self):
        """평일이면서 휴장일이 아닌 날만 거래일."""
        return self.is_weekday() and not self.is_holiday()

    def is_market_open(self):
        # 주말/휴장일에는 시간대와 무관하게 장이 열리지 않는다.
        # (2026-06-13 버그: 토요일에 _watchlist_loop가 시간대만 보고 매수 승인요청 발송)
        if not self.is_trading_day():
            return False
        now = _kst_now().time()
        return self.open_time <= now <= self.close_time

    def is_force_close_time(self):
        now = _kst_now().time()
        return now >= self.force_close_time

    def seconds_until_open(self):
        now = _kst_now()
        today_open = now.replace(
            hour=self.open_time.hour, minute=self.open_time.minute,
            second=0, microsecond=0
        )
        if now.time() >= self.close_time:
            today_open += timedelta(days=1)
        elif now.time() >= self.open_time:
            return 0
        diff = (today_open - now).total_seconds()
        return max(0, diff)

    def is_weekday(self):
        return _kst_now().weekday() < 5


# ═══════════════════════════════════════════
#  RiskManager — 리스크 관리
# ═══════════════════════════════════════════

class RiskManager:
    """일일 매매횟수/손실 한도, 포지션 제한"""

    def __init__(self):
        self.daily_trades = 0
        self.daily_pnl = 0.0
        self.daily_new_codes = set()
        self.last_reset_date = _kst_now().strftime('%Y-%m-%d')

    def _check_reset(self):
        today = _kst_now().strftime('%Y-%m-%d')
        if self.last_reset_date != today:
            self.daily_trades = 0
            self.daily_pnl = 0.0
            self.daily_new_codes = set()      # 오늘 새로 산 종목 (PO 2026-09-23: 하루 2종목까지)
            self.last_reset_date = today
            self._save_new_codes()

    _NEW_CODES_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'daily_new_codes.json')

    def note_new_code(self, code):
        """새 종목을 처음 산 날 기록. 같은 종목에 계약을 더 얹는 것은 '새 종목'이 아니다.
        장중 재시작해도 한도가 되살아나게 파일에 남긴다."""
        self._check_reset()
        if not code:
            return
        if not hasattr(self, 'daily_new_codes'):
            self.daily_new_codes = set()
        self.daily_new_codes.add(code)
        self._save_new_codes()

    def _save_new_codes(self):
        try:
            import json as _j
            os.makedirs(os.path.dirname(self._NEW_CODES_PATH), exist_ok=True)
            with open(self._NEW_CODES_PATH, 'w', encoding='utf-8') as f:
                _j.dump({'date': _kst_now().strftime('%Y-%m-%d'),
                         'codes': sorted(getattr(self, 'daily_new_codes', None) or set())}, f, ensure_ascii=False)
        except Exception as e:
            log.debug(f'[Risk] 오늘 새 종목 저장 실패: {e}')

    def load_new_codes(self):
        """기동 시 오늘 이미 새로 산 종목을 되살린다(재시작으로 한도가 풀리는 것 방지)."""
        self._check_reset()
        try:
            import json as _j
            with open(self._NEW_CODES_PATH, encoding='utf-8') as f:
                d = _j.load(f)
            if d.get('date') == _kst_now().strftime('%Y-%m-%d'):
                self.daily_new_codes = set(d.get('codes') or [])
                if self.daily_new_codes:
                    log.info(f'[Risk] 오늘 이미 새로 산 종목 복원: {len(self.daily_new_codes)}개')
        except FileNotFoundError:
            pass
        except Exception as e:
            log.debug(f'[Risk] 오늘 새 종목 복원 실패: {e}')

    def can_open_code(self, code, active_positions):
        """이 종목을 지금 새로 살 수 있나. (PO 2026-09-23: 하루 새 종목 2개 · 동시 보유 5종목)
        이미 가진 종목에 계약을 더 얹는 경우는 두 한도 모두 적용받지 않는다(계약수 한도는 호출부가 본다)."""
        import config as _c
        self._check_reset()
        codes = {getattr(p, 'code', None) for p in (active_positions or [])}
        if code in codes:
            return True, ''
        cap_day = int(getattr(_c, 'MAX_NEW_STOCKS_PER_DAY', 2))
        new_codes = getattr(self, 'daily_new_codes', None) or set()
        if len(new_codes) >= cap_day:
            return False, f'오늘 새로 산 종목 {len(new_codes)}/{cap_day} — 오늘은 더 안 삼'
        cap_hold = int(getattr(_c, 'SENTRY_MAX_POSITIONS', 5))
        if len(codes) >= cap_hold:
            return False, f'보유 종목 {len(codes)}/{cap_hold} — 자리 없음'
        return True, ''

    def can_trade(self, active_positions):
        self._check_reset()

        if self.daily_trades >= MAX_DAILY_TRADES:
            log.warning(f'[Risk] 일일 매매횟수 초과: {self.daily_trades}/{MAX_DAILY_TRADES}')
            return False

        # 일일 손실 한도 = 당일 실현손익 + 보유 포지션 평가손익(주식선물 승수 10) — 한도 이하이면 신규 진입 금지(보유는 청산 규칙대로)
        unrealized = 0.0
        for p in (active_positions or []):
            try:
                cur = getattr(p, 'current_price', None) or p.entry_price
                unrealized += (cur - p.entry_price) * 10 * p.qty * (1 if p.side == 'CALL' else -1)
            except Exception:
                pass
        if self.daily_pnl + unrealized <= -MAX_DAILY_LOSS:
            log.warning(f'[Risk] 일일 손실한도 초과: 실현 {self.daily_pnl:,.0f} + 평가 {unrealized:,.0f} = {self.daily_pnl + unrealized:,.0f}원 → 신규 진입 금지')
            return False

        _codes = {getattr(p, 'code', None) for p in (active_positions or [])}
        if len(_codes) >= SENTRY_MAX_POSITIONS:
            log.warning(f'[Risk] 동시 보유 종목 한도: {len(_codes)}/{SENTRY_MAX_POSITIONS}종목')
            return False

        return True

    def record_trade(self, pnl=0.0):
        self._check_reset()
        self.daily_trades += 1
        self.daily_pnl += pnl


# ═══════════════════════════════════════════
#  Position — 포지션 관리
# ═══════════════════════════════════════════

def _trading_days_between(d0, d1):
    """d0 다음 날부터 d1 까지의 거래일 수(주말·config_data/holidays.json 제외). 검증(거래일 20일 보유)과 일치시키기 위해 사용."""
    try:
        import json as _json
        hp = os.path.join(os.path.dirname(__file__), 'config_data', 'holidays.json')
        with open(hp, encoding='utf-8') as _f:
            _h = _json.load(_f)
        hol = set(_h.get('holidays', _h) if isinstance(_h, dict) else _h)
    except Exception:
        hol = set()
    import datetime as _dt
    n = 0
    d = d0
    while d < d1:
        d += _dt.timedelta(days=1)
        if d.weekday() < 5 and d.strftime('%Y-%m-%d') not in hol:
            n += 1
    return n


class Position:
    """개별 포지션 추적"""

    def __init__(self, code, name, side, qty, entry_price,
                 is_futures=False, is_stock_futures=False,
                 signal_id=None, algo_id=None,
                 strategy='scalp', hold_days=None):
        self.code = code
        self.name = name
        self.side = side          # 'CALL' or 'PUT'
        self.qty = qty
        self.entry_price = entry_price
        self.is_futures = is_futures
        self.is_stock_futures = is_stock_futures
        self.signal_id = signal_id
        self.algo_id = algo_id
        self.entry_time = _kst_now()
        self.highest_price = entry_price   # 트레일링용
        self.lowest_price = entry_price
        # 전략 트랙: 'scalp'(분봉 손절/익절/트레일링) vs 'momentum'(시간기반 N일 보유)
        self.strategy = strategy
        self.hold_days = hold_days         # momentum: 보유 영업일

    def update_price(self, current_price):
        """가격 업데이트 + 트레일링 추적"""
        self.current_price = current_price
        if current_price > self.highest_price:
            self.highest_price = current_price
        if current_price < self.lowest_price:
            self.lowest_price = current_price

    def check_exit(self, current_price):
        """
        손절/익절/트레일링 체크
        Returns: (should_exit, reason)
        """
        if self.entry_price == 0:
            return False, ''

        if self.side == 'CALL':
            pnl_pct = (current_price - self.entry_price) / self.entry_price * 100
            trailing_drop = (self.highest_price - current_price) / self.highest_price * 100
        else:  # PUT
            pnl_pct = (self.entry_price - current_price) / self.entry_price * 100
            trailing_drop = (current_price - self.lowest_price) / self.lowest_price * 100

        # ── 모멘텀 전략: 시간기반 청산(N영업일 보유) — 백테스트와 일치 ──
        # 분봉 손절/트레일링을 적용하지 않는다(60일 보유 전략은 변동성을 견뎌야 함).
        # 단 파국적 손실(-15%) 방어용 캐치-올 스톱만 둔다.
        if self.strategy == 'momentum':
            import config as _cfg_x
            _sl = getattr(_cfg_x, 'DAILY_STRATEGY_STOP_LOSS_PCT', None)
            if _sl and pnl_pct <= -float(_sl):
                return True, f'모멘텀 손절 ({pnl_pct:+.2f}%, 손절선 -{float(_sl):.1f}%)'
            if pnl_pct <= -float(getattr(_cfg_x, 'DAILY_STRATEGY_CATASTROPHIC_PCT', 15.0)):
                return True, f'모멘텀 파국손절 ({pnl_pct:+.2f}%)'
            # 트레일링 익절 (PO 2026-09-22): 고점이 +N% 이상 갔다가 고점 대비 M% 되밀리면 이익을 지키고 나온다
            _arm = getattr(_cfg_x, 'DAILY_STRATEGY_TRAIL_ARM_PCT', None)
            _drop = getattr(_cfg_x, 'DAILY_STRATEGY_TRAIL_DROP_PCT', None)
            if _arm and _drop:
                if self.side == 'CALL':
                    peak_pnl = (self.highest_price - self.entry_price) / self.entry_price * 100
                else:
                    peak_pnl = (self.entry_price - self.lowest_price) / self.entry_price * 100
                if peak_pnl >= float(_arm) and trailing_drop >= float(_drop):
                    return True, f'모멘텀 트레일링 익절 ({pnl_pct:+.2f}%, 고점 +{peak_pnl:.1f}% → -{trailing_drop:.1f}%)'
            today = _kst_now().date()
            # 주식선물 월물 만기 = 둘째 목요일. "다음 만기"를 구한다 — 이번 달 만기가 이미 지났으면 다음 달 것
            # (2026-09-22 수정: today >= expiry-1 만 보면 만기 지난 뒤 새로 산 종목이 첫날 바로 롤오버로 잡혔다)
            import calendar as _cal
            import datetime as _dt2

            def _expiry_of(y, m):
                th = [w[3] for w in _cal.monthcalendar(y, m) if w[3] > 0]
                return _dt2.date(y, m, th[1]) if len(th) >= 2 else None

            exp = _expiry_of(today.year, today.month)
            if exp and today > exp - _dt2.timedelta(days=1):
                ny, nm = (today.year + 1, 1) if today.month == 12 else (today.year, today.month + 1)
                exp = _expiry_of(ny, nm)
            if exp and today >= exp - _dt2.timedelta(days=1) and getattr(self, '_rolled_for', None) != (exp.year, exp.month):
                return True, f'모멘텀 만기롤오버 ({pnl_pct:+.2f}%)'
            # 목표 보유기간: 거래일 기준(주말·KRX 휴장일 제외) — 검증(거래일 20일)과 일치
            held_days = _trading_days_between(self.entry_time.date(), today)
            if self.hold_days and held_days >= int(self.hold_days):
                return True, f'모멘텀 만기청산 ({held_days}거래일 보유, {pnl_pct:+.2f}%)'
            return False, ''

        # 손절
        if pnl_pct <= -SENTRY_STOP_LOSS_PCT:
            return True, f'손절 ({pnl_pct:+.2f}%)'

        # 트레일링 익절: 5% 이상 수익 달성 후 고점 대비 -3% 하락 시 청산
        if pnl_pct >= 5.0:
            if trailing_drop >= SENTRY_TRAILING_PCT:
                return True, f'트레일링익절 ({pnl_pct:+.2f}%, 고점대비 -{trailing_drop:.2f}%)'

        return False, ''

    def pnl_pct(self, current_price):
        if self.entry_price == 0:
            return 0
        if self.side == 'CALL':
            return (current_price - self.entry_price) / self.entry_price * 100
        else:
            return (self.entry_price - current_price) / self.entry_price * 100


# ═══════════════════════════════════════════
#  TraderBot — 메인 루프
# ═══════════════════════════════════════════

class TraderBot:
    """매매 자동화 봇"""

    def __init__(self):
        self.clock = MarketClock()
        self.risk = RiskManager()
        self.positions = []        # 활성 포지션 목록
        self.engine = IndicatorEngine()
        self.algo_id = None        # 현재 사용 알고리즘 ID
        self.scan_count = 0
        self._last_scan_ts = None  # 마지막 처리한 스캔 타임스탬프
        self._followup_queue = []  # [(signal_id, stock_code, signal_type, entry_price, time_5m, time_10m, time_30m, ...)]
        self._forced_traded_today = set()  # 오늘 강제매매 완료된 종목 코드
        self._last_forced_date = None      # 자정 리셋용
        self._regime_cache = None          # 시장 레짐(지수 등락률) 캐시 값
        self._regime_cache_ts = None       # 레짐 캐시 갱신 시각(epoch)
        self._setup_logging()

    def _setup_logging(self):
        """일별 파일 로그"""
        os.makedirs(LOG_DIR, exist_ok=True)
        today = _kst_now().strftime('%Y%m%d')
        fh = logging.FileHandler(
            os.path.join(LOG_DIR, f'trader_{today}.log'),
            encoding='utf-8',
        )
        fh.setFormatter(logging.Formatter(
            '%(asctime)s [%(name)s] %(levelname)s: %(message)s',
            datefmt='%H:%M:%S',
        ))
        logging.getLogger().addHandler(fh)

    def _load_daily_strategy(self):
        """data/daily_strategy.json 읽어 오늘 전략 적용"""
        from pathlib import Path
        path = Path(__file__).parent / 'data' / 'daily_strategy.json'
        if not path.exists():
            log.info('[DailyStrategy] 전략 파일 없음 — config 기본값 사용')
            return

        try:
            strat = json.loads(path.read_text(encoding='utf-8'))
            strat_date = strat.get('date', '')
            today = _kst_now().strftime('%Y-%m-%d')

            if strat_date != today:
                log.warning(f'[DailyStrategy] 날짜 불일치 ({strat_date} ≠ {today}) — 기본값 사용')
                return

            # 전역 설정에 반영 (config 모듈 직접 패치)
            import config as _cfg

            new_min_score = strat.get('min_score')
            new_max_pos = strat.get('max_positions')
            new_sl = strat.get('stop_loss_pct')
            new_tp = strat.get('take_profit_pct')

            if new_min_score:
                _cfg.SENTRY_MIN_SCORE = new_min_score
                _cfg.SENTRY_FUTURES_MIN_SCORE = new_min_score
            if new_max_pos:
                _cfg.SENTRY_MAX_POSITIONS = new_max_pos
            if new_sl:
                _cfg.SENTRY_STOP_LOSS_PCT = new_sl
            if new_tp:
                _cfg.SENTRY_TAKE_PROFIT_PCT = new_tp

            bias = strat.get('direction_bias', 'NEUTRAL')
            aggr = strat.get('aggression', 'NORMAL')
            conf = strat.get('confidence', 50)

            log.info(
                f'[DailyStrategy] 전략 적용 — min_score={new_min_score} '
                f'max_pos={new_max_pos} sl={new_sl}% tp={new_tp}% '
                f'bias={bias} aggr={aggr} conf={conf}%'
            )
        except Exception as e:
            log.error(f'[DailyStrategy] 전략 로드 실패: {e}')

    def _sync_positions_from_account(self):
        """시작 시 실계좌 잔고에서 포지션 복원"""
        try:
            from kis import _get, get_access_token
            from config import KIS_ACCOUNT
            get_access_token()
            params = {
                'CANO': KIS_ACCOUNT,
                'ACNT_PRDT_CD': '03',
                'MGNA_DVSN': '01',
                'EXCC_STAT_CD': '1',
                'CTX_AREA_FK200': '',
                'CTX_AREA_NK200': '',
            }
            data = _get('/uapi/domestic-futureoption/v1/trading/inquire-balance', 'CTFO6118R', params)
            held = [x for x in (data.get('output1') or []) if int(x.get('cblc_qty', '0')) > 0]

            from futures_map import get_stock_code
            for item in held:
                fcode = item['shtn_pdno']               # e.g. A57604
                from kis import _decode_kis_name as _dn
                raw_name = _dn(item.get('prdt_name', ''))   # "대한항공   F 202610 (  10)" → "대한항공" (2026-09-23)
                qty = int(item['cblc_qty'])
                # ccld_avg_unpr1 = 체결평균단가 (실제 매입가), excc_unpr = 청산단가(현재가)
                entry = float(item.get('ccld_avg_unpr1', 0)) or float(item.get('excc_unpr', 0))
                # 매도(短) → PUT, 매수(長) → CALL
                dvsn = item.get('sll_buy_dvsn_name', '')
                dvsn = _dn(dvsn)
                side = 'PUT' if '매도' in dvsn or 'sell' in dvsn.lower() else 'CALL'

                # 기초자산 코드 조회 (역매핑)
                base_code = get_stock_code(fcode) or fcode[:6]

                pos = Position(
                    code=base_code, name=raw_name, side=side, qty=qty,
                    entry_price=entry, is_stock_futures=True, algo_id=self.algo_id,
                )
                pos.code = base_code
                self.positions.append(pos)
                log.info(f'[Trader] 계좌 복원: {raw_name} {side} x{qty} @ {entry:,.0f}')

            log.info(f'[Trader] 계좌 동기화 완료: {len(held)}개 포지션 복원')
            self.risk.load_new_codes()
            self._push_status(log_msg=f'계좌 동기화: {len(held)}개 포지션 복원')
        except Exception as e:
            log.error(f'[Trader] 계좌 동기화 오류: {e}')

    def _register_algo(self):
        """알고리즘 등록 (처음 한 번)"""
        try:
            # Supabase REST API 캐시 이슈로 조회 스킵, 고정 algo_id 사용
            self.algo_id = 1  # v1_5boss2soldier (수동 등록됨)
            log.info(f'[Trader] 알고리즘 사용: algo_id={self.algo_id} (v1_5boss2soldier)')
        except Exception as e:
            log.error(f'[Trader] 알고리즘 등록 오류: {e}')

    def _classify_market(self):
        """KOSPI200 지수로 오늘 시장 분류"""
        try:
            kst = _kst_now()
            today = kst.strftime('%Y-%m-%d')
            # 지수코드(U001/0001)는 주식 시세 엔드포인트로 0만 반환 → KODEX200 ETF로 대체
            # (2026-06-19 수리: 레짐 분류용 코스피 프록시)
            info = get_stock_price('069500')  # KODEX200 (KOSPI200 추종 ETF)
            if info and info.get('change_pct') is not None:
                change_pct = float(info['change_pct'])
                regime = 'A' if change_pct > 0.3 else 'B' if change_pct < -0.3 else 'C'
                algo_db.record_regime(today, regime, change_pct, 0, info.get('price', 0))
                log.info(f'[Trader] 시장 분류: {today} = '
                         f'{"A상승" if regime=="A" else "B하락" if regime=="B" else "C횡보"} '
                         f'({change_pct:+.2f}%)')
        except Exception as e:
            log.warning(f'[Trader] 시장 분류 오류: {e}')

    # ─── 주문 실행 ───

    def _calc_max_qty(self, avail: int, price: float,
                      is_futures: bool, is_stock_futures: bool, default_qty: int) -> int:
        """
        잔액 범위 내 최대 주문 가능 수량 계산.
        0 반환 = 1계약도 불가 (주문 중단).
        가격 미조회(price=0)이면 0 반환해서 주문 차단.
        """
        if price <= 0:
            return 0  # 가격 모르면 안전하게 차단
        if is_futures or is_stock_futures:
            # 증거금은 명목의 약 29% (2026-09-22 주문 거부 교훈). 최종 수량은 아래에서
            # 증권사에 다시 물어 확정하므로 여기는 대략치다.
            margin_per = price * 10 * 0.29   # 계약당 증거금 추정
        else:
            margin_per = price               # 현물은 1주당 가격
        if margin_per <= 0:
            return 0
        # max(1,...) 제거 — 잔액이 부족하면 0 반환해서 주문 차단
        return min(default_qty, int(avail / margin_per))

    def _execute_order(self, code, name, side, is_futures=False, is_stock_futures=False, reason='', score=0, qty_override=None, strategy='scalp', hold_days=None, auto_approve=False):
        """
        주문 실행
        side: 'CALL'(매수) or 'PUT'(매도)
        is_futures: 코스피200 선물
        is_stock_futures: 개별 주식 선물
        auto_approve: True면 텔레그램 승인 생략하고 자동 체결(사전검증 리더 한정, 호출부가 한도 보장)
        """
        # ── 1. 현재가 조회 ──────────────────────────────────────────
        chg_pct = 0.0
        try:
            if is_futures:
                price_info = get_futures_price(code)
                price_now = price_info['price'] if price_info else 0
            else:
                price_info = get_stock_price(code)
                price_now = price_info['price'] if price_info else 0
                chg_pct = float((price_info or {}).get('change_pct', 0) or 0)
        except Exception:
            price_now = 0

        # ── 1.5 ★전역 추격방지 가드: 당일 +N% 이상 오른 종목은 매수 금지 ──
        if side == 'CALL':
            import config as _cfg_g
            ext_max = getattr(_cfg_g, 'ENTRY_MAX_DAY_CHG_PCT', 5.0)
            if chg_pct >= ext_max:
                log.info(f'[Trader] 추격방지 가드: {name} 당일 +{chg_pct:.1f}% (>= {ext_max}%) — 매수 보류')
                return None

        # ── 2. 증거금/예수금 조회 → 잔액 범위 내 수량 계산 ────────
        default_qty = qty_override if qty_override else (
            SENTRY_DEFAULT_QTY_FUTURES if is_futures else SENTRY_DEFAULT_QTY_STOCK
        )
        try:
            if is_futures or is_stock_futures:
                bal  = get_futures_balance()
                avail = (bal or {}).get('ord_psbl_cash', 0)
            else:
                bal  = get_balance()
                avail = (bal or {}).get('cash', 0)
        except Exception as e:
            log.warning(f'[Trader] 잔고 조회 실패: {e}')
            avail = 0

        MIN_ORDERABLE = 10_000  # 1만원 미만이면 승인 요청 없이 중단
        if avail < MIN_ORDERABLE:
            log.warning(f'[Trader] 주문가능금액 부족 ({avail:,}원 < {MIN_ORDERABLE:,}원) — {name} 승인 요청 없이 중단')
            return None

        qty = self._calc_max_qty(avail, price_now, is_futures, is_stock_futures, default_qty)
        if qty < 1:
            log.warning(f'[Trader] 잔액 부족 {avail:,}원 — {name} 1계약도 불가, 주문 중단')
            return None

        if qty < default_qty:
            log.info(f'[Trader] 잔액({avail:,}원) 기준 수량 축소: {default_qty}→{qty}계약')

        # KIS 가 계산한 실제 주문가능수량으로 최종 확인 (증거금률·기존 포지션 반영). 0이면 승인 요청 자체를 내지 않는다
        if is_stock_futures:
            try:
                _fc = get_futures_code(code)
                _lim = float(price_now) * (1.02 if side == 'CALL' else 0.98)
                _ord = get_futures_orderable(_fc, 'buy' if side == 'CALL' else 'sell', _lim) if _fc else None
                if _ord is not None:
                    if _ord['qty'] < 1:
                        log.warning(f'[Trader] 증거금 부족: {name} {side} — KIS 주문가능 0계약(주문가능금액 {avail:,}원) → 승인 요청 없이 건너뜀')
                        self._push_status(log_msg=f'증거금 부족: {name} {side} (주문가능 0계약) — 건너뜀')
                        self._last_skip = 'margin'
                        return None
                    if _ord['qty'] < qty:
                        log.info(f'[Trader] KIS 주문가능수량 기준 축소: {qty}→{_ord["qty"]}계약 ({name})')
                        qty = _ord['qty']
            except Exception as _oe:
                log.debug(f'[Trader] 주문가능수량 조회 실패(추정치로 진행): {name} — {_oe}')

        # ── 3. 승인 모드: 텔레그램으로 승인 요청 (auto_approve면 생략) ──
        if auto_approve:
            log.info(f'[Trader] 자동매수(사전검증 리더·승인생략): {name}({code}) {side} {score}점 x{qty}계약 @ {price_now:,.0f}원 (당일 +{chg_pct:.1f}%, 잔액:{avail:,}원)')
        elif APPROVAL_REQUIRED:
            log.info(f'[Trader] 텔레그램 승인 요청: {name}({code}) {side} {score}점 x{qty}계약 @ {price_now:,.0f}원 (잔액:{avail:,}원)')
            approved = telegram_notify.request_approval(
                name=name, code=code, side=side, score=score,
                price=price_now, qty=qty, timeout=180, reason=reason
            )
            if not approved:
                return None

        # 이미 같은 종목 포지션 있으면 스킵
        for pos in self.positions:
            if pos.code == code:
                log.info(f'[Trader] {name} 이미 포지션 보유 중, 스킵')
                return None

        # ── 4. 주문 실행 (qty는 이미 잔액 기준으로 계산됨) ─────────
        buy_side = 'buy' if side == 'CALL' else 'sell'

        try:
            if is_futures:
                result = place_futures_order(code, buy_side, qty, price=0)
                price_info = get_futures_price(code)
                entry_price = price_info['price'] if price_info else price_now
            elif is_stock_futures:
                fcode = get_futures_code(code)
                if not fcode:
                    log.warning(f'[Trader] {name}({code}) 선물코드 없음 — 주문 스킵')
                    return None
                result = place_futures_order(fcode, buy_side, qty, price=0, stock_futures=True)
                price_info = get_stock_price(code)
                entry_price = price_info['price'] if price_info else price_now
            else:
                result = place_order(code, buy_side, qty, price=0)
                price_info = get_stock_price(code)
                entry_price = price_info['price'] if price_info else price_now

            if result:
                pos = Position(
                    code=code, name=name, side=side, qty=qty,
                    entry_price=entry_price,
                    is_futures=is_futures, is_stock_futures=is_stock_futures,
                    algo_id=self.algo_id,
                    strategy=strategy, hold_days=hold_days,
                )
                self.positions.append(pos)
                self.risk.note_new_code(code)
                self.risk.record_trade()
                msg = f'주문 체결: {name} {side} x{qty} @ {entry_price:,.0f}원'
                log.info(f'[Trader] {msg}')
                self._write_trade_event('BUY' if side=='CALL' else 'SELL', name, side, entry_price, qty, reason=reason, score=score)
                self._push_status(log_msg=msg)
                # 텔레그램 매수 알림
                try:
                    # 일봉 트랙(momentum)은 손절 -10%·트레일링이고, 옛 분봉 트랙만 -3%/+5% 다.
                    # 2026-09-23: 알림이 언제나 분봉 값(-3%)을 보내 실제 규칙과 달랐다.
                    import config as _cfg_n
                    if strategy == 'momentum':
                        _stop = float(getattr(_cfg_n, 'DAILY_STRATEGY_STOP_LOSS_PCT', 10.0))
                        _take = None
                    else:
                        _stop, _take = SENTRY_STOP_LOSS_PCT, SENTRY_TAKE_PROFIT_PCT
                    telegram_notify.notify_buy(
                        name, code, side, entry_price, qty,
                        score=score,
                        reason=reason,
                        stop_pct=_stop,
                        take_pct=_take,
                    )
                except Exception as _e:
                    log.debug(f'[Trader] 텔레그램 매수 알림 오류: {_e}')
                return pos
            else:
                log.warning(f'[Trader] 주문 실패: {name} {side}')
                self._push_status(log_msg=f'주문 실패: {name} {side}')
                return None

        except Exception as e:
            log.error(f'[Trader] 주문 오류: {name} {side} — {e}')
            return None

    def _roll_position(self, pos, reason=''):
        """만기 -1영업일: 근월물 청산 + 같은 종목 차근월물 재매수(20영업일 시계·entry_time 유지). 차근월물이 없으면 청산.
        승인: 청산 승인 규칙(만기 = 무응답 자동)을 그대로 따르고, 재매수는 안전장치성 롤오버라 별도 승인 없이 이어서 실행(텔레그램 통지)."""
        from futures_map import get_next_futures_code
        nxt = get_next_futures_code(pos.code)
        if not (pos.is_stock_futures and nxt):
            return self._close_position(pos, reason.replace('롤오버', '롤오버(차근월물 없음→청산)'))
        entry_time = pos.entry_time
        hold_days = pos.hold_days
        highest, lowest = pos.highest_price, pos.lowest_price
        ok = self._close_position(pos, reason)
        if not ok:
            return False
        try:
            side = 'buy' if pos.side == 'CALL' else 'sell'
            sp = get_stock_price(pos.code)
            px = sp['price'] if sp else pos.entry_price
            res = place_futures_order(nxt, side, pos.qty, price=0, stock_futures=True)
            if not res:
                log.warning(f'[Trader] 롤오버 재매수 실패: {pos.name} → {nxt} (포지션 종료 상태로 둠)')
                return False
            newpos = Position(pos.code, pos.name, pos.side, pos.qty, px, is_futures=False, is_stock_futures=True,
                              signal_id=None, algo_id=pos.algo_id, strategy='momentum', hold_days=hold_days)
            newpos.entry_time = entry_time          # 20영업일 시계 유지
            newpos.highest_price, newpos.lowest_price = max(highest, px), min(lowest, px)
            # 롤오버한 만기(둘째 목요일)를 기록 — 같은 만기로 두 번 롤오버하지 않게 (check_exit 와 같은 기준)
            import calendar as _cal2, datetime as _dt3
            _t = _kst_now().date()
            _th = [w[3] for w in _cal2.monthcalendar(_t.year, _t.month) if w[3] > 0]
            _e = _dt3.date(_t.year, _t.month, _th[1]) if len(_th) >= 2 else None
            if _e and _t > _e - _dt3.timedelta(days=1):
                _ny, _nm = (_t.year + 1, 1) if _t.month == 12 else (_t.year, _t.month + 1)
                _th2 = [w[3] for w in _cal2.monthcalendar(_ny, _nm) if w[3] > 0]
                _e = _dt3.date(_ny, _nm, _th2[1]) if len(_th2) >= 2 else None
            newpos._rolled_for = (_e.year, _e.month) if _e else None
            self.positions.append(newpos)
            msg = (f'🔁 {pos.name} — 다음 달 계약으로 갈아탔습니다 @ {px:,.0f}원 '
                   f'(판 것이 아니라 그대로 이어갑니다)')
            log.info(f'[Trader] {msg}'); self._push_status(log_msg=msg)
            try: telegram_notify.get_bot().send_message(f'🔁 {msg}')
            except Exception: pass
            self._write_trade_event('ROLL', pos.name, pos.side, px, pos.qty, reason=f'만기 롤오버 → {nxt}')
            return True
        except Exception as e:
            log.error(f'[Trader] 롤오버 오류: {pos.name} — {e}')
            return False

    def _close_position(self, pos, reason=''):
        """포지션 청산"""
        # 2026-09-20 PO: 청산도 텔레그램 승인. 손절은 응답 없으면 자동(안전), 익절·트레일링은 보류 후 재요청
        try:
            import config as _cfg
            # PO 2026-09-22 결정 7: 종목별 누적 손실 -10% 는 묻지 않고 자동 청산 (파국손절도 동일). 승인 요청은 시간청산·익절·롤오버에만
            if any(k in str(reason) for k in ('손절', '트레일링')) and getattr(_cfg, 'EXIT_STOPLOSS_AUTO', True):
                log.warning(f'[Trader] 손절 자동 청산(승인 생략, PO 규칙): {pos.name} [{reason}]')
                try:
                    telegram_notify.get_bot().send_message(f'🛑 {pos.name} {reason} — 규칙에 따라 자동 청산합니다.')
                except Exception:
                    pass
            elif getattr(_cfg, 'EXIT_APPROVAL_REQUIRED', False) and not getattr(pos, '_exit_forced', False):
                import time as _t
                last_ask = getattr(pos, '_exit_ask_ts', 0)
                if _t.time() - last_ask < getattr(_cfg, 'EXIT_REASK_SEC', 600):
                    return  # 최근 거절/보류 — 재요청 간격 전
                pos._exit_ask_ts = _t.time()
                cur = getattr(pos, 'current_price', 0) or pos.entry_price
                pnl_pct = ((cur - pos.entry_price) / pos.entry_price * 100) if pos.side == 'CALL' else ((pos.entry_price - cur) / pos.entry_price * 100)
                ans = telegram_notify.request_exit_approval(
                    name=pos.name, code=pos.code, side=pos.side, qty=pos.qty, price=cur,
                    pnl_pct=pnl_pct, reason=reason, timeout=getattr(_cfg, 'EXIT_APPROVAL_TIMEOUT', 120))
                if ans == 'reject':
                    if '사람이 지금 정리' in str(reason):
                        # 직접 지시해 놓고 아니오를 누른 것 = 그 지시를 취소한 것. 다시 묻지 않는다
                        pos._exit_ask_ts = 0
                        log.info(f'[Trader] 정리 지시 취소(사용자): {pos.name} — 다시 묻지 않습니다')
                        try:
                            telegram_notify.get_bot().send_message(
                                f'{pos.name} 은 그대로 둡니다. 규칙대로 계속 지켜봅니다.')
                        except Exception:
                            pass
                        return
                    log.info(f'[Trader] 청산 보류(사용자): {pos.name} [{reason}] — {getattr(_cfg, "EXIT_REASK_SEC", 600)}초 후 재요청')
                    return
                if ans is None:
                    # 무응답 시 자동 청산 = 안전장치성 청산만: 손절·파국손절·만기롤오버(만기를 넘기면 안 됨). 시간청산·익절은 보류 후 재요청 (2026-09-22 Codex·Grok 심사 반영)
                    if any(k in str(reason) for k in ('손절', '만기', '트레일링')) and getattr(_cfg, 'EXIT_STOPLOSS_AUTO_ON_TIMEOUT', True):
                        _why = ('만기를 넘길 수 없어' if '만기' in str(reason) else '손실을 더 키우지 않으려고')
                        log.warning(f'[Trader] 승인 응답 없음 → 자동 처리: {pos.name} [{reason}]')
                        try:
                            telegram_notify.get_bot().send_message(
                                f'⏰ 답이 없어 {_why} {pos.name} 을 먼저 정리했습니다.')
                        except Exception:
                            pass
                    else:
                        log.info(f'[Trader] 청산 승인 응답 없음 → 보류: {pos.name} [{reason}]')
                        return
        except Exception as _e:
            log.error(f'[Trader] 청산 승인 처리 오류(자동 청산으로 진행): {_e}')

        # 반대 방향 주문
        close_side = 'sell' if pos.side == 'CALL' else 'buy'

        try:
            if pos.is_futures:
                result = place_futures_order(pos.code, close_side, pos.qty, price=0)
                price_info = get_futures_price(pos.code)
                exit_price = price_info['price'] if price_info else pos.entry_price
            elif pos.is_stock_futures:
                fcode = get_futures_code(pos.code)
                if not fcode:
                    log.warning(f'[Trader] {pos.name}({pos.code}) 선물코드 없음 — 청산 스킵')
                    return
                result = place_futures_order(fcode, close_side, pos.qty,
                                             price=0, stock_futures=True)
                stock_price = get_stock_price(pos.code[:6])
                exit_price = stock_price['price'] if stock_price else pos.entry_price
            else:
                result = place_order(pos.code, close_side, pos.qty, price=0)
                stock_price = get_stock_price(pos.code)
                exit_price = stock_price['price'] if stock_price else pos.entry_price

            pnl_pct = pos.pnl_pct(exit_price)

            if result:
                pnl_krw = int((exit_price - pos.entry_price) * 10 * pos.qty *
                              (1 if pos.side == 'CALL' else -1))
                msg = f'청산: {pos.name} {pos.side} @ {exit_price:,.0f}원 ({pnl_pct:+.2f}%) [{reason}]'
                log.info(f'[Trader] {msg}')
                # 실현손익을 일일 손실 한도(MAX_DAILY_LOSS)에 반영 — 2026-09-22 심사에서 발견: 이전엔 진입 때 0원만 기록돼 한도가 한 번도 작동하지 않았음
                # 2026-09-23: daily_pnl 만 직접 더하고 daily_trades 는 안 늘려서 하루 매매 횟수가 진입만 세고 있었다.
                # 같은 값을 두 경로로 고치지 않도록 record_trade() 하나로 모은다.
                try:
                    self.risk.record_trade(pnl_krw)
                except Exception:
                    pass
                self._write_trade_event('CLOSE', pos.name, pos.side, exit_price, pos.qty, reason=reason)
                if pos.signal_id:
                    elapsed = (_kst_now() - pos.entry_time).total_seconds() / 60
                    offset = '5m' if elapsed <= 7 else '10m' if elapsed <= 15 else '30m'
                    rdb.fill_outcome(pos.signal_id, offset, exit_price)

                self.positions.remove(pos)
                self._push_status(log_msg=msg)
                # 텔레그램 청산 알림
                try:
                    telegram_notify.notify_sell(
                        pos.name, pos.code, pos.side,
                        pos.entry_price, exit_price,
                        pos.qty, pnl_krw, pnl_pct,
                        reason=telegram_notify._plain(reason),
                    )
                except Exception as _e:
                    log.debug(f'[Trader] 텔레그램 청산 알림 오류: {_e}')
                return True
            else:
                log.warning(f'[Trader] 청산 실패: {pos.name}')
                self._push_status(log_msg=f'청산 실패: {pos.name}')
                return False

        except Exception as e:
            log.error(f'[Trader] 청산 오류: {pos.name} — {e}')
            return False

    # ─── 포지션 모니터링 ───

    def _monitor_positions(self):
        """모든 포지션 손절/익절/트레일링 체크"""
        import time as _t; self._last_monitor_ts = _t.time()
        # 주식선물 현재가 일괄 조회 (get_futures_balance 활용)
        sf_prices = {}
        if any(p.is_stock_futures for p in self.positions):
            try:
                bal = get_futures_balance()
                for p in bal.get('positions', []):
                    if p.get('current', 0) > 0:
                        sf_prices[p['code']] = p['current']
            except Exception as e:
                log.warning(f'[Trader] 주식선물 현재가 조회 실패: {e}')

        for pos in list(self.positions):
            try:
                if pos.is_stock_futures:
                    # 주식선물: 기초자산 현물가를 Naver에서 실시간 조회 (잔고API 청산단가는 지연)
                    try:
                        _, current, _ = get_stock_info_naver(pos.code)
                    except Exception:
                        fcode = get_futures_code(pos.code) or pos.code
                        current = sf_prices.get(fcode, sf_prices.get(pos.code, 0))
                elif pos.is_futures:
                    price_info = get_futures_price(pos.code)
                    current = price_info['price'] if price_info else 0
                else:
                    stock_info = get_stock_price(pos.code)
                    current = stock_info['price'] if stock_info else 0

                if current <= 0:
                    log.debug(f'[Trader] 현재가 미조회: {pos.name} ({pos.code})')
                    continue

                pos.update_price(current)
                should_exit, reason = pos.check_exit(current)

                if should_exit:
                    if '만기롤오버' in str(reason):
                        self._roll_position(pos, reason)
                    else:
                        self._close_position(pos, reason)

            except Exception as e:
                log.error(f'[Trader] 모니터링 오류: {pos.name} — {e}')

    def _force_close_all(self):
        """장 마감 전 전포지션 강제 청산 + 일일 요약"""
        if not self.positions:
            return
        log.info(f'[Trader] 강제 청산 시작 ({len(self.positions)}건)')
        for pos in list(self.positions):
            pos._exit_forced = True
            self._close_position(pos, '장마감 강제청산')
        # 로컬 일일 요약
        try:
            today = _kst_now().strftime('%Y-%m-%d')
            algo_db.compute_daily_summary(today)
        except Exception as e:
            log.error(f'[Trader] 로컬 일일요약 오류: {e}')

    # ─── 스캔 & 신호 처리 ───

    def _watchlist_loop(self):
        """
        관심종목 정밀 타점 감시 — 5-Layer Precision Scoring (algo_precision)
        S등급(90+): 기본 수량 100%
        A등급(80+): 기본 수량 80%
        B등급(70+): 기본 수량 60%
        """
        try:
            import algo_precision as _prec
        except ImportError:
            # 선택 기능 — 모듈이 없으면 이 감시만 쉬고 본 루프는 그대로 돈다
            log.info('[Watchlist] algo_precision 모듈 없음 — 관심종목 정밀 감시는 건너뜁니다')
            return

        _signal_sent = {}  # 'code_side' -> last timestamp (쿨다운)
        COOLDOWN = 600     # 10분

        log.info('[Watchlist] Precision-5Layer 감시 루프 시작')
        while True:
            try:
                if not self.clock.is_market_open():
                    time.sleep(60)
                    continue

                wl_path = os.path.join(os.path.dirname(__file__), 'config_data', 'watchlist.json')
                with open(wl_path, encoding='utf-8') as f:
                    import json as _json
                    stocks = _json.load(f).get('watchlist', [])

                for item in stocks:
                    code = item['code']
                    name = item['name']
                    try:
                        result = _prec.check_precision_entry(code, name, min_grade='B')
                        if result is None:
                            time.sleep(1.0)
                            continue

                        side  = result['side']
                        score = result['score']
                        grade = result['grade']
                        price = result['price']
                        L     = result['layers']

                        # 쿨다운 체크
                        sig_key = f'{code}_{side}'
                        if time.time() - _signal_sent.get(sig_key, 0) < COOLDOWN:
                            time.sleep(1.0)
                            continue

                        # 포지션 중복 체크
                        already = any(
                            p.code == code or p.code == (get_futures_code(code) or '')
                            for p in self.positions
                        )
                        if already:
                            time.sleep(1.0)
                            continue

                        # 등급별 수량 비율
                        qty_ratio = {'S': 1.0, 'A': 0.8, 'B': 0.6}.get(grade, 0.6)
                        default_q = SENTRY_DEFAULT_QTY_STOCK
                        qty_override = max(1, int(default_q * qty_ratio))

                        _signal_sent[sig_key] = time.time()
                        log.info(
                            f'[Watchlist] ★★ {name}({code}) {side} {grade}등급 {score}점 '
                            f'@ {price:,.0f}원  수량:{qty_override}  '
                            f'[A:{L["A"]} B:{L["B"]} C:{L["C"]} D:{L["D"]} E:{L["E"]}]'
                        )
                        self._execute_order(
                            code, name, side,
                            is_futures=False, is_stock_futures=True,
                            reason=f'Precision {grade}등급',
                            score=score,
                            qty_override=qty_override,
                        )

                    except Exception as e:
                        log.debug(f'[Watchlist] {code} 오류: {e}')
                    time.sleep(1.5)  # 종목 간 간격 (KIS 7page 조회 시간 고려)

            except Exception as e:
                log.error(f'[Watchlist] 루프 오류: {e}')

            time.sleep(180)  # 3분 대기

    def _trigger_scan(self):
        """scanner_web에 새 스캔 요청. 이미 진행중이거나 쿨다운 중이면 무시."""
        try:
            r = _requests.post(SCANNER_SCAN_URL, timeout=5)
            if r.status_code == 200:
                log.info('[Trader] 스캔 트리거 완료')
            elif r.status_code == 409:
                pass  # already running — 정상
            elif r.status_code == 429:
                pass  # 쿨다운 중 — 다음 사이클에서 재시도
        except Exception as e:
            log.warning(f'[Trader] 스캔 트리거 실패: {e}')

    def _poll_scan_until(self, total_wait, tick=5):
        """① 즉시 처리: total_wait초 동안 tick초 간격으로 스캐너를 감시.
        새 스캔이 완료되는 즉시 stage2 결과를 처리하고 다음 스캔을 트리거한 뒤 반환한다.
        (기존엔 사이클당 1회만 확인하고 180초를 통째로 대기 → 완료된 신호가 최대 180초 묵었음.)
        결과가 없으면 total_wait까지 대기 후 반환(다음 메인 사이클로)."""
        waited = 0
        last_trigger = -999
        while waited < total_wait:
            nap = min(tick, total_wait - waited)
            time.sleep(nap)
            waited += nap
            try:
                d = _requests.get(SCANNER_URL, timeout=5).json()
            except Exception as e:
                log.warning(f'[Trader] 스캐너 접속 실패: {e}')
                continue
            if d.get('running'):
                continue  # 스캔 진행중 — 완료 대기
            finished_at = d.get('finished_at')
            if not finished_at or finished_at == self._last_scan_ts:
                # 완료된 새 결과 없음 → 새 스캔 트리거 (쿨다운 중이면 429로 무시됨).
                # 30초마다만 시도해 429 폴링 소음을 줄임.
                if waited - last_trigger >= 30:
                    self._trigger_scan()
                    last_trigger = waited
                continue
            # ── 새 스캔 완료! 즉시 처리 ──
            self._last_scan_ts = finished_at
            s2 = len(d.get('stage2', []))
            log.info(f'[Trader] (즉시) 스캐너 결과 수신: stage2={s2}개 / 대기 {waited}초 경과')
            self._process_scan_results(d)
            self._trigger_scan()  # 다음 스캔 즉시 트리거
            return

    def _process_scan_results(self, scan_result):
        """스캔 결과 → 주문 실행 + 연구 DB 기록"""
        if not scan_result:
            return

        # 1) 코스피200 선물
        futures = scan_result.get('futures')
        if futures:
            self._process_futures_signal(futures)

        # 2) 개별 주식 (2단계 통과)
        stage2 = scan_result.get('stage2', [])
        # 종합 신호: 일봉 후보 ∩ 분봉 타이밍 → 하나의 승인 요청 (PO 2026-09-22)
        try:
            import config as _cfg_c
            if getattr(_cfg_c, 'COMBINED_SIGNAL_ENABLED', False):
                self._combined_timing_scan(stage2)
        except Exception as _ce:
            log.error(f'[Trader] 종합 신호 타이밍 스캔 오류: {_ce}', exc_info=True)
        for item in stage2:
            # 옛 분봉 매수 경로(5대장2졸병) — PO 2026-09-23: 엣지 없음, 승인 요청 올리지 않는다
            if getattr(_cfg_c, 'MINUTE_SCAN_ENABLED', True):
                self._process_stock_signal(item)
            # 사용자 전략(strategies/*.json, live:true) 경로 — config STRATEGY_LIVE_ENABLED 가 켜졌을 때만 (2026-09-20, 기본 꺼짐)
            try:
                import config as _cfg_s
                if getattr(_cfg_s, 'STRATEGY_LIVE_ENABLED', False) and item.get('strategies'):
                    self._process_strategy_signals(item)
            except Exception as _se:
                log.error(f'[Trader] 전략 경로 오류: {item.get("name")} — {_se}')

    def _process_futures_signal(self, f):
        """KOSPI200 선물 신호 — 신호 기록만, 주문 없음
        (지수선물은 TTTO1101U 아닌 별도 엔드포인트 필요, 현재 미지원)"""
        code = f.get('code', KOSPI200_FUTURES_CODE)

        if f['call_score'] >= SENTRY_FUTURES_MIN_SCORE:
            self._record_signal(
                code, f['name'], 'CALL',
                f['call_score'], f['call_boss'], f['call_soldier'],
                f.get('call_signal', {}).get('values', {}),
                f['price']
            )
            log.info(f'[Trader] KOSPI200 CALL {f["call_score"]}점 — 신호 기록 (주문 미지원)')

        if f['put_score'] >= SENTRY_FUTURES_MIN_SCORE:
            self._record_signal(
                code, f['name'], 'PUT',
                f['put_score'], f['put_boss'], f['put_soldier'],
                f.get('put_signal', {}).get('values', {}),
                f['price']
            )
            log.info(f'[Trader] KOSPI200 PUT {f["put_score"]}점 — 신호 기록 (주문 미지원)')

    def _revalidate_signal(self, code, name, sig_type, min_score):
        """진입 직전 신선한 분봉으로 신호 재판정 (뒷북 무효화 게이트).
        같은 방향이 아직 min_score 이상이면 (True, 현재점수), 아니면 (False, 현재점수).
        스캔 시점과 주문 시점 사이 지연 동안 신호가 깨졌으면 주문을 폐기한다."""
        try:
            import pandas as pd
            bars = get_minute_bars_naver(code)  # 스캔과 동일 소스, 지금 시점 분봉
            if not bars or len(bars) < 50:
                log.warning(f'[Trader] 재검증: {name} 봉 데이터 부족 ({len(bars) if bars else 0}개) — 폐기')
                return False, 0
            df = pd.DataFrame(bars)
            both = analyze_both(self.engine, df)
            fresh = both[sig_type.lower()]['score']
            return (fresh >= min_score), fresh
        except Exception as e:
            log.error(f'[Trader] 재검증 오류: {name} — {e} — 폐기')
            return False, 0

    def _get_market_regime(self):
        """KOSPI 프록시(KODEX200)의 당일 등락률(%)을 캐시와 함께 반환. 실패 시 None."""
        import config as _cfg
        cache_sec = getattr(_cfg, 'REGIME_CACHE_SEC', 60)
        now = time.time()
        if (self._regime_cache_ts is not None
                and (now - self._regime_cache_ts) < cache_sec
                and self._regime_cache is not None):
            return self._regime_cache
        chg = None
        try:
            ticker = getattr(_cfg, 'REGIME_PROXY_TICKER', '069500')
            info = get_stock_price(ticker)
            if info:
                chg = float(info.get('change_pct', 0))
        except Exception as e:
            log.debug(f'[Trader] 레짐 지수 조회 실패: {e}')
            chg = None
        if chg is not None:
            self._regime_cache = chg
            self._regime_cache_ts = now
        return chg

    def _check_regime_gate(self, sig_type, score):
        """시장 레짐 게이트 (2026-06-19 재설계 — 단순 원칙):
        상승장에서만 롱(CALL) 매수. 하락장이면 떨어지는 칼날 안 잡는다(매수 금지).
        KOSPI 프록시(KODEX200) 당일 등락률이 기준 미만이면 CALL 폐기.
        반환: (통과 여부, 사유 메시지).
        """
        import config as _cfg
        if not getattr(_cfg, 'REGIME_FILTER_ENABLED', True):
            return True, ''
        if sig_type != 'CALL':
            return True, ''
        chg = self._get_market_regime()
        if chg is None:
            return True, ''  # 지수 조회 실패 시 게이트 미적용
        floor = getattr(_cfg, 'REGIME_BUY_FLOOR_PCT', -0.3)
        if chg < floor:
            return False, f'하락장 매수금지 (KOSPI {chg:+.2f}% < {floor}% → 롱 진입 안 함)'
        return True, ''

    def _process_stock_signal(self, item):
        """개별 주식 신호 처리 (현물 차트 → 현물 주식 매매, 모의투자 호환)"""
        code = item['code']
        name = item['name']
        sig_type = item['type']      # 'CALL' or 'PUT'
        score = item['score']
        price = item.get('price', 0)

        # 텔레그램 override 반영
        effective_min_score = telegram_notify.get_override('min_score', SENTRY_MIN_SCORE)
        aggr_override = telegram_notify.get_override('aggression')
        if aggr_override == 'AGGRESSIVE':
            effective_min_score = max(55, effective_min_score - 5)
        elif aggr_override == 'CONSERVATIVE':
            effective_min_score = min(80, effective_min_score + 5)

        # PUT(숏) 비활성 — 2026-06-18 연구결론: PUT 신호 12k건 평균 -2.5%, 순손실원. 숏 금지.
        import config as _cfg_p
        if sig_type == 'PUT' and not getattr(_cfg_p, 'PUT_ENABLED', True):
            log.debug(f'[Trader] PUT 비활성: {name} 숏 신호 스킵 (연구결론)')
            return

        # 방향 편향 필터
        bias_override = telegram_notify.get_override('direction_bias')
        if bias_override and bias_override != 'NEUTRAL' and sig_type != bias_override:
            log.debug(f'[Trader] 방향 편향 필터: {sig_type} ≠ {bias_override} — 스킵')
            return

        if score < effective_min_score:
            return

        # 시간대 필터: 주식선물 장 시간 전체 허용 (08:45~15:45 — PO 2026-09-21: "주식선물은 8시 45분부터")
        now_time = _kst_now().time()
        import datetime as _dt
        if not (SENTRY_MARKET_OPEN <= now_time <= SENTRY_MARKET_CLOSE):
            log.debug(f'[Trader] 시간대 필터: {now_time} 장 시간 외 제외')
            return

        # 가격 필터: 주당 50만원 이상 종목 거래 제외
        if price >= 500000:
            log.info(f'[Trader] 가격 필터 제외: {name} {price:,}원 (50만원 이상)')
            return

        # 연구 DB 기록 (점수 상관없이 30점 이상은 기록)
        signal_id = self._record_signal(
            code, name, sig_type, score,
            item.get('boss', 0), item.get('soldier', 0),
            item.get('values', {}),
            item.get('price', 0)
        )

        # 종합 신호 모드(PO 2026-09-22): 분봉 5대장2졸병 단독으로는 승인 요청을 내지 않는다.
        # 일봉 후보 종목의 타이밍은 _combined_timing_scan 이 맡고, 후보 밖 종목은 위 _record_signal 로 기록만 남긴다.
        if getattr(_cfg_p, 'COMBINED_SIGNAL_ENABLED', False):
            if code in (getattr(self, '_combined_candidates', None) or {}):
                log.debug(f'[Trader] 종합 신호: {name} {sig_type} {score}점 — 후보 종목, 타이밍 스캔이 처리')
            else:
                log.debug(f'[Trader] 종합 신호: {name} {sig_type} {score}점 — 일봉 후보 아님, 기록만')
            return

        # 주문 실행 (50점 이상 — 주식선물 CALL=매수/PUT=매도)
        if score >= SENTRY_MIN_SCORE and self.risk.can_trade(self.positions):
            # ── 1단계: 상위 타임프레임(월/주/일봉) 추세 선별 (2026-06-18) ──
            # 분봉 6대장은 '타이밍'일 뿐. 월/주/일봉이 상승 추세인 종목만 CALL 매수한다.
            import config as _cfg_h
            if getattr(_cfg_h, 'HTF_FILTER_ENABLED', True) and sig_type == 'CALL':
                try:
                    import htf_filter
                    htf = htf_filter.evaluate(code)
                except Exception as _he:
                    log.debug(f'[Trader] HTF 평가 오류: {name} — {_he} (게이트 미적용)')
                    htf = {'ok': True}
                if not htf.get('ok'):
                    log.info(f'[Trader] HTF 선별 폐기: {name} CALL — 상위추세 미확인 '
                             f'({htf.get("grade","?")} {htf.get("score","?")}점 [{htf.get("detail","")}])')
                    self._push_status(log_msg=f'HTF 선별: {name} CALL 추세약함')
                    return
            # ── 시장 레짐 필터: 급등장 CALL 추격매수 억제 (2026-06-12 교훈) ──
            regime_ok, regime_msg = self._check_regime_gate(sig_type, score)
            if not regime_ok:
                log.info(f'[Trader] 레짐 필터 폐기: {name} {sig_type} {score}점 — {regime_msg}')
                self._push_status(log_msg=f'레짐 필터: {name} {sig_type} ({regime_msg})')
                return
            # ── 진입 직전 신호 재검증 (뒷북 무효화 게이트) ──
            ok, fresh_score = self._revalidate_signal(code, name, sig_type, effective_min_score)
            if not ok:
                log.info(f'[Trader] 재검증 폐기: {name} {sig_type} 스캔{score}점 → 현재{fresh_score}점 '
                         f'(<{effective_min_score}점) — 뒷북 신호 무효, 주문 안 함')
                self._push_status(log_msg=f'재검증 폐기: {name} {sig_type} (뒷북 무효)')
                return
            if fresh_score != score:
                log.info(f'[Trader] 재검증 통과: {name} {sig_type} 스캔{score}점 → 현재{fresh_score}점')
            score = fresh_score  # 최신 점수로 주문/기록
            boss = item.get('boss', 0)
            soldier = item.get('soldier', 0)
            reason_msg = (f'신호: {name} {sig_type} (대장{boss}/5 졸병{soldier}/2) '
                          f'→ 주식선물 {"매수" if sig_type=="CALL" else "매도"} 진입')
            log.info(f'[Trader] {reason_msg}')
            self._push_status(log_msg=reason_msg)
            pos = self._execute_order(code, name, sig_type, is_stock_futures=True, reason=reason_msg, score=score)
            if pos:
                pos.signal_id = signal_id

    def _process_strategy_signals(self, item):
        """사용자 전략 경로: 2단계 결과의 strategies[] 중 passed && live 인 전략만 주문 후보로.
        샘플(5대장2졸병)은 기존 _process_stock_signal 경로가 맡는다. 기존 게이트(PUT 금지·시간대·가격·HTF·레짐·재검증·리스크·승인)는 전부 그대로 통과해야 한다."""
        try:
            import strategy_engine as _se
        except Exception as e:
            log.error(f'[Trader] strategy_engine 로드 실패: {e}')
            return
        code = item['code']; name = item['name']; price = item.get('price', 0)
        import config as _cfg_p
        import datetime as _dt
        hits = [st for st in (item.get('strategies') or []) if st.get('passed') and st.get('live') and st.get('id') != _se.SAMPLE_ID]
        if not hits:
            return
        # 이미 같은 종목 포지션이 있으면 중복 진입 금지 (샘플 경로가 먼저 잡았을 수도 있음)
        _room, _held, _cap = self._qty_room(code)
        if _room <= 0:
            log.debug(f'[Trader] 전략 경로: {name} 이미 {_held}/{_cap}계약 — 스킵')
            return
        _okc, _whyc = self.risk.can_open_code(code, self.positions)
        if not _okc:
            log.debug(f'[Trader] 전략 경로: {name} — {_whyc}')
            return
        now_time = _kst_now().time()
        if not (SENTRY_MARKET_OPEN <= now_time <= SENTRY_MARKET_CLOSE):
            return
        if price >= 500000:
            return
        for st in hits:
            sig_type = st.get('direction', 'CALL')
            sid = st.get('id')
            if sig_type == 'PUT' and not getattr(_cfg_p, 'PUT_ENABLED', True):
                log.debug(f'[Trader] 전략 {sid}: PUT 비활성 — 스킵'); continue
            if not self.risk.can_trade(self.positions):
                return
            if getattr(_cfg_p, 'HTF_FILTER_ENABLED', True) and sig_type == 'CALL':
                try:
                    import htf_filter
                    htf = htf_filter.evaluate(code)
                except Exception:
                    htf = {'ok': True}
                if not htf.get('ok'):
                    log.info(f'[Trader] 전략 {sid} HTF 폐기: {name}'); self._push_status(log_msg=f'전략 {sid} HTF 폐기: {name}'); continue
            regime_ok, regime_msg = self._check_regime_gate(sig_type, st.get('score', 0))
            if not regime_ok:
                log.info(f'[Trader] 전략 {sid} 레짐 폐기: {name} — {regime_msg}'); continue
            # 진입 직전 재검증: 그 전략 규칙으로 최신 분봉을 다시 평가
            try:
                import pandas as pd
                bars = get_minute_bars_naver(code)
                if not bars or len(bars) < 50:
                    log.warning(f'[Trader] 전략 {sid} 재검증: {name} 봉 부족 — 폐기'); continue
                fresh = next((r for r in _se.evaluate_all(pd.DataFrame(bars), self.engine) if r['id'] == sid), None)
            except Exception as e:
                log.error(f'[Trader] 전략 {sid} 재검증 오류: {name} — {e} — 폐기'); continue
            if not fresh or not fresh.get('passed'):
                log.info(f'[Trader] 전략 {sid} 재검증 폐기: {name} (현재 {fresh.get("score") if fresh else "?"}점, 미통과)')
                self._push_status(log_msg=f'전략 {sid} 재검증 폐기: {name}'); continue
            score = fresh['score']
            signal_id = self._record_signal(code, name, sig_type, score, fresh.get('boss', 0), fresh.get('soldier', 0), {'strategy': sid}, price)
            reason_msg = f"전략 '{sid}' 신호: {name} {sig_type} {score}점 (대장{fresh.get('boss',0)} 졸병{fresh.get('soldier',0)}) → {'매수' if sig_type=='CALL' else '매도'} 진입"
            log.info(f'[Trader] {reason_msg}')
            self._push_status(log_msg=reason_msg)
            pos = self._execute_order(code, name, sig_type, is_stock_futures=True, reason=reason_msg, score=score, strategy=sid)
            if pos:
                pos.signal_id = signal_id
                return  # 종목당 한 번

    def _record_signal(self, code, name, sig_type, score, boss, soldier, values, price):
        """연구 DB에 신호 기록 (Supabase + 로컬 SQLite)"""
        signal_id = None
        try:
            signal_id = rdb.record_signal(
                algo_id=self.algo_id,
                ticker=code,
                ticker_name=name,
                signal_type=sig_type,
                score=score,
                boss_count=boss,
                soldier_count=soldier,
                indicator_values=values,
                price_at_signal=price,
            )
        except Exception as e:
            log.error(f'[Trader] Supabase 신호 기록 오류: {e}')

        # 로컬 SQLite 기록 + 팔로우업 큐 등록
        try:
            local_id = algo_db.record_signal(
                stock_code=code,
                stock_name=name,
                signal_type=sig_type,
                score=score,
                boss_count=boss,
                soldier_count=soldier,
                entry_price=price,
                factors_dict=values if isinstance(values, dict) else {},
            )
            if local_id:
                now = datetime.now()
                self._followup_queue.append({
                    'local_id':   local_id,
                    'stock_code': code,
                    'signal_type': sig_type,
                    'entry_price': price,
                    'time_5m':    now + timedelta(minutes=5),
                    'time_10m':   now + timedelta(minutes=10),
                    'time_30m':   now + timedelta(minutes=30),
                    'done_5m':    False,
                    'done_10m':   False,
                    'done_30m':   False,
                })
        except Exception as e:
            log.error(f'[Trader] 로컬 신호 기록 오류: {e}')

        return signal_id

    def _check_followups(self):
        """팔로우업 큐: 5분/10분/30분 후 가격 조회해서 결과 기록"""
        now = datetime.now()
        for fq in self._followup_queue:
            try:
                if not fq['done_5m'] and now >= fq['time_5m']:
                    price_info = get_stock_price(fq['stock_code'])
                    if price_info:
                        algo_db.record_outcome(
                            fq['local_id'], 5, price_info['price'],
                            fq['entry_price'], fq['signal_type']
                        )
                    fq['done_5m'] = True
                if not fq['done_10m'] and now >= fq['time_10m']:
                    price_info = get_stock_price(fq['stock_code'])
                    if price_info:
                        algo_db.record_outcome(
                            fq['local_id'], 10, price_info['price'],
                            fq['entry_price'], fq['signal_type']
                        )
                    fq['done_10m'] = True
                if not fq['done_30m'] and now >= fq['time_30m']:
                    price_info = get_stock_price(fq['stock_code'])
                    if price_info:
                        algo_db.record_outcome(
                            fq['local_id'], 30, price_info['price'],
                            fq['entry_price'], fq['signal_type']
                        )
                    fq['done_30m'] = True
            except Exception as e:
                log.warning(f'[Trader] followup 오류: {e}')
        # 완료된 것 제거
        self._followup_queue = [
            fq for fq in self._followup_queue
            if not (fq['done_5m'] and fq['done_10m'] and fq['done_30m'])
        ]

    # ─── 강제 일일 매매 ───

    def _check_forced_daily_trades(self):
        """rules.json forced_daily_trades: 매일 지정 종목 주식선물 강제 매매
        contracts = 최대 보유 계약수 한도 (한 번에 1계약씩, 한도 내에서만 진입)"""
        # 날짜 변경 시 강제매매 완료 목록 초기화
        today = _kst_now().strftime('%Y-%m-%d')
        if self._last_forced_date != today:
            self._forced_traded_today = set()
            self._last_forced_date = today

        try:
            rules_path = os.path.join(os.path.dirname(__file__), 'config_data', 'rules.json')
            with open(rules_path, encoding='utf-8') as f:
                rules = json.load(f)
        except Exception as e:
            log.warning(f'[Trader] rules.json 로드 실패: {e}')
            return

        for code, rule in rules.get('forced_daily_trades', {}).items():
            if not rule.get('enabled', True):
                continue

            max_contracts = rule.get('contracts', 1)  # 최대 보유 계약수 한도
            min_score = rule.get('min_score', 50)
            name = rule.get('name', code)
            fcode = rule.get('futures_code') or get_futures_code(code)

            if not fcode:
                log.warning(f'[Trader] 강제매매: {name}({code}) 선물코드 없음')
                continue

            # 현재 보유 계약수 합산
            held = sum(p.qty for p in self.positions if p.code == code)

            if held >= max_contracts:
                log.debug(f'[Trader] 강제매매 스킵: {name} 이미 {held}/{max_contracts}계약 보유')
                continue

            if code in self._forced_traded_today:
                log.debug(f'[Trader] 강제매매 스킵: {name} 오늘 이미 진입 완료')
                continue

            if not self.risk.can_trade(self.positions):
                log.info(f'[Trader] 강제매매: {name} 리스크 한도 초과 — 스킵')
                continue

            # 분석: 1분봉 가져와서 신호 방향 결정
            try:
                import pandas as pd
                bars = get_minute_bars_naver(code)  # 3거래일치 700봉 — 장 초반도 지표 계산 가능
                if not bars or len(bars) < 50:
                    log.warning(f'[Trader] 강제매매: {name} 봉 데이터 부족 ({len(bars) if bars else 0}개)')
                    continue

                df = pd.DataFrame(bars)
                both = analyze_both(self.engine, df)
                call = both['call']
                put = both['put']

                # 더 점수 높은 방향으로 진입 (min_score 미달 시 스킵)
                if call['score'] >= put['score'] and call['score'] >= min_score:
                    sig_type = 'CALL'
                    score = call['score']
                elif put['score'] > call['score'] and put['score'] >= min_score:
                    sig_type = 'PUT'
                    score = put['score']
                else:
                    log.info(f'[Trader] 강제매매: {name} 신호 점수 미달 '
                             f'(CALL {call["score"]} / PUT {put["score"]} < {min_score}점) — 스킵')
                    continue

                reason_msg = (f'강제일일매매: {name} {sig_type} '
                              f'(보유{held}/{max_contracts}계약 한도, 1계약 진입)')
                log.info(f'[Trader] {reason_msg}')
                self._push_status(log_msg=reason_msg)

                pos = self._execute_order(
                    code, name, sig_type,
                    is_stock_futures=True,
                    reason=reason_msg,
                    score=score,
                    qty_override=1,  # 항상 1계약씩 진입
                )
                # 성공/실패 관계없이 오늘 한 번만 시도
                self._forced_traded_today.add(code)

            except Exception as e:
                log.error(f'[Trader] 강제매매 분석 오류: {name} — {e}')

    # ─── 장기 모멘텀 스윙 스캔 (2026-06-22 백테스트 검증, momentum_strategy.py) ───

    def _momentum_daily_scan(self, kst):
        """하루 1회: 검증된 장기 모멘텀 후보를 선정해 진입(승인 거쳐). 시간기반 N일 보유.
        레짐 약세면 후보 0 → 진입 안 함(약세장 회피). 분봉 스캘핑과 별개 트랙."""
        import config as _cfg
        if kst.time() < SENTRY_MARKET_OPEN:   # 주식선물 개장 08:45 부터 (PO 2026-09-21)
            return
        today = kst.strftime('%Y-%m-%d')
        if getattr(self, '_momentum_last_date', None) == today:
            return  # 오늘 이미 스캔함
        self._momentum_last_date = today
        try:
            import momentum_strategy as _mom
            universe = self._scan_universe()
            top_n = getattr(_cfg, 'MOMENTUM_TOP_N', 5)
            hold_days = getattr(_cfg, 'MOMENTUM_HOLD_DAYS', 60)
            _mom.MOMENTUM_MIN = getattr(_cfg, 'MOMENTUM_MIN_PCT', 0.10)
            _mom.HOLD_DAYS = hold_days
            cands = _mom.get_candidates(universe, top_n=top_n)
            if not cands:
                log.info('[Trader] 모멘텀 스캔: 후보 없음(약세장 회피 또는 조건 미충족)')
                return
            log.info(f'[Trader] 모멘텀 스캔: {len(cands)}종목 후보 → 진입 시도')
            for c in cands:
                # 이미 보유 종목 스킵
                if any(p.code == c['code'] for p in self.positions):
                    continue
                if not self.risk.can_trade(self.positions):
                    log.info('[Trader] 모멘텀: 리스크 한도 도달 — 추가 진입 중단')
                    break
                if c['price'] >= 500000:
                    log.info(f"[Trader] 모멘텀: {c['name']} 가격필터 제외({c['price']:,.0f}원)")
                    continue
                reason = f"[모멘텀] {c['reason']}"
                log.info(f'[Trader] 모멘텀 진입 시도: {c["name"]} (모멘텀 {c["momentum"]}%)')
                # 주식선물 매수 — 이 봇은 주식선물 계좌(03) 운용. 자금도 선물계좌에 있음.
                # 주식선물은 월물 만기(둘째 목요일)라, 모멘텀 보유는 만기 전 청산 + 다음월물 재진입(롤오버)으로 처리.
                self._execute_order(
                    c['code'], c['name'], 'CALL', is_stock_futures=True,
                    reason=reason, score=int(min(100, 60 + c['momentum'] / 5)),
                    strategy='momentum', hold_days=hold_days,
                )
        except Exception as e:
            log.error(f'[Trader] 모멘텀 스캔 오류: {e}')

    # ─── 일봉 전략 트랙 (2026-09-21 — daily_strategy_engine.py, strategies/*.json timeframe "1d") ───
    # 과매도 반등(oversold_strategy 하드코딩판)을 JSON 전략 규격으로 일반화. 현재 live 전략: 3대장4졸병.

    def _daily_strategy_scan(self, kst):
        """하루 1회(08:45 개장 첫 스캔): strategies/*.json 중 timeframe 1d · enabled · live 전략을 일봉 엔진으로 평가해
        후보를 우선순위대로 텔레그램 승인 요청 → 승인 시 주식선물 매수(Position 'momentum' 트랙: 시간 청산·파국 -15%·만기 롤오버).
        신호는 전일 확정 일봉 기준(x_entry.at=next_open). 보유 중 종목 재진입 금지, 리스크 한도·가격 상한 준수.
        보유일·최대 포지션은 운영 전략(config_data/operating_strategy.json)이 전략 파일 값보다 우선한다."""
        import config as _cfg
        # 스캔 시각: 주식선물 개장 08:45 (PO 2026-09-21). config 값이 '8:45' 문자열이면 분 단위, 정수면 시 단위(하위호환)
        _sc = getattr(_cfg, 'DAILY_STRATEGY_SCAN_TIME', None) or SENTRY_MARKET_OPEN
        if kst.time() < _sc:
            return
        today = kst.strftime('%Y-%m-%d')
        if getattr(self, '_daily_strategy_last_date', None) == today:
            return
        self._daily_strategy_last_date = today
        try:
            import daily_strategy_engine as _dse
            # enabled 전략은 전부 평가(스캐너 카드·로그에 오늘 후보 표시), 승인 요청은 live 전략만
            strategies = _dse.enabled_strategies()
            if not strategies:
                log.info('[Trader] 일봉 전략: 켜진 전략 없음 (strategies/*.json timeframe 1d · enabled)')
                return
            hold_days = int(getattr(_cfg, 'DAILY_STRATEGY_HOLD_DAYS', getattr(_cfg, 'OVERSOLD_HOLD_DAYS', 20)))
            max_price = int(getattr(_cfg, 'ENTRY_MAX_PRICE', 500000))
            universe = self._scan_universe()
            log.info(f'[Trader] 일봉 전략 스캔 시작: {", ".join(s["name"] + ("" if s.get("live") else "(신호만)") for s in strategies)} / 유니버스 {len(universe)}종목')
            res = _dse.evaluate_universe(universe, strategies, hold_days=hold_days)
            for line in _dse.format_table(res).splitlines():
                log.info(f'[Trader] {line}')
            total = sum(len(v) for v in res['candidates'].values())
            if not total:
                log.info('[Trader] 일봉 전략: 오늘 후보 없음')
                self._push_status(log_msg='일봉 전략: 오늘 후보 없음')
                return
            # ── 종합 신호 모드 (PO 2026-09-22): 일봉 후보는 '종목'만 확정하고, 승인 요청은 분봉 타이밍이 뜰 때 낸다 ──
            if getattr(_cfg, 'COMBINED_SIGNAL_ENABLED', False):
                self._combined_candidates = {}
                self._combined_done = {}
                self._combined_date = today
                for spec in strategies:
                    if not spec.get('live'):
                        continue
                    for c in res['candidates'].get(spec['id'], []):
                        if c['code'] in self._combined_candidates:
                            continue
                        self._combined_candidates[c['code']] = dict(c, spec=spec, hold_days=hold_days)
                prev = self._combined_load(today)
                if prev and prev.get('done'):
                    # 08:45 이후 재시작: 이미 요청·진입·포기한 종목은 다시 요청하지 않는다
                    self._combined_done = {k: v for k, v in prev['done'].items() if k in self._combined_candidates}
                    log.info(f'[Trader] 종합 신호: 오늘 처리 상태 복원 {self._combined_done}')
                self._combined_save()
                _FAMK = {'반등형': '반등형', '추세형': '추세형'}
                names = ('\n').join(
                    f"· {c['name']} {int(c['score'])}점 — {(c['spec'].get('family') or '')}"
                    + (' CALL(매수)' if c['spec'].get('direction', 'CALL') == 'CALL' else ' PUT(매도)')
                    for c in self._combined_candidates.values())
                ws, we = getattr(_cfg, 'TIMING_WINDOW_START', None), getattr(_cfg, 'TIMING_WINDOW_END', None)
                msg = (f"📋 <b>오늘 살펴볼 후보 {len(self._combined_candidates)}개</b>\n"
                       f"<code>────────────────</code>\n{names}\n"
                       f"<code>────────────────</code>\n"
                       f"이 종목들만 {ws.strftime('%H:%M') if ws else '08:45'}~{we.strftime('%H:%M') if we else '12:00'} 동안 지켜보다가, 살 시점이 오면 물어봅니다.\n"
                       f"<i>시간 안에 시점이 안 오면 오늘은 그냥 넘어갑니다</i>")
                log.info(f'[Trader] {msg}')
                self._push_status(log_msg=msg)
                if not prev:
                    try:
                        telegram_notify.notify(msg)
                    except Exception:
                        pass
                return
            for spec in strategies:
                cands = res['candidates'].get(spec['id'], [])
                if not cands:
                    continue
                if not spec.get('live'):
                    log.info(f'[Trader] [{spec["name"]}] 후보 {len(cands)}건 — 신호만(live:false), 승인 요청 없음')
                    continue
                log.info(f'[Trader] [{spec["name"]}] 후보 {len(cands)}건 → 승인 요청')
                # R5-7 (2026-09-22 심사 반영): 같은 날 일봉 트랙 신규 진입은 최대 N건(기본 1) — 폭락일 후보 몰림·동시 파국손실 방지
                max_new = int(getattr(_cfg, 'DAILY_STRATEGY_MAX_NEW_PER_DAY', 1))
                new_today = 0
                for c in cands:
                    if new_today >= max_new:
                        log.info(f'[Trader] [{spec["name"]}] 오늘 신규 {max_new}건 한도 도달 — 나머지 후보는 기록만')
                        break
                    _room, _held, _cap = self._qty_room(c['code'])
                    if _room <= 0:
                        log.info(f"[Trader] [{spec['name']}] {c['name']} 이미 {_held}/{_cap}계약 — 더 안 삼")
                        continue
                    if not self.risk.can_trade(self.positions):
                        log.info(f'[Trader] [{spec["name"]}] 리스크 한도 도달 — 추가 진입 중단')
                        break
                    _okc, _whyc = self.risk.can_open_code(c['code'], self.positions)
                    if not _okc:
                        log.info(f"[Trader] [{spec['name']}] {c['name']} — {_whyc}")
                        continue
                    if c['price'] >= max_price:
                        log.info(f"[Trader] [{spec['name']}] {c['name']} 가격 상한 제외({c['price']:,.0f}원 >= {max_price:,}원)")
                        continue
                    # R3-1 (v1.1 #1): 현재가가 시가 대비 +3% 를 넘었으면 추격하지 않고 그날 포기
                    try:
                        q = get_stock_price(c['code'])
                        if q and q.get('open') and q.get('price') and q['price'] > q['open'] * 1.03:
                            log.info(f"[Trader] [{spec['name']}] {c['name']} 시가 대비 +{(q['price']/q['open']-1)*100:.1f}% — 추격 안 함(당일 포기)")
                            continue
                    except Exception:
                        pass
                    before = len(self.positions)
                    self._execute_order(
                        c['code'], c['name'], spec.get('direction', 'CALL'), is_stock_futures=True,
                        reason=f"[{spec['name']}] {c['reason']}", score=int(c['score']),
                        strategy='momentum', hold_days=hold_days,
                    )
                    if len(self.positions) > before:
                        new_today += 1
        except Exception as e:
            log.error(f'[Trader] 일봉 전략 스캔 오류: {e}')

    def _maybe_monitor(self, min_gap=25):
        """마지막으로 보유 종목을 본 지 min_gap 초가 지났으면 한 번 더 본다.
        후보가 늘어 한 바퀴가 길어져도 손절/이익 확정이 그만큼 늦어지지 않게 하는 장치."""
        import time as _t
        now = _t.time()
        last = getattr(self, '_last_monitor_ts', 0)
        if now - last < min_gap:
            return
        self._last_monitor_ts = now
        try:
            self._monitor_positions()
        except Exception as e:
            log.debug(f'[Trader] 중간 보유 점검 실패: {e}')

    def _qty_room(self, code):
        """이 종목에 몇 계약 더 살 수 있나. (PO 2026-09-23: 한 번에 1계약씩, 한 종목 최대 3계약까지)
        반환 (더 살 수 있는 계약수, 지금 보유 계약수, 한도)"""
        import config as _c
        cap = int(getattr(_c, 'MAX_QTY_PER_STOCK', 1))
        fcode = get_futures_code(code) or ''
        held = sum(int(getattr(p, 'qty', 0) or 0) for p in self.positions
                   if getattr(p, 'code', None) in (code, fcode))
        return max(0, cap - held), held, cap

    def _combined_timing_scan(self, stage2):
        """종합 신호 2층(타이밍): 오늘 일봉 후보(_combined_candidates) 각각에 대해 분봉 타이밍을 확인하고,
        뜨면 그때 한 번만 승인 요청 → 승인 시 일봉 트랙(momentum: 20거래일 시가 청산·파국 -15%·롤오버)으로 진입.
        타이밍 규칙(config TIMING_RULES): 3m_golden_5_20 = 3분봉 5/20 골든크로스(검증 +0.7%p) · boss_soldier_1m = 1분봉 5대장2졸병 65점.
        창(09:00~12:00) 밖이면 대기/포기. 후보당 하루 1회만 요청(거절·무응답 = 당일 취소). 일일 신규 한도·리스크·가격상한·+3% 추격 금지 적용."""
        import config as _cfg
        cands = getattr(self, '_combined_candidates', None) or {}
        if not cands:
            return
        kst = _kst_now()
        today = kst.strftime('%Y-%m-%d')
        if getattr(self, '_combined_date', None) != today:
            return
        now_t = kst.time()
        ws = getattr(_cfg, 'TIMING_WINDOW_START', None) or SENTRY_MARKET_OPEN
        we = getattr(_cfg, 'TIMING_WINDOW_END', None) or SENTRY_MARKET_CLOSE
        done = getattr(self, '_combined_done', None)
        if done is None:
            done = self._combined_done = {}
        pending = [c for code, c in cands.items() if code not in done]
        if not pending:
            return
        if now_t < ws:
            return
        if now_t >= we:
            for c in pending:
                done[c['code']] = 'no_timing'
                log.info(f"[Trader] 종합 신호: {c['name']} — {we.strftime('%H:%M')}까지 타이밍 없음, 당일 포기")
            self._push_status(log_msg=f'종합 신호: 타이밍 창 종료 — {len(pending)}건 당일 포기')
            return
        rules = list(getattr(_cfg, 'TIMING_RULES', ['3m_golden_5_20']))
        lookback = int(getattr(_cfg, 'TIMING_CROSS_LOOKBACK_BARS', 2))
        max_new = int(getattr(_cfg, 'DAILY_STRATEGY_MAX_NEW_PER_DAY', 1))
        max_price = int(getattr(_cfg, 'ENTRY_MAX_PRICE', 500000))
        new_today = sum(1 for v in done.values() if v == 'entered')
        s2 = {it['code']: it for it in (stage2 or []) if it.get('code')}
        day8 = kst.strftime('%Y%m%d')
        live_rows = []
        try:
            for c in pending:
                self._maybe_monitor()      # 후보가 많아도 손절 확인이 밀리지 않게
                code, name = c['code'], c['name']
                direction = c['spec'].get('direction', 'CALL')
                no_more = new_today >= max_new   # 한도 도달: 표시용 판정만 하고 요청은 안 냄
                _room, _held, _cap = self._qty_room(code)
                if _room <= 0:
                    done[code] = 'held'
                    log.debug(f'[Trader] 종합 신호: {name} 이미 {_held}/{_cap}계약 — 더 안 삼')
                    continue
                hit = None; info = {}
                import timing_signal as _ts
                try:
                    q0 = get_stock_price(code) or {}
                except Exception:
                    q0 = {}
                # 1단계 사전 선별(시세만, 분봉 조회 전): 방향 불일치·추격 구간이면 분봉을 받지 않는다.
                # (2026-09-23 후보 5→23건으로 늘자 종목마다 분봉을 받느라 한 바퀴가 6분 걸렸다 — 통과 종목만 받는다)
                if getattr(_cfg, 'TIMING_STAGE1_ENABLED', True):
                    _op = float(q0.get('open') or 0); _px = float(q0.get('price') or 0)
                    _why0 = None
                    if not _op or not _px:
                        _why0 = '시가 없음'
                    else:
                        _chg = _px / _op - 1
                        if direction == 'CALL' and _chg < 0:
                            _why0 = f'시가 아래({_chg*100:+.1f}%)'
                        elif direction == 'PUT' and _chg > 0:
                            _why0 = f'시가 위({_chg*100:+.1f}%)'
                        elif abs(_chg) > 0.03:
                            _why0 = f'시가 대비 {_chg*100:+.1f}% 추격 금지'
                    if _why0:
                        live_rows.append({'code': code, 'name': name, 'family': c['spec'].get('family', ''), 'direction': direction,
                                          'score': int(c['score']), 'price': _px, 'open': _op,
                                          'stage1': {'ok': False, 'why': _why0}, 'types': {}, 'hit': None,
                                          'src': '시세만', 'bars_today': 0})
                        log.debug(f'[Trader] 종합 신호 1단계 탈락(시세): {name} {direction} — {_why0}')
                        continue
                # 분봉 = 어제까지 네이버(KRX) + 오늘 KIS 통합(KRX+NXT, 08:00 프리마켓부터). KIS 가 비면 오늘도 네이버(09:01~)
                bars = []
                try:
                    _nv = get_minute_bars_naver(code) or []
                except Exception as e:
                    log.debug(f'[Trader] 종합 신호 네이버 분봉 실패: {name} — {e}'); _nv = []
                try:
                    _un = get_minute_bars_union(code) or []
                except Exception as e:
                    log.debug(f'[Trader] 종합 신호 KIS 통합 분봉 실패: {name} — {e}'); _un = []
                if _un:
                    bars = [b for b in _nv if not str(b.get('ts', '')).startswith(day8)] + _un
                    live_src = 'KIS통합'
                else:
                    bars = _nv; live_src = '네이버'
                # 1단계 빠른 선별 (PO 2026-09-22): 오늘 방향이 규칙과 같고 추격 구간이 아닌 후보만 2단계로
                live_row = {'code': code, 'name': name, 'family': c['spec'].get('family', ''), 'direction': direction, 'score': int(c['score']),
                            'price': float(q0.get('price') or 0), 'open': float(q0.get('open') or 0), 'stage1': None, 'types': {}, 'hit': None, 'src': live_src, 'bars_today': sum(1 for b in bars if str(b.get('ts', '')).startswith(day8))}
                live_rows.append(live_row)
                if getattr(_cfg, 'TIMING_STAGE1_ENABLED', True):
                    ok1, why1 = _ts.stage1_screen(bars, day8, direction=direction, quote=q0)
                    live_row['stage1'] = {'ok': bool(ok1), 'why': why1}
                    if not ok1:
                        log.debug(f'[Trader] 종합 신호 1단계 탈락: {name} {direction} — {why1}')
                        continue
                else:
                    live_row['stage1'] = {'ok': True, 'why': '선별 끔'}
                # 2단계 정밀조사 — 타입별로 따로 판정(복합 금지). 네 타입 전부 기록하고, 먼저 맞는 타입 하나로 요청
                tres = {}
                if '3m_golden_5_20' in rules:      # A타입
                    try:
                        okA, infoA = _ts.golden_cross_5_20(bars, day8, direction=direction, lookback=lookback, now_hhmm=kst.strftime('%H%M'))
                    except Exception as e:
                        okA, infoA = False, {'reason': str(e)[:60]}
                    tres['A'] = {'ok': bool(okA), 'info': {k: v for k, v in (infoA or {}).items() if k != 'rule'}}
                if 'open_breakout' in rules:       # B타입
                    okB, infoB = _ts.type_B_open_breakout(q0, direction=direction, min_pct=float(getattr(_cfg, 'TIMING_B_MIN_PCT', 1.0)))
                    tres['B'] = {'ok': bool(okB), 'info': {k: v for k, v in (infoB or {}).items() if k != 'rule'}}
                if 'boss_soldier_1m' in rules:     # C타입
                    it = s2.get(code)
                    okC = bool(it and it.get('type') == direction and int(it.get('score', 0)) >= max(65, SENTRY_MIN_SCORE))
                    tres['C'] = {'ok': okC, 'info': ({'score': it.get('score'), 'boss': it.get('boss'), 'soldier': it.get('soldier')} if it else {'reason': '스캐너 신호 없음'})}
                if 'vwap_volume' in rules:         # D타입
                    okD, infoD = _ts.type_D_vwap_volume(bars, day8, direction=direction, surge=float(getattr(_cfg, 'TIMING_D_VOL_SURGE', 1.5)))
                    tres['D'] = {'ok': bool(okD), 'info': {k: v for k, v in (infoD or {}).items() if k != 'rule'}}
                live_row['types'] = tres
                for _k, _rid in (('A', '3m_golden_5_20'), ('B', 'open_breakout'), ('C', 'boss_soldier_1m'), ('D', 'vwap_volume')):
                    if tres.get(_k, {}).get('ok'):
                        hit = f'{_k}:{_rid}'; info = tres[_k]['info']; break
                live_row['hit'] = hit
                if not hit:
                    continue
                if no_more:
                    log.debug(f'[Trader] 종합 신호: 오늘 신규 {max_new}건 한도 — {name} 타이밍({hit}) 있으나 요청 안 냄')
                    continue
                # 타이밍 확인됨 → 운영 게이트 후 승인 요청 (하루 1회)
                if not self.risk.can_trade(self.positions):
                    log.info(f'[Trader] 종합 신호: {name} 타이밍({hit}) 확인됐으나 리스크 한도 도달 — 진입 중단')
                    done[code] = 'risk'; self._combined_save()
                    return
                _okc, _whyc = self.risk.can_open_code(code, self.positions)
                if not _okc:
                    log.info(f'[Trader] 종합 신호: {name} 타이밍({hit}) 확인됐으나 {_whyc}')
                    done[code] = 'risk'; self._combined_save()
                    continue
                try:
                    q = get_stock_price(code) or {}
                except Exception:
                    q = {}
                price_now = float(q.get('price') or 0)
                if not price_now or not q.get('open'):
                    # 현재가 조회 실패 → 상한·추격 게이트를 우회하지 않는다. 요청 안 하고 다음 스캔에 다시 본다 (Codex 심사)
                    log.warning(f'[Trader] 종합 신호: {name} 현재가 조회 실패 — 이번 스캔 보류')
                    continue
                done[code] = 'requested'; self._combined_save(); self._last_skip = None
                if price_now and price_now >= max_price:
                    log.info(f'[Trader] 종합 신호: {name} 가격 상한 제외({price_now:,.0f}원 >= {max_price:,}원)')
                    done[code] = 'price_cap'
                    continue
                _chg = price_now / float(q['open']) - 1 if q.get('open') and price_now else 0.0
                if (direction == 'CALL' and _chg > 0.03) or (direction == 'PUT' and _chg < -0.03):
                    log.info(f"[Trader] 종합 신호: {name} {direction} 시가 대비 {_chg*100:+.1f}% — 추격 안 함(당일 포기)")
                    done[code] = 'chase'
                    continue
                _DK = {'cross_at': '교차', 'ma5': '5분선', 'ma20': '20분선', 'score': '점수', 'boss': '필수', 'soldier': '보조',
                       'chg_pct': '어제 대비 %', 'vwap': '평균 매매가', 'vol_ratio': '거래량 배수'}
                detail = ', '.join(f'{_DK[k]} {v}' for k, v in info.items() if k in _DK)
                _tag = '⚠ 아직 실전 성적이 쌓이지 않은 규칙입니다\n' if (c['spec'].get('family') == '추세형' or direction == 'PUT') else ''
                _fam = (c['spec'].get('family') or '') + (' CALL(매수)' if direction == 'CALL' else ' PUT(매도)')
                _TYPE_KR = {'A': '3분봉에서 5개 평균선이 20개 평균선을 위로 뚫음', 'B': '장 초반 강세 — 시작가·어제 마감가 위',
                            'D': '오늘 평균 매매가 위 + 거래량 늘어남'}
                _tk = str(hit).split(':')[0]
                reason = (f"{_tag}{_fam} · {int(c['score'])}점\n"
                          f"{c.get('reason', '')}\n"
                          f"살 시점 {_tk}: {_TYPE_KR.get(_tk, str(hit))}" + (f" ({detail})" if detail else '') + f" · {kst.strftime('%H:%M')}")
                log.info(f'[Trader] 종합 신호 → 승인 요청: {name} {direction} — {reason}')
                self._push_status(log_msg=f'종합 신호: {name} {direction} 타이밍 {hit} → 승인 요청')
                try:
                    self._record_signal(code, name, direction, int(c['score']), 3, 1, {'combined': hit, **{k: v for k, v in info.items() if k != 'reason'}}, price_now)
                except Exception:
                    pass
                before = len(self.positions)
                self._execute_order(code, name, direction, is_stock_futures=True, reason=reason, score=int(c['score']),
                                    strategy='momentum', hold_days=c['hold_days'])
                if len(self.positions) > before:
                    done[code] = 'entered'
                    new_today += 1
                elif getattr(self, '_last_skip', None) == 'margin':
                    done[code] = 'margin'
                    self._last_skip = None
                    log.info(f'[Trader] 종합 신호: {name} 증거금 부족으로 주문 불가 — 당일 제외')
                else:
                    done[code] = 'declined'
                    log.info(f'[Trader] 종합 신호: {name} 승인 거절/무응답 — 당일 취소')
                self._combined_save()

        finally:
            self._combined_live_save(live_rows, kst, ws, we)

    _COMBINED_LIVE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'combined_live.json')

    def _combined_live_save(self, rows, kst, ws, we):
        """스캐너 화면용: 오늘 후보별 1단계·타입 A~D 판정을 매 스캔 남긴다 (PO 2026-09-22 '내일 가동할 스캐너를 미리 수정')."""
        try:
            done = getattr(self, '_combined_done', None) or {}
            cands = getattr(self, '_combined_candidates', None) or {}
            seen = {r['code'] for r in rows}
            for code, c in cands.items():
                if code not in seen:
                    rows.append({'code': code, 'name': c['name'], 'family': c['spec'].get('family', ''), 'direction': c['spec'].get('direction', 'CALL'),
                                 'score': int(c['score']), 'price': float(c.get('price') or 0), 'open': 0, 'stage1': None, 'types': {}, 'hit': None})
            for r in rows:
                r['status'] = done.get(r['code'], '대기')
            state = {'date': kst.strftime('%Y-%m-%d'), 'at': kst.strftime('%H:%M:%S'),
                     'window': f"{ws.strftime('%H:%M')}~{we.strftime('%H:%M')}", 'in_window': ws <= kst.time() < we,
                     'types': {'A': '3분봉에서 5개 평균선이 20개 평균선을 위로 뚫음',
                               'B': '장 초반 강세 — 시가·어제 마감가 둘 다 위',
                               'D': '오늘 평균 매매가 위 + 거래량 1.5배'},
                     'rows': rows}
            with open(self._COMBINED_LIVE, 'w', encoding='utf-8') as f:
                json.dump(state, f, ensure_ascii=False, indent=1, default=str)
        except Exception as e:
            log.debug(f'[Trader] combined_live 저장 실패: {e}')

    _COMBINED_STATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'combined_state.json')

    def _combined_save(self):
        """오늘 후보·처리 상태를 파일에 남긴다 — 08:45 이후 재시작해도 후보 유실·중복 승인 요청이 없도록 (Codex 심사 2026-09-22)."""
        try:
            cands = {}
            for k, v in (getattr(self, '_combined_candidates', None) or {}).items():
                d = {kk: vv for kk, vv in v.items() if kk != 'spec'}
                d.update(spec_id=v['spec'].get('id'), spec_name=v['spec'].get('name'), direction=v['spec'].get('direction', 'CALL'))
                cands[k] = d
            state = {'date': getattr(self, '_combined_date', None), 'candidates': cands, 'done': getattr(self, '_combined_done', None) or {}}
            os.makedirs(os.path.dirname(self._COMBINED_STATE), exist_ok=True)
            with open(self._COMBINED_STATE, 'w', encoding='utf-8') as f:
                json.dump(state, f, ensure_ascii=False, indent=1, default=str)
        except Exception as e:
            log.debug(f'[Trader] 종합 신호 상태 저장 실패: {e}')

    def _combined_load(self, today):
        """오늘 날짜의 저장 상태를 읽는다(없으면 None)."""
        try:
            with open(self._COMBINED_STATE, encoding='utf-8') as f:
                st = json.load(f)
            return st if st.get('date') == today else None
        except Exception:
            return None

    _oversold_daily_scan = _daily_strategy_scan   # 하위호환 이름

    def _scan_universe(self):
        """모멘텀·돌파 스캔 유니버스. config SCAN_FUTURES_UNIVERSE면 주식선물 가능 전체(~250종목),
        아니면 watchlist.json(소수 대형주). 사용자 요구: 손으로 고르지 말고 선물 되는 전체 스캔."""
        import config as _cfg
        if getattr(_cfg, 'SCAN_FUTURES_UNIVERSE', False):
            try:
                import futures_map
                uni = futures_map.get_futures_universe()
                if uni:
                    return uni
                log.warning('[Trader] 선물 유니버스 비어있음 — watchlist 폴백')
            except Exception as e:
                log.warning(f'[Trader] 선물 유니버스 로드 실패, watchlist 폴백: {e}')
        import json as _json, os as _os
        wl_path = _os.path.join(_os.path.dirname(__file__), 'config_data', 'watchlist.json')
        with open(wl_path, encoding='utf-8') as f:
            return _json.load(f).get('watchlist', [])

    def _auto_buy_allowed(self, today):
        """하루 자동매수 건수 한도(폭주 방지) 체크. today=날짜문자열."""
        import config as _cfg
        cap = getattr(_cfg, 'AUTO_BUY_DAILY_MAX', 2)
        if getattr(self, '_auto_buy_date', None) != today:
            self._auto_buy_date = today
            self._auto_buy_count = 0
        return getattr(self, '_auto_buy_count', 0) < cap

    def _breakout_scan(self, kst):
        """장전 NXT 돌파매수: 장전(STAGE_HOUR~)에 추세 리더 워치리스트 고정,
        09:00~ 매 루프 실시간 돌파(전일고가+거래량 급증) 감시 → 매수(승인 필수). 6대장 우회.
        청산은 일반 손절/익절/트레일링(시간기반 아님)."""
        import config as _cfg
        stage_hour = getattr(_cfg, 'BREAKOUT_STAGE_HOUR', 8)
        if kst.hour < stage_hour:
            return
        today = kst.strftime('%Y-%m-%d')
        try:
            import breakout_strategy as _bo
            _bo.BREAKOUT_MIN_PCT = getattr(_cfg, 'BREAKOUT_MIN_PCT', 2.0)
            _bo.BREAKOUT_VOL_SURGE = getattr(_cfg, 'BREAKOUT_VOL_SURGE', 1.5)
            _bo.BREAKOUT_RET60_MIN = getattr(_cfg, 'BREAKOUT_RET60_MIN', 10.0)
            _bo.BREAKOUT_MAX_PRICE = getattr(_cfg, 'BREAKOUT_MAX_PRICE', 500000)
            _bo.BREAKOUT_ENTRY_BUFFER = getattr(_cfg, 'BREAKOUT_ENTRY_BUFFER', 0.02)
            _bo.OPENING_WINDOW_MIN = getattr(_cfg, 'OPENING_WINDOW_MIN', 30)
            _bo.OPENING_MIN_CHG_PCT = getattr(_cfg, 'OPENING_MIN_CHG_PCT', 0.5)
            _bo.OPENING_MAX_CHG_PCT = getattr(_cfg, 'ENTRY_MAX_DAY_CHG_PCT', 5.0)
            top_n = getattr(_cfg, 'BREAKOUT_TOP_N', 5)
            # 장전 워치리스트 하루 1회 고정
            if getattr(self, '_breakout_staged_date', None) != today:
                universe = self._scan_universe()
                self._breakout_staged = _bo.stage_premarket(universe, top_n=top_n)
                self._breakout_staged_date = today
                self._breakout_done = set()
            staged = getattr(self, '_breakout_staged', {})
            if not staged or kst.hour < 9:
                return  # 장전엔 워치리스트만 준비, 09:00부터 실거래 감시
            already = getattr(self, '_breakout_done', set())
            held = {p.code for p in self.positions}
            excl = already | held
            # 장초반 조기진입(러너 +5% 전에 일찍) + 전일고가 돌파, 둘 다 수집(중복 제거)
            triggers = []
            seen_t = set()
            cand_lists = []
            if getattr(_cfg, 'OPENING_ENTRY_ENABLED', False):
                cand_lists.append(_bo.scan_opening(staged, already=excl))
            cand_lists.append(_bo.scan_breakouts(staged, already=excl))
            for lst in cand_lists:
                for c in lst:
                    if c['code'] in seen_t:
                        continue
                    seen_t.add(c['code'])
                    triggers.append(c)
            # 자동매수 설정 (사전검증 리더 = 돌파 워치리스트 → 승인 생략, 소액 한도)
            auto = getattr(_cfg, 'AUTO_BUY_VETTED', False)
            auto_max = getattr(_cfg, 'AUTO_BUY_MAX_CONTRACTS', 1)
            for c in triggers:
                if not self.risk.can_trade(self.positions):
                    log.info('[Trader] 돌파: 리스크 한도 — 추가 진입 중단')
                    break
                use_auto = auto and self._auto_buy_allowed(today)
                self._breakout_done.add(c['code'])  # 중복 진입/요청 방지(오늘 1회)
                log.info(f'[Trader] 돌파 진입 시도: {c["name"]} ({c["reason"]}) [{"자동매수" if use_auto else "승인"}]')
                pos = self._execute_order(
                    c['code'], c['name'], 'CALL', is_stock_futures=True,
                    reason=c['reason'], score=c['score'], strategy='breakout',
                    qty_override=(auto_max if use_auto else None),
                    auto_approve=use_auto,
                )
                if pos and use_auto:
                    self._auto_buy_count = getattr(self, '_auto_buy_count', 0) + 1
        except Exception as e:
            log.error(f'[Trader] 돌파 스캔 오류: {e}')

    # ─── 메인 루프 ───

    def _day_start_summary(self, kst):
        """오늘 매매 시작 승인에 붙는 요약 — 쉬운 말, 줄 바꿈 (PO 2026-09-22)"""
        import config as _c
        lines = [f'{kst.strftime("%Y년 %m월 %d일")} · ' + ('실제 계좌' if not KIS_PAPER_MODE else '모의투자')]
        try:
            bal = get_futures_balance()
            if bal:
                lines.append(f'쓸 수 있는 돈 {bal.get("ord_psbl_cash", 0):,}원 · 가지고 있는 종목 {len(bal.get("positions", []))}개')
        except Exception:
            pass
        lines.append('')
        lines.append('<b>오늘 지킬 한도</b>')
        lines.append(f'· 하루 손실이 {MAX_DAILY_LOSS:,}원(투자금의 10%)을 넘으면 더 사지 않음')
        lines.append(f'· 하루에 새로 사는 종목은 {getattr(_c, "MAX_NEW_STOCKS_PER_DAY", 2)}개까지 · 한 번에 {getattr(_c, "SENTRY_DEFAULT_QTY_STOCK", 1)}계약씩, 한 종목 최대 {getattr(_c, "MAX_QTY_PER_STOCK", 1)}계약까지')
        lines.append(f'· 동시에 가지고 있을 수 있는 종목은 {SENTRY_MAX_POSITIONS}개까지')
        lines.append(f'· 종목별 주식 가격이 {getattr(_c, "ENTRY_MAX_PRICE", 0):,}원 이하인 종목만')
        lines.append('')
        lines.append('<b>어떻게 고르나</b>')
        try:
            _ws = getattr(_c, 'TIMING_WINDOW_START', None); _we = getattr(_c, 'TIMING_WINDOW_END', None)
            _win = f'{_ws.strftime("%H:%M")}~{_we.strftime("%H:%M")}' if _ws and _we else '08:45~12:00'
            if getattr(_c, 'COMBINED_SIGNAL_ENABLED', False):
                lines.append('· 어제까지 시세로 오늘 후보를 먼저 뽑습니다 (반등형 CALL · 추세형 CALL · 반등형 PUT)')
                lines.append(f'· 그 종목만 {_win} 동안 지켜보다가 살 시점이 오면 물어봅니다')
                lines.append('· 시간 안에 시점이 안 오면 오늘은 그냥 넘어갑니다')
        except Exception:
            pass
        lines.append('')
        lines.append('<b>언제 정리하나</b>')
        try:
            _sl = getattr(_c, 'DAILY_STRATEGY_STOP_LOSS_PCT', None)
            _arm = getattr(_c, 'DAILY_STRATEGY_TRAIL_ARM_PCT', None)
            _drop = getattr(_c, 'DAILY_STRATEGY_TRAIL_DROP_PCT', None)
            _hold = int(getattr(_c, 'DAILY_STRATEGY_HOLD_DAYS', 20))
            lines.append('<b>묻지 않고 봇이 바로 정리하는 것</b>')
            if _sl:
                lines.append(f'· -{float(_sl):.0f}%까지 밀리면 손절')
            if _arm and _drop:
                lines.append(f'· 수익이 +{float(_arm):.0f}%까지 갔다가 고점에서 -{float(_drop):.0f}% 되밀리면 이익 확정')
            lines.append('· 선물 만기(매월 둘째 목요일)에 다음 달 물건으로 갈아타기(롤오버) — 파는 게 아니라 이어가기')
            lines.append('')
            lines.append('<b>물어보고 정리하는 것</b>')
            lines.append(f'· 정리가 되지 않은 채 {_hold}거래일(약 한 달)이 지나면 그날 아침에 정리 여부를 묻습니다')
        except Exception:
            pass
        try:
            import os as _os
            pm = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'wiki', '신호', '거래기록', '_premarket.md')
            if _os.path.exists(pm):
                txt = open(pm, encoding='utf-8').read()
                cands = [l.strip('- ').strip() for l in txt.splitlines() if l.strip().startswith('- ')][:6]
                if cands:
                    lines.append('')
                    lines.append('<b>장 전에 눈에 띈 종목</b>')
                    lines.append('· ' + ' · '.join(c[:24] for c in cands))
        except Exception:
            pass
        return '\n'.join(lines)

    def run(self):
        """메인 실행 루프"""
        mode = '모의투자' if KIS_PAPER_MODE else '실전'
        log.info(f'')
        log.info(f'{"="*60}')
        log.info(f'  매매 자동화 봇 시작 ({mode})')
        log.info(f'  스캔간격: {SENTRY_SCAN_INTERVAL}초 / 최소점수: {SENTRY_MIN_SCORE}점')
        log.info(f'  손절: {SENTRY_STOP_LOSS_PCT}% / 익절: {SENTRY_TAKE_PROFIT_PCT}% / '
                 f'트레일링: {SENTRY_TRAILING_PCT}%')
        log.info(f'  최대포지션: {SENTRY_MAX_POSITIONS}개 / '
                 f'일일한도: {MAX_DAILY_TRADES}건, {MAX_DAILY_LOSS:,}원')
        log.info(f'  강제청산: {SENTRY_FORCE_CLOSE_TIME}')
        log.info(f'{"="*60}')

        # KIS 토큰 확인
        token = get_access_token()
        if not token:
            log.error('[Trader] KIS 토큰 발급 실패. 종료.')
            return

        # 주식선물 코드 매핑 확인
        if not has_map():
            log.warning('[Trader] 주식선물 코드 매핑 없음 → python build_futures_map.py 실행 필요')
            log.warning('[Trader] 매핑 없이 계속 (선물 주문은 스킵됨)')

        # 로컬 연구 DB 초기화
        algo_db.init_db()

        # 일일 전략 로드 (daily_strategy.py가 08:30에 생성)
        self._load_daily_strategy()

        # 알고리즘 등록
        self._register_algo()

        # 실계좌 포지션 복원
        self._sync_positions_from_account()

        # 관심종목 실시간 감시 스레드 시작
        import threading as _threading
        _wt = _threading.Thread(target=self._watchlist_loop, daemon=True, name='watchlist')
        _wt.start()
        log.info('[Trader] 관심종목 실시간 감시 스레드 시작')

        while True:
            try:
                kst = _kst_now()

                # 주말/휴장일 체크
                if not self.clock.is_trading_day():
                    reason = '휴장일' if self.clock.is_holiday() else '주말'
                    log.info(f'[Trader] {reason} — 다음 거래일까지 대기')
                    time.sleep(3600)
                    continue

                # 장 외 시간 대기
                if not self.clock.is_market_open():
                    wait = self.clock.seconds_until_open()
                    if wait > 0:
                        log.info(f'[Trader] 장 외 — {wait/60:.0f}분 후 개장 대기'
                                 f' (현재 {kst.strftime("%H:%M:%S")})')
                        time.sleep(min(wait, 300))  # 최대 5분씩 대기
                    continue

                # 장 마감 후 일일 요약만 (강제청산 없음)
                if self.clock.is_force_close_time():
                    today = kst.strftime('%Y-%m-%d')
                    try:
                        rdb.compute_daily_summary(today)
                    except Exception as e:
                        log.error(f'[Trader] 일일요약 오류: {e}')
                    log.info('[Trader] 장 마감 — 포지션 유지, 내일 계속')
                    time.sleep(3600)
                    continue

                # 장 시작 전 '오늘 매매 시작' 승인 (config DAY_START_APPROVAL_REQUIRED) — 승인 전엔 신규 진입 없음
                import config as _cfg_day
                if getattr(_cfg_day, 'DAY_START_APPROVAL_REQUIRED', False):
                    today_key = kst.strftime('%Y-%m-%d')
                    if getattr(self, '_day_approved_date', None) != today_key:
                        if getattr(self, '_day_rejected_date', None) == today_key:
                            # 오늘은 쉼: 청산 감시만
                            if self.positions:
                                self._monitor_positions()
                            time.sleep(SENTRY_SCAN_INTERVAL)
                            continue
                        last_ask = getattr(self, '_day_ask_ts', 0)
                        if time.time() - last_ask >= getattr(_cfg_day, 'DAY_START_APPROVAL_TIMEOUT', 600):
                            self._day_ask_ts = time.time()
                            ans = telegram_notify.request_day_start(self._day_start_summary(kst), timeout=getattr(_cfg_day, 'DAY_START_APPROVAL_TIMEOUT', 600))
                            if ans == 'approve':
                                self._day_approved_date = today_key
                                log.info('[Trader] 오늘 매매 시작 승인됨')
                            elif ans == 'reject':
                                self._day_rejected_date = today_key
                                log.info('[Trader] 오늘 매매 쉼(사용자) — 청산 감시만')
                                continue
                            else:
                                log.info('[Trader] 오늘 매매 시작 승인 응답 없음 — 진입 없이 대기, 다시 묻습니다')
                        if getattr(self, '_day_approved_date', None) != today_key:
                            if self.positions:
                                self._monitor_positions()
                            time.sleep(min(60, SENTRY_SCAN_INTERVAL))
                            continue

                # 텔레그램 일시 정지 체크
                if telegram_notify.get_override('paused', False):
                    log.info('[Trader] 텔레그램 명령 — 일시 정지 중 (재개: 텔레그램에서 "재개")')
                    time.sleep(60)
                    continue

                # 시장 분류 (장중 첫 스캔 시)
                if self.scan_count == 0:
                    self._classify_market()

                # 장기 모멘텀 스윙 스캔 (하루 1회, 검증된 전략 — config MOMENTUM_ENABLED)
                import config as _cfg_mom
                if getattr(_cfg_mom, 'MOMENTUM_ENABLED', False):
                    self._momentum_daily_scan(kst)

                # 일봉 전략 트랙 (하루 1회 — strategies/*.json timeframe 1d, config DAILY_STRATEGY_ENABLED; OVERSOLD_ENABLED 는 옛 이름)
                if getattr(_cfg_mom, 'DAILY_STRATEGY_ENABLED', False) or getattr(_cfg_mom, 'OVERSOLD_ENABLED', False):
                    self._daily_strategy_scan(kst)

                # 장전 NXT 돌파매수 스캔 (config BREAKOUT_ENABLED) — 장전 워치리스트 고정 + 매 루프 실시간 돌파 감시
                if getattr(_cfg_mom, 'BREAKOUT_ENABLED', False):
                    self._breakout_scan(kst)

                # ─── 스캔 ───
                self.scan_count += 1
                log.info(f'')
                log.info(f'[Trader] === 스캔 #{self.scan_count} '
                         f'({kst.strftime("%H:%M:%S")}) ===')
                log.info(f'[Trader] 활성 포지션: {len(self.positions)}건')

                # 팔로우업 결과 체크 (5분/10분/30분 후 가격 기록)
                self._check_followups()

                # 포지션 모니터링 (먼저)
                if self.positions:
                    self._monitor_positions()

                # 강제 일일 매매 체크 (삼성전자 등 rules.json 규칙)
                self._check_forced_daily_trades()

                # 사람이 '지금 정리'를 눌렀으면 그것부터 (종목마다 승인을 다시 묻는다)
                try:
                    for _req in telegram_notify.take_exit_requests():
                        for _p in list(self.positions):
                            if _req == 'all' or _req in (_p.code, _p.name):
                                log.info(f'[Trader] 사람 지시 정리: {_p.name}')
                                self._close_position(_p, '사람이 지금 정리를 지시함')
                except Exception as _ee:
                    log.error(f'[Trader] 사람 지시 정리 오류: {_ee}', exc_info=True)

                # 상태 출력 + 웹 푸시
                self._print_status()
                self._push_status()

                # ─── 스캐너 결과 즉시 처리 (① 신호 묵히지 않기) ───
                # 새 스캔이 끝나는 즉시 stage2를 처리하고 사이클을 다시 돈다.
                # 결과가 없으면 SENTRY_SCAN_INTERVAL까지만 대기.
                # 290종목 분봉 스캔은 PO 2026-09-23 결정으로 꺼져 있다.
                # 290종목은 아침 일봉으로 후보를 고르는 데만 쓰고, 그 뒤로는 후보만 본다.
                import config as _cfg_ms
                if getattr(_cfg_ms, 'MINUTE_SCAN_ENABLED', True):
                    log.info(f'[Trader] 스캐너 감시 (최대 {SENTRY_SCAN_INTERVAL}초, 완료 즉시 처리)...')
                    self._poll_scan_until(SENTRY_SCAN_INTERVAL)
                else:
                    # 후보 타이밍만 확인하고 다음 바퀴로. 보유 종목 점검은 그 사이에도 돈다.
                    self._combined_timing_scan([])
                    _left = SENTRY_SCAN_INTERVAL
                    while _left > 0:
                        _nap = min(10, _left)
                        time.sleep(_nap)
                        _left -= _nap
                        self._maybe_monitor()

            except KeyboardInterrupt:
                log.info('[Trader] 사용자 중단 (Ctrl+C) — 포지션 유지')
                break
            except Exception as e:
                log.error(f'[Trader] 루프 오류: {e}', exc_info=True)
                time.sleep(30)

        log.info('[Trader] 종료')

    def _write_trade_event(self, event_type, name, side, price, qty, reason='', score=0):
        """매매 이벤트를 파일에 기록 (Claude Code 채팅창 표시용)"""
        try:
            feed_path = os.path.join(os.path.dirname(__file__), 'data', 'trade_feed.jsonl')
            os.makedirs(os.path.dirname(feed_path), exist_ok=True)
            event = {
                'ts': _kst_now().strftime('%H:%M:%S'),
                'type': event_type,   # 'BUY' / 'SELL' / 'CLOSE'
                'name': name,
                'side': side,
                'price': price,
                'qty': qty,
                'reason': reason,
                'score': score,
            }
            with open(feed_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(event, ensure_ascii=False) + '\n')
        except Exception:
            pass

    def _push_status(self, log_msg=None):
        """scanner_web 매매 탭에 상태 푸시"""
        try:
            positions_data = []
            for pos in self.positions:
                kind = '선물' if pos.is_futures else '주식선물' if pos.is_stock_futures else '현물'
                positions_data.append({
                    'code': pos.code,
                    'name': pos.name,
                    'side': pos.side,
                    'qty': pos.qty,
                    'entry': pos.entry_price,
                    'kind': kind,
                    'pnl': 0.0,
                })
            payload = {
                'running': True,
                'positions': positions_data,
                'daily_trades': self.risk.daily_trades,
                'daily_pnl': self.risk.daily_pnl,
            }
            if log_msg:
                payload['log'] = log_msg
            _requests.post(SCANNER_UPDATE_URL, json=payload, timeout=2)
        except Exception:
            pass

    def _print_status(self):
        """현재 상태 출력"""
        if not self.positions:
            log.info(f'[Trader] 보유 포지션 없음')
            return

        log.info(f'[Trader] ─── 보유 포지션 ({len(self.positions)}건) ───')
        # 주식선물 현재가 일괄 조회
        sf_prices = {}
        if any(p.is_stock_futures for p in self.positions):
            try:
                bal = get_futures_balance()
                for p in bal.get('positions', []):
                    if p.get('current', 0) > 0:
                        sf_prices[p['code']] = p['current']
            except Exception:
                pass

        for pos in self.positions:
            try:
                if pos.is_stock_futures:
                    try:
                        _, current, _ = get_stock_info_naver(pos.code)
                    except Exception:
                        fcode = get_futures_code(pos.code) or pos.code
                        current = sf_prices.get(fcode, sf_prices.get(pos.code, 0))
                elif pos.is_futures:
                    info = get_futures_price(pos.code)
                    current = info['price'] if info else 0
                else:
                    info = get_stock_price(pos.code)
                    current = info['price'] if info else 0

                pnl = pos.pnl_pct(current) if current > 0 else 0
                kind = '선물' if pos.is_futures else '주식선물' if pos.is_stock_futures else '현물'
                cur_str = f'{current:,.0f}' if current > 0 else '조회실패'
                log.info(f'  {pos.name} [{kind}] {pos.side} x{pos.qty} '
                         f'진입{pos.entry_price:,.0f} → 현재{cur_str} '
                         f'({pnl:+.2f}%)')
            except Exception:
                log.info(f'  {pos.name} {pos.side} x{pos.qty} (가격 조회 실패)')

        log.info(f'[Trader] 일일매매: {self.risk.daily_trades}건 / '
                 f'일일손익: {self.risk.daily_pnl:+,.0f}원')
        try:
            wr = algo_db.get_win_rate(days=7)
            if wr['total'] > 0:
                log.info(f'[Trader] 최근7일 승률: 5분={wr["win_rate_5m"]:.0f}% '
                         f'10분={wr["win_rate_10m"]:.0f}% (총{wr["total"]}건)')
        except Exception:
            pass


# ═══════════════════════════════════════════
#  실행
# ═══════════════════════════════════════════

if __name__ == '__main__':
    # ── 중복 실행 방지 (락 파일) ──
    import atexit
    LOCK_FILE = os.path.join(os.path.dirname(__file__), 'data', '.trader.lock')
    os.makedirs(os.path.dirname(LOCK_FILE), exist_ok=True)

    if os.path.exists(LOCK_FILE):
        try:
            with open(LOCK_FILE) as _lf:
                old_pid = int(_lf.read().strip())
        except Exception:
            old_pid = None  # 락 파일 손상 → 덮어쓴다

        if old_pid is not None:
            # pid_exists()만 보면 OS가 재사용한 남의 PID를 우리 프로세스로 착각해
            # 정상 기동을 막는다. 2026-07-25자 락이 한 달 넘게 남아 있었으므로
            # 실제로 trader.py를 돌리는 파이썬인지 명령줄까지 확인한다.
            try:
                import psutil
                _p = psutil.Process(old_pid)          # 죽은 PID면 NoSuchProcess
                _cmd = ' '.join(_p.cmdline())
                _same = 'trader.py' in _cmd and 'python' in _p.name().lower()
            except Exception:
                _same = False  # psutil 없음 / 죽은 PID / 권한 없음 → 덮어쓴다
            # sys.exit는 try 밖에서 호출한다. SystemExit이 except에 삼켜지면
            # 중복 실행 방지가 조용히 무력화된다.
            if _same:
                print(f'[Trader] 이미 실행 중 (PID {old_pid}). 종료합니다.')
                sys.exit(1)

    with open(LOCK_FILE, 'w') as _lf:
        _lf.write(str(os.getpid()))

    def _remove_lock():
        try:
            os.remove(LOCK_FILE)
        except Exception:
            pass
    atexit.register(_remove_lock)

    bot = TraderBot()
    bot.run()
