/**
 * Antigravity(agy) CLI 어댑터 — 명령줄 조립(buildArgs) · 출력 해석(parseOutput).
 * 출력은 --output-format json 을 요청하지만, JSON 이 깨지면 텍스트로 폴백한다(대화 복구 판정보다 먼저).
 */
const fs = require('fs');
const path = require('path');
const { extractJson, parseVersion } = require('./_common');

const ai = 'agy';
const label = 'Antigravity';

function resolveExe() {
  const candidates = [
    path.join(process.env.LOCALAPPDATA || path.join(require('os').homedir(), 'AppData', 'Local'), 'agy', 'bin', 'agy.exe')
  ];
  return { cmd: candidates.find(p => fs.existsSync(p)) || 'agy.exe', pre: [] };
}

/** opts: { model, conversationId, cwd, printTimeout('9m'), safe }  — safe: 자동 승인 플래그 대신 agy --sandbox(터미널 제한) + 작업 폴더(--add-dir) 한정 */
function buildArgs(prompt, opts) {
  opts = opts || {};
  const exe = resolveExe();
  const args = [...exe.pre, '-p', prompt, ...(opts.safe ? ['--sandbox'] : ['--dangerously-skip-permissions']), '--output-format', 'json', '--print-timeout', opts.printTimeout || '9m'];
  if (opts.cwd) args.push('--add-dir', opts.cwd);
  if (opts.model) args.push('--model', opts.model);
  if (opts.conversationId) args.push('--conversation', opts.conversationId);
  return { cmd: exe.cmd, args, cwd: opts.cwd, env: null, stdin: null };
}

/** opts: { useConversation } → { ok, reply, format, error, conversationId, convBroken } */
function parseOutput(stdout, stderr, code, opts) {
  opts = opts || {};
  stdout = String(stdout || ''); stderr = String(stderr || '');
  const parsed = extractJson(stdout);
  if (parsed && typeof parsed === 'object' && ('response' in parsed || 'status' in parsed || 'conversation_id' in parsed)) {
    const ok = !parsed.status || /success/i.test(parsed.status);
    const text = String(parsed.response || '').trim();
    const base = { format: 'json', conversationId: parsed.conversation_id || null };
    if (ok) return Object.assign(base, { ok: true, reply: text || '작업이 완료되었습니다.' });
    const err = parsed.error || parsed.message || text || ('상태: ' + parsed.status);
    const convBroken = !!opts.useConversation && /conversation|not found|resume/i.test(String(err) + stderr);
    return Object.assign(base, { ok: false, reply: '', error: String(err), convBroken });
  }
  // 텍스트 폴백 — JSON 이 아니어도 종료코드 0 이고 내용이 있으면 답으로 인정 (convBroken 판정보다 먼저)
  const cleaned = (stdout + '\n' + stderr).trim();
  if (code === 0 && cleaned) return { ok: true, reply: cleaned, format: 'text' };
  const convBroken = !!opts.useConversation && /conversation|not found|resume/i.test(cleaned);
  return { ok: false, reply: '', format: 'text', error: cleaned, convBroken };
}

const versionArgs = (() => { const e = resolveExe(); return { cmd: e.cmd, args: [...e.pre, '--version'] }; })();

module.exports = { ai, label, resolveExe, buildArgs, parseOutput, versionArgs, parseVersion };
