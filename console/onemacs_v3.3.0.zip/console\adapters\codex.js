/**
 * Codex CLI 어댑터 — 명령줄 조립(buildArgs) · 출력 해석(parseOutput) 을 이 파일 하나에 모은다.
 * CLI 가 업데이트되어 인자나 출력 형식이 바뀌면 여기만 고친다. (검증 버전: cli_compat.json)
 */
const fs = require('fs');
const path = require('path');
const { extractJson, parseVersion, IS_WIN } = require('./_common');

const ai = 'codex';
const label = 'Codex';

function resolveExe() {
  // npm 전역 설치의 실제 진입점을 node 로 직접 실행 (Windows 에서 .cmd 를 shell 없이 spawn 하면 EINVAL)
  const candidates = [
    path.join(process.env.APPDATA || path.join(require('os').homedir(), 'AppData', 'Roaming'), 'npm', 'node_modules', '@openai', 'codex', 'bin', 'codex.js')
  ];
  const js = candidates.find(p => p && fs.existsSync(p));
  if (js) return { cmd: process.execPath, pre: [js] };
  return { cmd: IS_WIN ? 'codex.cmd' : 'codex', pre: [] };
}

/** opts: { model, cwd, safe }  — safe(안전 모드): 우회 플래그 대신 Codex 자체 샌드박스(workspace-write, 작업 폴더 한정) */
function buildArgs(prompt, opts) {
  opts = opts || {};
  const exe = resolveExe();
  const args = [
    ...exe.pre,
    'exec',
    ...(opts.safe ? ['-s', 'workspace-write', ...(opts.cwd ? ['-C', opts.cwd] : [])] : ['--dangerously-bypass-approvals-and-sandbox']),
    '--skip-git-repo-check',
    '--ephemeral',
    ...(opts.model ? ['-m', opts.model] : []),
    prompt
  ];
  return { cmd: exe.cmd, args, cwd: opts.cwd, env: null, stdin: null };
}

const NOISE = ['Reading additional', 'OpenAI Codex', 'workdir:', 'model:', 'provider:', 'approval:', 'sandbox:', 'reasoning', 'session id:', '--------', 'user', 'codex', 'hook:', 'tokens used'];

/** JSON 우선(향후 --json 출력 대비) → 'codex' 마커 뒤 본문 → 잡음 제거 텍스트 폴백 */
function parseOutput(stdout, stderr, code) {
  stdout = String(stdout || ''); stderr = String(stderr || '');
  const j = extractJson(stdout);
  if (j && typeof j === 'object' && (typeof j.response === 'string' || typeof j.result === 'string' || typeof j.message === 'string')) {
    const text = (j.response || j.result || j.message || '').trim();
    if (text) return { ok: true, reply: text, format: 'json' };
  }
  let reply = '';
  const marker = '\ncodex\n';
  const idx = stdout.indexOf(marker);
  if (idx !== -1) {
    let sub = stdout.slice(idx + marker.length);
    const endIdx = sub.lastIndexOf('\ntokens used');
    if (endIdx !== -1) sub = sub.slice(0, endIdx);
    reply = sub.trim();
  }
  if (!reply) {
    reply = (stdout || stderr).split('\n').filter(l => !NOISE.some(p => l.startsWith(p)) && !l.includes('ERROR codex_core::session')).join('\n').trim();
  }
  if (reply && code === 0) return { ok: true, reply, format: 'text' };
  if (reply && !/\berror\b|unauthorized|not logged|rate limit|unexpected argument|unknown option|unrecognized/i.test(reply)) return { ok: true, reply, format: 'text' };
  if (code === 0) return { ok: true, reply: '작업이 완료되었습니다.', format: 'text' };
  return { ok: false, reply: '', format: 'text', error: (stderr || stdout).trim() };
}

const versionArgs = (() => { const e = resolveExe(); return { cmd: e.cmd, args: [...e.pre, '--version'] }; })();

module.exports = { ai, label, resolveExe, buildArgs, parseOutput, versionArgs, parseVersion };
