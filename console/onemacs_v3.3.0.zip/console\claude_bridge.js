/**
 * Claude Code Mobile Bridge Engine
 * Handles bi-directional communication between mobile web console and Anthropic Claude Code CLI
 */
const { spawn } = require('child_process');
const fs = require('fs');
const TIMEOUT_MS = 30 * 60 * 1000; // PO 승인(2026-09-21 09:30): Claude Code 30분 (구 120초 하드코딩 제거)
const { classifyFailure, toMessage } = require('./fail_msg');
const { isSafe } = require('./perm');
const { audit } = require('./audit');
const path = require('path');

const MESSAGES_FILE = path.join(__dirname, 'claude_messages.json');
const WORK_DIR = path.resolve(__dirname, '..');

// Initialize messages file if not exists
if (!fs.existsSync(MESSAGES_FILE)) {
  try {
    fs.writeFileSync(MESSAGES_FILE, JSON.stringify([
      {
        id: 1,
        role: 'ai',
        text: '🤖 Claude (Opus 5.0) 모바일 서브 워커가 연결되었습니다!\n스마트폰에서 코딩 작업, 아키텍처 분석, 파일 수정을 지시하시면 PC의 Claude Code (Opus 5.0)가 실시간으로 실행합니다.',
        time: new Date().toLocaleTimeString('ko-KR')
      }
    ], null, 2), 'utf8');
  } catch (_) {}
}

let isClaudeBusy = false;
let currentTask = '';
const activeChildren = new Set();

function getMessages() {
  try {
    if (fs.existsSync(MESSAGES_FILE)) {
      return JSON.parse(fs.readFileSync(MESSAGES_FILE, 'utf8'));
    }
  } catch (_) {}
  return [];
}

function saveMessages(msgs) {
  try {
    const limited = msgs.slice(-100);
    const tmpFile = MESSAGES_FILE + '.tmp';
    fs.writeFileSync(tmpFile, JSON.stringify(limited, null, 2), 'utf8');
    fs.renameSync(tmpFile, MESSAGES_FILE);
  } catch (_) {
    try {
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(msgs.slice(-100), null, 2), 'utf8');
    } catch (_) {}
  }
}

function killCurrentProcess() {
  if (activeChildren.size > 0) {
    activeChildren.forEach(child => {
      try {
        if (child && child.pid) {
          if (process.platform === 'win32') {
            const { execSync } = require('child_process');
            execSync(`taskkill /pid ${child.pid} /T /F 2>nul || exit 0`, { shell: true });
          } else {
            child.kill('SIGKILL');
          }
        }
      } catch (_) {}
    });
    activeChildren.clear();
  }
  isClaudeBusy = false;
  currentTask = '';
  const updatedMsgs = getMessages();
  updatedMsgs.push({
    id: Date.now(),
    role: 'ai',
    text: '🛑 [긴급 정지] 사용자에 의해 실행 중이던 모든 Claude Code 작업이 즉시 강제 종료되었습니다.',
    time: new Date().toLocaleTimeString('ko-KR')
  });
  saveMessages(updatedMsgs);
  return true;
}

function getStatus() {
  return {
    isWorking: isClaudeBusy,
    currentTask: currentTask,
    messages: getMessages()
  };
}

function executeClaudePrompt(prompt) {
  return new Promise((resolve) => {
    if (!prompt || !prompt.trim()) {
      return resolve({ success: false, error: 'Empty prompt' });
    }

    const cleanPrompt = prompt.trim();
    const msgs = getMessages();
    const userMsgId = Date.now();
    msgs.push({
      id: userMsgId,
      role: 'user',
      text: cleanPrompt,
      time: new Date().toLocaleTimeString('ko-KR')
    });
    saveMessages(msgs);

    isClaudeBusy = true;
    currentTask = cleanPrompt;

    const claudeExe = process.platform === 'win32'
      ? (fs.existsSync(path.join(require('os').homedir(), '.local', 'bin', 'claude.exe')) ? path.join(require('os').homedir(), '.local', 'bin', 'claude.exe') : 'claude.exe')
      : 'claude';

    audit('instruction', { ai: 'claude', mode: isSafe() ? 'safe' : 'full', prompt: cleanPrompt });
    const child = spawn(claudeExe, [
      '-p',
      cleanPrompt,
      ...(isSafe() ? ['--permission-mode', 'acceptEdits', '--add-dir', WORK_DIR] : ['--dangerously-skip-permissions'])
    ], {
      cwd: WORK_DIR,
      shell: false,
      windowsHide: true,
      stdio: ['pipe', 'pipe', 'pipe']
    });

    activeChildren.add(child);

    // 타임아웃 안전 장치 (TIMEOUT_MS)
    const timer = setTimeout(() => {
      if (activeChildren.has(child)) {
        try {
          if (process.platform === 'win32') {
            const { execSync } = require('child_process');
            execSync(`taskkill /pid ${child.pid} /T /F 2>nul || exit 0`, { shell: true });
          } else {
            child.kill('SIGKILL');
          }
        } catch (_) {}
        activeChildren.delete(child);
        isClaudeBusy = activeChildren.size > 0;
        currentTask = isClaudeBusy ? currentTask : '';
        const updatedMsgs = getMessages();
        updatedMsgs.push(toMessage(classifyFailure({ ai: 'claude', kind: 'timeout', minutes: TIMEOUT_MS / 60000 })));
        saveMessages(updatedMsgs);
        resolve({ success: false, error: 'Timeout ' + (TIMEOUT_MS / 60000) + 'm' });
      }
    }, TIMEOUT_MS);

    try {
      child.stdin.end();
    } catch (_) {}

    let stdoutData = '';
    let stderrData = '';

    child.stdout.on('data', (d) => {
      stdoutData += d.toString();
    });

    child.stderr.on('data', (d) => {
      stderrData += d.toString();
    });

    child.on('close', (code) => {
      clearTimeout(timer);
      activeChildren.delete(child);
      isClaudeBusy = activeChildren.size > 0;
      if (!isClaudeBusy) currentTask = '';

      let replyText = (stdoutData.trim() || stderrData.trim());
      replyText = replyText
        .replace(/^Warning: no stdin data received in 3s[^\n]*\n?/gm, '')
        .replace(/SessionEnd hook[^\n]*failed:[^\n]*\n?/gm, '')
        .trim();

      const updatedMsgs = getMessages();
      if (!replyText && code !== 0) {
        // 실패 문구 통일(fail_msg): 종료 코드·원문은 카드의 "자세히" 안에만
        const fm = toMessage(classifyFailure({ ai: 'claude', kind: 'exit', code, stderr: stderrData, stdout: stdoutData }));
        updatedMsgs.push(fm);
        saveMessages(updatedMsgs);
        return resolve({ success: false, error: fm.fail.title, fail: fm.fail, code });
      }
      if (!replyText) replyText = '작업이 완료되었습니다.';
      updatedMsgs.push({
        id: Date.now(),
        role: 'ai',
        text: replyText,
        time: new Date().toLocaleTimeString('ko-KR')
      });
      saveMessages(updatedMsgs);

      resolve({ success: true, reply: replyText, code });
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      activeChildren.delete(child);
      isClaudeBusy = activeChildren.size > 0;
      if (!isClaudeBusy) currentTask = '';
      resolve({ success: false, error: err.message });
    });
  });
}

module.exports = {
  getStatus,
  getMessages,
  executeClaudePrompt,
  killCurrentProcess
};
