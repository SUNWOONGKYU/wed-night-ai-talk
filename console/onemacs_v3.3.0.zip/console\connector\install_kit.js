/**
 * install_kit.js — 에이전트 폴더에 「주소 연결」 꾸러미를 넣는다 (콘솔 없이 고정 주소로 여는 것)
 *   PO 2026-09-23: 「모든 에이전트 폴더별로 이 설정 관련된 내용을 다 담아놔야 돼」
 *
 *   node install_kit.js "<에이전트 폴더>" --cmd "시작.bat" --label "보고서 작성 에이전트" [--license OM-…] [--port 7790]
 *
 * 넣는 것:  onemacs_connect.py(연결기) · 주소연결_시작.bat(두 번 누르면 시작) · onemacs_connect.json(이 에이전트 설정)
 *           · 주소연결_안내.html(사람용 안내)
 * 이미 onemacs_connect.json 이 있으면 license 는 그대로 두고 나머지만 갱신한다(판매 후 재설치 때 키가 날아가지 않게).
 * 에이전트 폴더는 각 채널 담당이다 — 이 도구는 그 채널이 자기 폴더에 돌린다.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const a = process.argv.slice(2);
const dir = a[0] && !a[0].startsWith('--') ? a[0] : '';
const opt = (k) => { const i = a.indexOf('--' + k); return i >= 0 ? a[i + 1] : undefined; };
if (!dir || !fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
  console.error('사용법: node install_kit.js "<에이전트 폴더>" --cmd "시작.bat" --label "이름" [--license OM-…] [--port 7790]');
  process.exit(2);
}
const cmd = opt('cmd') || '';
if (cmd && !fs.existsSync(path.join(dir, cmd))) { console.error('그 폴더에 켜는 파일이 없습니다: ' + cmd); process.exit(2); }

const HERE = __dirname;
const copy = (src, dst) => { fs.copyFileSync(path.join(HERE, src), path.join(dir, dst)); console.log('  넣음: ' + dst); };
copy('onemacs_connect.py', 'onemacs_connect.py');
copy('start_connect.bat', '주소연결_시작.bat');
copy('안내.html', '주소연결_안내.html');

const cfgPath = path.join(dir, 'onemacs_connect.json');
let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8').replace(/^﻿/, '')); } catch (_) {}
cfg = Object.assign({ license: '', agent_cmd: '', agent_url: '', label: '', gate_port: 7790 }, cfg);
if (opt('license')) cfg.license = opt('license');
if (cmd) cfg.agent_cmd = cmd;
if (opt('label')) cfg.label = opt('label');
if (opt('port')) cfg.gate_port = parseInt(opt('port'), 10) || 7790;
if (!cfg.label) cfg.label = path.basename(path.resolve(dir));
fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2), 'utf8');
console.log('  설정: onemacs_connect.json  (라이선스 ' + (cfg.license ? '있음' : '비어 있음 — 구매자가 넣는다') + ', 켜는 파일 ' + (cfg.agent_cmd || '없음') + ', 앞문 포트 ' + cfg.gate_port + ')');
console.log('\n끝. 구매자는 onemacs_connect.json 에 라이선스 키를 넣고 「주소연결_시작.bat」 을 두 번 누르면 됩니다.');
console.log('⚠️ 에이전트가 토큰 붙은 접속 주소(http://localhost:포트/?t=…)를 검은 창에 찍어야 연결기가 들어갈 수 있습니다.');
