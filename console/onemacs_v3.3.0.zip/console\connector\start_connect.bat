@echo off
rem OneMACS address connector - opens this agent at its fixed address (PIN protected).
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
where python >/dev/null 2>&1
if errorlevel 1 (
  echo Python is not installed. Install Python 3.10+ from python.org and run again.
  pause
  exit /b 1
)
python onemacs_connect.py
pause
