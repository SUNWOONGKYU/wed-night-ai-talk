/**
 * fixed_address_admin.js — 콘솔 HQ 전용. 클라우드플레어에 고정 주소(터널 + DNS 이름)를 만들고 거둔다.
 *   PO 2026-09-23: 「고정 주소로 바꿔. 우리 것부터 먼저. 콘솔 전용 도메인을 하나 사.」
 *
 *   node hq/fixed_address_admin.js check                         API 토큰·도메인이 제대로 잡혔는지
 *   node hq/fixed_address_admin.js create <사용자코드|new> <PC번호> [--port 7890] [--label "PC 3"]
 *                                                                  고정 주소 하나를 만든다 → 주소 + 토큰 + 그 PC 에서 칠 한 줄
 *   node hq/fixed_address_admin.js list                          만든 것 목록(주소 · 터널 · 연결 상태)
 *   node hq/fixed_address_admin.js revoke <주소이름>             거둔다(DNS 이름 + 터널 삭제) — 미납·해지 때
 *
 * 설정: %USERPROFILE%\.onemacs\cloudflare.env  (저장소·정본에 올리지 않는다)
 *   CF_API_TOKEN=...      권한: Account › Cloudflare Tunnel › Edit, Zone › DNS › Edit, Zone › Zone › Read
 *   CF_ACCOUNT_ID=...
 *   CF_DOMAIN=onemacs.com  (CF_ZONE_ID 는 없으면 도메인으로 찾는다)
 *
 * 주소 모양 — **<사용자코드>-<PC번호>.<도메인>** (한 단계). 두 단계(pc1.사용자.도메인)로 하면 무료 인증서가
 *   덮지 못해 「안전하지 않음」이 뜬다. 그리고 이 모양은 나중에 10만 명 규모로 가며 뒤쪽 구조를 중계 방식으로
 *   바꿔도 **사용자 주소는 그대로** 두려고 지금 정한 것이다(PO 2026-09-23).
 *
 * 한도(공식 문서, 2026-09-23 확인): 무료 도메인의 DNS 이름 200개(2024-09-01 이후 만든 도메인) · 계정당 터널 1,000개.
 *   → PC 하나가 이름 하나·터널 하나를 쓰므로 이 방식은 **PC 200대까지**다. 그 뒤는 중계 방식으로 간다.
 */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const https = require('https');
const crypto = require('crypto');

const ENV_FILE = path.join(os.homedir(), '.onemacs', 'cloudflare.env');
function loadEnv() {
  const e = {};
  try {
    for (const line of fs.readFileSync(ENV_FILE, 'utf8').split(/\r?\n/)) {
      const m = /^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/.exec(line);
      if (m) e[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  } catch (_) {}
  for (const k of ['CF_API_TOKEN', 'CF_ACCOUNT_ID', 'CF_DOMAIN', 'CF_ZONE_ID']) if (process.env[k]) e[k] = process.env[k];
  return e;
}
const E = loadEnv();

function api(method, p, body) {
  return new Promise((resolve, reject) => {
    const data = body ? Buffer.from(JSON.stringify(body), 'utf8') : null;
    const r = https.request({
      host: 'api.cloudflare.com', path: '/client/v4' + p, method, timeout: 30000,
      headers: Object.assign({ Authorization: 'Bearer ' + E.CF_API_TOKEN, 'Content-Type': 'application/json' },
        data ? { 'Content-Length': data.length } : {}),
    }, (res) => {
      const b = []; res.on('data', d => b.push(d));
      res.on('end', () => {
        let j = null; try { j = JSON.parse(Buffer.concat(b).toString('utf8')); } catch (_) {}
        if (!j) return reject(new Error('HTTP ' + res.statusCode + ' — 응답을 읽지 못했습니다'));
        if (!j.success) return reject(new Error((j.errors || []).map(x => x.code + ' ' + x.message).join(' / ') || ('HTTP ' + res.statusCode)));
        resolve(j.result);
      });
    });
    r.on('timeout', () => r.destroy(new Error('클라우드플레어 응답 시간 초과')));
    r.on('error', reject);
    if (data) r.write(data); r.end();
  });
}

function need(keys) {
  const miss = keys.filter(k => !E[k]);
  if (miss.length) {
    console.error('설정이 모자랍니다: ' + miss.join(', '));
    console.error('  ' + ENV_FILE + ' 에 적어 주십시오. 예:');
    console.error('    CF_API_TOKEN=...   (권한: Account › Cloudflare Tunnel › Edit · Zone › DNS › Edit · Zone › Zone › Read)');
    console.error('    CF_ACCOUNT_ID=...  (대시보드 오른쪽 아래 「Account ID」)');
    console.error('    CF_DOMAIN=onemacs.com');
    process.exit(2);
  }
}
async function zoneId() {
  if (E.CF_ZONE_ID) return E.CF_ZONE_ID;
  const z = await api('GET', '/zones?name=' + encodeURIComponent(E.CF_DOMAIN));
  if (!z.length) throw new Error('도메인을 이 계정에서 찾지 못했습니다: ' + E.CF_DOMAIN);
  return z[0].id;
}

// 헷갈리는 글자(0 o 1 l i)를 뺀 소문자·숫자 6자 — 말로 불러 주거나 손으로 옮겨 적어도 틀리지 않게
const ALPH = 'abcdefghjkmnpqrstuvwxyz23456789';
function newCode(n) { const b = crypto.randomBytes(n || 6); let s = ''; for (const x of b) s += ALPH[x % ALPH.length]; return s; }

async function cmdCheck() {
  need(['CF_API_TOKEN', 'CF_ACCOUNT_ID', 'CF_DOMAIN']);
  const v = await api('GET', '/user/tokens/verify');
  console.log('API 토큰       : ' + v.status);
  const z = await zoneId();
  console.log('도메인         : ' + E.CF_DOMAIN + ' (zone ' + z.slice(0, 8) + '…)');
  const recs = await api('GET', '/zones/' + z + '/dns_records?per_page=1');
  const tuns = await api('GET', '/accounts/' + E.CF_ACCOUNT_ID + '/cfd_tunnel?is_deleted=false&per_page=1');
  console.log('DNS 읽기       : 됨' + (Array.isArray(recs) ? '' : ''));
  console.log('터널 읽기      : 됨' + (Array.isArray(tuns) ? '' : ''));
  console.log('준비됐습니다. 이제 create 로 고정 주소를 만들 수 있습니다.');
}

async function cmdCreate(codeArg, pcNo, opts) {
  need(['CF_API_TOKEN', 'CF_ACCOUNT_ID', 'CF_DOMAIN']);
  const code = (!codeArg || codeArg === 'new') ? newCode() : String(codeArg).toLowerCase();
  if (!/^[a-z0-9]{4,12}$/.test(code)) throw new Error('사용자코드는 소문자·숫자 4~12자여야 합니다: ' + code);
  const pc = String(pcNo || '1');
  if (!/^[0-9]{1,2}$/.test(pc)) throw new Error('PC 번호는 숫자여야 합니다: ' + pc);
  const name = code + '-' + pc;
  const host = name + '.' + E.CF_DOMAIN;
  const port = parseInt(opts.port || '7890', 10);
  const z = await zoneId();

  // 같은 이름이 이미 있으면 만들지 않는다 — 남의 주소를 덮어쓰는 일을 막는다
  const exists = await api('GET', '/zones/' + z + '/dns_records?name=' + encodeURIComponent(host));
  if (exists.length) throw new Error('이미 있는 주소입니다: ' + host + ' — revoke 로 거둔 뒤 다시 만드십시오');

  const t = await api('POST', '/accounts/' + E.CF_ACCOUNT_ID + '/cfd_tunnel', { name: 'onemacs-' + name, config_src: 'cloudflare' });
  const tid = t.id;
  try {
    await api('PUT', '/accounts/' + E.CF_ACCOUNT_ID + '/cfd_tunnel/' + tid + '/configurations', {
      config: { ingress: [{ hostname: host, service: 'http://127.0.0.1:' + port, originRequest: {} }, { service: 'http_status:404' }] },
    });
    await api('POST', '/zones/' + z + '/dns_records', {
      type: 'CNAME', proxied: true, name: host, content: tid + '.cfargotunnel.com',
      comment: 'onemacs ' + (opts.label || name) + ' ' + new Date().toISOString().slice(0, 10),
    });
  } catch (e) {
    // 반쯤 만들어진 것은 치운다 — 이름만 남거나 터널만 남으면 다음에 헷갈린다
    try { await api('DELETE', '/accounts/' + E.CF_ACCOUNT_ID + '/cfd_tunnel/' + tid); } catch (_) {}
    throw e;
  }
  const token = await api('GET', '/accounts/' + E.CF_ACCOUNT_ID + '/cfd_tunnel/' + tid + '/token');

  console.log('만들었습니다.');
  console.log('  주소       : https://' + host);
  console.log('  사용자코드 : ' + code + '   (같은 사람의 다른 PC 는 이 코드로 번호만 바꿔 만듭니다)');
  console.log('  터널       : ' + tid);
  console.log('\n그 PC 에서 칠 한 줄 (토큰은 비밀입니다 — 옮긴 뒤 이 화면·파일에서 지우십시오):');
  console.log('  node C:\\OneMACS\\console\\set_fixed_address.js https://' + host + ' ' + token);
}

async function cmdList() {
  need(['CF_API_TOKEN', 'CF_ACCOUNT_ID', 'CF_DOMAIN']);
  const z = await zoneId();
  const recs = await api('GET', '/zones/' + z + '/dns_records?type=CNAME&per_page=500');
  const mine = recs.filter(r => /\.cfargotunnel\.com$/.test(r.content));
  const tuns = await api('GET', '/accounts/' + E.CF_ACCOUNT_ID + '/cfd_tunnel?is_deleted=false&per_page=1000');
  const byId = new Map(tuns.map(t => [t.id, t]));
  console.log('고정 주소 ' + mine.length + '개 (무료 도메인 한도 200개 중 DNS 이름 ' + recs.length + '개 사용)');
  for (const r of mine) {
    const t = byId.get(r.content.replace('.cfargotunnel.com', ''));
    const st = t ? (t.status || '?') : '터널 없음';
    console.log('  ' + r.name.padEnd(34) + st.padEnd(10) + (r.comment || ''));
  }
}

async function cmdRevoke(name) {
  need(['CF_API_TOKEN', 'CF_ACCOUNT_ID', 'CF_DOMAIN']);
  if (!name) throw new Error('거둘 주소 이름을 주십시오 (예: k7m2q9-1)');
  const host = name.includes('.') ? name : (name + '.' + E.CF_DOMAIN);
  const z = await zoneId();
  const recs = await api('GET', '/zones/' + z + '/dns_records?name=' + encodeURIComponent(host));
  if (!recs.length) throw new Error('그런 주소가 없습니다: ' + host);
  const tid = recs[0].content.replace('.cfargotunnel.com', '');
  await api('DELETE', '/zones/' + z + '/dns_records/' + recs[0].id);
  try { await api('DELETE', '/accounts/' + E.CF_ACCOUNT_ID + '/cfd_tunnel/' + tid + '/connections'); } catch (_) {}
  await api('DELETE', '/accounts/' + E.CF_ACCOUNT_ID + '/cfd_tunnel/' + tid);
  console.log('거뒀습니다: ' + host + ' (터널 ' + tid.slice(0, 8) + '…)');
  console.log('그 PC 는 다음 재시작 때 고정 주소로 못 서고 임시 터널로 물러섭니다.');
}

(async () => {
  const a = process.argv.slice(2);
  const opt = {};
  for (let i = 0; i < a.length; i++) if (a[i].startsWith('--')) { opt[a[i].slice(2)] = a[i + 1]; a.splice(i, 2); i--; }
  try {
    if (a[0] === 'check') await cmdCheck();
    else if (a[0] === 'create') await cmdCreate(a[1], a[2], opt);
    else if (a[0] === 'list') await cmdList();
    else if (a[0] === 'revoke') await cmdRevoke(a[1]);
    else { console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0]); }
  } catch (e) { console.error('실패: ' + e.message); process.exit(1); }
})();
