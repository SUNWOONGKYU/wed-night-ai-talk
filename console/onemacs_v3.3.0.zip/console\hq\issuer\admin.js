/**
 * admin.js — 분양 서버 관리 (HQ 전용). 관리자 키는 %USERPROFILE%\.onemacs\cloudflare.env 의 ISSUER_ADMIN_KEY.
 *
 *   node hq/issuer/admin.js license --pcs 3 --days 365 --plan paid --note "홍길동 2026-09-23 주문 #123"
 *   node hq/issuer/admin.js list
 *   node hq/issuer/admin.js revoke  <라이선스>            미납·해지 — 그 라이선스의 주소 전부 회수, 라이선스 정지
 *   node hq/issuer/admin.js release <라이선스> <machine>  PC 한 대 분만 회수(기기 교체)
 *   node hq/issuer/admin.js status  <라이선스>
 */
'use strict';
const fs = require('fs'), os = require('os'), path = require('path');
const ISSUER = process.env.ONEMACS_ISSUER || 'https://onemacs-issuer.consolesystem.workers.dev';
let KEY = '';
try { KEY = (/^ISSUER_ADMIN_KEY=(.+)$/m.exec(fs.readFileSync(path.join(os.homedir(), '.onemacs', 'cloudflare.env'), 'utf8')) || [])[1] || ''; } catch (_) {}
KEY = (process.env.ISSUER_ADMIN_KEY || KEY).trim();

async function call(method, p, body) {
  const r = await fetch(ISSUER + p, { method, headers: { authorization: 'Bearer ' + KEY, 'content-type': 'application/json', 'user-agent': 'OneMACS-HQ/1.0' }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({ error: 'HTTP ' + r.status }));
  if (!r.ok) throw new Error(j.error || ('HTTP ' + r.status));
  return j;
}
const a = process.argv.slice(2);
const opt = (k, d) => { const i = a.indexOf('--' + k); return i >= 0 ? a[i + 1] : d; };
const fmt = (l) => `${l.license}  코드 ${l.code}  ${l.plan}  ${l.status}  PC ${l.addresses.length}/${l.max_pcs}` + (l.days_left != null ? `  남은 ${l.days_left}일` : '') + (l.addresses.length ? '\n    ' + l.addresses.map(x => x.url + (x.label ? ' (' + x.label + ')' : '')).join('\n    ') : '');

(async () => {
  if (!KEY) { console.error('관리자 키가 없습니다 (ISSUER_ADMIN_KEY)'); process.exit(2); }
  try {
    if (a[0] === 'license') {
      const j = await call('POST', '/v1/admin/license', { max_pcs: +opt('pcs', 3), days: +opt('days', 0), plan: opt('plan', 'paid'), note: opt('note', '') });
      console.log('발급했습니다:\n  ' + fmt(j) + '\n구매자에게 보낼 것은 라이선스 키 한 줄뿐입니다.');
    } else if (a[0] === 'list') {
      const j = await call('GET', '/v1/admin/list');
      console.log('라이선스 ' + j.licenses.length + '개'); for (const l of j.licenses) console.log('  ' + fmt(l));
    } else if (a[0] === 'revoke' && a[1]) {
      const j = await call('POST', '/v1/admin/revoke', { license: a[1] }); console.log('회수했습니다 (주소 ' + j.removed + '개):\n  ' + fmt(j));
    } else if (a[0] === 'release' && a[1] && a[2]) {
      const j = await call('POST', '/v1/admin/release', { license: a[1], machine: a[2] }); console.log('PC 한 대 분 회수:\n  ' + fmt(j));
    } else if (a[0] === 'status' && a[1]) {
      const r = await fetch(ISSUER + '/v1/status?license=' + encodeURIComponent(a[1]), { headers: { 'user-agent': 'OneMACS-HQ/1.0' } });
      console.log(fmt(await r.json()));
    } else {
      console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0]);
    }
  } catch (e) { console.error('실패: ' + e.message); process.exit(1); }
})();
