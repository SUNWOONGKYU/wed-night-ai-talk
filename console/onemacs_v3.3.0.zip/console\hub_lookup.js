/**
 * hub_lookup.js — 허브 장부에서 **내 다른 PC** 를 찾는다 (2026-09-23 분리)
 *
 *  같은 페어링 코드를 쓰는 PC 들이 장부에 주소를 올려 둔다(5분마다 갱신). 여기서 그걸 읽는다.
 *  daemon_ask.js(다른 PC 채널에 지시)와 bridge.js(파일 주고받기)가 **같은 코드를 쓰게** 하려고 떼어 냈다
 *  — 두 벌로 두면 한쪽만 고쳐져 어긋난다.
 *
 *  장부에 있는 것은 주소와 PC 이름표뿐이다. 대화·파일은 각자 PC 에 남는다.
 */
'use strict';
const https = require('https');
const fs = require('fs');
const path = require('path');

const HOME = process.env.CONSOLE_HOME || __dirname;

function cfg() { try { return JSON.parse(fs.readFileSync(path.join(HOME, 'console_config.json'), 'utf8').replace(/^﻿/, '')); } catch (_) { return {}; } }

function getJson(url, timeoutMs) {
  return new Promise((resolve, reject) => {
    const r = https.get(url, (res) => {
      const bufs = [];
      res.on('data', d => bufs.push(d));
      res.on('end', () => { try { resolve(JSON.parse(Buffer.concat(bufs).toString('utf8'))); } catch (e) { reject(e); } });
    });
    r.on('error', reject);
    r.setTimeout(timeoutMs || 10000, () => r.destroy(new Error('허브 응답 시간 초과')));
  });
}

// 운영본(legacy) 장부 — 배포판 빌드가 비운다. 페어링 허브가 없던 시절의 PC 를 위해 남겨 둔다
const LEGACY_GIST = { owner: '', id: '' };   // 배포판: 페어링 허브만 쓴다

/**
 * 장부 원본 주소. 페어링 허브가 먼저고, 없으면 옛 장부(Gist)로 물러선다.
 * ⚠️ 기본값 규칙은 start_all.js 와 **같아야** 한다 — pair_hub_url 이 없으면(undefined) 원맥스 허브,
 *    빈 문자열('')이면 허브를 안 쓴다는 뜻이다(배포판 -HubMode none). 이걸 다르게 두면
 *    콘솔은 허브에 등록하는데 조회 쪽만 딴 데를 보는 일이 생긴다(2026-09-23: daemon_ask 가 그래서
 *    페어링 허브를 놔두고 옛 장부만 보고 있었다).
 */
function sources(c) {
  const out = [];
  const pairUrl = c.pair_hub_url === '' ? '' : String(c.pair_hub_url || 'https://console-hub.consolesystem.workers.dev').replace(/\/+$/, '');
  const code = String(c.pair_code || '');
  if (pairUrl && code) out.push(pairUrl + '/devices?code=' + encodeURIComponent(code) + '&t=' + Date.now());
  // 옛 장부도 **같이** 본다. 둘 중 하나에만 올라와 있는 PC 가 실제로 있다
  // (2026-09-23 실측: 페어링 허브에는 PC3 만, 옛 장부에는 세 대가 다 있었다 — 옮겨 가는 중이라 그렇다).
  if (c.legacy_hub !== false) {
    const owner = String(c.legacy_gist_owner || process.env.CONSOLE_GIST_OWNER || LEGACY_GIST.owner);
    const gist = String(c.legacy_gist_id || process.env.CONSOLE_GIST_ID || LEGACY_GIST.id);
    if (gist && owner) out.push('https://gist.githubusercontent.com/' + owner + '/' + gist + '/raw/devices.json?t=' + Date.now());
  }
  return out;
}

/** 등록된 내 PC 목록 — [{ key, hostname, label, url, last_seen }] (최근에 본 순서) */
async function listPcs() {
  const c = cfg();
  const rows = [];
  for (const src of sources(c)) {
    let j;
    try { j = await getJson(src); } catch (_) { continue; }
    const devs = j.active_devices || j.devices || {};
    for (const [k, v] of Object.entries(devs)) {
      const url = String(v.url || '').replace(/\/$/, '');
      if (!url) continue;
      rows.push({ key: k, hostname: v.hostname || k, label: v.label || v.pc_label || v.hostname || k, url, last_seen: v.last_seen || 0 });
    }
  }
  // 같은 PC 가 두 장부에 다 있으면 **최근에 본 쪽**의 주소를 쓴다 — 옛 주소로 보내면 터널이 죽어 있다
  const best = new Map();
  for (const r of rows.sort((a, b) => (b.last_seen || 0) - (a.last_seen || 0))) {
    const k = String(r.hostname).toLowerCase();
    if (!best.has(k)) best.set(k, r);
  }
  return [...best.values()].sort((a, b) => (b.last_seen || 0) - (a.last_seen || 0));
}

/** 이름(hostname 또는 이름표 일부)으로 그 PC 의 지금 주소를 찾는다 */
async function findPcUrl(name) {
  const q = String(name || '').toLowerCase();
  if (!q) throw new Error('PC 이름이 없습니다');
  const rows = await listPcs();
  if (!rows.length) throw new Error('허브 장부를 읽지 못했습니다 (console_config.json 의 pair_hub_url·pair_code 를 확인하십시오)');
  const hit = rows.filter(v => v.hostname.toLowerCase() === q)
    .concat(rows.filter(v => v.hostname.toLowerCase().includes(q) || v.key.toLowerCase().includes(q) || String(v.label).toLowerCase().includes(q)));
  if (!hit.length) throw new Error('허브 장부에 없는 PC: ' + name + ' (등록: ' + rows.map(r => r.hostname).join(', ') + ')');
  return hit[0].url;
}

module.exports = { listPcs, findPcUrl };
