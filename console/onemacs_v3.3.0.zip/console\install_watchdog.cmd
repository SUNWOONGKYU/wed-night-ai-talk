@echo off
rem
chcp 65001 >nul
schtasks /Create /TN "OneMACS-Watchdog" /SC MINUTE /MO 5 /TR "cmd /c \"%~dp0watchdog.cmd\"" /F
schtasks /Query /TN "OneMACS-Watchdog" /FO LIST | findstr /I "TaskName Status Next"
