/**
 * Main Worker Bridge — Claude Code (Opus 5) : PC의 진짜 Claude Code 터미널 창 + 폰 미러링
 *
 *  - PC: 사용자가 평소처럼 쓰는 Claude Code 창(Windows Terminal/cmd). 브라우저 터미널 없음.
 *  - 폰 → PC: 폰 채팅창 지시를 그 창의 콘솔 입력 버퍼에 타이핑해 넣는다 (console_inject.ps1, 포커스 안 뺏음).
 *  - PC → 폰: 그 세션의 transcript(~/.claude/projects/<proj>/<id>.jsonl)를 읽어 말풍선(요약/상세/전체)으로 보여준다.
 *  - 창이 없으면 서버가 `claude --resume <id>` 창을 하나 띄운다. 긴급정지 = 그 창에 Ctrl+C. 새 세션 = 새 창.
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn, execFile } = require('child_process');

const SESSION_FILE = path.join(__dirname, 'main_session.json');
let _audit = null; try { _audit = require('./audit').audit; } catch (_) {}   // 감사 로그 (2026-09-21)
const INJECT_PS1 = path.join(__dirname, 'console_inject.ps1');
const WORK_DIR = path.resolve(__dirname, '..');
// 화면에 보여 줄 이름 — **설정에 지정된 모델을 따라간다.** 코드에 박아 두면 모델을 바꿔도
// 폰에는 옛 이름이 뜬다(2026-09-23: 모델은 Opus 5.5 인데 「Opus 5」로 보였다).
const WORKER_LABEL = (() => {
  try {
    const cs = require('./console_settings.js');
    const label = cs.get().model_labels.claude;
    if (label) return 'Claude Code (' + label + ')';
  } catch (_) {}
  return 'Claude Code';
})();
const PROJECT_KEY = WORK_DIR.replace(/[^a-zA-Z0-9]/g, '-'); // C:\myproject → C--myproject
const TRANSCRIPT_DIR = path.join(os.homedir(), '.claude', 'projects', PROJECT_KEY);
const CLAUDE_EXE = fs.existsSync(path.join(os.homedir(), '.local', 'bin', 'claude.exe')) ? path.join(os.homedir(), '.local', 'bin', 'claude.exe') : 'claude';
// 런처 .cmd 에 적을 이름 — 배치 파일은 ASCII 로만 쓸 수 있는데(cmd 코드페이지), 사용자 폴더 이름에 한글이
// 들어가면 절대경로가 그대로 들어가 깨진다. PC1 실측(2026-09-23): 사용자가 "선웅규" 라
//   "C:\Users\ ??\.local\bin\claude.exe"  로 써져 실행 파일을 못 찾고 1번 창이 안 떴다(main-restart 60초 타임아웃).
// → 홈 아래면 %USERPROFILE% 로 바꿔 ASCII 만 남기고, 그래도 ASCII 가 아니면 PATH 의 claude 를 쓴다.
const CLAUDE_EXE_CMD = (() => {
  if (CLAUDE_EXE === 'claude') return 'claude';
  const rel = path.relative(os.homedir(), CLAUDE_EXE);
  const cand = (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) ? ('%USERPROFILE%\\' + rel) : CLAUDE_EXE;
  return /^[\x20-\x7E]+$/.test(cand) ? cand : 'claude';
})();

let sessionState = loadSession();
let version = 0;
let lastAction = '';
let pendingMobile = [];
let windowPid = null;          // 메인 워커 창의 claude.exe PID
let launching = null;          // 창 띄우는 중이면 Promise

function nowIso() { return new Date().toISOString(); }
function bump() { version++; }

// ---------- 세션 ----------
function loadSession() {
  try { if (fs.existsSync(SESSION_FILE)) { const s = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf8')); if (s && s.sessionId) return s; } } catch (_) {}
  return { sessionId: null, started: false, createdAt: null };
}
function saveSession() { try { fs.writeFileSync(SESSION_FILE, JSON.stringify(sessionState, null, 2), 'utf8'); } catch (_) {} }
function newSession() { sessionState = { sessionId: crypto.randomUUID(), started: false, createdAt: nowIso() }; saveSession(); return sessionState; }
function transcriptPath(id) { return path.join(TRANSCRIPT_DIR, (id || sessionState.sessionId) + '.jsonl'); }

/** 활성 세션 판단: 고정 세션 파일이 최근 30분 내 갱신됐으면 그것, 아니면 프로젝트 폴더에서 가장 최근 갱신된 세션 */
function activeSessionId() {
  const pinned = sessionState.sessionId;
  // locked: 사용자가 고정한 세션은 같은 폴더에 다른 창/세션이 생겨도 자동 전환하지 않는다 (main_session.json "locked": true)
  if (sessionState.locked && pinned && fs.existsSync(transcriptPath(pinned))) return pinned;
  try {
    if (pinned && fs.existsSync(transcriptPath(pinned)) && Date.now() - fs.statSync(transcriptPath(pinned)).mtimeMs < 30 * 60 * 1000) return pinned;
    if (fs.existsSync(TRANSCRIPT_DIR)) {
      const newest = fs.readdirSync(TRANSCRIPT_DIR).filter(f => f.endsWith('.jsonl'))
        .map(f => ({ id: f.slice(0, -6), m: fs.statSync(path.join(TRANSCRIPT_DIR, f)).mtimeMs }))
        .sort((a, b) => b.m - a.m)[0];
      if (newest && (!pinned || newest.m > (fs.existsSync(transcriptPath(pinned)) ? fs.statSync(transcriptPath(pinned)).mtimeMs : 0))) {
        if (newest.id !== pinned) { sessionState = { sessionId: newest.id, started: true, createdAt: nowIso(), note: '가장 최근 활동 세션 자동 선택' }; saveSession(); cache = { mtime: 0, size: 0, messages: [], isWorking: false }; }
        return newest.id;
      }
    }
  } catch (_) {}
  return pinned;
}

// ---------- 창(claude.exe) 찾기 / 띄우기 ----------
function ps(args) {
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', ...args], { windowsHide: true, maxBuffer: 4 * 1024 * 1024, timeout: 60000 }, (err, stdout, stderr) => resolve({ err, stdout: String(stdout || ''), stderr: String(stderr || '') }));
  });
}

/** 대화형 claude.exe 후보 (헤드리스 -p 제외) 중 **이 프로젝트 폴더에서 실행 중인 창만** 대상.
 *  다른 프로젝트 창은 무시한다. 같은 프로젝트 창이 여럿이면 세션 ID 일치 > 가장 최근 창. */
const PROC_CWD_PS1 = path.join(__dirname, 'proc_cwd.ps1');
function samePath(a, b) { return String(a || '').replace(/[\\\/]+$/, '').toLowerCase() === String(b || '').replace(/[\\\/]+$/, '').toLowerCase(); }
async function listProjectWindows() {
  const r = await ps(['-File', PROC_CWD_PS1]);
  return r.stdout.split(/\r?\n/).filter(Boolean).map(l => {
    const p = l.split('|'); return { pid: parseInt(p[0], 10), created: p[1] || '', cwd: p[2] || '', cmd: p.slice(3).join('|') };
  }).filter(x => x.pid && /claude/i.test(x.cmd) && !/ -p | --print|--output-format/.test(x.cmd) && samePath(x.cwd, WORK_DIR))
    .sort((a, b) => (b.created > a.created ? 1 : b.created < a.created ? -1 : 0));
}
// PC1 발견(2026-09-22 06:20): proc_cwd.ps1(PEB 읽기)이 가끔 빈 값을 주면 기존 창을 못 찾고 새 창을 또 띄웠다(같은 세션 창 3개).
// 세션ID는 WMI CommandLine 에 그대로 있으므로 커맨드라인으로 먼저 찾고, 실패할 때만 cwd 기반 폴백
async function findByCommandLine(sid) {
  if (!sid) return null;
  const esc = sid.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const r = await ps(['-Command',
    `(Get-CimInstance Win32_Process -Filter "Name='claude.exe'" | Where-Object { $_.CommandLine -match '${esc}' -and $_.CommandLine -notmatch ' -p |--print|--output-format' } | Sort-Object CreationDate -Descending | Select-Object -First 1).ProcessId`]);
  const pid = parseInt((r.stdout || '').trim(), 10);
  return pid || null;
}
async function findWindowPid() {
  if (windowPid) { const r = await ps(['-Command', `if (Get-Process -Id ${windowPid} -ErrorAction SilentlyContinue) { 'alive' }`]); if (r.stdout.includes('alive')) return windowPid; windowPid = null; }
  const sid = activeSessionId() || '';
  const bySidFast = await findByCommandLine(sid);
  if (bySidFast) { windowPid = bySidFast; return windowPid; }
  const rows = await listProjectWindows();
  if (!rows.length) return null;
  const bySid = sid ? rows.find(x => x.cmd.includes(sid)) : null;
  windowPid = (bySid || (sessionState.locked ? rows[rows.length - 1] : rows[0])).pid; // locked 면 가장 오래된(원래) 창
  return windowPid;
}

function cleanEnv() {
  const env = Object.assign({}, process.env);
  for (const k of Object.keys(env)) if (k === 'CLAUDECODE' || k === 'CLAUDE_PID' || k === 'CLAUDE_EFFORT' || k.startsWith('CLAUDE_CODE_') || k === 'NoDefaultCurrentDirectoryInExePath') delete env[k];
  return env;
}

/** 메인 워커 창이 없으면 하나 띄운다 (보이는 콘솔 창) */
async function launchWindow(sessionId, resume) {
  if (launching) return launching;
  launching = (async () => {
    const id = sessionId || activeSessionId() || newSession().sessionId;
    const flag = resume ? `--resume ${id}` : `--session-id ${id}`;
    // 인라인 명령은 폴더명에 & ( ) 등이 있으면 cmd 파싱이 깨진다(예: "A&B") → 런처 .cmd 파일을 써서 실행
    // 배치 파일은 ASCII 만 (한글 경로는 cmd 코드페이지 문제로 깨짐) → 폴더는 %~dp0.. 로, 제목은 영문
    // 쓸 모델을 **창을 띄울 때 명시한다.** `--resume` 만 주면 그 대화가 처음 쓰던 모델을 그대로 이어받아
    // 설정을 바꿔도 안 바뀐다(2026-09-23 실측: 설정은 Opus 5.5 인데 대화 기록에는 계속 claude-opus-5).
    // 사용자가 정한 기본 모델(~/.claude/settings.json)을 먼저 쓴다 — 1M 같은 접미사가 거기 들어 있다.
    const modelFlag = (() => {
      try {
        const sj = JSON.parse(fs.readFileSync(path.join(os.homedir(), '.claude', 'settings.json'), 'utf8'));
        if (sj && typeof sj.model === 'string' && sj.model.trim()) return ' --model ' + sj.model.trim();
      } catch (_) {}
      try {
        const id = require('./console_settings.js').get().models.claude;
        if (id) return ' --model ' + id;
      } catch (_) {}
      return '';
    })();
    const launcher = path.join(__dirname, 'launch_main.cmd');
    fs.writeFileSync(launcher, ['@echo off', 'title Claude Code', 'cd /d "%~dp0.."', '"' + CLAUDE_EXE_CMD + '" --dangerously-skip-permissions' + modelFlag + ' ' + flag, ''].join('\r\n'), 'ascii');
    // 부모(콘솔 서버)가 창 없는(hidden) 프로세스일 때 PowerShell Start-Process·cmd start 는 창을 못 띄우는 경우가 있다(특히 G: 한글 경로).
    // explorer.exe 로 .cmd 를 열면 항상 사용자 데스크톱에 보이는 콘솔 창이 뜬다 (실측: 2026-09-20).
    const child = spawn('explorer.exe', [launcher], { cwd: WORK_DIR, env: cleanEnv(), detached: true, stdio: 'ignore', windowsHide: true });
    child.unref();
    lastAction = '🪟 PC에 Claude Code 창을 띄우는 중...'; bump();
    for (let i = 0; i < 30; i++) {
      await new Promise(r => setTimeout(r, 1000));
      const r = await ps(['-Command', `(Get-CimInstance Win32_Process -Filter "Name='claude.exe'" | Where-Object { $_.CommandLine -match '${id}' } | Select-Object -First 1).ProcessId`]);
      const pid = parseInt(r.stdout.trim(), 10);
      if (pid) { windowPid = pid; sessionState = { sessionId: id, started: true, createdAt: nowIso() }; saveSession(); await new Promise(r => setTimeout(r, 6000)); lastAction = ''; bump(); return pid; }
    }
    lastAction = '⚠️ Claude Code 창을 띄우지 못했습니다'; bump();
    return null;
  })();
  try { return await launching; } finally { launching = null; }
}

async function ensureWindow() {
  const pid = await findWindowPid();
  if (pid) return pid;
  const id = activeSessionId();
  return launchWindow(id, !!(id && fs.existsSync(transcriptPath(id))));
}

async function inject(text) {
  const pid = await ensureWindow();
  if (!pid) return { ok: false, error: 'Claude Code 창이 없습니다' };
  const r = await ps(['-File', INJECT_PS1, '-TargetPid', String(pid), '-Text', text]);
  if (r.stdout.includes('OK')) return { ok: true, pid };
  windowPid = null; // 붙기 실패 → 다음엔 다시 찾기
  return { ok: false, error: (r.stderr || r.stdout || '주입 실패').trim().slice(0, 200) };
}

// ---------- 도구 요약 ----------
function summarizeTool(name, input) {
  input = input || {};
  switch (name) {
    case 'Bash': case 'PowerShell': return { summary: input.description || '명령 실행', detail: '> ' + (input.command || '') };
    case 'Read': return { summary: '파일 읽기', detail: 'File: ' + (input.file_path || '') };
    case 'Edit': return { summary: '파일 수정', detail: 'File: ' + (input.file_path || '') };
    case 'Write': return { summary: '파일 작성', detail: 'File: ' + (input.file_path || '') };
    case 'Glob': return { summary: '파일 검색', detail: (input.pattern || '') + (input.path ? ' in ' + input.path : '') };
    case 'Grep': return { summary: '내용 검색', detail: (input.pattern || '') + (input.path ? ' in ' + input.path : '') };
    case 'Task': case 'Agent': return { summary: '서브에이전트: ' + (input.description || ''), detail: (input.prompt || '').slice(0, 400) };
    case 'WebFetch': case 'WebSearch': return { summary: '웹 조회', detail: input.url || input.query || '' };
    case 'Skill': return { summary: '스킬 호출', detail: input.skill || '' };
    case 'AskUserQuestion': {
      // PC 창의 선택 위젯은 폰에 안 보이므로 질문·보기를 글로 풀어 준다 (폰에서는 번호나 보기 글자를 채팅으로 답하면 된다)
      const qs = Array.isArray(input.questions) ? input.questions : [];
      const NL = String.fromCharCode(10);
      const lines = qs.map((q, i) => (qs.length > 1 ? (i + 1) + '. ' : '') + (q.question || '') + NL + (q.options || []).map((o, j) => '   ' + (j + 1) + ') ' + (o.label || '') + (o.description ? ' — ' + o.description : '')).join(NL));
      return { summary: '❓ 질문 — 아래에서 고르세요', detail: lines.join(NL + NL).slice(0, 1500), questions: qs.map(q => ({ question: q.question || '', header: q.header || '', multi: !!q.multiSelect, options: (q.options || []).map(o => ({ label: o.label || '', description: o.description || '' })) })) };
    }
    default: { let d = ''; try { d = JSON.stringify(input); } catch (_) {} return { summary: name, detail: d.slice(0, 400) }; }
  }
}

// ---------- transcript 읽기 ----------
let cache = { mtime: 0, size: 0, messages: [], isWorking: false };

// 사용자 텍스트에서 시스템 자동 주입 블록 제거 → 남는 게 없으면 '' (폰에 표시 안 함)
function cleanUserText(txt) {
  let s = String(txt || '');
  s = s.replace(/<system-reminder>[\s\S]*?<\/system-reminder>/g, '');
  s = s.replace(/<task-notification>[\s\S]*?<\/task-notification>/g, '');
  s = s.replace(/\[SYSTEM NOTIFICATION - NOT USER INPUT\][\s\S]*?(?=<task-notification>|$)/g, '');
  s = s.replace(/<command-message>[\s\S]*?<\/command-message>/g, '');
  return s.trim();
}

/** transcript(jsonl 본문) → 폰 말풍선 목록. 창 미러링·데몬 모드가 같이 쓴다 (claude_daemon_bridge.js) */
function parseTranscript(text) {
  const messages = []; let lastRole = null; let openTools = 0;
  for (const line of String(text || '').split('\n')) {
    if (!line.trim()) continue;
    let j; try { j = JSON.parse(line); } catch (_) { continue; }
    if (j.isSidechain) continue;
    const t = j.timestamp || nowIso();
    if (j.type === 'user' && j.message) {
      const c = j.message.content;
      // 시스템 자동 주입(백그라운드 작업 알림·system-reminder)은 사람 말이 아니므로 폰에 비추지 않는다
      if (typeof c === 'string') { const ut = cleanUserText(c); if (ut) { messages.push({ id: j.uuid, role: 'user', text: ut, time: t }); lastRole = 'user'; } }
      else if (Array.isArray(c)) for (const b of c) {
        if (b.type === 'text' && b.text) { const ut = cleanUserText(b.text); if (ut) { messages.push({ id: j.uuid, role: 'user', text: ut, time: t }); lastRole = 'user'; } }
        else if (b.type === 'image') { messages.push({ id: j.uuid, role: 'user', text: '🖼️ (이미지 첨부)', time: t }); lastRole = 'user'; }
        else if (b.type === 'tool_result') openTools = Math.max(0, openTools - 1);
      }
    } else if (j.type === 'assistant' && j.message && Array.isArray(j.message.content)) {
      for (const b of j.message.content) {
        if (b.type === 'text' && b.text && b.text.trim()) { messages.push({ id: j.uuid + '-t', role: 'ai', text: b.text.trim(), time: t }); lastRole = 'ai'; }
        else if (b.type === 'tool_use') { const st = summarizeTool(b.name, b.input); messages.push(Object.assign({ id: b.id || j.uuid, role: 'tool', toolName: b.name, time: t }, st)); openTools++; lastRole = 'tool'; }
      }
    }
  }
  const isWorking = lastRole === 'user' || lastRole === 'tool' || openTools > 0;
  return { messages, isWorking };
}

function readTranscript() {
  const id = activeSessionId();
  const tp = id ? transcriptPath(id) : null;
  if (!tp || !fs.existsSync(tp)) return { messages: [], isWorking: false };
  let st; try { st = fs.statSync(tp); } catch (_) { return cache; }
  if (st.mtimeMs === cache.mtime && st.size === cache.size) return cache;
  const r = parseTranscript(fs.readFileSync(tp, 'utf8'));
  cache = { mtime: st.mtimeMs, size: st.size, messages: r.messages, isWorking: r.isWorking };
  return cache;
}

// ---------- 공개 API ----------
function getStatus() {
  const tr = readTranscript();
  if (pendingMobile.length) pendingMobile = pendingMobile.filter(p => Date.now() - p.ts < 120000 && !tr.messages.some(m => m.role === 'user' && m.text === p.text));
  const messages = tr.messages.concat(pendingMobile.map(p => ({ id: p.id, role: 'user', text: p.text, time: p.time, isMobile: true })));
  const working = tr.isWorking || pendingMobile.length > 0;
  return {
    success: true, worker: WORKER_LABEL, mode: 'pc-window-mirror',
    conversationId: sessionState.sessionId, windowPid,
    activeStep: version + messages.length * 7 + (working ? 1 : 0) + tr.mtime,
    isWorking: working,
    currentTask: working ? ((messages.filter(m => m.role === 'user').slice(-1)[0] || {}).text || '') : '',
    lastAction: working ? (lastAction || '💬 PC Claude Code 창에서 실행 중...') : (lastAction || ''),
    queued: pendingMobile.length, count: messages.length, messages
  };
}

async function executeMainPrompt(prompt) {
  const clean = String(prompt || '').trim();
  if (!clean) return { success: false, error: 'Empty prompt' };
  pendingMobile.push({ id: 'm-' + Date.now(), text: clean, time: nowIso(), ts: Date.now() });
  if (_audit) _audit('instruction', { ai: 'claude', mode: 'mirror', prompt: String(prompt || '') });
  lastAction = '📱 폰 지시를 PC Claude Code 창에 입력하는 중...'; bump();
  const r = await inject(clean);
  lastAction = r.ok ? '📱 폰 지시가 PC 창에 입력됨' : '⚠️ 입력 실패: ' + r.error; bump();
  return r.ok ? { success: true, reply: 'PC 창에 전달됨' } : { success: false, error: r.error };
}

/** 특수키 열 전송 (선택 위젯 조작). keys: ['DOWN','DOWN','ENTER'] */
async function injectKeys(keys) {
  const pid = await findWindowPid();
  if (!pid) return { ok: false, error: 'Claude Code 창이 없습니다' };
  const list = (Array.isArray(keys) ? keys : String(keys || '').split(',')).map(k => String(k).trim()).filter(Boolean).slice(0, 40);
  if (!list.length) return { ok: false, error: '키 없음' };
  const r = await ps(['-File', INJECT_PS1, '-TargetPid', String(pid), '-Keys', list.join(',')]);
  if (r.stdout.includes('OK')) { lastAction = '⌨️ 폰에서 선택 입력: ' + list.join(' '); bump(); return { ok: true, pid }; }
  return { ok: false, error: (r.stderr || r.stdout || '키 전송 실패').trim().slice(0, 200) };
}

async function killCurrentProcess() {
  const pid = await findWindowPid();
  if (pid) await ps(['-File', INJECT_PS1, '-TargetPid', String(pid), '-CtrlC']);
  pendingMobile = [];
  lastAction = pid ? '🛑 PC 창에 Ctrl+C 전송' : '⚠️ Claude Code 창을 찾지 못함'; bump();
  return true;
}

async function resetSession() {
  const s = newSession();
  cache = { mtime: 0, size: 0, messages: [], isWorking: false };
  pendingMobile = []; windowPid = null;
  await launchWindow(s.sessionId, false);
  return s.sessionId;
}

function getMessages() { return getStatus().messages; }

module.exports = { WORKER_LABEL, getStatus, getMessages, executeMainPrompt, killCurrentProcess, resetSession, ensureWindow, findWindowPid, injectKeys, parseTranscript, summarizeTool, cleanUserText };
