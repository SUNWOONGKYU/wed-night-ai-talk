/**
 * 재발 방지 게이트 (PO 지시 2026-09-20): 채팅 입력창 옆 빨간 정지 버튼 금지.
 * start_all.js · tunnel.js 시작부에서 호출. server.js · hub_console.html 에 아래 지문이 있으면 기동을 중단(exit 1)하고 위치를 출력한다.
 * 우회 플래그 없음 — 해제는 PO 결정으로 이 파일과 호출부를 함께 지울 때만.
 */
const fs = require('fs');
const path = require('path');
const PATTERNS = [/id="stopFixedBtn"/, /\.btn-stop-fixed/, /getElementById\('stopFixedBtn'\)/];
function check(dir) {
  const hits = [];
  for (const f of ['server.js', 'hub_console.html']) {
    const p = path.join(dir || __dirname, f);
    let s = ''; try { s = fs.readFileSync(p, 'utf8'); } catch (_) { continue; }
    const lines = s.split(/\r?\n/);
    lines.forEach((ln, i) => { for (const re of PATTERNS) if (re.test(ln)) hits.push(`${f}:${i + 1} ${re.source}`); });
  }
  return hits;
}
function enforce(dir) {
  const hits = check(dir);
  if (hits.length) {
    console.error('⛔ 기동 중단 — 금지된 정지 버튼 지문 발견 (PO 2026-09-20):');
    hits.forEach(h => console.error('   ' + h));
    console.error('   해당 코드를 지운 뒤 다시 켜 주세요.');
    process.exit(1);
  }
}
module.exports = { check, enforce, PATTERNS };
if (require.main === module) { const h = check(process.argv[2]); console.log(h.length ? h.join('\n') : 'OK — 금지 지문 없음'); process.exit(h.length ? 1 : 0); }
