@echo off
rem Restart = stop, wait 3s, start. Master copy is applied on start.
rem If stop fails, do NOT start: starting anyway hits a port conflict and dies quietly,
rem so you never learn the restart failed. (PC2 measured 2026-09-23 05:50)
call "%~dp0stop_console.cmd"
if errorlevel 3 (
  echo.
  echo [restart aborted] could not stop the console - see the message above.
  echo Run as Administrator, or end node.exe in Task Manager and run start_console.cmd.
  exit /b 3
)
ping -n 4 127.0.0.1 >nul
call "%~dp0start_console.cmd"
