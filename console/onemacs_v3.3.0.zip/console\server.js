/**
 * 모바일 원격 제어 웹 콘솔 서버 (Mobile Remote Web Console)
 * Node.js 내장 모듈만 사용 (Zero External Dependency)
 */

const http = require('http');
const { exec, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const agyBridge = require('./antigravity_bridge.js'); // 서브 워커 2: Antigravity (agy)
const grokBridge = require('./grok_bridge.js');       // 서브 워커 3: Grok (grok-4.6, CLI 로그인)
const failMsg = require('./fail_msg.js');             // 실패 문구 통일 (2026-09-21)
const { audit, authLog } = require('./audit.js');     // 감사·인증 로그 (2026-09-21 보안)
const perm = require('./perm.js');                    // 권한 모드 safe|full
const consoleSettings = require('./console_settings.js'); // 폰 ⚙ 설정 패널 8항목 (console_config.json, 즉시 반영)

let _srvCfg = {};
try { _srvCfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'console_config.json'), 'utf8').replace(/^﻿/, '')); } catch (_) {}
// 메인 워커 역할 (2026-09-20 PC1 지시): 1번 프로젝트 = 'primary'(PC 대화형 Claude Code 창 미러링), 2번째 이후 = 'daemon'(창 없이 claude -p --resume).
//  - 라우터가 PROJECT_ROLE 을 주면 그대로. 없으면: 라우터 자식(PROJECT_NAME 있음)이면서 라우터 본체 폴더(config 에 projects 목록)가 아니면 daemon, 그 외(단독 실행 포함) primary.
const PROJECT_ROLE = process.env.PROJECT_ROLE || _srvCfg.role || ((process.env.PROJECT_NAME && !(Array.isArray(_srvCfg.projects) && _srvCfg.projects.length)) ? 'daemon' : 'primary');
// PC 창 미러링(첫 프로젝트의 대화창 있는 Claude Code 를 핸드폰에 비춤)은 기본 켬 — PO 2026-09-22 카탈로그 문답 Q1("창 미러링 꺼짐이면 안 된다"). config mirror_window:false(또는 CONSOLE_MIRROR=0) 로만 끈다 → 창 없는 claude -p/--resume(데몬)
const MIRROR_WINDOW = process.env.CONSOLE_MIRROR === '1' || (process.env.CONSOLE_MIRROR !== '0' && _srvCfg.mirror_window !== false);
let MIRROR_ON = !!MIRROR_WINDOW;
let mainBridge = (PROJECT_ROLE === 'daemon' || !MIRROR_ON) ? require('./claude_daemon_bridge.js') : require('./main_worker_bridge.js'); // 메인 워커: Claude Code (Opus 5)
// 핸드폰 설정에서 미러링 켬/끔 → 즉시 반영(첫 프로젝트만). 데몬 역할 프로젝트는 항상 창 없음
function setMirror(on) {
  MIRROR_ON = !!on; process.env.CONSOLE_MIRROR = MIRROR_ON ? '1' : '0';
  try { saveConsoleConfig({ mirror_window: MIRROR_ON }); } catch (_) {}
  if (PROJECT_ROLE !== 'daemon') mainBridge = MIRROR_ON ? require('./main_worker_bridge.js') : require('./claude_daemon_bridge.js');
  try { audit('mirror_window', { on: MIRROR_ON, by: 'phone' }); } catch (_) {}
  return MIRROR_ON;
}
const SHOW_QUOTA_BOOT = process.env.CONSOLE_SHOW_QUOTA === '1' || (process.env.CONSOLE_SHOW_QUOTA !== '0' && _srvCfg.show_quota === true);
function showQuotaNow() { try { return require('./console_settings.js').get().show_quota; } catch (_) { return SHOW_QUOTA_BOOT; } } // 폰 ⚙ 설정 즉시 반영 // 한도 표시(비공식 조회) 옵션 — 배포판 기본 false
const PORT = Number(process.env.PORT || _srvCfg.port || 7890);
let PIN_CODE = String(process.env.PIN || _srvCfg.pin || ''); // 모바일 접속 비밀번호 (핸드폰 설정에서 바꿀 수 있음 — PO 2026-09-22)
const WEAK_PIN = /^(1234|0000|1111|123456|654321|000000|111111|222222|333333|444444|555555|666666|777777|888888|999999|121212|112233)$/;
function pinValid(p) { p = String(p || ''); return /^\d{6}$/.test(p) && !WEAK_PIN.test(p) && !/^(\d)\1+$/.test(p); }
// 콘솔 본체 폴더의 console_config.json 에 값 저장 (perm.js 와 같은 파일 — 라우터·자식이 공유)
function saveConsoleConfig(patch) {
  const f = path.join(process.env.CONSOLE_HOME || __dirname, 'console_config.json');
  let raw = {}; try { raw = JSON.parse(fs.readFileSync(f, 'utf8').replace(/^\uFEFF/, '')); } catch (_) {}
  Object.assign(raw, patch); fs.writeFileSync(f, JSON.stringify(raw, null, 2), 'utf8'); return raw;
}
const BASE_DIR = path.resolve(__dirname, '..'); // 기본 작업 디렉토리 (프로젝트 루트)
// 2026-09-22 원맥스 프로젝트: 홈 프로젝트(원맥스, C:\OneMACS)는 콘솔 자체(console\)와 작업 폴더(general\)가 한 지붕 아래 있다.
//   Claude 세션은 C:\OneMACS 에서 돌지만(CLAUDE.md 가 general\ 규칙을 안다), 폰이 보는 파일 목록·업로드·경로 해석은 general\ 로 제한한다 —
//   콘솔 코드가 파일탭에 섞이거나 업로드가 console\ 옆에 떨어지지 않도록. 라우터가 PROJECT_HOME=1 을 넘긴다.
const HOME_PROJECT = process.env.PROJECT_HOME === '1';
const USER_DIR = HOME_PROJECT ? path.join(BASE_DIR, 'general') : BASE_DIR;
// AI 워커 구성 (console_config.json workers — 설치 마법사가 채움). 없으면 전부 켜짐·기본 모델.
let WORKERS = {};
try { WORKERS = JSON.parse(process.env.CONSOLE_WORKERS || 'null') || _srvCfg.workers || {}; } catch (_) { WORKERS = _srvCfg.workers || {}; }
function workerOn(k) { const w = WORKERS[k]; return !(w && w.enabled === false); }
function prettyModel(m) { if (!m) return ''; return String(m).replace(/^gemini-(\d+\.\d+)-(flash|pro)(?:-(high|low|medium))?$/i, (_, v, t, l) => 'Gemini ' + v + ' ' + t[0].toUpperCase() + t.slice(1) + (l ? ' (' + l[0].toUpperCase() + l.slice(1) + ')' : '')).replace(/^gpt-/i, 'GPT-'); }
// 탭 소제목 = 현재 선택 모델 (폰 ⚙ 설정에서 바꾸면 다음 화면 로드부터 반영; 화면 안에서는 JS 가 즉시 갱신)
function currentLabels() {
  try { const g = consoleSettings.get(); return { claude: g.model_labels.claude, codex: g.model_labels.codex, agy: g.model_labels.agy, grok: g.model_labels.grok }; }
  catch (_) { return { claude: 'Opus 5', codex: 'GPT-5.6-terra', agy: 'Gemini 3.8 Flash', grok: 'grok-4.6' }; }
}
const WLBL = new Proxy({}, { get: (_, k) => currentLabels()[k] });
let WORK_DIR = BASE_DIR;

// ── 에이전트 뷰(agentRuns) — 도구 버튼으로 띄운 로컬 웹 에이전트를 전용 주소로 감싸 콘솔 안에 보여준다.
// 에이전트는 127.0.0.1 로만 듣고 실행마다 접근 토큰이 바뀌므로, stdout 에서 주소를 읽어
// cloudflared 임시 터널을 붙이고 그 공개 주소를 폰 화면(iframe)에 띄운다.
const agentRuns = new Map(); // index -> { state, localUrl, publicUrl, error, proc, tunnel, startedAt }
const AGENT_URL_RE = /(https?:\/\/(?:127\.0\.0\.1|localhost|0\.0\.0\.0):\d+(?:\/\S*)?)/; // uvicorn 처럼 경로 없이 찍는 경우도 잡는다
const TUNNEL_URL_RE = /(https:\/\/[a-z0-9-]+\.trycloudflare\.com)/i;

function startAgentTunnel(rec, log) {
  // 자식 프로젝트 폴더에는 cloudflared 가 복사되지 않는다 → 콘솔 본체 폴더(CONSOLE_HOME)도 본다
  const exe = [path.join(__dirname, 'cloudflared.exe'), path.join(process.env.CONSOLE_HOME || '', 'cloudflared.exe')].find(f => f && fs.existsSync(f));
  if (!exe) { rec.state = 'error'; rec.error = 'cloudflared.exe 없음'; return; }
  let port = '';
  try { port = new URL(rec.localUrl).port; } catch (_) {}
  if (!port) { rec.state = 'error'; rec.error = '에이전트 포트를 못 읽음'; return; }
  const t = spawn(exe, ['tunnel', '--url', 'http://127.0.0.1:' + port], { windowsHide: true });
  rec.tunnel = t;
  const onData = (buf) => {
    const m = TUNNEL_URL_RE.exec(String(buf));
    if (m && !rec.publicUrl) {
      const rest = rec.localUrl.replace(/^https?:\/\/[^/]+/, '');
      rec.publicUrl = m[1] + rest;
      rec.state = 'ready';
      log('🌐 에이전트 외부 주소: ' + m[1]);
    }
  };
  t.stdout.on('data', onData); t.stderr.on('data', onData);
  t.on('exit', () => { if (rec.state !== 'ready') { rec.state = 'error'; rec.error = rec.error || '터널 종료'; } });
}


// 에이전트는 첫 접속(?t=토큰)에서 쿠키를 내주고 그 뒤로는 쿠키로만 인증한다(SameSite=Strict).
// 허브 iframe 은 다른 사이트로 취급돼 그 쿠키를 못 보내므로, 콘솔이 쿠키를 받아 두었다가
// 중계할 때마다 대신 붙인다. 그래서 폰에서는 콘솔 주소만으로 에이전트 화면이 열린다.
function grabAgentCookie(rec, log) {
  // 끝나면(성공·실패 무관) rec.cookieDone 이 풀린다 — 중계 방식은 이걸 기다려야 첫 화면이 403 으로 안 뜬다
  // 주소를 먼저 찍고 조금 뒤에 문을 여는 에이전트가 있다 → 연결이 거절되면 0.5초 간격으로 다시 시도(최대 약 10초)
  rec.cookieDone = new Promise((done) => {
    let tries = 0;
    const attempt = () => {
      tries++;
      const retry = () => (tries < 20 ? setTimeout(attempt, 500) : done());
      try {
        const u = new URL(rec.localUrl);
        const r = require('http').request({ host: '127.0.0.1', port: u.port, path: u.pathname + u.search, method: 'GET', timeout: 8000 }, (res) => {
          const sc = res.headers['set-cookie'];
          if (sc && sc.length) { rec.cookie = sc.map(c => String(c).split(';')[0]).join('; '); log('🔑 에이전트 인증 쿠키 확보'); }
          res.resume(); done();
        });
        r.on('timeout', () => { r.destroy(); });
        r.on('error', retry);
        r.end();
      } catch (_) { done(); }
    };
    attempt();
  });
}

// /agent/<i>/... → 에이전트(127.0.0.1:포트)로 중계. 본문이 HTML·JS 면 절대경로(/api/...)를 중계 경로로 바꿔 준다.
function proxyAgent(rec, prefix, req, res, subPath) {
  let u; try { u = new URL(rec.localUrl); } catch (_) { res.writeHead(502); return res.end('bad agent url'); }
  const headers = Object.assign({}, req.headers);
  delete headers.host; delete headers['accept-encoding'];
  if (rec.cookie) headers.cookie = rec.cookie;
  const pReq = require('http').request({ host: '127.0.0.1', port: u.port, path: subPath || '/', method: req.method, headers }, (pRes) => {
    const ct = String(pRes.headers['content-type'] || '');
    const out = Object.assign({}, pRes.headers);
    delete out['set-cookie'];
    // (PC3 2026-09-21) 에이전트의 연결 힌트(connection/keep-alive)는 에이전트↔콘솔 구간 것이다 — 그대로 흘리지 않고 각 홉(Node)이 자기 것을 붙이게 한다.
    delete out['connection']; delete out['keep-alive'];
    // 에이전트가 iframe 표시를 막는 헤더를 보내면 콘솔 안에 빈 화면이 된다(ABD 실측) → 중계본에서는 걷어낸다
    delete out['x-frame-options'];
    if (out['content-security-policy']) out['content-security-policy'] = String(out['content-security-policy']).replace(/frame-ancestors[^;]*;?/gi, '');
    if (out['content-security-policy-report-only']) delete out['content-security-policy-report-only'];
    if (out.location) out.location = String(out.location).replace(/^\//, prefix + '/');
    if (/text\/html|javascript|json/.test(ct)) {
      let body = '';
      pRes.setEncoding('utf8');
      pRes.on('data', (c) => body += c);
      pRes.on('end', () => {
        // 절대경로(/api/…, /assets/… )를 중계 경로로 바꾼다. 규칙이 겹쳐 접두사가 두 번 붙지 않도록
        // href/src/action 속성을 먼저 처리하고, 남은 따옴표 안 절대경로만 추가로 바꾼다.
        const pfx = prefix.replace(/\/$/, '');
        const fixed = body
          .replace(/(href|src|action)=("|')\/(?!agent\/)/g, '$1=$2' + pfx + '/')
          .replace(/(["'`(])\/(api|static|assets|favicon|css|js|img|media)\//g, (m0, q, seg) => q + pfx + '/' + seg + '/')
          .split(pfx + pfx).join(pfx);
        delete out['content-length'];
        res.writeHead(pRes.statusCode, out);
        res.end(fixed);
      });
    } else {
      res.writeHead(pRes.statusCode, out);
      pRes.pipe(res);
    }
  });
  pReq.on('error', (e) => { res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('에이전트 중계 실패: ' + e.message); });
  req.pipe(pReq);
}

// 이미 그 포트에서 돌고 있으면 새로 띄우지 않고 그대로 사용한다(ABD 처럼 상시 대시보드형).
function probeLocal(url) {
  return new Promise((resolve) => {
    let u; try { u = new URL(url); } catch (_) { return resolve(false); }
    const r = require('http').request({ host: '127.0.0.1', port: u.port, path: u.pathname || '/', method: 'GET', timeout: 2500 }, (res) => { res.resume(); resolve(res.statusCode < 500); });
    r.on('timeout', () => { r.destroy(); resolve(false); });
    r.on('error', () => resolve(false));
    r.end();
  });
}

// (PC1 2026-09-21 00:05) 주소 확정 → 쿠키 확보 + 터널. runAgent 의 onOut 이 토큰 우선/폴백 두 경로에서 호출한다.
function finalizeAgentUrl(rec, url, log) {
  rec.localUrl = url;
  log('🖥 에이전트 로컬 주소 확인: ' + rec.localUrl.replace(/\?t=.*/, '?t=***'));
  grabAgentCookie(rec, log);
  exposeAgent(rec, log);
}

// (PC3 2026-09-23 고정 주소) 에이전트는 콘솔 주소의 /agent/<i>/ 중계로 연다 — 주소가 콘솔과 함께 고정되고
// 에이전트마다 터널·DNS 이름을 쓰지 않는다. 중계 경로에서 라우팅이 깨지는 화면 앱만(view.direct) 전용 임시 터널을 붙인다.
function exposeAgent(rec, log) {
  if (rec.direct) return startAgentTunnel(rec, log);
  Promise.resolve(rec.cookieDone).then(() => { if (rec.state === 'starting') rec.state = 'ready'; });
}

function runAgent(i, tab, log) {
  const prev = agentRuns.get(i);
  if (prev && (prev.state === 'ready' || prev.state === 'starting')) return prev;
  const target = path.resolve(BASE_DIR, tab.cmd);
  const rec = { state: 'starting', localUrl: '', publicUrl: '', error: '', startedAt: Date.now(), label: tab.label, direct: !!(tab.view && tab.view.direct) };
  agentRuns.set(i, rec);
  const knownUrl = (tab.view && typeof tab.view === 'object' && tab.view.url) ? String(tab.view.url) : '';
  if (knownUrl) {
    probeLocal(knownUrl).then((alive) => {
      if (alive && !rec.localUrl) {
        rec.localUrl = knownUrl;
        log('🖥 이미 실행 중인 에이전트를 사용: ' + knownUrl);
        grabAgentCookie(rec, log);
        exposeAgent(rec, log);
      }
    });
  }
  // 한글 경로·UTF-8 배치를 안전하게 띄우기 위해 ASCII 경로의 임시 런처를 거친다.
  // (cmd 인자로 'chcp && "경로"' 를 통째로 넘기면 따옴표가 깨져 실행 자체가 안 된다)
  const launcher = path.join(__dirname, 'agent_launch_' + i + '.cmd');
  fs.writeFileSync(launcher, ['@echo off', 'chcp 65001>nul', 'call "' + target + '"', ''].join('\r\n'), 'utf8');
  const child = spawn('cmd', ['/d', '/c', launcher], { cwd: path.dirname(target), env: Object.assign({}, process.env, { DCF_AGENT_NO_AUTO_OPEN: '1', TAX_AGENT_NO_AUTO_OPEN: '1', PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8', PYTHONUNBUFFERED: '1' }), windowsHide: true });
  rec.proc = child;
  const onOut = (buf) => {
    const line = String(buf);
    rec.tail = ((rec.tail || '') + line).slice(-1200);
    if (!rec.localUrl) {
      // (PC1 2026-09-21 00:05 ③) 한 청크에 배너 줄과 토큰 붙은 줄이 같이 들어올 수 있다 — exec() 는 첫 매치만 주므로
      // 청크 안의 모든 매치를 훑어 토큰(?…=) 있는 것을 우선한다. 없으면 첫 후보를 0.8초 뒤 폴백으로 확정.
      const all = line.match(new RegExp(AGENT_URL_RE.source, 'g')) || [];
      const clean = all.map(u => u.replace(/[)\]"'<>]+$/, '').replace('0.0.0.0', '127.0.0.1'));
      const tokened = clean.find(u => /\?\S+=/.test(u));
      if (tokened) {
        if (rec._urlFallbackTimer) clearTimeout(rec._urlFallbackTimer);
        finalizeAgentUrl(rec, tokened, log);
      } else if (clean.length && !rec._urlCandidate) {
        rec._urlCandidate = clean[0];
        rec._urlFallbackTimer = setTimeout(() => { if (!rec.localUrl) finalizeAgentUrl(rec, rec._urlCandidate, log); }, 800);
      }
    }
  };
  child.stdout.on('data', onOut); child.stderr.on('data', onOut);
  child.on('exit', (code) => {
    if (rec.state !== 'ready') {
      // 폰에는 사람 말만 — 종료 코드·출력 원문은 detail 에 (2026-09-21 fail_msg)
      const f = failMsg.classifyFailure({ ai: rec.label || '에이전트', kind: 'exit', code, stderr: rec.tail || '' });
      rec.state = 'error'; rec.error = rec.error || ((rec.label || '에이전트') + '가 시작되지 못했습니다. (원인: ' + f.cause + ')' + (f.hint ? ' ' + f.hint : '')); rec.detail = f.detail;
    }
  });
  setTimeout(() => {
    if (rec.state === 'starting' && !rec.localUrl) { rec.state = 'error'; rec.error = '에이전트가 접속 주소를 알려주지 않음(120초)'; }
  }, 120000); // (PC3 2026-09-21) 60→120초: M3 는 이전 인스턴스 정리(강제종료 + 포트 해제 대기 PowerShell 루프)에 60초를 넘겨 실측 90초 뒤 주소를 찍었다
  return rec;
}


// 세션 토큰 관

// 세션 토큰 관리 (2026-09-21 보안): 토큰마다 발급 시각·세대 번호. 만료 7일. /api/logout-all → 세대 번호 증가로 현재 세션 외 전부 무효화
const TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000;
let sessionGen = 1;
const tokenInfo = new Map(); // token -> { at, gen }
const validTokens = { // 옛 코드 호환(has/add) — PIN 자체는 항상 유효(도구·설치지시문의 ?pin= 경로)
  has(t) { if (t === PIN_CODE) return true; const i = tokenInfo.get(t); if (!i) return false; if (i.gen !== sessionGen || Date.now() - i.at > TOKEN_TTL_MS) { tokenInfo.delete(t); return false; } return true; },
  add(t) { tokenInfo.set(t, { at: Date.now(), gen: sessionGen }); }
};
function generateToken() {
  const token = require('crypto').randomBytes(18).toString('base64url') + Date.now().toString(36);
  validTokens.add(token);
  return token;
}
function currentToken(req, parsedUrl) {
  const auth = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '').trim();
  const query = parsedUrl ? (parsedUrl.searchParams.get('token') || parsedUrl.searchParams.get('pin')) : '';
  return auth || query || getCookie(req, 'm_sid') || '';
}
// 로그인 잠금: IP 단위 실패 5회 → 1분, 20회 → 1시간. 시도는 logs/auth_YYYYMMDD.log
const loginFails = new Map(); // ip -> { n, until }
function clientIp(req) { return String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(); }
function loginLocked(ip) { const f = loginFails.get(ip); return f && f.until > Date.now() ? f.until : 0; }
function loginFailuresSummary() {
  const now = Date.now(); const list = [];
  for (const [ip, f] of loginFails) if (f.n > 0) list.push({ ip: String(ip).replace(/(\d+\.\d+)\.\d+\.\d+$/, '$1.*.*'), fails: f.n, locked_until: f.until > now ? new Date(f.until).toISOString() : null });
  return { ips: list.length, locked: list.filter(x => x.locked_until).length, list: list.slice(0, 20) };
}
function loginFailed(ip) {
  const f = loginFails.get(ip) || { n: 0, until: 0 };
  f.n++;
  if (f.n >= 20) f.until = Date.now() + 60 * 60 * 1000; else if (f.n >= 5) f.until = Date.now() + 60 * 1000;
  loginFails.set(ip, f);
  return f;
}

// 🛡️ 디렉토리 탈출(Path Traversal) 원천 차단 헬퍼
function safeResolvePath(userPath) {
  if (!userPath) return null;
  const abs = path.resolve(USER_DIR, userPath);
  const rel = path.relative(USER_DIR, abs);
  if (rel.startsWith('..') || path.isAbsolute(rel)) {
    return null; // 작업 디렉토리 외부 탈출 원천 차단
  }
  return abs;
}

// 🛡️ 요청 본문 크기 상한(DDoS/OOM 방어) 헬퍼
function readRequestBody(req, maxBytes, callback) {
  // ⚠️ 조각을 `body += chunk` 로 이어 붙이면 안 된다 — 한글처럼 여러 바이트인 글자가 조각 경계에서
  //    쪼개지면 조각마다 따로 문자열로 바뀌어 깨진 글자(U+FFFD)가 섞인다. 같은 PC 안에서는 본문이 한 조각으로
  //    와서 안 드러나지만, 터널을 지나면 여러 조각으로 온다. 바이트로 모아 두고 **끝에서 한 번에** 해석한다.
  const chunks = [];
  let bytes = 0;
  let done = false;
  req.on('data', chunk => {
    if (done) return;
    bytes += chunk.length;
    if (bytes > maxBytes) {
      done = true;
      req.destroy();
      return callback(new Error('PAYLOAD_TOO_LARGE'));
    }
    chunks.push(chunk);
  });
  req.on('end', () => {
    if (!done) { done = true; callback(null, Buffer.concat(chunks).toString('utf8')); }
  });
  req.on('error', err => {
    if (!done) { done = true; callback(err); }
  });
}

// 🛡️ 실질적 보안 인증 검증 (PIN 및 토큰 유효성 검사)
function getCookie(req, name) {
  const raw = req.headers['cookie'] || '';
  for (const part of raw.split(';')) {
    const [k, ...v] = part.trim().split('=');
    if (k === name) return decodeURIComponent(v.join('='));
  }
  return '';
}
// 세션 쿠키 발급 (URL에 토큰을 싣지 않기 위함 — /term·/term/ws 는 쿠키로 인증)
// 허브(vercel) iframe 안에서 쓰이므로 https 터널이면 SameSite=None; Secure
function sessionCookieHeader(req, tokenValue) {
  const https = (req.headers['x-forwarded-proto'] || '').includes('https') || /trycloudflare\.com$/i.test(req.headers.host || '');
  return `m_sid=${encodeURIComponent(tokenValue)}; Path=/; HttpOnly; Max-Age=86400; ` + (https ? 'SameSite=None; Secure' : 'SameSite=Lax');
}
function isRequestAuthorized(req, parsedUrl) {
  const auth = (req.headers['authorization'] || '').replace(/^Bearer\s+/i, '').trim();
  const query = parsedUrl ? (parsedUrl.searchParams.get('token') || parsedUrl.searchParams.get('pin')) : '';
  const cookie = getCookie(req, 'm_sid');
  const checkToken = auth || query || cookie;
  if (!checkToken) return false;
  return validTokens.has(checkToken) || checkToken === PIN_CODE;
}

// 로컬 IPv4 주소 추출
function getLocalIpAddresses() {
  const interfaces = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        addresses.push(iface.address);
      }
    }
  }
  return addresses;
}

// 명령어 실행 큐/프로세스 풀
let currentProcess = null;
const activeExecChildren = new Set();

const server = http.createServer((req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;
  console.log(`[REQ ${new Date().toLocaleTimeString()}] ${req.method} ${pathname}`);

  // CORS 및 헤더 설정
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // 1. API: 로그인 (PIN 검증)
  if (pathname === '/api/login' && req.method === 'POST') {
    readRequestBody(req, 65536, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const ip = clientIp(req);
        const until = loginLocked(ip);
        if (until) {
          authLog(ip, 'LOCKED', 'until=' + new Date(until).toISOString());
          res.writeHead(423, { 'Content-Type': 'application/json; charset=utf-8', 'Retry-After': String(Math.ceil((until - Date.now()) / 1000)) });
          return res.end(JSON.stringify({ success: false, locked: true, retryAfterSec: Math.ceil((until - Date.now()) / 1000), message: '로그인 시도가 너무 많아 잠시 잠겼습니다. ' + Math.ceil((until - Date.now()) / 60000) + '분 뒤 다시 해 주세요.' }));
        }
        const data = JSON.parse(body);
        // PIN 이 비어 있으면(설정 누락) 어떤 입력도 통과시키지 않는다 — Codex 리뷰 2026-09-22 (배포판은 PIN 기본값이 빈 문자열)
        if (PIN_CODE && String(data.pin || '') === PIN_CODE) {
          loginFails.delete(ip);
          authLog(ip, 'OK');
          const token = generateToken();
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Set-Cookie': sessionCookieHeader(req, token) });
          res.end(JSON.stringify({ success: true, token, workDir: WORK_DIR, expiresInDays: 7 }));
        } else {
          const f = loginFailed(ip);
          authLog(ip, 'FAIL', 'n=' + f.n + (f.until > Date.now() ? ' lock_until=' + new Date(f.until).toISOString() : ''));
          if (f.until > Date.now()) console.log('⛔ 로그인 잠금 ' + ip + ' (' + f.n + '회) → ' + new Date(f.until).toLocaleTimeString('ko-KR'));
          res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({ success: false, message: 'PIN 번호가 일치하지 않습니다.' + (f.n >= 3 ? ' (' + f.n + '회 실패 — 5회면 1분, 20회면 1시간 잠깁니다)' : '') }));
        }
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ success: false, message: '잘못된 요청 형식입니다.' }));
      }
    });
    return;
  }

  // 🛡️ 실질적 인증 미들웨어 (PIN 인증을 거친 요청만 통과)
  const isAuthenticated = isRequestAuthorized(req, parsedUrl);

  // 2. API: 시스템 정보
  // 구독 잔여 한도 (5h/7d, 남은 %) — quota.js, 60초 캐시
  if (pathname === '/api/quota') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    if (!showQuotaNow()) { // 비공식 조회 경로 — 옵션(show_quota) 이 켜져 있을 때만. 꺼져 있으면 폰에는 아무것도 안 보인다
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ hidden: true }));
    }
    return require('./quota.js').getQuota(false).then((q) => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify(q));
    }).catch(() => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ hidden: true })); // 실패는 조용히 숨김
    });
  }

  // 프로젝트 도구 실행 — console_config.json 의 project_tab.mode === 'run' 일 때만.
  // 실행 대상은 설정 파일의 cmd 하나뿐이고, 항상 그 프로젝트 폴더에서 돈다(요청 본문은 사용하지 않는다).
  if (pathname === '/api/project-run' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const json = (code, o) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(o)); };
    const idx = parseInt(parsedUrl.searchParams.get('i'), 10) || 0;
    const tab = PROJECT_TABS[idx];
    if (!tab || tab.mode !== 'run' || !tab.cmd) return json(400, { success: false, error: '실행 설정 없음' });
    const target = path.resolve(BASE_DIR, tab.cmd);
    if (!fs.existsSync(target)) return json(400, { success: false, error: '실행 파일 없음: ' + tab.cmd });
    // view: true 면 콘솔 안 화면으로 띄운다(전용 주소 생성). 아니면 종전대로 PC 에서 실행만 한다.
    if (tab.view) {
      const rec = runAgent(idx, tab, (m) => console.log('[agent] ' + m));
      return json(200, { success: true, view: true, prefer: (tab.view && tab.view.direct) ? 'tunnel' : 'proxy', state: rec.state, viewUrl: rec.localUrl ? ((process.env.PROJECT_NAME ? ('/proj/' + encodeURIComponent(process.env.PROJECT_NAME)) : '') + '/agent/' + idx + '/') : '', publicUrl: rec.publicUrl || '', error: rec.error || '', at: new Date().toLocaleTimeString('ko-KR') });
    }
    try {
      const child = spawn('cmd', ['/c', 'start', '', target], { cwd: BASE_DIR, detached: true, stdio: 'ignore', windowsHide: false });
      child.unref();
      return json(200, { success: true, started: tab.cmd, at: new Date().toLocaleTimeString('ko-KR') });
    } catch (e) { return json(500, { success: false, error: e.message }); }
  }

  // 에이전트 화면 중계 — 폰 브라우저는 iframe(제3자) 쿠키를 막으므로 인증을 **경로**에 싣는다.
  //   /agent/<i>/<토큰>/...  ← 이 토큰은 콘솔 접속 토큰(또는 PIN)이며, 중계된 HTML 의 절대경로도 같은 접두사로 바뀐다.
  if (pathname.startsWith('/agent/')) {
    const mm = /^\/agent\/(\d+)\/([^\/]+)(\/.*)?$/.exec(pathname);
    const pathToken = mm ? decodeURIComponent(mm[2]) : '';
    const okByPath = pathToken && (validTokens.has(pathToken) || pathToken === PIN_CODE);
    if (!mm || !(okByPath || isAuthenticated)) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const idx = parseInt(mm[1], 10);
    let rec = agentRuns.get(idx);
    // 콘솔이 재시작되면 실행 기록이 사라진다 → 설정이 있으면 그 자리에서 다시 띄우고 '준비 중' 화면을 돌려준다
    if (!rec || !rec.localUrl) {
      const tab = PROJECT_TABS[idx];
      if (tab && tab.mode === 'run' && tab.cmd) {
        if (!rec || rec.state === 'error') rec = runAgent(idx, tab, (m) => console.log('[agent] ' + m));
        const wait = '<!doctype html><meta charset="utf-8">'
          + '<meta http-equiv="refresh" content="3">'
          + '<body style="margin:0;background:#0b0e17;color:#8a99b5;font:14px -apple-system,BlinkMacSystemFont,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;text-align:center">'
          + '<div><div style="font-size:15px;color:#e2e8f0;margin-bottom:6px">에이전트를 켜는 중입니다</div>'
          + '<div>' + (rec && rec.error ? String(rec.error) : '잠시 뒤 자동으로 화면이 열립니다') + '</div></div>';
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end(wait);
      }
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('에이전트가 실행 중이 아닙니다');
    }
    // 폰 iframe 은 쿠키가 막혀 라우터가 기본 프로젝트로 보낸다 → 경로에 프로젝트를 박아 둔다
    const projPrefix = process.env.PROJECT_NAME ? ('/proj/' + encodeURIComponent(process.env.PROJECT_NAME)) : '';
    return proxyAgent(rec, projPrefix + '/agent/' + idx + '/' + encodeURIComponent(pathToken), req, res, (mm[3] || '/') + (parsedUrl.search || ''));
  }

  // 에이전트 뷰 준비 상태 조회 (터널이 뜨기까지 몇 초 걸린다)
  if (pathname === '/api/agent-view') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const idx = parseInt(parsedUrl.searchParams.get('i'), 10) || 0;
    const rec = agentRuns.get(idx) || { state: 'idle' };
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ prefer: (PROJECT_TABS[idx] && PROJECT_TABS[idx].view && PROJECT_TABS[idx].view.direct) ? 'tunnel' : 'proxy', state: rec.state, viewUrl: rec.localUrl ? ((process.env.PROJECT_NAME ? ('/proj/' + encodeURIComponent(process.env.PROJECT_NAME)) : '') + '/agent/' + idx + '/') : '', publicUrl: rec.publicUrl || '', error: rec.error || '', label: rec.label || '' }));
  }

  // 현재 세션 외 전부 로그아웃 (2026-09-21 보안): 세대 번호를 올리고 지금 사용하는 토큰만 새 세대로 옮긴다. PIN 직접 접속(?pin=)은 영향 없음
  // 폰 ⚙ 설정 패널 (2026-09-21): GET = 현재 설정 + 모델 목록(근거 포함) / POST = 부분 갱신 → console_config.json 즉시 반영
  if (pathname === '/api/settings' || pathname === '/api/config') { // /api/config = 별칭(문서 표기)
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify({ settings: consoleSettings.get(), catalog: consoleSettings.catalog(), timeout_default: consoleSettings.TIMEOUT_DEFAULT, timeout_max: consoleSettings.TIMEOUT_MAX, perm_mode: perm.getPermMode(), mirror_window: !!MIRROR_ON && PROJECT_ROLE !== 'daemon', mirror_available: PROJECT_ROLE !== 'daemon' }));
    }
    if (req.method === 'POST') {
      readRequestBody(req, 65536, (err, body) => {
        if (err) { res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' }); return res.end(JSON.stringify({ error: '요청 크기 초과' })); }
        let patch = {}; try { patch = JSON.parse(body || '{}'); } catch (_) { res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8' }); return res.end(JSON.stringify({ error: '잘못된 요청 형식입니다.' })); }
        // 권한 모드·미러링은 핸드폰에서 바꾼다 (PO 2026-09-22: "PC에 가서 또 설정하라는 건 너무 불편"). 전체 권한으로 갈 때만 PIN 재확인
        const extra = {};
        const ip = clientIp(req);
        if (patch.perm_mode !== undefined) {
          const want = String(patch.perm_mode).toLowerCase() === 'full' ? 'full' : 'safe';
          const until = loginLocked(ip);
          if (until) { res.writeHead(423, { 'Content-Type': 'application/json; charset=utf-8' }); return res.end(JSON.stringify({ success: false, errors: ['PIN 을 너무 많이 틀려 잠시 잠겼습니다. ' + Math.ceil((until - Date.now()) / 60000) + '분 뒤 다시 해 주세요.'] })); }
          if (want === 'full' && String(patch.pin || '') !== PIN_CODE) {
            const f = loginFailed(ip); authLog(ip, 'PERM_PIN_FAIL', 'n=' + f.n);
            res.writeHead(403, { 'Content-Type': 'application/json; charset=utf-8' }); return res.end(JSON.stringify({ success: false, errors: ['PIN 이 맞지 않습니다.' + (f.n >= 3 ? ' (' + f.n + '회 실패 — 5회면 1분 잠깁니다)' : '')] }));
          }
          loginFails.delete(ip);
          extra.perm_mode = perm.setPermMode(want, 'phone ' + ip);
          delete patch.perm_mode;
        }
        delete patch.pin;
        if (patch.mirror_window !== undefined) { extra.mirror_window = setMirror(!!patch.mirror_window) && PROJECT_ROLE !== 'daemon'; delete patch.mirror_window; }
        const r = Object.keys(patch).length ? consoleSettings.set(patch) : { settings: consoleSettings.get(), errors: [] };
        try { audit('settings', { ip, keys: Object.keys(patch).concat(Object.keys(extra)) }); } catch (_) {}
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
        return res.end(JSON.stringify(Object.assign({ success: r.errors.length === 0, settings: r.settings, errors: r.errors, perm_mode: perm.getPermMode(), mirror_window: !!MIRROR_ON && PROJECT_ROLE !== 'daemon' }, extra)));
      });
      return;
    }
  }

  // 사용법(오프라인 폴백): 배포판 동봉 사용법.html 을 서빙. 없으면 안내 문구 + 온라인 링크
  if (pathname === '/guide') {
    const cands = [path.join(__dirname, '사용법.html'), path.join(BASE_DIR, '사용법.html'), path.join(__dirname, 'guide.html')];
    const f = cands.find(x => { try { return fs.existsSync(x); } catch (_) { return false; } });
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    if (f) return res.end(fs.readFileSync(f, 'utf8'));
    return res.end('<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark light"><title>One MACS · 원맥스 사용법</title>'
      + '<style>body{margin:0;padding:24px 18px;font:16px/1.6 -apple-system,"Pretendard",sans-serif;background:#0b0e17;color:#f1f5f9}@media(prefers-color-scheme:light){body{background:#f3f5f9;color:#111827}}a{color:#4f7fff;word-break:break-all}h1{font-size:20px;margin:0 0 12px}</style></head>'
      + '<body><h1>One MACS · 원맥스 사용법</h1><p>이 PC에는 사용법 파일이 아직 없습니다. 인터넷이 되면 아래 주소에서 볼 수 있습니다.</p>'
      + '<p><a href="https://www.waat.community/market/onemacs/guide">https://www.waat.community/market/onemacs/guide</a></p>'
      + '<p>궁금한 것은 PC의 Claude Code에 "원맥스 사용법 알려줘"라고 물어봐도 됩니다.</p></body></html>');
  }

  // PIN 바꾸기 (핸드폰 설정, PO 2026-09-22): 지금 PIN + 새 PIN 6자리 → 저장 · 다른 기기 세션 전부 무효 · 이 기기 새 토큰. 틀리면 로그인과 같은 잠금(5회 1분·20회 1시간)
  if (pathname === '/api/pin-change' && req.method === 'POST') {
    if (!isAuthenticated) { res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' }); return res.end(JSON.stringify({ success: false, error: '인증 필요' })); }
    readRequestBody(req, 4096, (err, body) => {
      const ip = clientIp(req);
      const bad = (code, msg, extraH) => { res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, extraH || {})); res.end(JSON.stringify({ success: false, error: msg })); };
      if (err) return bad(413, '요청 크기 초과');
      let d = {}; try { d = JSON.parse(body || '{}'); } catch (_) { return bad(400, '잘못된 요청 형식입니다.'); }
      const until = loginLocked(ip);
      if (until) return bad(423, 'PIN 을 너무 많이 틀려 잠시 잠겼습니다. ' + Math.ceil((until - Date.now()) / 60000) + '분 뒤 다시 해 주세요.');
      // 지금 PIN 은 보내면 검증하고, 안 보내면 로그인된 세션(토큰)으로 갈음한다 (PO 2026-09-22: 지금 PIN 칸 없음)
      if (d.pin_current !== undefined && String(d.pin_current) !== PIN_CODE) { const f = loginFailed(ip); authLog(ip, 'PIN_CHANGE_FAIL', 'n=' + f.n); return bad(403, '지금 PIN 이 맞지 않습니다.' + (f.n >= 3 ? ' (' + f.n + '회 실패 — 5회면 1분 잠깁니다)' : '')); }
      if (!pinValid(d.pin_new)) return bad(400, '새 PIN 은 숫자 6자리여야 하고, 123456·000000 처럼 쉬운 번호는 안 됩니다.');
      if (String(d.pin_new) === PIN_CODE) return bad(400, '지금 PIN 과 같습니다. 다른 번호를 넣어 주세요.');
      loginFails.delete(ip);
      PIN_CODE = String(d.pin_new); process.env.PIN = PIN_CODE;
      try { saveConsoleConfig({ pin: PIN_CODE }); } catch (e) { return bad(500, 'PIN 저장에 실패했습니다: ' + e.message); }
      const before = tokenInfo.size; sessionGen++; tokenInfo.clear();
      const token = generateToken();
      try { audit('pin_change', { ip, invalidated: before }); authLog(ip, 'PIN_CHANGED', 'invalidated=' + before); } catch (_) {}
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Set-Cookie': sessionCookieHeader(req, token), 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify({ success: true, token, invalidated: before, expiresInDays: 7 }));
    });
    return;
  }

  if (pathname === '/api/logout-all' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const mine = currentToken(req, parsedUrl);
    const before = tokenInfo.size;
    sessionGen++;
    tokenInfo.clear();
    let token = mine;
    if (mine && mine !== PIN_CODE) { validTokens.add(mine); } else { token = generateToken(); }
    audit('logout_all', { ip: clientIp(req), invalidated: before });
    authLog(clientIp(req), 'LOGOUT_ALL', 'invalidated=' + before);
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Set-Cookie': sessionCookieHeader(req, token) });
    return res.end(JSON.stringify({ success: true, invalidated: before, token, message: '다른 기기의 접속을 모두 끊었습니다. 이 기기만 남습니다.' }));
  }

  // 콘솔 상태 API (2026-09-21): CLI 버전 실측·검증표 대조, 헬스체크, 마지막 실패, 원격 호환 공지 → 폰 상태줄
  if (pathname === '/api/status' || pathname === '/api/health') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    let out = { at: new Date().toISOString(), project: process.env.PROJECT_NAME || '', cli_versions: {}, unverified: [], health: {}, health_at: null, failing: [], last_failure: null, notices: [] };
    try {
      const cv = require('./cli_versions.js').readVersions();
      out.cli_versions = cv.versions || {}; out.unverified = cv.unverified || []; out.versions_at = cv.at || null;
      for (const k of out.unverified) if (out.cli_versions[k] && out.cli_versions[k].message) out.notices.push({ ai: k, kind: 'unverified', message: out.cli_versions[k].message });
    } catch (_) {}
    try {
      const h = require('./healthcheck.js').readHealth();
      out.health = h.results || {}; out.health_at = h.at || null; out.failing = h.failing || [];
      for (const k of out.failing) { const r = out.health[k] || {}; out.notices.push({ ai: k, kind: 'health', message: (r.label || k) + '는 지금 점검 중입니다. 다른 AI에게 맡기거나 잠시 뒤 다시 시켜 주세요.' + (r.cause ? ' (원인: ' + r.cause + ')' : '') }); }
    } catch (_) {}
    try { out.last_failure = failMsg.readLastFailure().last || null; } catch (_) {}
    try { out.notices.push(...require('./compat_notice.js').applicable(out.cli_versions)); } catch (_) {}
    // 권한 모드·미러링·한도 표시 (2026-09-21 보안)
    out.perm_mode = perm.getPermMode();
    // 로그인 실패·잠금 현황 (IP 는 뒤 두 옥텟만 가림). 라우터 모드에서는 라우터가 자기 값으로 대체한다
    out.login_failures = loginFailuresSummary();
    out.mirror_window = !!MIRROR_ON && PROJECT_ROLE !== 'daemon';
    out.show_quota = !!showQuotaNow();
    if (out.perm_mode === 'full') out.notices.push({ ai: '*', kind: 'perm', message: '자동 승인 모드입니다. AI가 확인 없이 PC의 파일을 바꾸고 명령을 실행할 수 있습니다. 안전 모드로 돌리려면 PC의 Claude Code에 "원맥스 안전 모드로"라고 하세요.' });
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify(out));
  }

  if (pathname === '/api/info') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const info = {
      hostname: os.hostname(),
      platform: os.platform(),
      arch: os.arch(),
      uptimeHours: (os.uptime() / 3600).toFixed(1),
      freeMemMB: Math.round(os.freemem() / (1024 * 1024)),
      totalMemMB: Math.round(os.totalmem() / (1024 * 1024)),
      workDir: WORK_DIR,
      mainRole: PROJECT_ROLE,
      localIps: getLocalIpAddresses()
    };
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(info));
  }

  // 2-1. API: 모바일 화면으로 PC AI 답변 실시간 스트리밍 전달
  if (pathname === '/api/ai-poll') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const lastId = parseInt(parsedUrl.searchParams.get('lastId') || '0', 10);
    const respFile = path.join(__dirname, 'ai_responses_to_mobile.json');
    let responses = [];
    try {
      if (fs.existsSync(respFile)) {
        const all = JSON.parse(fs.readFileSync(respFile, 'utf8'));
        responses = all.filter(item => item.id > lastId);
      }
    } catch (_) {}
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ responses }));
  }



  // 2-4. API: 메인 워커(Claude Code) 실시간 대화 트랜스크립트 동기화
  if (pathname === '/api/live-transcript') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const data = mainBridge.getStatus();
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(data));
  }

  // 2-5. API: 모바일에서 메인 워커(Claude Code)로 실시간 질문/지시 즉각 전송 (큐 순차 실행)
  // 선택 위젯 조작: 폰 버튼 → PC 창에 방향키/Enter 주입
  if (pathname === '/api/main-keys' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    return readRequestBody(req, 65536, (err, body) => {
      let keys = []; try { keys = JSON.parse(body || '{}').keys || []; } catch (_) {}
      mainBridge.injectKeys(keys).then((r) => {
        res.writeHead(r.ok ? 200 : 500, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify(Object.assign({ success: !!r.ok }, r)));
      });
    });
  }

  if (pathname === '/api/send-mobile-input' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 1048576, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const { text } = JSON.parse(body);
        if (!text || !text.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '지시 내용이 없습니다.' }));
        }
        const taskFile = path.join(__dirname, 'tasks_from_mobile.json');
        let tasks = [];
        try {
          if (fs.existsSync(taskFile)) tasks = JSON.parse(fs.readFileSync(taskFile, 'utf8'));
        } catch (_) {}
        const entry = {
          time: new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }),
          task: text.trim()
        };
        tasks.push(entry);
        fs.writeFileSync(taskFile, JSON.stringify(tasks.slice(-100), null, 2), 'utf8');

        mainBridge.executeMainPrompt(text.trim());

        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, entry, queued: mainBridge.getStatus().queued }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2-5-B. API: 메인 워커 세션 초기화 (대화 맥락 새로 시작)
  if (pathname === '/api/main-reset-session' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    if (PROJECT_ROLE === 'daemon') {
      return mainBridge.resetSession().then((sid) => { res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify({ success: true, sessionId: sid })); });
    }
    res.writeHead(410, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ success: false, error: '미러링 모드에서는 세션 리셋을 지원하지 않습니다 (PC 창의 대화가 정본)' }));
  }

  // 2-5-C. API: 메인 워커 창 확인/기동 (PC에 Claude Code 창이 없으면 --resume 으로 하나 띄움)
  if (pathname === '/api/main-restart' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    mainBridge.ensureWindow().then((pid) => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ success: !!pid, windowPid: pid, sessionId: mainBridge.getStatus().conversationId }));
    });
    return;
  }

  // 2-6. API: Codex 실시간 상태 및 대화내역 조회
  if (pathname === '/api/codex-status') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const codexBridge = require('./codex_bridge.js');
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(codexBridge.getStatus()));
  }

  // 2-7. API: 모바일에서 Codex로 실시간 코딩 지시 전송
  if (pathname === '/api/codex-send' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 1048576, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const { text } = JSON.parse(body);
        if (!text || !text.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '지시 내용이 없습니다.' }));
        }
        const codexBridge = require('./codex_bridge.js');
        codexBridge.executeCodexPrompt(text.trim());
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, message: 'Codex 실행 개시' }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2-8. API: Antigravity(서브 워커 2) 실시간 상태 및 대화내역 조회
  if (pathname === '/api/agy-status') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(agyBridge.getStatus()));
  }

  // 2-9. API: 모바일에서 Antigravity(서브 워커 2)로 실시간 코딩 지시 전송
  if (pathname === '/api/agy-send' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 1048576, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const { text } = JSON.parse(body);
        if (!text || !text.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '지시 내용이 없습니다.' }));
        }
        agyBridge.executeAgyPrompt(text.trim());
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, message: 'Antigravity 실행 개시' }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2-8G. API: Grok(서브 워커 3) 실시간 상태 및 대화내역 조회
  if (pathname === '/api/grok-status') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify(grokBridge.getStatus()));
  }

  // 2-9G. API: 모바일에서 Grok(서브 워커 3)로 실시간 코딩 지시 전송
  if (pathname === '/api/grok-send' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 1048576, (err, body) => {
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: '요청 크기 초과' }));
      }
      try {
        const { text } = JSON.parse(body);
        if (!text || !text.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '지시 내용이 없습니다.' }));
        }
        grokBridge.executeGrokPrompt(text.trim());
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, message: 'Grok 실행 개시' }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 2-10. API: 긴급 정지 (Emergency Stop / Kill Switch)
  if (pathname === '/api/emergency-stop' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    try {
      const codexBridge = require('./codex_bridge.js');

      // 메인·서브 워커 프로세스 정밀 타깃 강제 종료 (외부 사용자 터미널 보호)
      mainBridge.killCurrentProcess();
      if (typeof codexBridge.killCurrentProcess === 'function') codexBridge.killCurrentProcess();
      agyBridge.killCurrentProcess();
      if (typeof grokBridge.killCurrentProcess === 'function') grokBridge.killCurrentProcess();

      // exec 명령어 실행 하위 프로세스 일괄 트리 강제 종료
      if (activeExecChildren.size > 0) {
        activeExecChildren.forEach(p => {
          try {
            if (p && p.pid) {
              if (process.platform === 'win32') {
                const { execSync } = require('child_process');
                execSync(`taskkill /pid ${p.pid} /T /F 2>nul || exit 0`, { shell: true });
              } else {
                p.kill('SIGKILL');
              }
            }
          } catch (_) {}
        });
        activeExecChildren.clear();
      }
      currentProcess = null;

      // 모바일 태스크 기록에 정지 알림 기록
      const tasksFile = path.join(__dirname, 'tasks_from_mobile.json');
      try {
        let tasks = [];
        if (fs.existsSync(tasksFile)) tasks = JSON.parse(fs.readFileSync(tasksFile, 'utf8'));
        tasks.push({
          time: new Date().toLocaleString('ko-KR'),
          task: '🛑 [긴급 정지 발동] 사용자가 모바일 콘솔에서 긴급 정지(Kill Switch)를 눌러 모든 실행 중인 작업을 즉시 중단시켰습니다.'
        });
        fs.writeFileSync(tasksFile, JSON.stringify(tasks, null, 2), 'utf8');
      } catch (_) {}

      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ 
        success: true, 
        message: '🛑 모든 AI 프로세스 및 백그라운드 연산이 즉시 강제 중단되었습니다.' 
      }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ success: false, error: err.message }));
    }
  }

  // 2-10-B. API: 스캐너 상태 조회 프록시
  // 전략 목록·통과 종목·겹침 (scanner_web /api/strategies 프록시) + 켜기/끄기
  if (pathname === '/api/scanner-strategies' || pathname.startsWith('/api/scanner-strategy-toggle/')) {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const httpMod = require('http');
    const toggle = pathname.startsWith('/api/scanner-strategy-toggle/');
    const sid = toggle ? pathname.slice('/api/scanner-strategy-toggle/'.length) : '';
    const target = toggle ? ('http://127.0.0.1:5050/api/strategies/' + sid + '/enabled') : 'http://127.0.0.1:5050/api/strategies';
    const proxyReq = httpMod.request(target, { method: toggle ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json' } }, (proxyRes) => {
      res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
      proxyRes.pipe(res);
    });
    proxyReq.on('error', () => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ strategies: [], overlap: {}, error: '스캐너 백엔드 대기 중' }));
    });
    if (toggle) req.pipe(proxyReq); else proxyReq.end();
    return;
  }

  // 안내 자료 (trader-bot docs/*.html — tools/build_docs.py 산출물). 정해진 3개만, 매번 새로 읽는다 (PO 2026-09-23)
  if (pathname.startsWith('/api/docs/')) {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const file = DOC_FILES[pathname.slice('/api/docs/'.length)];
    if (!file) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('없는 문서'); }
    fs.readFile(path.join(BASE_DIR, 'docs', file), (err, buf) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('문서가 아직 없습니다 (python tools/build_docs.py)'); }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(buf);
    });
    return;
  }

  if (pathname === '/api/scanner-status') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const httpMod = require('http');
    const proxyReq = httpMod.request('http://127.0.0.1:5050/api/status', (proxyRes) => {
      res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
      proxyRes.pipe(res);
    });
    proxyReq.on('error', () => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ running: false, stage1: [], stage2: [], error: '스캐너 백엔드 대기 중' }));
    });
    proxyReq.end();
    return;
  }

  // 2-10-C. API: 스캐너 재스캔 실행 프록시
  if (pathname === '/api/scanner-scan' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const httpMod = require('http');
    const proxyReq = httpMod.request('http://127.0.0.1:5050/api/scan', { method: 'POST' }, (proxyRes) => {
      res.writeHead(proxyRes.statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
      proxyRes.pipe(res);
    });
    proxyReq.on('error', (e) => {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ error: '스캐너 서버 통신 오류: ' + e.message }));
    });
    proxyReq.end();
    return;
  }

  // 2-10. API: 기기 장부 조회 (듀얼 PC 탭 전환용)
  if (pathname === '/api/devices' && req.method === 'GET') {
    const devicesFile = path.join(__dirname, 'devices.json');
    let devices = {};
    if (fs.existsSync(devicesFile)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(devicesFile, 'utf8'));
        if (parsed && parsed.active_devices) devices = parsed.active_devices;
      } catch (_) {}
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({ success: true, devices }));
  }

  // 2-11. API: 모바일 파일/사진 업로드 (Upload)
  if (pathname === '/api/upload' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증이 필요합니다. 올바른 PIN 코드로 접속하세요.' }));
    }

    readRequestBody(req, 104857600, (err, body) => { // 100MB 상한
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: '업로드 파일 크기 초과 (최대 100MB)' }));
      }
      try {
        const { filename, base64, targetAi, uploadType } = JSON.parse(body);
        if (!filename || !base64) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '파일명 또는 데이터가 없습니다.' }));
        }

        const uploadDir = path.join(USER_DIR, 'uploads');
        if (!fs.existsSync(uploadDir)) {
          fs.mkdirSync(uploadDir, { recursive: true });
        }

        // Base64 데이터 파싱 (data:image/png;base64, 접두사 제거)
        const pureBase64 = base64.replace(/^data:[^;]+;base64,/, '');
        const fileBuffer = Buffer.from(pureBase64, 'base64');
        const safeName = Date.now() + '_' + path.basename(filename).replace(/[^a-zA-Z0-9_\.\-\uAC00-\uD7A3]/g, '_');
        const targetPath = safeResolvePath(path.join('uploads', safeName));
        if (!targetPath) {
          res.writeHead(403, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '안전하지 않은 파일 경로입니다.' }));
        }

        fs.writeFileSync(targetPath, fileBuffer);

        const bytes = fileBuffer.length;
        const sizeStr = bytes > 1024 * 1024 ? (bytes / (1024 * 1024)).toFixed(2) + ' MB' : Math.round(bytes / 1024) + ' KB';
        const relPath = (HOME_PROJECT ? 'general/' : '') + 'uploads/' + safeName; // Claude 의 작업 폴더(BASE_DIR) 기준 상대경로
        const isPhoto = uploadType === 'image' || /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(safeName);
        const itemLabel = isPhoto ? '사진' : '파일';
        const itemIcon = isPhoto ? '🖼️' : '📁';

        // 모바일 태스크 목록에 등록
        const tasksFile = path.join(__dirname, 'tasks_from_mobile.json');
        try {
          let tasks = [];
          if (fs.existsSync(tasksFile)) tasks = JSON.parse(fs.readFileSync(tasksFile, 'utf8'));
          tasks.push({
            time: new Date().toLocaleString('ko-KR'),
            task: `${itemIcon} [모바일 ${itemLabel} 수신] 파일명: ${safeName} (${sizeStr}) - 경로: ${relPath}`
          });
          fs.writeFileSync(tasksFile, JSON.stringify(tasks, null, 2), 'utf8');
        } catch (_) {}

        // 타깃 AI에 따라 대화창에 파일 등록 및 즉시 알림
        if (targetAi === 'codex') {
          const codexBridge = require('./codex_bridge.js');
          const prompt = `대표님께서 모바일에서 ${itemLabel}(${safeName}, ${sizeStr})을 업로드하셨습니다. 위치는 ${relPath} 입니다. ${itemLabel}의 내용을 확인하고 분석해 주세요.`;
          codexBridge.executeCodexPrompt(prompt);
        } else if (targetAi === 'agy') {
          const prompt = `대표님께서 모바일에서 ${itemLabel}(${safeName}, ${sizeStr})을 업로드하셨습니다. 위치는 ${relPath} 입니다. ${itemLabel}의 내용을 확인하고 정밀 분석해 주세요.`;
          agyBridge.executeAgyPrompt(prompt);
        } else if (targetAi === 'grok') {
          const prompt = `대표님께서 모바일에서 ${itemLabel}(${safeName}, ${sizeStr})을 업로드하셨습니다. 위치는 ${relPath} 입니다. ${itemLabel}의 내용을 확인하고 정밀 분석해 주세요.`;
          grokBridge.executeGrokPrompt(prompt);
        } else if (targetAi === 'assistant') {
          const prompt = `모바일에서 ${itemLabel}(${safeName}, ${sizeStr})을 업로드했다. 위치는 ${relPath} 이다. 내용을 확인하고 핵심을 분석해 보고해줘.`;
          mainBridge.executeMainPrompt(prompt);
        }

        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ 
          success: true, 
          filename: safeName, 
          filePath: relPath, 
          sizeStr,
          message: `${itemLabel}(${safeName})이 성공적으로 업로드되었습니다.`
        }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 3. API: 파일 목록 조회
  if (pathname === '/api/files') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    try {
      const items = fs.readdirSync(USER_DIR, { withFileTypes: true }).map(item => {
        let size = 0;
        try {
          if (!item.isDirectory()) {
            size = fs.statSync(path.join(USER_DIR, item.name)).size;
          }
        } catch (_) {}
        return {
          name: item.name,
          isDir: item.isDirectory(),
          size
        };
      });
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ workDir: USER_DIR, files: items }));
    } catch (err) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: err.message }));
    }
  }

  // 3-1. API: 특정 파일 내용 읽기
  if (pathname === '/api/file-content' && req.method === 'GET') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    const relFile = parsedUrl.searchParams.get('file');
    if (!relFile) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: '파일 경로 누락' }));
    }
    const absPath = safeResolvePath(relFile);
    if (!absPath || !fs.existsSync(absPath)) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: '파일을 찾을 수 없거나 접근 권한이 없습니다.' }));
    }
    try {
      const content = fs.readFileSync(absPath, 'utf8');
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ file: relFile, content }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: e.message }));
    }
  }

  // 3-2. API: 모바일에서 파일 수정 후 즉시 저장
  if (pathname === '/api/save-file' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증 필요' }));
    }
    readRequestBody(req, 10485760, (err, body) => { // 10MB 상한
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: '파일 크기 초과' }));
      }
      try {
        const { file, content } = JSON.parse(body);
        if (!file) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '파일명 누락' }));
        }
        const absPath = safeResolvePath(file);
        if (!absPath) {
          res.writeHead(403, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '프로젝트 작업 디렉토리 외부 경로는 수정할 수 없습니다.' }));
        }
        fs.writeFileSync(absPath, content, 'utf8');
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ success: true, file, message: '파일이 PC에 정상 저장되었습니다!' }));
      } catch (e) {
        res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // 스마트 자연어 의도 해석기 (한국어 대화 및 명령어 자동 처리)
  function handleSmartIntent(input, workDir) {
    const text = input.trim();
    if (!text) return null;

    // 1. 인사 및 환영
    if (/^(안녕|하이|반가|hello|hi|헤이|누구|뭐해)/i.test(text)) {
      return {
        type: 'chat',
        reply: `안녕하세요, 대표님! 👋\n멀티 AI 에이전트(Claude Code, Codex, Antigravity) 모바일 콘솔입니다.\n\n어떤 작업을 지시하시겠습니까?\n아래 버튼을 터치하시거나 편하게 명령을 입력해 주세요!`,
        actions: [
          { label: '📁 프로젝트 파일', cmd: '파일' },
          { label: '💻 PC 시스템 상태', cmd: '상태' },
          { label: '⚡ 핵심 요약', cmd: '현재 작업 핵심만 3줄 요약해줘' },
          { label: '▶ 계속 진행', cmd: '작업 계속 진행해' }
        ]
      };
    }

    // 2. 파일 목록 조회
    if (/^(파일|폴더|디렉토리|file|dir|내용)/i.test(text)) {
      try {
        const items = fs.readdirSync(workDir);
        const filtered = items.filter(f => !f.startsWith('.') && f !== 'node_modules');
        const formatted = filtered.map(f => {
          try {
            const stat = fs.statSync(path.join(workDir, f));
            const icon = stat.isDirectory() ? '📁' : '📄';
            return `${icon} ${f}`;
          } catch (_) {
            return `📄 ${f}`;
          }
        }).slice(0, 20).join('\n');
        return {
          type: 'files',
          reply: `📁 [프로젝트 파일 목록]\n${formatted}\n\n(총 ${filtered.length}개 파일/폴더)`,
          actions: [
            { label: '📁 파일 탐색 탭 열기', tab: 'system' }
          ]
        };
      } catch (e) {
        return { type: 'chat', reply: `파일 목록 확인 오류: ${e.message}` };
      }
    }

    // 3. PC 시스템 상태 점검
    if (/상태|메모리|컴퓨터|pc|ram|사양|리소스/i.test(text)) {
      const freeMB = Math.round(os.freemem() / (1024 * 1024));
      const totalMB = Math.round(os.totalmem() / (1024 * 1024));
      const uptimeH = (os.uptime() / 3600).toFixed(1);
      return {
        type: 'system',
        reply: `💻 [PC 시스템 실시간 상태]\n• 컴퓨터 이름: ${os.hostname()}\n• 가동 시간: ${uptimeH}시간\n• CPU 코어: ${os.cpus().length} Cores\n• RAM 메모리: ${freeMB} MB 여유 / ${totalMB} MB 전체\n• 작업 디렉토리: ${workDir}`
      };
    }

    // 4. 도움말 및 기능 안내
    if (/도움|help|사용법|어떻게|뭐할수|무슨.*작업|할.*수.*있|기능|역할|명령/i.test(text)) {
      return {
        type: 'help',
        reply: `💡 [모바일 콘솔 핵심 기능 안내]\n\n1. Claude Code (Opus 5): 프로젝트 전체 조율·심층 분석·리팩터링 (대화 맥락 유지)\n2. Codex (GPT-5.6-terra): 고속 스크립트 작성 및 백그라운드 자동 코딩\n3. Antigravity (Gemini 3.8 Flash): 보조 코딩·파일 수정 (무인 자동 승인)\n4. 📁 파일 & 시스템: 작업 디렉토리 실시간 탐색, 모바일 코드 편집, PC 자원 모니터링\n5. 🖼️📎 사진/파일 업로드: 스마트폰 촬영 사진 및 문서를 PC로 즉시 전송\n\n명령창에 원하시는 작업 지시를 자유롭게 입력해 주세요!`,
        actions: [
          { label: '📁 파일 목록', cmd: '파일' },
          { label: '💻 시스템 상태', cmd: '상태' },
          { label: '⚡ 3줄 요약', cmd: '현재 작업 핵심만 3줄 요약해줘' },
          { label: '🛑 긴급 정지', cmd: '정지' }
        ]
      };
    }

    // 11. 임의의 한글 문장인 경우 → 메인 워커(Claude Code)로 전달
    if (/[가-힣]/.test(text)) {
      const taskFile = path.join(__dirname, 'tasks_from_mobile.json');
      try {
        let tasks = [];
        if (fs.existsSync(taskFile)) tasks = JSON.parse(fs.readFileSync(taskFile, 'utf8'));
        tasks.push({ time: new Date().toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' }), task: text });
        fs.writeFileSync(taskFile, JSON.stringify(tasks.slice(-100), null, 2), 'utf8');
      } catch (_) {}
      mainBridge.executeMainPrompt(text);
      return {
        type: 'chat',
        reply: `🤖 [Claude Code (Opus 5)에 전달 완료]\n\n지시 내용: "${text}"\n\n🎯 Claude Code 탭에서 실시간 진행 상황과 결과를 확인하세요.`,
        actions: [ { label: '🤖 Claude Code 탭 열기', tab: 'assistant' } ]
      };
    }

    // 12. 한글이 없으면 일반 CLI 터미널 명령어로 통과
    return null;
  }

  // 4. API: 명령어 / 자연어 실행
  if (pathname === '/api/exec' && req.method === 'POST') {
    if (!isAuthenticated) {
      res.writeHead(401, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: '인증이 필요합니다. 올바른 PIN 코드로 접속하세요.' }));
    }

    readRequestBody(req, 1048576, async (err, body) => { // 1MB 상한
      if (err) {
        res.writeHead(413, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: '명령어 크기 초과' }));
      }
      try {
        const { cmd } = JSON.parse(body);
        if (!cmd || typeof cmd !== 'string') {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          return res.end(JSON.stringify({ error: '명령어가 없습니다.' }));
        }
        // 감사 로그 + 안전 모드면 위험 명령 차단 (2026-09-21 보안)
        audit('exec', { ip: clientIp(req), mode: perm.getPermMode(), command: cmd });
        if (perm.isSafe()) {
          let why = null; try { why = require('./hooks/dangerous_cmd_block.js').isDangerous(cmd); } catch (_) {}
          if (why) {
            audit('hook_block', { tool: 'exec', why, command: cmd });
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
            return res.end(JSON.stringify({ success: false, output: '[원맥스 안전 모드] 이 명령은 실행하지 않습니다 — ' + why + '. 꼭 필요하면 ⚙ 설정에서 권한 모드를 자동 승인 모드로 바꾸세요(PIN 입력).', workDir: WORK_DIR, exitCode: 1 }));
          }
        }

        const trimmed = cmd.trim();

        // 🛡️ 위험 파괴 명령어 차단 가드 (포맷, 전체 삭제, 시스템 종료 등)
        const dangerousPatterns = [
          /format\s+[a-z]:/i,
          /del\s+(\/|\-)f\s+(\/|\-)s\s+(\/|\-)q/i,
          /rmdir\s+(\/|\-)s\s+(\/|\-)q\s+[a-z]:\\/i,
          /remove-item\s+.*-recurse.*[a-z]:\\/i,
          /shutdown/i,
          /diskpart/i
        ];
        if (dangerousPatterns.some(p => p.test(trimmed))) {
          res.writeHead(403, { 'Content-Type': 'application/json; charset=utf-8' });
          return res.end(JSON.stringify({ 
            error: '🛡️ 시스템 보안 정책에 의해 해당 위험 명령어 실행이 안전하게 차단되었습니다.', 
            exitCode: 1 
          }));
        }

        // 1) 스마트 자연어 인텐트 및 메인 워커 전달 검사
        const smartResult = await handleSmartIntent(trimmed, WORK_DIR);
        if (smartResult) {
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          return res.end(JSON.stringify({
            isSmart: true,
            smart: smartResult,
            workDir: WORK_DIR,
            exitCode: 0
          }));
        }

        // 2) 디렉토리 변경(cd) 특수 처리 (프로젝트 폴더 외부 탈출 원천 차단)
        if (trimmed.startsWith('cd ')) {
          const targetDir = trimmed.substring(3).trim();
          const targetPath = safeResolvePath(targetDir);
          if (targetPath && fs.existsSync(targetPath) && fs.statSync(targetPath).isDirectory()) {
            WORK_DIR = targetPath;
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
            return res.end(JSON.stringify({
              output: `디렉토리 변경: ${WORK_DIR}`,
              workDir: WORK_DIR,
              exitCode: 0
            }));
          } else {
            WORK_DIR = BASE_DIR; // 외부 이동 시도 시 기본 프로젝트 폴더로 보호
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
            return res.end(JSON.stringify({
              output: `경로를 찾을 수 없거나 프로젝트 작업 폴더 외부로 이동할 수 없습니다. (위치: ${WORK_DIR})`,
              workDir: WORK_DIR,
              exitCode: 0
            }));
          }
        }

        // 3) PowerShell 안전 실행 (UTF-8 인코딩 및 -EncodedCommand 사용으로 특수문자/한글 완벽 지원)
        const psCommand = `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; [Console]::InputEncoding = [System.Text.Encoding]::UTF8; $OutputEncoding = [System.Text.Encoding]::UTF8; ${trimmed}`;
        const encodedScript = Buffer.from(psCommand, 'utf16le').toString('base64');

        const proc = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encodedScript], {
          cwd: WORK_DIR,
          shell: false
        });

        activeExecChildren.add(proc);
        let output = '';
        currentProcess = proc;

        proc.stdout.on('data', data => { output += data.toString('utf8'); });
        proc.stderr.on('data', data => { output += data.toString('utf8'); });

        const timer = setTimeout(() => {
          if (activeExecChildren.has(proc)) {
            try {
              if (process.platform === 'win32') {
                const { execSync } = require('child_process');
                execSync(`taskkill /pid ${proc.pid} /T /F 2>nul || exit 0`, { shell: true });
              } else {
                proc.kill('SIGKILL');
              }
            } catch (_) {}
            activeExecChildren.delete(proc);
            output += '\n[시간 초과: 45초 경과로 프로세스를 중단했습니다]';
          }
        }, 45000);

        proc.on('close', code => {
          clearTimeout(timer);
          activeExecChildren.delete(proc);
          if (currentProcess === proc) currentProcess = null;
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
          res.end(JSON.stringify({
            output: output.length ? output : '(출력 결과 없음)',
            workDir: WORK_DIR,
            exitCode: code
          }));
        });

      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // 5. 프론트엔드 모바일 웹 콘솔 UI 제공
  if (pathname === '/' || pathname === '/index.html') {
    const headers = { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store, max-age=0', 'Pragma': 'no-cache' }; // 폰 브라우저·허브 iframe 이 옛 화면을 캐시하지 않게
    // ?pin= / ?token= 으로 정상 진입하면 세션 쿠키 발급 → 이후 /term·/term/ws 는 쿠키로 인증 (URL 토큰 불필요)
    const q = parsedUrl.searchParams.get('token') || parsedUrl.searchParams.get('pin') || '';
    if (q && (validTokens.has(q) || q === PIN_CODE)) headers['Set-Cookie'] = sessionCookieHeader(req, q);
    res.writeHead(200, headers);
    const appMode = parsedUrl.searchParams.get('app') === '1' || /ConsoleSystemApp|OneMACS/i.test(req.headers['user-agent'] || '');
    const embedMode = parsedUrl.searchParams.get('embed') === '1'; // 허브 페이지 iframe — 허브가 자기 맨 윗줄(ⓘ · 문구 · ⚙)을 가진다
    res.end(getMobileHtml({ app: appMode || embedMode }));
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not Found');
});

// 모바일 웹앱 HTML
const SHOW_SCANNER = fs.existsSync(path.join(BASE_DIR, 'scanner_web.py')); // 스캐너 버튼은 scanner_web.py 가 있는 프로젝트에서만
const DOC_FILES = { map: '파일관계도.html', flow: '신호체계_흐름도.html', setup: '설치안내_따라하기.html' };
const DOC_BTNS = [['map', '🧩', '관계도'], ['flow', '🔀', '흐름도'], ['setup', '📘', '설치 안내']];
const SHOW_DOCS = SHOW_SCANNER && fs.existsSync(path.join(BASE_DIR, 'docs')); // 안내 자료 버튼도 trader-bot 에서만
let PROJECT_TAB = null;
let PROJECT_TABS = []; // 도구 버튼 여러 개(project_tabs). project_tab(단수)는 그 첫 칸으로 취급한다.
try {
  const _c = JSON.parse(fs.readFileSync(path.join(__dirname, 'console_config.json'), 'utf8').replace(/^﻿/, ''));
  PROJECT_TABS = [].concat(_c.project_tab || [], _c.project_tabs || []).filter(t => t && (t.url || t.cmd));
  PROJECT_TAB = PROJECT_TABS[0] || null;
} catch (_) {}
function escapeAttr(v) { return String(v || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

function getMobileHtml(opt) {
  let html = getMobileHtmlRaw().replace(/Opus 5/g, WLBL.claude).replace(/GPT-5\.6-terra/g, WLBL.codex).replace(/Gemini 3\.8 Flash/g, WLBL.agy).replace(/grok-4\.6/g, WLBL.grok);
  // 앱(WebView) 안에서는 앱이 자기 맨 위 줄(? · 이름 · ⚙)을 가지므로 콘솔의 맨 위 줄을 그리지 않는다
  if (opt && opt.app) html = html.replace(/<!-- top-line:start -->[\s\S]*?<!-- top-line:end -->/, '');
  return html;
}
function getMobileHtmlRaw() {
  return `<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, interactive-widget=resizes-content">
<meta name="color-scheme" content="dark light">
<script>/* 저장된 테마를 CSS 보다 먼저 적용 — 깜빡임 방지 */(function(){try{var t=localStorage.getItem('theme');if(t==='light'||t==='dark')document.documentElement.setAttribute('data-theme',t);}catch(_){}})();</script>
<title>One MACS · 원맥스</title>
<link href="https://fonts.googleapis.com/css2?family=Pretendard:wght@400;600;700;800&family=Fira+Code:wght@400;500&display=swap" rel="stylesheet">
<style>
/* ===== 색 토큰 (2026-09-21 라이트 모드): 색은 여기서만 정의하고 [data-theme] 에서 값만 바꾼다 =====
   기본 = 시스템(prefers-color-scheme). 수동 선택(localStorage.theme = light|dark)은 <html data-theme> 로 덮는다 */
:root, :root[data-theme="dark"] {
  color-scheme: dark;
  --bg: #0b0e17;
  --surface: #131826;
  --card: #1c2237;
  --border: #2a3350;
  --accent: #4f7fff;
  --accent-light: #7097ff;
  --win: #10b981;
  --danger: #ef4444;
  --warn: #f59e0b;
  --text: #f1f5f9;
  --text-strong: #ffffff;
  --dim: #94a3b8;
  --dim2: #cbd5e1;
  --dim3: #e2e8f0;
  --hair: rgba(255,255,255,0.06);
  --hair2: rgba(255,255,255,0.08);
  --hair3: rgba(255,255,255,0.035);
  --hair4: rgba(255,255,255,0.14);
  --tab-bg-a: #273049; --tab-bg-b: #1a2136; --tab-border: #3a4667; --tab-shadow: #0d1120; --tab-shadow2: #0b0f1c;
  --input-bg: #111827; --input-bg-focus: #151d2f; --input-border: rgba(148,163,184,0.28); --placeholder: rgba(203,213,225,0.5);
  --user-bg: rgba(37,99,235,0.22); --user-text: #dbe4ff;
  --status-bg: rgba(16,185,129,0.08);
  --overlay-bg: rgba(11,14,23,0.98); --backdrop: rgba(0,0,0,0.7);
  --shadow: rgba(0,0,0,0.35); --shadow-strong: rgba(0,0,0,0.5);
  --notice-text: #fde68a; --notice-b: #fbbf24; --notice-bg: rgba(245,158,11,0.12); --notice-border: rgba(245,158,11,0.3);
  --fail-title: #fca5a5;
  --c-claude: #F2A48A; --c-codex: #3ED2A8; --c-agy: #8AB4F8; --c-grok: #D1D5DB;
  --sel-arrow: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path d='M1 1l4 4 4-4' fill='none' stroke='%2394a3b8' stroke-width='1.6'/></svg>");
}
:root[data-theme="light"] {
  color-scheme: light;
  --bg: #f3f5f9;
  --surface: #ffffff;
  --card: #e9edf4;
  --border: #cfd6e3;
  --accent: #2f5fe0;
  --accent-light: #2f5fe0;
  --win: #047857;
  --danger: #b91c1c;
  --warn: #b45309;
  --text: #111827;
  --text-strong: #0b1220;
  --dim: #566275;
  --dim2: #3f4a5c;
  --dim3: #1f2937;
  --hair: rgba(15,23,42,0.06);
  --hair2: rgba(15,23,42,0.08);
  --hair3: rgba(15,23,42,0.045);
  --hair4: rgba(15,23,42,0.14);
  --tab-bg-a: #ffffff; --tab-bg-b: #e6eaf2; --tab-border: #c5cddc; --tab-shadow: #b8c1d1; --tab-shadow2: #c9d1de;
  --input-bg: #ffffff; --input-bg-focus: #ffffff; --input-border: #b9c3d3; --placeholder: #7b8797;
  --user-bg: rgba(47,95,224,0.12); --user-text: #1e3a8a;
  --status-bg: rgba(4,120,87,0.08);
  --overlay-bg: rgba(243,245,249,0.98); --backdrop: rgba(15,23,42,0.45);
  --shadow: rgba(15,23,42,0.12); --shadow-strong: rgba(15,23,42,0.2);
  --notice-text: #7c3a00; --notice-b: #92400e; --notice-bg: rgba(245,158,11,0.16); --notice-border: rgba(180,83,9,0.35);
  --fail-title: #b91c1c;
  --c-claude: #b8532f; --c-codex: #0e7a5c; --c-agy: #2e63c9; --c-grok: #4b5563;
  --sel-arrow: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path d='M1 1l4 4 4-4' fill='none' stroke='%23566275' stroke-width='1.6'/></svg>");
}
@media (prefers-color-scheme: light) {
  :root:not([data-theme="dark"]) {
    color-scheme: light;
    --bg: #f3f5f9; --surface: #ffffff; --card: #e9edf4; --border: #cfd6e3;
    --accent: #2f5fe0; --accent-light: #2f5fe0; --win: #047857; --danger: #b91c1c; --warn: #b45309;
    --text: #111827; --text-strong: #0b1220; --dim: #566275; --dim2: #3f4a5c; --dim3: #1f2937;
    --hair: rgba(15,23,42,0.06); --hair2: rgba(15,23,42,0.08); --hair3: rgba(15,23,42,0.045); --hair4: rgba(15,23,42,0.14);
    --tab-bg-a: #ffffff; --tab-bg-b: #e6eaf2; --tab-border: #c5cddc; --tab-shadow: #b8c1d1; --tab-shadow2: #c9d1de;
    --input-bg: #ffffff; --input-bg-focus: #ffffff; --input-border: #b9c3d3; --placeholder: #7b8797;
    --user-bg: rgba(47,95,224,0.12); --user-text: #1e3a8a;
    --status-bg: rgba(4,120,87,0.08);
    --overlay-bg: rgba(243,245,249,0.98); --backdrop: rgba(15,23,42,0.45);
    --shadow: rgba(15,23,42,0.12); --shadow-strong: rgba(15,23,42,0.2);
    --notice-text: #7c3a00; --notice-b: #92400e; --notice-bg: rgba(245,158,11,0.16); --notice-border: rgba(180,83,9,0.35);
    --fail-title: #b91c1c;
    --c-claude: #b8532f; --c-codex: #0e7a5c; --c-agy: #2e63c9; --c-grok: #4b5563;
    --sel-arrow: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path d='M1 1l4 4 4-4' fill='none' stroke='%23566275' stroke-width='1.6'/></svg>");
  }
}
/* 화면 테마 전환은 ⚙ 콘솔 설정 패널(8번 항목)에서 — 단독 버튼 없음 */
* { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
html, body {
  background: var(--bg);
  color: var(--text);
  font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, sans-serif;
  height: 100%;
  height: 100dvh;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* 최상단 듀얼 PC 원터치 탭 스위처 바 */
.pc-switch-bar {
  display: flex;
  background: var(--surface);
  border-bottom: 1.5px solid var(--border);
  padding: 6px 10px;
  gap: 6px;
  flex-shrink: 0;
  z-index: 100;
}
.pc-nav-tab {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background: var(--hair3);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 7px 10px;
  color: var(--dim);
  font-size: 12.5px;
  font-weight: 700;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.15s ease;
}
.pc-nav-tab.active {
  background: var(--user-bg);
  border-color: var(--accent-light);
  color: var(--text-strong);
  box-shadow: 0 0 10px rgba(37,99,235,0.3);
}
.pc-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--dim);
  flex-shrink: 0;
}
.pc-dot.online {
  background: var(--win);
  box-shadow: 0 0 6px var(--win);
}

/* 상단 헤더 */
.top-bar {
  background: var(--surface);
  border-bottom: 0; /* 테두리 규칙: 구역은 배경색 차이로만 구분 */
  padding: 0 12px;
  height: 44px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-shrink: 0;
}
.brand {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 14px;
  font-weight: 800;
  color: var(--text-strong);
  white-space: nowrap;
}
.brand-tag {
  font-size: 11px;
  color: var(--accent-light);
  font-weight: 700;
  letter-spacing: 0.2px;
}
.status-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--win);
  display: inline-block;
  box-shadow: 0 0 6px var(--win);
}
.top-bar-right {
  display: flex;
  align-items: center;
  gap: 6px;
}
.btn-pc-switch {
  background: var(--hair2);
  border: 1px solid var(--border);
  color: var(--dim2);
  text-decoration: none;
  font-size: 11px;
  font-weight: 700;
  padding: 3px 8px;
  border-radius: 8px;
}
.btn-pc-switch:active {
  background: var(--accent);
  color: var(--text-strong);
}

/* 탭 메뉴 — 버튼형 (눌리는 느낌) */
/* 맨 꼭대기 줄(PC 브라우저 전용, 44px): [?] One MACS · 원맥스 [⚙] — AI 탭 줄에는 아무것도 두지 않는다(PO) */
.top-line { display: flex; align-items: center; justify-content: space-between; gap: 8px; height: 44px; padding: 0 8px; background: var(--surface); flex-shrink: 0; }
.top-side { flex: 0 0 44px; width: 44px; height: 44px; border: 0; border-radius: 10px; background: var(--hair2); color: var(--dim2); font-size: 18px; font-weight: 800; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
.top-side:active { background: var(--accent); color: #fff; }
/* 맨 윗줄 문구(PO 확정): "One-stop Multi AI Console System" 대소문자 그대로(uppercase 변환 금지), 보라→파랑 그라데이션 글자, 한 줄. 안 들어가면 글자 크기만 줄인다 */
.top-title { flex: 1 1 auto; min-width: 0; text-align: center; font-size: clamp(14px, 3.9vw, 15.5px); line-height: 1; font-weight: 600; letter-spacing: .02em; white-space: nowrap; overflow: visible; background: linear-gradient(90deg, #a855f7 0%, #60a5fa 60%, #38bdf8 100%); -webkit-background-clip: text; background-clip: text; color: transparent; }
/* 문구 크기(PO 정본 2026-09-21): clamp(14px,3.9vw,15.5px)·600·자간 .02em 고정 — index.html·hub_page.js·앱과 동일 */
/* AI 탭 줄: 탭만 (가로 스크롤) */
.tabs-row { display: flex; align-items: center; gap: 4px; padding: 7px 6px 8px; background: var(--surface); flex-shrink: 0; }
.tabs {
  display: flex;
  gap: 5px;
  flex: 1 1 auto; min-width: 0;
  overflow-x: auto; overflow-y: hidden; scrollbar-width: none; -webkit-overflow-scrolling: touch;
  padding: 0; align-items: flex-start;
  background: var(--surface);
  border-bottom: 0; /* 테두리 규칙 */
  flex-shrink: 1;
}
.tabs::-webkit-scrollbar { display: none; }
.tabs .tab-btn { flex: 0 0 auto; min-width: 96px; }
/* 탭 소제목 = 현재 모델 표시만 (변경은 ⚙ 설정에서) */
/* ⚙ 콘솔 설정 패널 (아래에서 올라오는 시트, 폰 폭 우선) — 맨 꼭대기 줄 ⚙ 로 연다 */
.sheet-backdrop { position: fixed; inset: 0; background: var(--backdrop); z-index: 10001; display: none; }
.sheet-backdrop.open { display: block; }
.sheet { position: fixed; left: 0; right: 0; bottom: 0; max-height: 94vh; overflow-y: auto; background: var(--surface); border-radius: 18px 18px 0 0; z-index: 10002; padding: 10px 16px calc(16px + env(safe-area-inset-bottom, 0px)); display: none; box-shadow: 0 -10px 30px var(--shadow-strong); }
.sheet.open { display: block; }
.sheet h2 { font-size: 16px; font-weight: 800; color: var(--text-strong); margin: 6px 0 4px; display: flex; align-items: center; justify-content: space-between; }
.sheet .sheet-close { border: 0; background: var(--hair2); color: var(--dim2); width: 44px; height: 44px; border-radius: 10px; font-size: 18px; cursor: pointer; }
.sheet .sheet-note { font-size: 12px; color: var(--dim); margin: 0 0 8px; }
.srow { display: flex; align-items: center; justify-content: space-between; gap: 10px; min-height: 46px; padding: 5px 0; }
.srow + .srow { box-shadow: inset 0 1px 0 var(--hair); }
.srow .sl { font-size: 14.5px; font-weight: 700; color: var(--text); min-width: 0; }
.srow .sl small { display: block; font-size: 11.5px; font-weight: 500; color: var(--dim); margin-top: 2px; }
.srow .sc { flex-shrink: 0; display: flex; align-items: center; gap: 6px; }
.sel-plain { appearance: none; -webkit-appearance: none; background: var(--hair2) var(--sel-arrow) no-repeat right 9px center; border: 0; border-radius: 10px; color: var(--text); font-size: 13.5px; font-weight: 700; padding: 0 26px 0 10px; height: 40px; min-width: 120px; max-width: 200px; cursor: pointer; }
.seg { display: inline-flex; background: var(--hair2); border-radius: 10px; padding: 3px; }
.seg button { border: 0; background: transparent; color: var(--dim2); font-size: 13px; font-weight: 700; min-height: 34px; padding: 0 12px; border-radius: 8px; cursor: pointer; }
.seg button.on { background: var(--accent); color: #fff; }
.tog { position: relative; width: 38px; height: 22px; border-radius: 11px; border: 0; background: var(--hair4); cursor: pointer; flex-shrink: 0; transition: background .18s ease; }
.tog::after { content: ''; position: absolute; top: 3px; left: 3px; width: 16px; height: 16px; border-radius: 50%; background: #fff; transition: left .18s ease; box-shadow: 0 1px 2px rgba(0,0,0,.25); }
.tog.on { background: #2a8f52; }   /* 더 가라앉힌 초록 (PO 2026-09-23: 「너무 커서 투박해」) */
.tog.on::after { left: 19px; }   /* 폭 38 − 손잡이 16 − 여백 3. 크기를 바꾸면 이 값도 같이 바꿔야 한다 */
.num-row { display: flex; align-items: center; gap: 6px; }
.num-row button { width: 40px; height: 40px; border: 0; border-radius: 10px; background: var(--hair2); color: var(--text); font-size: 18px; font-weight: 800; cursor: pointer; }
.num-row button:disabled { opacity: .35; }
.num-row span { min-width: 56px; text-align: center; font-size: 14px; font-weight: 700; color: var(--text); }
.sheet .saved { font-size: 12px; color: var(--win); font-weight: 700; min-height: 16px; margin-top: 6px; }
.srow-stack { flex-direction: column; align-items: stretch; gap: 6px; }
.srow-stack .sc { justify-content: flex-start; }
.szone { border-radius: 14px; padding: 4px 12px 6px; margin: 6px 0 8px; border-left: 4px solid var(--zone); background: var(--zone-bg); }
.szone-phone { --zone: #22c55e; --zone-bg: rgba(34,197,94,.08); }
.szone-pc { --zone: #4f7fff; --zone-bg: rgba(79,127,255,.08); }
.szone-head { display: flex; flex-direction: column; gap: 2px; padding: 8px 0 6px; }
.szone-head b { font-size: 15px; font-weight: 800; color: var(--zone); }
.szone-head span { font-size: 12.5px; color: var(--dim); font-weight: 600; }
.szone .srow + .srow { box-shadow: inset 0 1px 0 var(--hair); }
.pin-row { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
.pin-in { flex: 1 1 96px; min-width: 0; max-width: 140px; height: 40px; border-radius: 10px; border: 1.5px solid var(--border); background: var(--hair2); color: var(--text); font-size: 15px; font-weight: 700; padding: 0 10px; letter-spacing: 2px; }
.pin-btn { height: 40px; padding: 0 12px; border: 0; border-radius: 10px; background: var(--accent); color: #fff; font-size: 13.5px; font-weight: 800; cursor: pointer; }
.pin-btn.ghost { background: var(--hair2); color: var(--text); }
.tab-btn {
  flex: 1 1 0; min-width: 0;
  min-height: 48px; /* 엄지 터치 타깃 48px */
  padding: 7px 2px 6px;
  text-align: center;
  font-size: 12px;
  font-weight: 800;
  color: var(--dim2);
  background: linear-gradient(180deg, var(--tab-bg-a) 0%, var(--tab-bg-b) 100%);
  border: 1px solid var(--tab-border);
  border-bottom: 3px solid var(--tab-shadow);
  border-radius: 10px;
  box-shadow: 0 3px 0 var(--tab-shadow2), 0 4px 8px var(--shadow-strong), inset 0 1px 0 var(--hair2);
  cursor: pointer;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
  transition: transform 0.08s, box-shadow 0.08s, background 0.15s, color 0.15s;
  line-height: 1.25;
}
.tab-btn:active {
  transform: translateY(3px);
  box-shadow: 0 0 0 var(--tab-shadow2), 0 1px 3px var(--shadow), inset 0 2px 4px var(--shadow-strong);
  border-bottom-width: 1px;
}
.tab-btn.active {
  color: #fff;
  background: linear-gradient(180deg, #3d6bff 0%, #2f55d6 100%);
  border-color: #6b93ff;
  border-bottom: 1px solid #1d3a99;
  transform: translateY(3px);
  box-shadow: 0 0 0 var(--tab-shadow2), inset 0 2px 5px var(--shadow), 0 0 0 1px rgba(79,127,255,0.35);
}
.tab-btn.active .tab-sub { color: var(--user-text) !important; }
.tab-sub {
  font-size: 9.5px;
  font-weight: 700;
  margin-top: 2px;
  letter-spacing: -0.2px;
}

/* 테두리 규칙(2026-09-21): 테두리는 입력창(.composer-input)·선택된 탭(.tab-btn.active/.strat-tab.active)·경고(.chip-stop:active, #pinError 등) 3곳만.
   선택되지 않은 탭·도구 버튼은 테두리를 투명으로 두어 크기·입체감만 유지한다 */
.tab-btn:not(.active), .strat-tab:not(.active) { border-color: transparent; }
.tab-btn.hdr-btn:not(.active), .tab-btn.hdr-btn.hdr-tool:not(.active) { border-color: transparent; }
/* 헤더 우측 프로젝트 버튼 (탭 버튼과 동일 입체감, 소형) */
.brand { min-width: 0; overflow: hidden; }
.brand > span:not(.brand-tag) { flex-shrink: 0; }
.brand-tag { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.top-bar-right { flex-shrink: 0; }
.top-bar-left { display: flex; align-items: center; flex-shrink: 0; gap: 8px; }
/* 브랜드 마크: One MACS · 원맥스 — 표시 전용(버튼 아님) */
.top-bar { height: auto; min-height: 44px; padding: 5px 10px; }
.top-bar.empty { display: none; } /* 프로젝트 선택기·도구 버튼이 하나도 없으면 행 자체를 없앤다 (updateTopBar) */
.top-bar-right { gap: 5px; }
.tab-btn.hdr-btn { flex: 0 0 auto; min-width: 60px; min-height: 34px; padding: 5px 10px 4px; font-size: 12px; line-height: 1.2; display: inline-flex; flex-direction: column; align-items: center; justify-content: center; }
.tab-btn.hdr-btn .tab-sub { font-size: 9px; margin-top: 2px; }
.tab-btn.hdr-btn:not(.active) { background: linear-gradient(180deg, #1f3a33 0%, #162a26 100%); border-color: #2f6b5b; color: #a7f3d0; }
.tab-btn.hdr-btn.active { background: linear-gradient(180deg, var(--win) 0%, #0b8f63 100%); border-color: #34d399; border-bottom-color: #065f46; box-shadow: 0 0 0 var(--tab-shadow2), inset 0 2px 5px var(--shadow), 0 0 0 1px rgba(16,185,129,0.35); }
.tab-btn.hdr-btn.active .tab-sub { color: #d1fae5 !important; }
@media (max-width: 380px) { .brand { font-size: 13px; gap: 5px; } .tab-btn.hdr-btn { min-width: 54px; padding: 4px 8px 3px; font-size: 11px; } }

/* 프로젝트 선택기 (라우터 모드) */
#projSel { display: none; position: relative; align-items: center; gap: 5px; }
#projSel.on { display: inline-flex; }
.proj-menu { position: absolute; top: 110%; left: 0; z-index: 9999; min-width: 240px; background: var(--card); border: 1px solid var(--border); border-radius: 12px; box-shadow: 0 12px 30px var(--shadow-strong); padding: 6px; display: none; }
.proj-menu.open { display: block; }
.proj-item { display: flex; align-items: center; gap: 10px; padding: 15px 12px; min-height: 48px; border-radius: 10px; font-size: 14px; font-weight: 700; color: var(--dim3); cursor: pointer; }
.proj-item:active { background: rgba(79,127,255,0.25); }
.proj-item.cur { background: rgba(79,127,255,0.14); color: var(--text-strong); }
.proj-item .pdot { width: 8px; height: 8px; border-radius: 50%; background: #475569; flex-shrink: 0; }
.proj-item .pdot.on { background: var(--win); box-shadow: 0 0 6px var(--win); }
.proj-item .psub { margin-left: auto; font-size: 10px; color: var(--dim); font-weight: 600; }
/* 2026-09-22 ④ 프로젝트 관리: 홈/1번 배지, 항목 ⋯ 버튼, 추가·관리 바텀시트 (허브 iframe 안에서 window.prompt 가 막혀 시트로) */
.proj-item .pbadge { font-size: 10px; font-weight: 800; padding: 2px 6px; border-radius: 6px; background: var(--hair2); color: var(--dim2); flex-shrink: 0; }
.proj-item .pbadge.home { background: rgba(245,158,11,0.18); color: #fbbf24; }
.proj-item .pbadge.pri { background: rgba(16,185,129,0.18); color: #34d399; }
.proj-item .pmore { margin-left: 4px; width: 36px; height: 36px; border: 0; border-radius: 8px; background: transparent; color: var(--dim2); font-size: 18px; font-weight: 800; flex-shrink: 0; cursor: pointer; }
.proj-item .pmore:active { background: var(--hair2); }
.proj-item .pname { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.pj-opt { display: flex; flex-direction: column; align-items: flex-start; gap: 2px; width: 100%; min-height: 64px; padding: 10px 14px; margin: 8px 0; border: 1px solid var(--hair); border-radius: 12px; background: var(--card); color: var(--text); text-align: left; font-size: 15px; font-weight: 800; cursor: pointer; }
.pj-opt small { display: block; font-size: 12px; font-weight: 500; color: var(--dim); margin-top: 3px; }
.pj-opt:disabled { opacity: .45; }
.pj-opt.danger { color: #f87171; }
.pj-path { font-size: 12px; color: var(--dim); word-break: break-all; margin: 4px 0 8px; }
.pj-bar { display: flex; gap: 8px; align-items: center; margin: 6px 0 8px; flex-wrap: wrap; }
.pj-bar button { border: 0; border-radius: 10px; background: var(--hair2); color: var(--text); font-size: 13px; font-weight: 700; min-height: 40px; padding: 0 12px; cursor: pointer; }
.pj-bar button.go { background: var(--accent); color: #fff; }
.pj-bar button:disabled { opacity: .4; }
.pj-list { max-height: 44vh; overflow-y: auto; border: 1px solid var(--hair); border-radius: 12px; }
.pj-row { display: flex; align-items: center; gap: 10px; min-height: 52px; padding: 6px 12px; font-size: 14px; color: var(--text); cursor: pointer; }
.pj-row + .pj-row { box-shadow: inset 0 1px 0 var(--hair); }
.pj-row:active { background: var(--hair2); }
.pj-row .pj-nm { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 700; }
.pj-row .pj-tag { margin-left: auto; font-size: 10.5px; color: var(--dim); white-space: nowrap; flex-shrink: 0; }
.pj-row.blocked { opacity: .5; }
.pj-in { width: 100%; box-sizing: border-box; min-height: 44px; border: 1px solid var(--hair); border-radius: 10px; background: var(--card); color: var(--text); font-size: 15px; padding: 8px 12px; margin: 4px 0 8px; }
.pj-msg { font-size: 13px; min-height: 18px; margin: 6px 0; color: var(--dim2); }
.pj-msg.err { color: #f87171; font-weight: 700; }
.pj-msg.ok { color: var(--win); font-weight: 700; }
.pj-chk { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--dim2); margin: 8px 0; }
.proj-add { border-top: 1px solid var(--border); margin-top: 4px; padding-top: 6px; color: #93c5fd; }

/* AI 탭 브랜드 색 (선택 탭 배경 = 그 회사 색, 모델명 = 그 회사 색의 밝은 톤) */
.tab-btn.w-claude .tab-sub { color: var(--c-claude); }
.tab-btn.w-codex .tab-sub { color: var(--c-codex); }
.tab-btn.w-agy .tab-sub { color: var(--c-agy); }
.tab-btn.w-grok .tab-sub { color: var(--c-grok); }
.tab-btn.w-claude.active { background: linear-gradient(180deg, #E48D6E 0%, #C9643F 100%); border-color: #F2A48A; border-bottom-color: #8F4426; box-shadow: 0 0 0 var(--tab-shadow2), inset 0 2px 5px var(--shadow), 0 0 0 1px rgba(217,119,87,0.4); }
.tab-btn.w-codex.active { background: linear-gradient(180deg, #17B58C 0%, #0B8A69 100%); border-color: #3ED2A8; border-bottom-color: #085C46; box-shadow: 0 0 0 var(--tab-shadow2), inset 0 2px 5px var(--shadow), 0 0 0 1px rgba(16,163,127,0.4); }
.tab-btn.w-agy.active { background: linear-gradient(135deg, #4285F4 0%, #9B72CB 100%); border-color: #8AB4F8; border-bottom-color: #2B4FA0; box-shadow: 0 0 0 var(--tab-shadow2), inset 0 2px 5px var(--shadow), 0 0 0 1px rgba(66,133,244,0.4); }
.tab-btn.w-grok.active { background: linear-gradient(180deg, #F9FAFB 0%, #D1D5DB 100%); border-color: #ffffff; border-bottom-color: #6B7280; color: var(--input-bg); box-shadow: 0 0 0 var(--tab-shadow2), inset 0 2px 5px var(--shadow), 0 0 0 1px rgba(255,255,255,0.35); }
.tab-btn.w-grok.active .tab-sub { color: #374151 !important; }
.tab-btn.active:not(.w-grok) .tab-sub { color: #fff !important; opacity: 0.92; }

/* 도구 버튼(스캐너·프로젝트 사이트): 프로젝트 선택기(초록)와 구분 — 하늘색 계열 */
.tab-btn.hdr-btn.hdr-tool:not(.active) { background: linear-gradient(180deg, #1c3550 0%, #14283d 100%); border-color: #2f6b93; color: #bae6fd; }
.tab-btn.hdr-btn.hdr-tool .tab-sub { color: #7dd3fc !important; }
.tab-btn.hdr-btn.hdr-tool.active { background: linear-gradient(180deg, #38bdf8 0%, #0284c7 100%); border-color: #7dd3fc; border-bottom-color: #075985; color: var(--text-strong); box-shadow: 0 0 0 var(--tab-shadow2), inset 0 2px 5px var(--shadow), 0 0 0 1px rgba(56,189,248,0.35); }
.tab-btn.hdr-btn.hdr-tool.active .tab-sub { color: #e0f2fe !important; }
/* 안내 자료 버튼 3개 — 트레이딩 시그널 ▾ 와 스캐너 사이 빈칸에 들어가도록 좁게 (PO 2026-09-23) */
.tab-btn.hdr-btn.hdr-doc { min-width: 44px; padding-left: 6px; padding-right: 6px; font-size: 14px; }
.tab-btn.hdr-btn.hdr-doc .tab-sub { font-size: 9px; white-space: nowrap; }
#docOverlay { position: fixed; inset: 0; z-index: 9999; background: var(--bg, #0b0f17); display: none; flex-direction: column; }
#docOverlay.on { display: flex; }
#docOverlay .doc-head { display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; background: var(--surface); color: var(--text-strong); font-weight: 800; font-size: 14px; }
#docOverlay .doc-head button { background: transparent; border: 0; color: var(--text-strong); font-size: 20px; min-width: 44px; min-height: 44px; }
#docOverlay iframe { flex: 1; width: 100%; border: 0; background: #fff; }

/* 스캐너 전략 탭 */
.strat-tab { flex: 0 0 auto; padding: 7px 11px; border-radius: 10px; font-size: 12px; font-weight: 800; color: var(--dim2); background: linear-gradient(180deg, var(--tab-bg-a) 0%, var(--tab-bg-b) 100%); border: 1px solid var(--tab-border); border-bottom: 3px solid var(--tab-shadow); cursor: pointer; white-space: nowrap; display: inline-flex; align-items: center; gap: 6px; }
.strat-tab.active { color: #fff; background: linear-gradient(180deg, var(--win) 0%, #0b8f63 100%); border-color: #34d399; border-bottom: 1px solid #065f46; transform: translateY(2px); }
.strat-tab.off { opacity: 0.45; }
.strat-tab .cnt { font-size: 10.5px; padding: 1px 6px; border-radius: 8px; background: var(--hair4); }
.strat-row { display: flex; justify-content: space-between; align-items: center; background: var(--hair3); border: 1px solid var(--border); border-radius: 8px; padding: 8px 10px; font-size: 12.5px; }
.strat-switch { white-space: nowrap; flex-shrink: 0; margin-left: 8px; font-size: 11px; font-weight: 700; padding: 4px 9px; border-radius: 8px; border: 1px solid var(--border); background: var(--hair); color: var(--dim2); cursor: pointer; }
.strat-switch.on { background: rgba(16,185,129,0.18); border-color: var(--win); color: #6ee7b7; }

/* 선택형 질문 보기 버튼 */
.ask-opt { text-align: left; font-family: -apple-system, BlinkMacSystemFont, 'Pretendard', 'Segoe UI', sans-serif; font-size: 12px; color: var(--dim3); background: linear-gradient(180deg, var(--tab-bg-a) 0%, var(--tab-bg-b) 100%); border: 1px solid var(--tab-border); border-bottom: 3px solid var(--tab-shadow); border-radius: 9px; padding: 8px 10px; cursor: pointer; display: flex; flex-direction: column; gap: 2px; }
.ask-opt span { color: var(--dim); font-size: 10.5px; font-weight: 500; }
.ask-opt:active { transform: translateY(2px); border-bottom-width: 1px; background: var(--accent); color: #fff; }
.ask-opt:disabled { opacity: 0.45; cursor: default; }
.ask-opt.ask-mini { flex: 1; align-items: center; padding: 6px 4px; font-weight: 700; }

/* 메인 뷰 컨테이너 */
.view { flex: 1; min-height: 0; display: none; flex-direction: column; overflow: hidden; }
.view.active { display: flex; }

/* 1. 대화형 AI 뷰 (Claude Code & Codex & Antigravity 공통 적용) */
#chatContainer, #codexChatContainer, #agyChatContainer, #grokChatContainer {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.msg-bubble {
  max-width: 88%;
  padding: 12px 15px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.55;
  word-break: break-word;
}
/* 내 말: 작고 옅게 (AI 답이 주인공) — 폭 80%, 13.5px, 파랑 20% 톤 */
.msg-user {
  align-self: flex-end;
  max-width: 80%;
  padding: 9px 13px;
  background: var(--user-bg);
  color: var(--user-text);
  font-size: 13.5px;
  border-bottom-right-radius: 4px;
}
/* AI 답: 테두리 상자 대신 왼쪽 3px 브랜드 선만 (border-color 인라인이 있으면 그 색이 선 색이 된다) */
.msg-ai {
  align-self: flex-start;
  max-width: 94%;
  background: var(--hair3);
  border: 0;
  border-left: 3px solid var(--c-claude);
  border-radius: 6px 12px 12px 6px;
  color: var(--text);
  font-size: 15px;
}
.msg-title {
  font-weight: 700;
  font-size: 14px;
  color: var(--c-claude);
  margin-bottom: 6px;
}
.msg-body {
  white-space: pre-wrap;
}
.msg-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 10px;
}
.action-btn {
  background: rgba(79,127,255,0.15);
  border: 1px solid var(--accent);
  color: var(--text-strong);
  padding: 6px 12px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.action-btn.primary {
  background: var(--accent);
}

/* 단순화 모드 & 메시지 접기 스타일 */
.fold-btn {
  font-size: 11px;
  color: var(--accent-light);
  font-weight: 700;
  cursor: pointer;
  background: rgba(79,127,255,0.14);
  padding: 3px 8px;
  border-radius: 12px;
  border: 0;
  transition: all 0.2s;
  user-select: none;
}
.fold-btn:active {
  background: var(--accent);
  color: var(--text-strong);
}
.collapsed-body {
  max-height: 125px;
  overflow: hidden;
  position: relative;
  mask-image: linear-gradient(to bottom, black 60%, transparent 100%);
  -webkit-mask-image: linear-gradient(to bottom, black 60%, transparent 100%);
}
.history-banner {
  text-align: center;
  padding: 6px 0 12px;
  flex-shrink: 0;
}
.history-toggle-btn {
  background: var(--hair);
  border: 0;
  color: var(--dim);
  font-size: 11.5px;
  font-weight: 600;
  padding: 5px 14px;
  border-radius: 20px;
  cursor: pointer;
}
.history-toggle-btn:active {
  background: rgba(79,127,255,0.18);
  color: var(--text-strong);
}
.mode-switch-btn {
  font-size: 11px;
  padding: 3px 9px;
  border-radius: 12px;
  border: 0;
  background: var(--hair);
  color: var(--dim);
  cursor: pointer;
  font-weight: 700;
  transition: all 0.2s;
}
.mode-switch-btn.active {
  background: rgba(16,185,129,0.18);
  color: var(--win);
  border-color: var(--win);
}

/* 보기 모드(요약/상세/전체) — 상태줄 오른쪽 드롭다운 한 칸. 한 번 정하면 잘 안 바꾸는 설정이라 버튼 줄을 차지하지 않는다 */
.status-line { padding: 0 12px; height: 24px; min-height: 24px; line-height: 1; font-size: 11px; display: flex; align-items: center; justify-content: space-between; gap: 8px; flex-shrink: 0; border-bottom: 0 !important; }
.status-line > span:first-child { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.mode-sel {
  appearance: none; -webkit-appearance: none;
  background: var(--hair2) var(--sel-arrow) no-repeat right 7px center;
  border: 0; border-radius: 8px;
  color: var(--dim2); font-size: 11.5px; font-weight: 700;
  padding: 0 20px 0 8px; height: 18px; min-height: 18px; line-height: 18px;
  cursor: pointer; flex-shrink: 0;
}
.mode-sel:focus { outline: 1px solid var(--accent); }
/* 답 표시 방식 커스텀 펼침 메뉴 (PO 2026-09-22): 표준 <select> 는 안드로이드가 큰 기본 선택창을 띄워 어색 → 버튼 44px + 다크 팝오버.
   #chatModeSel 은 값·저장 로직 호환을 위해 숨긴 채 유지한다 */
.status-line.status-line--tall { height: 44px; min-height: 44px; }
.mode-menu { position: relative; flex-shrink: 0; }
.mode-menu-btn {
  /* PO 2026-09-22: "선택 버튼이라는 느낌이 안 든다" → 알약형 버튼(배경·테두리·'보기' 접두·굵은 ▾)으로 도드라지게 */
  height: 36px; min-height: 36px; margin: 4px 0; padding: 0 10px 0 12px; border: 1.5px solid var(--border); border-radius: 18px;
  background: var(--card); color: var(--text); font-size: 15px; font-weight: 800; line-height: 34px;
  display: inline-flex; align-items: center; gap: 6px; cursor: pointer; -webkit-tap-highlight-color: transparent;
  box-shadow: 0 1px 2px rgba(0,0,0,.18);
}
.mode-menu-btn .pre { font-size: 12px; font-weight: 600; color: var(--dim); }
.mode-menu-btn:active { background: var(--hair2); }
.mode-menu-btn[aria-expanded="true"] { border-color: var(--accent); }
.mode-menu-btn .caret { font-size: 15px; color: var(--accent); font-weight: 900; }
.mode-menu-pop {
  position: absolute; right: 0; top: calc(100% + 2px); width: 140px; padding: 5px; z-index: 60;
  background: var(--card); color: var(--text); border: 1px solid var(--border); border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,.35); display: none;
}
.mode-menu-pop[data-open="1"] { display: block; }
.mode-menu-item {
  height: 40px; line-height: 40px; padding: 0 10px; border-radius: 8px; font-size: 15px; font-weight: 600;
  display: flex; align-items: center; justify-content: space-between; cursor: pointer; color: var(--text);
}
.mode-menu-item:hover, .mode-menu-item:focus-visible { background: var(--hair2); outline: none; }
.mode-menu-item .chk { width: 18px; text-align: right; color: var(--accent); font-weight: 800; }
/* 키보드 포커스 링: outline 만 사용한다 (border 는 테두리 규칙 3곳에만) */
:focus-visible { outline: 2px solid var(--accent-light); outline-offset: 2px; }
.tab-btn:focus-visible, .chip:focus-visible, .btn-send:focus-visible, .btn-file-label:focus-visible, .mode-sel:focus-visible { outline: 2px solid var(--accent-light); outline-offset: 2px; }
.composer-input:focus-visible { outline: 2px solid var(--accent-light); outline-offset: 0; }

/* 빠른 추천 칩 (Chips) 바 */
.fail-card { border-color: rgba(248,113,113,0.45) !important; background: rgba(248,113,113,0.06) !important; }
.fail-title { color:var(--fail-title); font-weight:700; font-size:13.5px; }
.fail-hint { color:var(--dim2); font-size:12.5px; margin-top:4px; }
.fail-actions { display:flex; gap:6px; margin-top:8px; flex-wrap:wrap; }
.fail-chip { display:inline-flex; align-items:center; padding:5px 10px; border-radius:14px; font-size:12px; font-weight:700; cursor:pointer; border:1px solid var(--hair4); background:var(--hair); color:var(--dim3); }
.fail-chip.primary { background:rgba(16,185,129,0.18); border-color:var(--win); color:#a7f3d0; }
.fail-detail { margin-top:8px; font-size:11px; color:var(--dim); }
.fail-detail summary { cursor:pointer; user-select:none; }
.fail-detail pre { margin:6px 0 0; white-space:pre-wrap; word-break:break-all; font-size:10.5px; line-height:1.4; max-height:160px; overflow:auto; background:var(--shadow); padding:6px 8px; border-radius:4px; color:var(--dim); }
.chips-bar {
  background: var(--bg);
  border-top: 0; /* 테두리 규칙 */
  padding: 8px 12px;
  display: flex;
  gap: 8px;
  overflow-x: auto;
  white-space: nowrap;
  flex-shrink: 0;
}
.chip {
  background: var(--card);
  border: 0;
  color: var(--dim);
  font-size: 12.5px;
  min-height: 36px; /* 터치 타깃 ≥36px */
  display: inline-flex; align-items: center;
  padding: 0 14px;
  border-radius: 18px;
  cursor: pointer;
  font-weight: 600;
  flex-shrink: 0;
}
.chip:active { background: var(--accent); color: #fff; }

/* 🛑 긴급 정지 칩 — 평소엔 다른 칩과 같은 중립 모양(상태처럼 보이지 않게), 누를 때만 빨강 */
.chip-stop {
  margin-left: 0; /* 칩 줄 맨 앞(첫 칩) — 스크롤 없이 항상 보이게. 입력창 옆 고정은 금지(PO) */
  background: var(--card);
  border: 0;
  color: var(--dim);
  font-weight: 600;
}
.chip-stop:active {
  background: #dc2626;
  border-color: #dc2626;
  color: var(--text-strong);
}

/* ⏩ 계속 진행 칩 — 중립 모양, 아이콘만 하늘색. 누를 때만 파랑 */
.chip-continue {
  background: var(--card);
  border: 0;
  color: var(--dim);
  font-weight: 600;
  box-shadow: none;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.chip-continue svg {
  fill: #38bdf8;
  display: inline-block;
  vertical-align: middle;
  flex-shrink: 0;
}
.chip-continue:active {
  background: var(--accent);
  border-color: var(--accent);
  color: var(--text-strong);
}
.chip-continue:active svg {
  fill: var(--text-strong);
}

/* 입력창 */
.chat-input-row {
  background: var(--surface);
  border-top: 0; /* 테두리 규칙 */
  padding: 8px 10px;
  padding-bottom: calc(24px + env(safe-area-inset-bottom, 0px));  /* PO 2026-09-22: 입력창과 핸드폰 아래 영역(브라우저 막대·키보드) 사이 여백 — "완전히 붙어 있다, 간격을 둬라" */
  display: flex;
  gap: 7px;
  align-items: center;
  flex-shrink: 0;
  position: relative;
  z-index: 99;
}
.composer-input {
  flex: 1;
  height: 44px;
  min-height: 44px;
  max-height: 160px;
  resize: none;
  overflow-y: auto;
  background: var(--input-bg);
  border: 1px solid var(--input-border);
  border-radius: 12px;
  color: var(--text-strong);
  padding: 12px 12px;
  font-size: 14px !important;
  line-height: 20px !important;
  outline: none;
  white-space: pre-wrap;
  font-family: inherit;
  box-sizing: border-box;
  -webkit-appearance: none;
  appearance: none;
  user-select: text !important;
  -webkit-user-select: text !important;
  pointer-events: auto !important;
  box-shadow: inset 0 1px 0 var(--hair3);
  transition: border-color 0.16s ease;
}
.composer-input::placeholder {
  color: var(--placeholder);
  font-size: 13px;
}
.composer-input:focus {
  border-color: rgba(96,165,250,0.72);
  background: var(--input-bg-focus);
}
.btn-send {
  background: var(--accent);
  color: #fff;
  border: none;
  padding: 10px 14px;
  border-radius: 12px;
  font-weight: 700;
  font-size: 13px;
  cursor: pointer;
  flex-shrink: 0;
  touch-action: manipulation;
}
.chat-input-row .btn-send {
  width: 44px;
  height: 44px; /* 터치 타깃 44px */
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  border-radius: 12px;
  font-size: 0;
  box-shadow: 0 4px 12px rgba(37,99,235,0.34);
}
.chat-input-row .btn-send::before {
  content: '↑';
  font-size: 19px;
  line-height: 1;
  font-weight: 900;
}
.chat-input-row .btn-send:active {
  transform: scale(0.96);
}

/* 📎 스마트폰 파일/사진 통합 올리기 단일 클립 버튼 */
.btn-file-label {
  width: 44px;
  height: 44px; /* 터치 타깃 44px */
  padding: 0;
  background: var(--hair2);
  border: 0; /* 테두리 규칙 */
  border-radius: 10px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  flex-shrink: 0;
  touch-action: manipulation;
  font-size: 18px;
  line-height: 1;
  user-select: none;
  transition: all 0.15s ease;
}
.btn-file-label:active {
  background: rgba(79, 127, 255, 0.3);
  border-color: #3b82f6;
  transform: scale(0.95);
}

/* 📎 클립 팝업 (사진 vs 파일 2개만 선택 모달) */
.clip-modal-backdrop {
  display: none;
  position: fixed;
  inset: 0;
  background: var(--shadow-strong);
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  z-index: 9999;
  align-items: flex-end;
  justify-content: center;
}
.clip-modal-backdrop.show {
  display: flex !important;
}
.clip-modal-content {
  background: #141c2e;
  border: 1px solid #28334e;
  border-radius: 16px 16px 0 0;
  width: 100%;
  max-width: 480px;
  padding: 12px 14px 16px;
  padding-bottom: calc(16px + env(safe-area-inset-bottom, 0px));
  box-shadow: 0 -8px 24px var(--backdrop);
  animation: clipSlideUp 0.15s ease-out;
}
@keyframes clipSlideUp {
  from { transform: translateY(100%); }
  to { transform: translateY(0); }
}
.clip-modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
  padding-bottom: 6px;
  border-bottom: 1px solid var(--hair2);
  color: var(--text-strong);
  font-size: 13.5px;
  font-weight: 700;
}
.clip-modal-close {
  background: none;
  border: none;
  color: var(--dim);
  font-size: 20px;
  cursor: pointer;
  padding: 0 4px;
  line-height: 1;
}
.clip-modal-grid {
  display: flex;
  gap: 8px;
}
.clip-pick-btn {
  flex: 1;
  height: 42px;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 7px;
  background: var(--hair);
  border: 1px solid var(--border);
  border-radius: 10px;
  color: var(--text-strong);
  font-size: 13px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.15s ease;
  touch-action: manipulation;
}
.clip-pick-btn:active {
  background: var(--accent);
  border-color: var(--accent);
  transform: scale(0.97);
}

/* 업로드 미리보기 배너 */
.upload-preview-bar {
  display: none;
  background: rgba(37,99,235,0.12);
  border: 1px dashed rgba(96,165,250,0.5);
  border-radius: 10px;
  padding: 6px 12px;
  margin: 0 10px 6px 10px;
  font-size: 11.5px;
  color: #93c5fd;
  justify-content: space-between;
  align-items: center;
}

/* 2. 원클릭 제어 카드 뷰 */
.card-scroll {
  padding: 16px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.m-card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 14px;
  padding: 18px;
  box-shadow: 0 4px 12px var(--shadow);
}
.m-card h3 { font-size: 16px; color: var(--text-strong); margin-bottom: 8px; font-weight: 700; display: flex; align-items: center; gap: 8px; }
.m-card p { font-size: 13px; color: var(--dim); line-height: 1.6; margin-bottom: 14px; }
.card-btns { display: flex; gap: 8px; flex-wrap: wrap; }
.btn-link {
  display: inline-flex;
  align-items: center;
  background: var(--hair);
  border: 1px solid var(--border);
  color: var(--text-strong);
  text-decoration: none;
  font-size: 13px;
  font-weight: 600;
  padding: 9px 15px;
  border-radius: 8px;
  cursor: pointer;
}
.btn-link.primary {
  background: var(--accent);
  border-color: var(--accent);
}

/* 3. 터미널 뷰 */
#termOutput {
  flex: 1;
  background: #06080e;
  padding: 14px;
  overflow-y: auto;
  font-family: 'Fira Code', monospace;
  font-size: 12.5px;
  line-height: 1.55;
  white-space: pre-wrap;
  word-break: break-all;
  color: #cfd8dc;
}
.prompt-line { color: var(--accent-light); font-weight: 600; margin: 4px 0; }
.err-line { color: var(--danger); }
.sys-line { color: var(--win); font-style: italic; }

/* 모바일 툴바 */
.mobile-toolbar {
  background: var(--surface);
  border-top: 1px solid var(--border);
  padding: 6px 8px;
  display: flex;
  gap: 6px;
  overflow-x: auto;
  white-space: nowrap;
  flex-shrink: 0;
}
.tool-btn {
  background: var(--card);
  border: 1px solid var(--border);
  color: var(--text);
  font-size: 12px;
  font-family: 'Fira Code', monospace;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
}

/* 로그인 모달 */
#loginOverlay {
  position: fixed;
  inset: 0;
  background: var(--overlay-bg);
  z-index: 999;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 24px;
}
.login-box {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 18px;
  padding: 30px 24px;
  width: 100%;
  max-width: 340px;
  text-align: center;
}
.login-box h2 { font-size: 20px; font-weight: 800; margin-bottom: 8px; }
.login-box p { font-size: 13px; color: var(--dim); margin-bottom: 22px; }
#pinInput {
  width: 100%;
  background: var(--surface);
  border: 1.5px solid var(--border);
  border-radius: 12px;
  color: var(--text-strong);
  font-size: 26px;
  font-weight: 800;
  text-align: center;
  letter-spacing: 8px;
  padding: 12px;
  margin-bottom: 18px;
  outline: none;
}
#pinInput:focus { border-color: var(--accent); }
@media (max-width: 430px) { .tabs { gap: 4px; padding: 0; } .tab-btn { font-size: 11px; letter-spacing: -0.3px; padding-left: 1px; padding-right: 1px; } .tab-sub { font-size: 9px; } }
@media (max-width: 380px) { .tabs { gap: 3px; padding: 0; } .tab-btn { font-size: 10px; letter-spacing: -0.4px; } .tab-sub { font-size: 8.5px; } }
.tab-btn { overflow: hidden; }
.tabs:has(> .tab-btn:nth-child(6)) .tab-btn { font-size: 10px; letter-spacing: -0.4px; }
.tabs:has(> .tab-btn:nth-child(6)) .tab-sub { font-size: 8.5px; }

/* ===== W10 세로 압축 (PO 2026-09-22 "버튼들이 세로로 너무 크다 — 모양 안 깨고 채팅 영역을 넓혀라") =====
   시각 높이만 줄이고 터치 영역은 ::before 겹치기로 44px 유지. 글자 크기·색·그라데이션·모서리 그대로.
   목표(390×844): 맨 윗줄 40 · 프로젝트/도구줄 36 · AI 탭 줄 48 · 상태줄 34 · 칩 줄 40 · 입력줄 56 (전 363 → 후 ≈294, 채팅 +8%p) */
.top-line { height: 40px; }
.top-bar { min-height: 40px; padding: 3px 10px; }
.tab-btn.hdr-btn { min-height: 34px; padding: 4px 10px 3px; position: relative; }
.tab-btn.hdr-btn::before { content: ''; position: absolute; left: 0; right: 0; top: -7px; bottom: -7px; }
/* AI 탭: .tabs 가 overflow-x:auto 라 ::before 세로 확장이 잘린다(보조 실측 hit 30px) → 줄 높이(48)는 목표대로 두고 버튼 자체를 44 로 (hit = 시각 = 44) */
.tabs-row { padding: 2px 6px; }
.tab-btn { min-height: 44px; padding: 5px 2px 4px; line-height: 1.2; position: relative; }
.tab-btn.hdr-btn .tab-sub, .tab-sub { margin-top: 1px; }
.status-line.status-line--tall { height: 40px; min-height: 40px; overflow: visible; }
.mode-menu-btn { height: 34px; min-height: 34px; margin: 3px 0; line-height: 32px; font-size: 14px; position: relative; overflow: visible; }
.mode-menu-btn::before { content: ''; position: absolute; left: 0; right: 0; top: -5px; bottom: -5px; border-radius: 18px; z-index: 1; } /* 34 + 10 = hit 44 (상태줄 40 안팎) */
/* 칩 줄: chips-bar 도 overflow-x:auto 라 ::before 가 줄 밖으로 못 나간다 → 줄 44, 칩 36(원래 크기)으로 hit 44 확보 (줄은 52 → 44) */
.chips-bar { padding: 4px 12px; }
.chip { min-height: 38px; font-size: 13px; position: relative; }
.chip::before { content: ''; position: absolute; left: 0; right: 0; top: -3px; bottom: -3px; z-index: 1; } /* 38 + 6 = hit 44 (칩 줄 44 안) */
.chat-input-row { padding: 6px 10px; padding-bottom: calc(24px + env(safe-area-inset-bottom, 0px)); } /* 아래 24px 는 PO 2026-09-22 11:43 결정(핸드폰 하단 영역과의 간격) — 유지 */
.composer-input { height: 40px; min-height: 40px; padding: 10px 12px; }
.chat-input-row .btn-send { width: 40px; height: 40px; position: relative; }
.chat-input-row .btn-send::after { content: ''; position: absolute; inset: -4px; z-index: 1; } /* hit 48 (입력줄은 잘리지 않는다) */
/* W9 말로 입력 (PO 2026-09-22 "키보드가 화면을 잡아먹는다") — 앱은 네이티브 음성인식, 브라우저는 webkitSpeechRecognition, 둘 다 없으면 버튼 숨김 */
.btn-voice { width: 40px; height: 40px; padding: 0; background: var(--hair2); border: 0; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0; cursor: pointer; position: relative; -webkit-tap-highlight-color: transparent; }
.btn-voice::after { content: ''; position: absolute; inset: -4px; z-index: 1; }
.btn-voice.listening { background: rgba(220,38,38,0.22); animation: voicePulse 1.1s ease-in-out infinite; }
@keyframes voicePulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.55; } }
/* 프로젝트 줄 버튼: 위쪽 .tab-btn 의 overflow:hidden 이 자기 ::before 를 잘라내고 있었다(보조 실측 hit 30) → 이 버튼만 visible + 확장 */
.tab-btn.hdr-btn { overflow: visible; }
.tab-btn.hdr-btn::before { top: -7px; bottom: -7px; z-index: 1; } /* 30 + 14 = hit 44, 줄 높이 36 은 그대로 */
.chat-input-row .btn-attach, .chat-input-row .attach-btn { height: 40px; min-height: 40px; }

</style>
</head>
<body style="background: var(--bg); color: var(--text);">
<!-- top-line:start -->
<!-- 맨 꼭대기 줄(콘솔을 브라우저로 직접 열 때만): ⓘ 사용법 · One-stop Multi AI Console System · ⚙ 설정. 앱(?app=1)·허브 iframe(embed=1 또는 self!==top)에서는 그리지 않는다 -->
<div id="topLine" class="top-line" role="toolbar" aria-label="원맥스">
  <button id="guideBtn" class="top-side" type="button" aria-label="사용법 보기" title="사용법" onclick="openGuide()"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16.5"/><circle cx="12" cy="8" r="0.6" fill="currentColor"/></svg></button>
  <div class="top-title" aria-hidden="true">One-stop Multi AI Console System</div>
  <button id="settingsBtn" class="top-side" type="button" aria-label="콘솔 설정" title="콘솔 설정" onclick="openSettings()">⚙</button>
</div>
<!-- top-line:end -->

<!-- 비밀번호 없이 1초 즉시 접속 -->

<!-- 최상단 듀얼 PC 원터치 탭 스위처 바 (단독/직통 접속 시 자동 노출) -->
<div id="pcDirectSwitchBar" class="pc-switch-bar" style="display:none;">
  <button id="pcDirectBtn-pc1" class="pc-nav-tab" onclick="navigateToPc1()">
    <span class="pc-dot" id="pcDirectDot-pc1"></span>
    <span id="pcDirectLabel-pc1">PC 1</span>
  </button>
  <button id="pcDirectBtn-pc2" class="pc-nav-tab active" onclick="navigateToPc2()">
    <span class="pc-dot online"></span>
    <span>PC 2</span>
  </button>
</div>

<!-- 상단 헤더 -->
<div class="top-bar">
  <div class="top-bar-left">
    <span id="projSel"></span>
  </div>
  <div class="top-bar-right">
    ${PROJECT_TABS.map((t, i) => `<button class="tab-btn hdr-btn hdr-tool" id="projToolBtn${i}" onclick="${t.mode === 'run' ? ('runProjectTool(' + i + ')') : (t.mode === 'newtab' ? ("window.open('" + escapeAttr(t.url) + "', '_blank')") : "switchTab('project', this)")}">${escapeAttr(t.label)}<div class="tab-sub" id="projToolSub${i}" style="color:#34d399;">${escapeAttr(t.sub || '사이트')}</div></button>`).join('')}
    ${SHOW_DOCS ? DOC_BTNS.map(([k, ico, label]) => `<button class="tab-btn hdr-btn hdr-tool hdr-doc" onclick="openDoc('${k}')">${ico}<div class="tab-sub">${label}</div></button>`).join('') : ''}
    ${SHOW_SCANNER ? `<button class="tab-btn hdr-btn hdr-tool" id="tab-scanner" onclick="switchTab('scanner', this)">스캐너<div class="tab-sub" style="color:#38bdf8;">290종목</div></button>` : ''}
  </div>
</div>

<!-- 프로젝트 기동 실패 안내 — 상태줄 한 줄(배너 아님). 라우터 /api/projects 의 notice 가 있을 때만 -->
<div id="projNotice" class="status-line" role="status" style="display:none; background: var(--status-bg); color: var(--warn); font-weight: 700;"></div>
<!-- 탭 메뉴 (플랩) -->
<div class="tabs-row">
  <div class="tabs" role="tablist" aria-label="AI 선택">
    <button class="tab-btn w-claude active" role="tab" aria-selected="true" aria-controls="view-assistant" onclick="switchTab('assistant', this)">Claude Code<div class="tab-sub" id="modelSub-claude">Opus 5</div></button>
    ${workerOn('codex') ? `<button class="tab-btn w-codex" role="tab" aria-selected="false" aria-controls="view-codex" onclick="switchTab('codex', this)">Codex<div class="tab-sub" id="modelSub-codex">GPT-5.6-terra</div></button>` : ''}
    ${workerOn('agy') ? `<button class="tab-btn w-agy" role="tab" aria-selected="false" aria-controls="view-agy" onclick="switchTab('agy', this)">Antigravity<div class="tab-sub" id="modelSub-agy">Gemini 3.8 Flash</div></button>` : ''}
    ${workerOn('grok') ? `<button class="tab-btn w-grok" role="tab" aria-selected="false" aria-controls="view-grok" onclick="switchTab('grok', this)">Grok<div class="tab-sub" id="modelSub-grok">grok-4.6</div></button>` : ''}
  </div>
</div>
<div id="sheetBackdrop" class="sheet-backdrop" onclick="closeSheets()"></div>
<div id="projSheet" class="sheet" role="dialog" aria-modal="true" aria-label="프로젝트">
  <h2><span id="projSheetTitle">프로젝트</span> <button class="sheet-close" type="button" aria-label="닫기" onclick="closeProjSheet()">✕</button></h2>
  <div id="projSheetBody"></div>
</div>
<div id="settingsSheet" class="sheet" role="dialog" aria-modal="true" aria-label="One MACS · 원맥스 설정">
  <h2>One MACS · 원맥스 설정 <button class="sheet-close" type="button" aria-label="설정 닫기" onclick="closeSettings()">✕</button></h2>
  <div id="settingsBody"></div>
  <div id="settingsSaved" class="saved" aria-live="polite"></div>
</div>
<!-- 시스템 안내줄 (2026-09-21): CLI 새 버전 미확인 · 헬스체크 실패 · 원격 호환 공지 — /api/status -->
<!-- 상단 안내 배너·권한 배지 없음(PO 2026-09-21): 점검 중은 탭 소제목, 전체 권한은 ⚙ 설정 시트 한 줄, 미확인 버전은 설정 시트 회색 한 줄로만 -->

<!-- 1. Claude Code 뷰 (메인 워커: Opus 5 헤드리스 세션, 대화 맥락 영구 유지) -->
<div id="view-assistant" class="view active">
  <!-- 상태줄 한 줄: 상태 · 남은 한도 · 메시지 수 · 보기 모드 드롭다운 (옛 3단 버튼 줄은 여기로 흡수) -->
  <div class="status-line status-line--tall" style="background: var(--status-bg);">
    <span id="syncSessionStatus" style="color: var(--c-claude); font-weight: 700; display: flex; align-items: center; gap: 6px;">
      <span class="status-dot" style="width: 6px; height: 6px; background: var(--c-claude);"></span>
      <span>대기</span>
    </span>
    <span style="display:flex; align-items:center; gap:6px; flex-shrink:0;">
    <span id="quota-assistant" style="font-size:10.5px; color:var(--dim); font-weight:600; white-space:nowrap;"></span>
    <span id="transMsgCountBadge" style="font-size: 10.5px; color: var(--dim); font-weight: 700; white-space:nowrap;">0개 메시지</span>
    <select id="chatModeSel" class="mode-sel" aria-label="답변 표시 방식" onchange="setChatViewMode(this.value, true)" style="display:none" tabindex="-1" aria-hidden="true">
      <option value="summary" selected>요약</option>
      <option value="detail">상세</option>
      <option value="full">전체</option>
    </select>
    <span class="mode-menu" id="chatModeMenu">
      <button type="button" id="chatModeBtn" class="mode-menu-btn" aria-label="답변 표시 방식" aria-haspopup="menu" aria-expanded="false" aria-controls="chatModePop" onclick="toggleChatModeMenu(event)"><span class="pre">보기</span><span id="chatModeLabel">요약</span><span class="caret" aria-hidden="true">▾</span></button>
      <div id="chatModePop" class="mode-menu-pop" role="menu" aria-label="답변 표시 방식">
        <div class="mode-menu-item" role="menuitemradio" tabindex="-1" data-v="summary" aria-checked="true" onclick="pickChatMode('summary')"><span>요약</span><span class="chk">✓</span></div>
        <div class="mode-menu-item" role="menuitemradio" tabindex="-1" data-v="detail" aria-checked="false" onclick="pickChatMode('detail')"><span>상세</span><span class="chk"></span></div>
        <div class="mode-menu-item" role="menuitemradio" tabindex="-1" data-v="full" aria-checked="false" onclick="pickChatMode('full')"><span>전체</span><span class="chk"></span></div>
      </div>
    </span>
    </span>
  </div>
  <div id="chatContainer">
    <div style="color: var(--dim); text-align: center; padding: 30px;">Claude Code (Opus 5) 세션을 실시간으로 불러오는 중...</div>
  </div>

  <!-- 추천 칩 (Chips) 바 -->
  <div class="chips-bar">
    <div class="chip chip-stop" role="button" tabindex="0" aria-label="긴급 정지: PC의 AI 작업을 즉시 중단" onclick="triggerEmergencyStop()" title="🛑 긴급 정지">🛑 긴급 정지</div>
    <div class="chip" role="button" tabindex="0" aria-label="한 줄 결론만 요청" onclick="sendQuickInput('한 줄 결론만 말해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="10.7" width="14" height="2.8" rx="1.4" fill="#fbbf24"/><circle cx="20" cy="12.1" r="1.9" fill="#fbbf24"/></svg>한 줄 결론</div>
    <div class="chip" role="button" tabindex="0" aria-label="현재 작업을 3줄로 요약 요청" onclick="sendQuickInput('현재 작업 핵심만 3줄 요약해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="5" width="18" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="10.7" width="14" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="16.4" width="10" height="2.6" rx="1.3" fill="#38bdf8"/></svg>3줄 핵심 요약</div>
    <div class="chip chip-continue" role="button" tabindex="0" aria-label="작업 계속 진행 요청" onclick="sendQuickInput('작업 계속 진행해')"><svg width="13" height="13" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg><span>계속 진행</span></div>
  </div>

  <!-- 입력창 (단일 행 고정 입력창 + 📎 클립 팝업) -->
  <div id="uploadPreview-assistant" class="upload-preview-bar"></div>
  <div class="chat-input-row">
    <button type="button" class="btn-file-label" aria-label="사진이나 파일 올리기" onclick="triggerPickOption('file', 'assistant')" title="사진/파일 올리기">📎</button>
    <button type="button" class="btn-voice" id="voiceBtn-assistant" aria-label="말로 입력" onclick="toggleVoice('chatInput', this)" title="말로 입력" style="display:none">🎤</button>
    <input type="file" id="filePicker-assistant-file" onchange="handleMobileFileUpload(this, 'assistant', 'file')" accept="image/*,video/*,application/*,text/*" multiple style="display:none;">
    <textarea id="chatInput" class="composer-input" rows="1" placeholder="Claude Code (Opus 5)에 지시 입력..." enterkeyhint="send" autocomplete="off" autocorrect="off" autocapitalize="none"></textarea>
    <button class="btn-send" aria-label="지시 보내기" onclick="sendChatFromInput()" title="전송">전송</button>
    <!-- ★ PO 지시(2026-09-20): 입력창 옆에 정지/긴급 버튼 절대 추가 금지 — 긴급 정지는 칩 줄 하나뿐. 배포 빌드(build_dist.js)가 고정 정지 버튼 식별자를 발견하면 빌드 실패 -->
  </div>
</div>

<!-- 2. Codex 전용 뷰 (서브 워커 1: GPT-5.6-terra Medium 연동, 무인 자율 데몬) -->
<div id="view-codex" class="view">
  <div style="background: var(--status-bg); border-bottom: 0; padding: 0 12px; height: 24px; min-height: 24px; font-size: 11px; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;">
    <span id="codexStatus" style="color: var(--c-codex); font-weight: 700; display: flex; align-items: center; gap: 6px;">
      <span class="status-dot" style="width: 6px; height: 6px; background: var(--c-codex);"></span>
      <span>대기</span>
    </span>
    <span id="quota-codex" style="font-size:10.5px; color:var(--dim); font-weight:600; white-space:nowrap;"></span>
  </div>
  <div id="codexChatContainer">
    <div style="color: var(--dim); text-align: center; padding: 30px;">Codex (GPT-5.6-terra) 대기 중입니다. 코딩 명령을 내려보세요.</div>
  </div>

  <!-- 추천 칩 (Chips) 바 -->
  <div class="chips-bar">
    <div class="chip chip-stop" role="button" tabindex="0" aria-label="긴급 정지: PC의 AI 작업을 즉시 중단" onclick="triggerEmergencyStop()" title="🛑 긴급 정지">🛑 긴급 정지</div>
    <div class="chip" role="button" tabindex="0" aria-label="한 줄 결론만 요청" onclick="sendCodexQuick('한 줄 결론만 말해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="10.7" width="14" height="2.8" rx="1.4" fill="#fbbf24"/><circle cx="20" cy="12.1" r="1.9" fill="#fbbf24"/></svg>한 줄 결론</div>
    <div class="chip" role="button" tabindex="0" aria-label="현재 작업을 3줄로 요약 요청" onclick="sendCodexQuick('현재 작업 핵심만 3줄 요약해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="5" width="18" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="10.7" width="14" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="16.4" width="10" height="2.6" rx="1.3" fill="#38bdf8"/></svg>3줄 핵심 요약</div>
    <div class="chip chip-continue" role="button" tabindex="0" aria-label="작업 계속 진행 요청" onclick="sendCodexQuick('작업 계속 진행해')"><svg width="13" height="13" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg><span>계속 진행</span></div>
  </div>

  <!-- 입력창 (단일 행 고정 입력창 + 📎 클립 팝업) -->
  <div id="uploadPreview-codex" class="upload-preview-bar"></div>
  <div class="chat-input-row">
    <button type="button" class="btn-file-label" aria-label="사진이나 파일 올리기" onclick="triggerPickOption('file', 'codex')" title="사진/파일 올리기">📎</button>
    <button type="button" class="btn-voice" id="voiceBtn-codex" aria-label="말로 입력" onclick="toggleVoice('codexInput', this)" title="말로 입력" style="display:none">🎤</button>
    <input type="file" id="filePicker-codex-file" onchange="handleMobileFileUpload(this, 'codex', 'file')" accept="image/*,video/*,application/*,text/*" multiple style="display:none;">
    <textarea id="codexInput" class="composer-input" rows="1" placeholder="Codex (GPT-5.6-terra)에 명령 입력..." enterkeyhint="send" autocomplete="off" autocorrect="off" autocapitalize="none"></textarea>
    <button class="btn-send" aria-label="지시 보내기" onclick="sendCodexFromInput()" title="전송">전송</button>
  </div>
</div>

<!-- 3. Antigravity 전용 뷰 (서브 워커 2: agy -p 헤드리스, 무인 자동 승인) -->
<div id="view-agy" class="view">
  <div style="background: var(--status-bg); border-bottom: 0; padding: 0 12px; height: 24px; min-height: 24px; font-size: 11px; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;">
    <span id="agyStatus" style="color: var(--c-agy); font-weight: 700; display: flex; align-items: center; gap: 6px;">
      <span class="status-dot" style="width: 6px; height: 6px; background: #8AB4F8;"></span>
      <span>대기</span>
    </span>
    <span id="quota-agy" style="font-size:10.5px; color:var(--dim); font-weight:600; white-space:nowrap;"></span>
  </div>
  <div id="agyChatContainer">
    <div style="color: var(--dim); text-align: center; padding: 30px;">Antigravity (Gemini 3.8 Flash) 대기 중입니다. 코딩·분석 명령을 내려보세요.</div>
  </div>

  <!-- 추천 칩 (Chips) 바 -->
  <div class="chips-bar">
    <div class="chip chip-stop" role="button" tabindex="0" aria-label="긴급 정지: PC의 AI 작업을 즉시 중단" onclick="triggerEmergencyStop()" title="🛑 긴급 정지">🛑 긴급 정지</div>
    <div class="chip" role="button" tabindex="0" aria-label="한 줄 결론만 요청" onclick="sendAgyQuick('한 줄 결론만 말해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="10.7" width="14" height="2.8" rx="1.4" fill="#fbbf24"/><circle cx="20" cy="12.1" r="1.9" fill="#fbbf24"/></svg>한 줄 결론</div>
    <div class="chip" role="button" tabindex="0" aria-label="현재 작업을 3줄로 요약 요청" onclick="sendAgyQuick('현재 작업 핵심만 3줄 요약해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="5" width="18" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="10.7" width="14" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="16.4" width="10" height="2.6" rx="1.3" fill="#38bdf8"/></svg>3줄 핵심 요약</div>
    <div class="chip chip-continue" role="button" tabindex="0" aria-label="작업 계속 진행 요청" onclick="sendAgyQuick('작업 계속 진행해')"><svg width="13" height="13" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg><span>계속 진행</span></div>
  </div>

  <!-- 입력창 (단일 행 고정 입력창 + 📎 클립 팝업) -->
  <div id="uploadPreview-agy" class="upload-preview-bar"></div>
  <div class="chat-input-row">
    <button type="button" class="btn-file-label" aria-label="사진이나 파일 올리기" onclick="triggerPickOption('file', 'agy')" title="사진/파일 올리기">📎</button>
    <button type="button" class="btn-voice" id="voiceBtn-agy" aria-label="말로 입력" onclick="toggleVoice('agyInput', this)" title="말로 입력" style="display:none">🎤</button>
    <input type="file" id="filePicker-agy-file" onchange="handleMobileFileUpload(this, 'agy', 'file')" accept="image/*,video/*,application/*,text/*" multiple style="display:none;">
    <textarea id="agyInput" class="composer-input" rows="1" placeholder="Antigravity (Gemini 3.8 Flash)에 명령 입력..." enterkeyhint="send" autocomplete="off" autocorrect="off" autocapitalize="none"></textarea>
    <button class="btn-send" aria-label="지시 보내기" onclick="sendAgyFromInput()" title="전송">전송</button>
  </div>
</div>
<!-- 3G. Grok 전용 뷰 (서브 워커 3: grok -p 헤드리스, 무인 자동 승인) -->
<div id="view-grok" class="view">
  <div style="background: var(--status-bg); border-bottom: 0; padding: 0 12px; height: 24px; min-height: 24px; font-size: 11px; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;">
    <span id="grokStatus" style="color: var(--c-grok); font-weight: 700; display: flex; align-items: center; gap: 6px;">
      <span class="status-dot" style="width: 6px; height: 6px; background: #D1D5DB;"></span>
      <span>대기</span>
    </span>
    <span id="quota-grok" style="font-size:10.5px; color:var(--dim); font-weight:600; white-space:nowrap;"></span>
  </div>
  <div id="grokChatContainer">
    <div style="color: var(--dim); text-align: center; padding: 30px;">Grok (grok-4.6) 대기 중입니다. 코딩·분석 명령을 내려보세요.</div>
  </div>

  <!-- 추천 칩 (Chips) 바 -->
  <div class="chips-bar">
    <div class="chip chip-stop" role="button" tabindex="0" aria-label="긴급 정지: PC의 AI 작업을 즉시 중단" onclick="triggerEmergencyStop()" title="🛑 긴급 정지">🛑 긴급 정지</div>
    <div class="chip" role="button" tabindex="0" aria-label="한 줄 결론만 요청" onclick="sendGrokQuick('한 줄 결론만 말해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="10.7" width="14" height="2.8" rx="1.4" fill="#fbbf24"/><circle cx="20" cy="12.1" r="1.9" fill="#fbbf24"/></svg>한 줄 결론</div>
    <div class="chip" role="button" tabindex="0" aria-label="현재 작업을 3줄로 요약 요청" onclick="sendGrokQuick('현재 작업 핵심만 3줄 요약해줘')"><svg width="13" height="13" viewBox="0 0 24 24" style="vertical-align:-2px; margin-right:4px;"><rect x="3" y="5" width="18" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="10.7" width="14" height="2.6" rx="1.3" fill="#38bdf8"/><rect x="3" y="16.4" width="10" height="2.6" rx="1.3" fill="#38bdf8"/></svg>3줄 핵심 요약</div>
    <div class="chip chip-continue" role="button" tabindex="0" aria-label="작업 계속 진행 요청" onclick="sendGrokQuick('작업 계속 진행해')"><svg width="13" height="13" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg><span>계속 진행</span></div>
  </div>

  <!-- 입력창 (단일 행 고정 입력창 + 📎 클립 팝업) -->
  <div id="uploadPreview-grok" class="upload-preview-bar"></div>
  <div class="chat-input-row">
    <button type="button" class="btn-file-label" aria-label="사진이나 파일 올리기" onclick="triggerPickOption('file', 'grok')" title="사진/파일 올리기">📎</button>
    <button type="button" class="btn-voice" id="voiceBtn-grok" aria-label="말로 입력" onclick="toggleVoice('grokInput', this)" title="말로 입력" style="display:none">🎤</button>
    <input type="file" id="filePicker-grok-file" onchange="handleMobileFileUpload(this, 'grok', 'file')" accept="image/*,video/*,application/*,text/*" multiple style="display:none;">
    <textarea id="grokInput" class="composer-input" rows="1" placeholder="Grok (grok-4.6)에 명령 입력..." enterkeyhint="send" autocomplete="off" autocorrect="off" autocapitalize="none"></textarea>
    <button class="btn-send" aria-label="지시 보내기" onclick="sendGrokFromInput()" title="전송">전송</button>
  </div>
</div>
${PROJECT_TAB ? `<!-- 3P. 프로젝트 사이트 탭 (console_config.json project_tab) -->
<div id="view-project" class="view" style="padding:0;">
  <div style="display:flex; align-items:center; justify-content:space-between; padding:6px 12px; background:rgba(16,185,129,0.08); border-bottom:1px solid rgba(16,185,129,0.25); font-size:11.5px; color:#34d399; font-weight:700;"><span>${escapeAttr(PROJECT_TAB.label)} · ${escapeAttr(PROJECT_TAB.url)}</span><a href="${escapeAttr(PROJECT_TAB.url)}" target="_blank" style="color:#93c5fd; text-decoration:none;">화면이 비면 새 창으로 열기 ↗</a></div>
  <iframe id="projectFrame" data-src="${escapeAttr(PROJECT_TAB.url)}" src="about:blank" style="flex:1; width:100%; border:none; background:#fff;" allow="clipboard-read; clipboard-write"></iframe>
</div>
` : ''}<!-- 3A. 에이전트 화면 (도구 버튼 view:true 로 띄운 로컬 에이전트를 전용 주소로 표시) -->
<div id="view-agent" class="view" style="padding:0;">
  <div style="display:flex; align-items:center; justify-content:space-between; gap:8px; padding:6px 12px; background:rgba(56,189,248,0.08); border-bottom:1px solid rgba(56,189,248,0.25); font-size:11.5px; color:#7dd3fc; font-weight:700;">
    <span id="agentViewLabel">에이전트</span>
    <span style="display:flex; gap:8px; align-items:center;">
      <a id="agentViewOpen" href="#" target="_blank" rel="noopener" style="color:#93c5fd; text-decoration:none;">새 창 ↗</a>
      <span id="agentViewState" style="color:var(--dim); font-weight:600;"></span>
    </span>
  </div>
  <iframe id="agentFrame" src="about:blank" style="flex:1; width:100%; border:none; background:#fff;" allow="clipboard-read; clipboard-write"></iframe>
</div>

<!-- 4. 실시간 스캐너 전용 뷰 (주식선물 전 종목·현재 290, 5대장 2졸병 필터) -->
<div id="view-scanner" class="view">
  <div style="background:var(--surface); border-bottom:1px solid var(--border); padding:10px 14px; display:flex; justify-content:space-between; align-items:center; flex-shrink:0;">
    <div style="display:flex; align-items:center; gap:8px;">
      <span style="font-size:13px; font-weight:800; color:#fff; white-space:nowrap;">📊 스캐너 290</span>
      <span id="scannerRunningBadge" style="font-size:10.5px; color:#10b981; font-weight:700;">● 정상 가동 중</span>
    </div>
    <div style="display:flex; gap:6px;">
      <button onclick="triggerScannerScan()" style="background:var(--accent); color:#fff; border:none; border-radius:8px; padding:6px 10px; font-size:12px; font-weight:700; cursor:pointer; white-space:nowrap;">▶ 재스캔</button>
      <button onclick="refreshScannerTab()" style="background:rgba(255,255,255,0.08); color:#cbd5e1; border:1px solid var(--border); border-radius:8px; padding:6px 10px; font-size:12px; font-weight:700; cursor:pointer;">🔄</button>
    </div>
  </div>
  <div id="scannerContentArea" style="flex:1; overflow-y:auto; padding:12px; display:flex; flex-direction:column; gap:12px;">
    <!-- 전략 (strategies/*.json) — 전략별 통과 종목 · 겹침 · 켜기/끄기 -->
    <div style="background:var(--card); border:1.5px solid rgba(16,185,129,0.45); border-radius:14px; padding:12px 14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span style="font-size:13.5px; font-weight:800; color:#34d399;">🧭 전략</span>
        <span id="stratMeta" style="font-size:11px; color:var(--dim); font-weight:600;"></span>
      </div>
      <div id="stratKis" style="font-size:11.5px; color:#fbbf24; margin-bottom:6px; line-height:1.4;"></div>
      <div id="stratTabs" style="display:flex; gap:6px; overflow-x:auto; padding-bottom:6px; margin-bottom:8px;"></div>
      <div id="stratDetail" style="display:flex; flex-direction:column; gap:6px;">
        <p style="color:var(--dim); font-size:12px; text-align:center; padding:8px;">전략 로딩 중...</p>
      </div>
      <div id="stratOverlap" style="margin-top:8px; font-size:11.5px; color:#fbbf24;"></div>
    </div>

    <!-- Stage 2 5대장 2졸병 최종 통과 종목 -->
    <div style="background:var(--card); border:1.5px solid rgba(56,189,248,0.45); border-radius:14px; padding:14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <span style="font-size:13.5px; font-weight:800; color:#38bdf8;">👑 Stage 2 통과 종목 (5대장·2졸병 일치)</span>
        <span id="scannerStage2Count" style="font-size:11px; color:#38bdf8; font-weight:700;">0종목</span>
      </div>
      <div id="scannerStage2List" style="display:flex; flex-direction:column; gap:6px;">
        <p style="color:var(--dim); font-size:12px; text-align:center; padding:10px;">통과 종목 로딩 중...</p>
      </div>
    </div>

    <!-- Stage 1 CALL 우세 종목 -->
    <div style="background:var(--card); border:1.5px solid var(--border); border-radius:14px; padding:14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <span style="font-size:13.5px; font-weight:800; color:#10b981;">🔥 Stage 1 CALL 포착 종목</span>
        <span id="scannerCallCount" style="font-size:11.5px; color:var(--dim);"></span>
      </div>
      <div id="scannerTopCallsList" style="display:flex; flex-direction:column; gap:6px;">
        <p style="color:var(--dim); font-size:12px; text-align:center; padding:15px;">스캐너 결과 로딩 중...</p>
      </div>
    </div>

    <!-- 실시간 진단 로그 -->
    <div style="background:var(--card); border:1.5px solid var(--border); border-radius:14px; padding:14px;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span style="font-size:13.5px; font-weight:800; color:#cbd5e1;">📋 실시간 진단 로그</span>
      </div>
      <div id="scannerLogsArea" style="background:#06080e; border:1px solid rgba(255,255,255,0.06); border-radius:8px; padding:10px; font-family:monospace; font-size:11.5px; color:#94a3b8; max-height:160px; overflow-y:auto; line-height:1.5;"></div>
    </div>
  </div>
</div>

<!-- 로그인 인증 모달 (PIN Authentication Modal) -->
<div id="loginOverlay" style="display: none; position: fixed; inset: 0; background: rgba(11, 14, 23, 0.98); z-index: 99999; flex-direction: column; justify-content: center; align-items: center; padding: 24px; backdrop-filter: blur(16px);">
  <div style="width: 100%; max-width: 340px; background: var(--surface); border: 1px solid var(--border); border-radius: 18px; padding: 26px 20px; box-shadow: 0 20px 40px rgba(0,0,0,0.6); text-align: center;">
    <div style="font-size: 36px; margin-bottom: 10px;">🔐</div>
    <h3 style="font-size: 17px; font-weight: 800; color: #fff; margin-bottom: 6px;">One MACS · 원맥스 접속</h3>
    <p style="font-size: 12.5px; color: var(--dim); margin-bottom: 16px;">보안 PIN 번호를 입력해 주세요. (console_config.json 의 pin)</p>
    <input id="pinInput" type="text" maxlength="8" inputmode="numeric" placeholder="PIN 번호 입력" style="width: 100%; background: var(--card); border: 1.5px solid var(--border); border-radius: 12px; padding: 13px; color: #fff; font-size: 20px; font-weight: 800; text-align: center; letter-spacing: 6px; outline: none; margin-bottom: 12px; box-sizing: border-box;" onkeydown="if(event.key==='Enter') submitPinLogin()">
    <div id="pinError" style="font-size: 12px; color: var(--danger); margin-bottom: 12px; min-height: 16px; font-weight: 600;"></div>
    <button onclick="submitPinLogin()" style="width: 100%; background: var(--accent); color: #fff; border: none; border-radius: 12px; padding: 13px; font-size: 15px; font-weight: 800; cursor: pointer; margin-bottom: 10px; box-shadow: 0 4px 14px rgba(37,99,235,0.4);">접속 승인</button>
      </div>
</div>


<!-- 파일 탐색기 모달 (File Manager Modal) -->
<div id="fileModalOverlay" style="display: none; position: fixed; inset: 0; background: rgba(11, 14, 23, 0.96); z-index: 9998; flex-direction: column; padding: 12px 14px; backdrop-filter: blur(12px);">
  <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 4px 12px; border-bottom: 1px solid var(--border);">
    <div style="font-size: 15px; font-weight: 800; color: #fff; display: flex; align-items: center; gap: 6px;">
      <span>📂 프로젝트 파일 탐색기</span>
    </div>
    <button onclick="closeFileManager()" style="background: rgba(255,255,255,0.1); color: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 6px 12px; font-size: 12px; font-weight: 700; cursor: pointer;">✕ 닫기</button>
  </div>
  <div style="padding: 10px 0 6px;">
    <input id="fileSearchInput" type="text" placeholder="🔍 파일명 실시간 필터링..." oninput="filterFilesList()" style="width: 100%; background: var(--card); border: 1px solid var(--border); border-radius: 8px; padding: 8px 12px; color: #fff; font-size: 13px; outline: none; box-sizing: border-box;">
  </div>
  <div id="fileList" style="flex: 1; overflow-y: auto; padding: 6px 0 20px; display: flex; flex-direction: column; gap: 6px;">
    <p style="color: var(--dim); text-align: center; padding: 20px;">파일 목록 로딩 중...</p>
  </div>
</div>

<!-- 파일 편집기 오버레이 (File Editor Modal) -->
<div id="editorOverlay" style="display: none; position: fixed; inset: 0; background: rgba(11, 14, 23, 0.98); z-index: 9999; flex-direction: column; padding: 12px 14px; backdrop-filter: blur(12px);">
  <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 4px 12px; border-bottom: 1px solid var(--border);">
    <div style="font-size: 13.5px; font-weight: 800; color: var(--accent-light); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 60%;" id="editFileName">파일 편집</div>
    <div style="display: flex; gap: 6px;">
      <button onclick="saveCurrentFile()" style="background: var(--accent); color: #fff; border: none; border-radius: 8px; padding: 6px 12px; font-size: 12px; font-weight: 700; cursor: pointer;">💾 저장</button>
      <button onclick="closeEditor()" style="background: rgba(255,255,255,0.1); color: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 6px 12px; font-size: 12px; font-weight: 700; cursor: pointer;">✕ 닫기</button>
    </div>
  </div>
  <div style="flex: 1; padding: 10px 0; display: flex;">
    <textarea id="fileEditorArea" style="width: 100%; height: 100%; background: #070a12; border: 1px solid var(--border); border-radius: 8px; padding: 10px; color: #e2e8f0; font-family: monospace; font-size: 12.5px; line-height: 1.5; resize: none; outline: none; box-sizing: border-box;"></textarea>
  </div>
</div>

<script>
var NL = String.fromCharCode(10);
// 🛡️ 보안 토큰 동적 관리 (하드코딩 제거)
let token = localStorage.getItem('m_auth_token') || '';
let currentEditFile = '';

// URL 파라미터에서 pin/token 자동 감지 및 저장 (편의 지원)
(function() {
  try {
    var params = new URLSearchParams(window.location.search);
    var qToken = params.get('token') || params.get('pin');
    if (qToken) {
      token = qToken;
      localStorage.setItem('m_auth_token', token);
    }
    var qProj = params.get('project');
    if (qProj) localStorage.setItem('c_project', qProj);
  } catch (_) {}
})();

function showLoginOverlay(errMsg) {
  var overlay = document.getElementById('loginOverlay');
  var errEl = document.getElementById('pinError');
  if (overlay) {
    if (overlay.style.display === 'flex') {
      if (errMsg && errEl && !errEl.innerText) errEl.innerText = errMsg;
      return;
    }
    overlay.style.display = 'flex';
  }
  if (errEl) errEl.innerText = errMsg || '';
  var input = document.getElementById('pinInput');
  if (input) { input.value = ''; setTimeout(function() { input.focus(); }, 100); }
}

function quickPin2612() { /* 배포판: 운영 PIN 단축 버튼 없음 */ }

function hideLoginOverlay() {
  var overlay = document.getElementById('loginOverlay');
  if (overlay) overlay.style.display = 'none';
}

function closeFileManager() {
  var overlay = document.getElementById('fileModalOverlay');
  if (overlay) overlay.style.display = 'none';
}

async function submitPinLogin() {
  var input = document.getElementById('pinInput');
  var errEl = document.getElementById('pinError');
  var pin = (input ? input.value : '').trim();
  if (!pin) {
    if (errEl) errEl.innerText = 'PIN 번호를 입력해 주세요.';
    return;
  }
  try {
    var res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: pin })
    });
    var data = await res.json();
    if (data.success && data.token) {
      token = data.token;
      localStorage.setItem('m_auth_token', token);
      hideLoginOverlay();
      if (typeof initApp === 'function') initApp();
      if (typeof syncLiveTranscript === 'function') syncLiveTranscript();
      if (typeof syncCodexStatus === 'function') syncCodexStatus();
      if (typeof syncAgyStatus === 'function') syncAgyStatus();
    if (typeof syncGrokStatus === 'function') syncGrokStatus();
    } else {
      if (errEl) errEl.innerText = data.message || data.error || '인증 실패';
    }
  } catch (err) {
    if (errEl) errEl.innerText = '서버 통신 오류가 발생했습니다.';
  }
}

// 🛡️ 모바일 모든 API 요청에 보안 인증 토큰 자동 주입 및 401 감지 인터셉터
(function() {
  var _origFetch = window.fetch;
  window.fetch = async function(url, options) {
    options = options || {};
    options.headers = options.headers || {};
    var _proj = ''; try { _proj = localStorage.getItem('c_project') || ''; } catch (_) {}
    if (typeof options.headers.set === 'function') {
      if (!options.headers.get('Authorization') && token) options.headers.set('Authorization', token);
      if (_proj && !options.headers.get('X-Console-Project')) options.headers.set('X-Console-Project', encodeURIComponent(_proj));
    } else {
      if (!options.headers['Authorization'] && token) options.headers['Authorization'] = token;
      if (_proj && !options.headers['X-Console-Project']) options.headers['X-Console-Project'] = encodeURIComponent(_proj);
    }
    var res = await _origFetch.call(this, url, options);
    if (res.status === 401 && String(url).indexOf('/api/login') === -1) {
      showLoginOverlay('보안 인증이 필요합니다. PIN을 입력하세요.');
    }
    return res;
  };
})();

var pc1LiveUrl = '';

async function checkPcDevices() {
  try {
    var res = await fetch('/api/devices');
    if (res.ok) {
      var data = await res.json();
      var devMap = data.active_devices || {};
      var p1 = null; // 배포판: PC 전환 바 없음 (허브 페이지가 PC 목록을 맡는다)
      if (p1 && p1.url) {
        pc1LiveUrl = p1.url;
        var lbl = document.getElementById('pcDirectLabel-pc1');
        if (lbl) lbl.innerText = 'PC 1';
        var dot = document.getElementById('pcDirectDot-pc1');
        if (dot) dot.classList.add('online');
      }
    }
  } catch (_) {}
}

function navigateToPc1() {
  if (pc1LiveUrl) {
    window.location.href = pc1LiveUrl;
  } else {
    alert('허브 페이지에서 PC 를 고르세요');
  }
}

function navigateToPc2() {
  // 이미 PC 2번 화면
}

window.addEventListener('DOMContentLoaded', function() {
  if (!token) {
    showLoginOverlay();
  }
  checkPcDevices();
  setInterval(checkPcDevices, 5000);
  refreshQuota(); setInterval(refreshQuota, 60000);
  refreshSysStatus(); setInterval(refreshSysStatus, 60000);
  updateTopBar(); loadProjects(); setInterval(loadProjects, 15000);
});

// 주소에 ?agent=<번호> 가 있으면 그 도구 버튼을 자동으로 눌러 준다.
// 에이전트별 고정 바로가기 링크(허브 → 프로젝트 → 에이전트)를 폰 북마크로 사용하기 위한 것.
function autoOpenAgentFromUrl() {
  try {
    var q = new URLSearchParams(location.search);
    var a = q.get('agent');
    if (a === null || a === '') return;
    var i = parseInt(a, 10); if (isNaN(i)) return;
    if (!document.getElementById('projToolBtn' + i)) return;
    setTimeout(function () { runProjectTool(i); }, 800);
  } catch (_) {}
}

// 프로젝트 도구 실행 버튼(project_tab.mode === 'run') — PC 에서 설정된 실행 파일을 띄운다
async function runProjectTool(i) {
  var sub = document.getElementById('projToolSub' + (i || 0));
  var prev = sub ? sub.textContent : '';
  if (sub) sub.textContent = '실행 중...';
  try {
    var res = await fetch('/api/project-run?i=' + (i || 0), { method: 'POST' });
    var d = await res.json();
    if (!d.success) { if (sub) sub.textContent = d.error || '실패'; setTimeout(function () { if (sub) sub.textContent = prev; }, 6000); return; }
    if (!d.view) { if (sub) sub.textContent = '실행됨 ' + d.at; setTimeout(function () { if (sub) sub.textContent = prev; }, 6000); return; }
    // 콘솔 안 화면으로 띄우는 에이전트 — 전용 주소가 열릴 때까지 기다렸다 iframe 에 건다
    if (sub) sub.textContent = '화면 여는 중...';
    switchTab('agent', document.getElementById('projToolBtn' + (i || 0)));
    document.getElementById('agentViewLabel').textContent = prev && prev !== '실행' ? prev : '에이전트';
    document.getElementById('agentViewState').textContent = '준비 중…';
    for (var n = 0; n < 40; n++) {
      var st = await (await fetch('/api/agent-view?i=' + (i || 0))).json();
      if (st.state === 'ready' && ((st.prefer === 'tunnel' ? st.publicUrl : st.viewUrl) || st.publicUrl)) {
        // 화면 앱(SPA)은 중계 경로에서 라우팅이 깨지므로 전용 주소를 그대로 사용한다(prefer=tunnel)
        var src = (st.prefer === 'tunnel' && st.publicUrl)
          ? st.publicUrl
          : (st.viewUrl ? (st.viewUrl + encodeURIComponent(token || '') + '/') : st.publicUrl);
        document.getElementById('agentFrame').src = src;
        document.getElementById('agentViewOpen').href = src;
        document.getElementById('agentViewState').textContent = '';
        if (st.label) document.getElementById('agentViewLabel').textContent = st.label;
        if (sub) sub.textContent = prev;
        return;
      }
      if (st.state === 'error') {
        document.getElementById('agentViewState').textContent = st.error || '실패';
        if (sub) sub.textContent = '실패';
        setTimeout(function () { if (sub) sub.textContent = prev; }, 6000);
        return;
      }
      await new Promise(function (r) { setTimeout(r, 1500); });
    }
    document.getElementById('agentViewState').textContent = '시간 초과';
    if (sub) sub.textContent = prev;
  } catch (e) {
    if (sub) sub.textContent = '통신 오류';
    setTimeout(function () { if (sub) sub.textContent = prev; }, 6000);
  }
}

function switchTab(name, el) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.tab-btn').forEach(b => { b.classList.remove('active'); if (b.getAttribute('role') === 'tab') b.setAttribute('aria-selected', 'false'); });
  var targetView = document.getElementById('view-' + name);
  if (targetView) targetView.classList.add('active');
  if (el) { el.classList.add('active'); if (el.getAttribute('role') === 'tab') el.setAttribute('aria-selected', 'true'); }
  if (name === 'codex') syncCodexStatus();
  if (name === 'agy') syncAgyStatus();
  if (name === 'grok') syncGrokStatus();
  if (name === 'scanner') refreshScannerTab();
  if (name === 'project') { var pf = document.getElementById('projectFrame'); if (pf && pf.src === 'about:blank') pf.src = pf.dataset.src; }
}

// 프로젝트 선택기 — 라우터 모드(/api/projects 200)일 때만 켜짐
var projList = [];
async function loadProjects() {
  var box = document.getElementById('projSel'); if (!box) return;
  try {
    var r = await fetch('/api/projects'); if (!r.ok) { box.classList.remove('on'); updateTopBar(); return; }
    var d = await r.json(); projList = d.projects || []; window.__recentRemoved = d.recentRemoved || [];
    // 기동 실패 안내: 배너가 아니라 상태줄 한 줄 (라우터 /api/projects 의 failedCount·notice)
    var pn = document.getElementById('projNotice');
    if (pn) { if (d.failedCount && d.notice) { pn.textContent = d.notice; pn.style.display = 'flex'; } else { pn.style.display = 'none'; } }
    if (!projList.length) { updateTopBar(); return; }
    var cur = projList.find(function (p) { return p.current; }) || projList[0];
    var items = projList.map(function (p) {
      // 2026-09-22: 홈(원맥스)은 서버가 맨 위로 내려줌 — 배지 "홈", 1번(PC 창)은 "PC창", 나머지는 상태. ⋯ 는 관리 시트(1번 지정·이름·해제)
      var badges = (p.home ? '<span class="pbadge home">홈</span>' : '') + (p.primary ? '<span class="pbadge pri">PC창</span>' : '');
      var sub = p.failed ? '기동 실패' : (p.primary ? '' : (p.windowPid === 'daemon' ? '데몬' : (p.alive ? '준비 중' : '꺼짐')));
      return '<div class="proj-item' + (p.current ? ' cur' : '') + '" onclick="selectProject(&quot;' + escapeHtml(p.name) + '&quot;)"><span class="pdot' + (p.windowPid ? ' on' : '') + '"></span><span class="pname">' + escapeHtml(p.name) + '</span>' + badges + '<span class="psub">' + sub + '</span><button type="button" class="pmore" aria-label="프로젝트 관리" onclick="event.stopPropagation(); openProjActions(&quot;' + escapeHtml(p.name) + '&quot;)">⋯</button></div>';
    }).join('');
    // 이 프로젝트 전용 화면(스캐너 등)은 헤더 버튼 대신 메뉴 항목으로 — 헤더에는 [현재 프로젝트 ▾] [＋] 만
    // 프로젝트 전용 도구(스캐너 등)는 헤더에 선택기 옆 버튼으로 남긴다 — 그 프로젝트의 서버가 렌더하므로 다른 프로젝트에선 자동으로 없음
    var tools = '';
    box.innerHTML = '<button class="tab-btn hdr-btn" onclick="toggleProjMenu(event)">' + escapeHtml(cur.name) + ' ▾</button>'
      + '<div class="proj-menu" id="projMenu">' + items + tools + '<div class="proj-item proj-add" onclick="addProject()">＋ 프로젝트 추가</div></div>'; // 추가는 메뉴 안 한 곳만
    box.classList.add('on');
  } catch (_) { box.classList.remove('on'); }
  updateTopBar();
}
// 상단 프로젝트/도구 행: 내용(프로젝트 선택기 on 또는 도구 버튼)이 없으면 행을 숨긴다 — 렌더 뒤마다 판정
// ===== 화면 테마: 설정 패널(8번)에서 light|dark|system. localStorage 에 같이 저장해 다음 로드 때 깜빡임 없이 먼저 적용 =====
function applyTheme(t) {
  if (t === 'light' || t === 'dark') document.documentElement.setAttribute('data-theme', t);
  else document.documentElement.removeAttribute('data-theme');
  try { if (t === 'light' || t === 'dark') localStorage.setItem('theme', t); else localStorage.removeItem('theme'); } catch (_) {}
}
// 키보드가 올라오면(visualViewport 가 줄면) 본문 높이를 보이는 영역에 맞춰 입력줄이 키보드 위로 올라오게 한다 (PO 2026-09-22)
(function () {
  var vv = window.visualViewport; if (!vv) return;
  var root = document.documentElement, body = document.body;
  function fit() {
    try {
      var h = Math.round(vv.height), off = Math.round(vv.offsetTop || 0);
      var kb = Math.max(0, window.innerHeight - h - off);
      if (kb > 80) { body.style.height = h + 'px'; root.style.height = h + 'px'; body.style.transform = off ? 'translateY(' + off + 'px)' : ''; body.setAttribute('data-kb', '1'); }
      else { body.style.height = ''; root.style.height = ''; body.style.transform = ''; body.removeAttribute('data-kb'); }
      var a = document.activeElement;
      if (kb > 80 && a && (a.tagName === 'TEXTAREA' || a.tagName === 'INPUT')) { try { a.scrollIntoView({ block: 'end' }); } catch (_) {} }
      var box = document.querySelector('.view.active [id$="ChatContainer"], .view.active #chatContainer');
      if (box && kb > 80) box.scrollTop = box.scrollHeight;
    } catch (_) {}
  }
  vv.addEventListener('resize', fit); vv.addEventListener('scroll', fit); window.addEventListener('orientationchange', function () { setTimeout(fit, 250); });
  document.addEventListener('focusin', function (e) { var t = e.target; if (t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT')) { setTimeout(fit, 60); setTimeout(fit, 350); } });
  document.addEventListener('focusout', function () { setTimeout(fit, 120); });
  window.__vvFit = fit;
})();
// 허브 iframe 안이면(embed 파라미터가 없더라도) 맨 윗줄을 숨기고, 허브의 ⚙ 가 보내는 메시지로 설정 시트를 연다
(function () {
  try { if (window.self !== window.top) { var tl = document.getElementById('topLine'); if (tl) tl.remove(); } } catch (_) {}
  window.addEventListener('message', function (e) {
    var d = e && e.data; if (!d || typeof d !== 'object') return;
    if (d.type === 'onemacs:open-settings') { try { openSettings(); } catch (_) {} try { (e.source || window.parent).postMessage({ type: 'onemacs:settings-opened' }, '*'); } catch (_) {} }
    if (d.type === 'onemacs:open-guide') { try { openGuide(); } catch (_) {} }
  });
})();
function openGuide() {
  // 온라인 사용법이 우선, 안 열리면(오프라인) 이 PC 콘솔의 /guide 폴백
  var online = 'https://www.waat.community/market/onemacs/guide';
  if (navigator.onLine === false) { window.open('/guide', '_blank'); return; }
  var w = window.open(online, '_blank');
  if (!w) location.href = '/guide';
}

// ===== ⚙ 콘솔 설정 패널 (/api/settings) =====
var CS = { settings: null, catalog: null, tdef: {}, tmax: 180 };
var AI_NAME = { claude: 'Claude Code', codex: 'Codex', agy: 'Antigravity', grok: 'Grok' };
async function loadSettings(apply) {
  try {
    var r = await fetch('/api/settings'); if (!r.ok) return null;
    var d = await r.json(); CS.settings = d.settings; CS.catalog = d.catalog; CS.tdef = d.timeout_default || {}; CS.tmax = d.timeout_max || 180; CS.permMode = d.perm_mode || ''; CS.mirror = d.mirror_window; CS.mirrorAvailable = d.mirror_available;
    if (apply) {
      applyTheme(CS.settings.theme);
      if (typeof setChatViewMode === 'function' && !window._userPickedMode) setChatViewMode(CS.settings.chat_view_mode);
      renderModelSubs();
    }
    return d;
  } catch (_) { return null; }
}
function renderModelSubs() {
  if (!CS.settings) return;
  ['claude', 'codex', 'agy', 'grok'].forEach(function (ai) { var el = document.getElementById('modelSub-' + ai); if (el) el.textContent = CS.settings.model_labels[ai] || CS.settings.models[ai]; });
}
async function saveSettings(patch, label) {
  var saved = document.getElementById('settingsSaved');
  try {
    var r = await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(patch) });
    var d = await r.json();
    if (d.settings) { CS.settings = d.settings; renderModelSubs(); }
    if (d.errors && d.errors.length) { if (saved) { saved.style.color = 'var(--danger)'; saved.textContent = d.errors.join(' · '); } if (typeof showToast === 'function') showToast(d.errors[0]); }
    else if (saved) { saved.style.color = 'var(--win)'; saved.textContent = (label || '설정') + ' 저장했습니다'; setTimeout(function () { if (saved.textContent.indexOf('저장했습니다') !== -1) saved.textContent = ''; }, 2500); }
    return d;
  } catch (e) { if (saved) { saved.style.color = 'var(--danger)'; saved.textContent = '저장 실패 — PC 콘솔 연결을 확인해 주세요'; } return null; }
}
async function pickModel(ai, id) {
  var patch = { models: {} }; patch.models[ai] = id;
  var d = await saveSettings(patch, (AI_NAME[ai] || ai) + ' 모델');
  if (d && d.success && typeof showToast === 'function') showToast((AI_NAME[ai] || ai) + ' 모델 → ' + (CS.settings.model_labels[ai] || id) + ' (다음 지시부터)');
}
// 설정 시트
function openSettings() {
  var go = function () { renderSettings(); document.getElementById('sheetBackdrop').classList.add('open'); document.getElementById('settingsSheet').classList.add('open'); };
  loadSettings(false).then(function (d) { if (d) go(); else { if (typeof showToast === 'function') showToast('설정을 불러오지 못했습니다 — PC 콘솔 연결을 확인해 주세요'); } });
}
function closeSettings() { document.getElementById('sheetBackdrop').classList.remove('open'); document.getElementById('settingsSheet').classList.remove('open'); }
function closeSheets() { closeSettings(); if (typeof closeProjSheet === 'function') closeProjSheet(); }
function segHtml(key, opts, cur) {
  return '<div class="seg" role="radiogroup">' + opts.map(function (o) { return '<button type="button" role="radio" aria-checked="' + (o.v === cur) + '" class="' + (o.v === cur ? 'on' : '') + '" onclick="setSeg(&quot;' + key + '&quot;, &quot;' + o.v + '&quot;, this)">' + o.l + '</button>'; }).join('') + '</div>';
}
function togHtml(key, on, label) { return '<button type="button" class="tog' + (on ? ' on' : '') + '" role="switch" aria-checked="' + !!on + '" aria-label="' + label + '" onclick="setTog(&quot;' + key + '&quot;, this)"></button>'; }
/** 핸드폰 앱 받기 — 앱 파일이 PC 에 있고, 지금 앱이 아닌 브라우저로 보고 있을 때만 보여 준다 */
function refreshGetApp() {
  var row = document.getElementById('srow-getapp');
  if (!row) return;
  fetch('/api/app-info').then(function (r) { return r.json(); }).then(function (d) {
    if (!d || !d.available) return;
    var mb = d.size ? ' (' + Math.round(d.size / 104857.6) / 10 + 'MB)' : '';
    var sub = document.getElementById('getapp-sub');
    if (d.inApp) {
      // 이미 앱으로 보고 있다 — **더 새 앱이 PC 에 있을 때만** 권한다.
      // 마켓을 안 거치므로 자동 업데이트가 없다. 우리가 알려 주지 않으면 옛 앱을 계속 쓴다.
      if (!d.update) return;
      row.style.display = '';
      if (sub) sub.textContent = '새 앱 v' + d.version + ' 이 PC에 있습니다' + mb + '. 지금 쓰시는 것은 v' + (d.yours || '1.0') + ' 입니다';
    } else {
      row.style.display = '';
      if (sub) sub.textContent = '내 PC에서 바로 받습니다' + mb + '. 앱을 쓰면 작업이 끝났을 때 알림이 오고 PIN을 매번 넣지 않아도 됩니다';
    }
  }).catch(function () {});
}
function getApp() {
  showToast('앱 파일을 내려받습니다. 받은 뒤 열어서 설치하세요');
  // 주소에 열쇠를 같이 붙인다 — 허브 페이지 안(iframe)에서는 브라우저가 쿠키를 안 보내는 일이 있어
  // 쿠키만 믿으면 「인증 필요」가 뜬다 (PO 폰 실측 2026-09-23, 삼성 인터넷).
  var q = '';
  try {
    var sp = new URLSearchParams(location.search);
    var t = sp.get('token') || sp.get('pin') || '';
    if (t) q = '?pin=' + encodeURIComponent(t);
  } catch (_) {}
  try { window.location.href = '/app.apk' + q; } catch (_) {}
}
function renderSettings() {
  var st = CS.settings; if (!st) return;
  var b = document.getElementById('settingsBody'); if (!b) return;
  var h = '';
  // ── 구역 1: 핸드폰에 저장되는 설정 (PO 2026-09-22: 구역을 색으로 나누고 "연결된 모든 PC에 똑같이 적용") ──
  h += '<div class="szone szone-phone"><div class="szone-head"><b>핸드폰에 저장되는 설정</b><span>연결된 모든 PC에 똑같이 적용</span></div>';
  // 1-1 AI 답변 보기 방식
  h += '<div class="srow srow-stack"><div class="sl">AI 답변 보기 방식</div><div class="sc">' + segHtml('chat_view_mode', [{ v: 'summary', l: '요약' }, { v: 'detail', l: '상세' }, { v: 'full', l: '전체' }], st.chat_view_mode) + '</div></div>';
  // 1-2 테마
  h += '<div class="srow srow-stack"><div class="sl">화면 테마</div><div class="sc">' + segHtml('theme', [{ v: 'dark', l: '어두운 화면' }, { v: 'light', l: '밝은 화면' }, { v: 'system', l: '기기 설정' }], st.theme) + '</div></div>';
  // 1-2b 핸드폰 앱 받기 — 앱 파일이 PC 에 있을 때만, 그리고 앱이 아닌 브라우저로 볼 때만 나타난다
  //  (PO 2026-09-23: 「한 개의 파일을 다운로드 받으면 앱도 쓸 수 있게」 — 배포판 zip 에 앱을 같이 넣고 내 PC 가 내려준다)
  h += '<div class="srow" id="srow-getapp" style="display:none"><div class="sl">핸드폰 앱 받기<small id="getapp-sub">내 PC에서 바로 받습니다. 앱을 쓰면 작업이 끝났을 때 알림이 오고 PIN을 매번 넣지 않아도 됩니다</small></div>'
    + '<div class="sc"><button type="button" class="pin-btn" onclick="getApp()">앱 받기</button></div></div>';
  // 1-3 알림
  h += '<div class="srow"><div class="sl">작업 끝나면 알림</div><div class="sc">' + togHtml('notify_on_done', st.notify_on_done, '작업 끝나면 알림') + '</div></div>';
  // 1-4 동시에 시키기
  h += '<div class="srow srow-stack"><div class="sl">동시에 작업시킬 대상 AI 선택</div><div class="sc">' + segHtml('delegate_default', [{ v: 'both', l: 'Codex+Antigravity' }, { v: 'all', l: '셋 다' }], st.delegate_default) + '</div></div>';
  // 1-5 재시도
  h += '<div class="srow"><div class="sl">실패 시 자동시도</div><div class="sc">' + togHtml('auto_retry', st.auto_retry, '실패 시 자동시도') + '</div></div>';
  // 1-6 남은 한도
  h += '<div class="srow"><div class="sl">남은 한도 표시</div><div class="sc">' + togHtml('show_quota', st.show_quota, '남은 한도 표시') + '</div></div>';
  h += '</div>';
  // ── 구역 2: 지금 연결된 PC에만 저장되는 설정 ──
  h += '<div class="szone szone-pc"><div class="szone-head"><b>지금 연결된 PC에만 저장되는 설정</b><span>연결된 PC마다 각각 적용</span></div>';
  // 2-1 모델 — AI 마다
  h += '<div class="srow"><div class="sl">AI별로 사용할 모델 선택</div></div>';
  ['claude', 'codex', 'agy', 'grok'].forEach(function (ai) {
    var cat = CS.catalog[ai]; var cur = st.models[ai];
    h += '<div class="srow" style="padding-left:8px"><div class="sl">' + AI_NAME[ai] + '</div><div class="sc"><select class="sel-plain" aria-label="' + AI_NAME[ai] + ' 모델" onchange="pickModel(&quot;' + ai + '&quot;, this.value)">'
      + cat.items.map(function (it) { return '<option value="' + escapeHtml(it.id) + '"' + (it.id === cur ? ' selected' : '') + '>' + escapeHtml(it.label) + '</option>'; }).join('') + '</select></div></div>';
  });
  // 모델 선택 아래: 새 버전 미확인 안내(회색 한 줄) — 배너 대신
  try {
    var unv = (sysStatus && sysStatus.notices || []).filter(function (n) { return n.kind === 'unverified'; });
    if (unv.length) h += '<div class="srow" style="min-height:0;padding:0 0 8px 8px"><div class="sl"><small>' + unv.map(function (n) { return escapeHtml(n.message); }).join('<br>') + '</small></div></div>';
  } catch (_) {}
  // 2-2 제한 시간
  h += '<div class="srow"><div class="sl">AI별 작업 제한 시간 설정<small>기본 설정 시간은 20분(Claude Code는 30분)이며, 늘리기만 가능</small></div></div>';
  ['claude', 'codex', 'agy', 'grok'].forEach(function (ai) {
    var v = st.timeout_min[ai], d = CS.tdef[ai] || v;
    h += '<div class="srow" style="padding-left:8px"><div class="sl">' + AI_NAME[ai] + '</div><div class="sc num-row"><button type="button" aria-label="' + AI_NAME[ai] + ' 제한 시간 줄이기" onclick="stepTimeout(&quot;' + ai + '&quot;, -10)"' + (v - 10 < d ? ' disabled' : '') + '>−</button><span id="tmo-' + ai + '">' + v + '분</span><button type="button" aria-label="' + AI_NAME[ai] + ' 제한 시간 늘리기" onclick="stepTimeout(&quot;' + ai + '&quot;, 10)"' + (v + 10 > CS.tmax ? ' disabled' : '') + '>+</button></div></div>';
  });
  // 2-3 PC 창 미러링 (첫 프로젝트만, 즉시 적용)
  var mw = (typeof CS.mirror === 'boolean') ? CS.mirror : null;
  if (CS.mirrorAvailable === false) h += '<div class="srow"><div class="sl">PC 창 미러링<small>이 프로젝트는 창 없이 동작합니다. 첫 프로젝트에서만 켤 수 있습니다.</small></div></div>';
  else h += '<div class="srow"><div class="sl">핸드폰 글의 PC 터미널 미러링(기본 켬)</div><div class="sc">' + togHtml('mirror_window', mw !== false, '핸드폰 글의 PC 터미널 미러링') + '</div></div>';
  // 2-4 권한 모드 (전체 권한으로 갈 때 경고 + PIN)
  var pm = CS.permMode || (sysStatus && sysStatus.perm_mode) || 'safe';
  h += '<div class="srow"><div class="sl">권한 모드</div><div class="sc">' + segHtml('perm_mode', [{ v: 'safe', l: '안전 모드' }, { v: 'full', l: '자동 승인 모드' }], pm) + '</div></div>';
  h += '<div class="srow" id="permConfirm" style="display:none;min-height:0"><div class="sl" style="flex:1"><small style="color:var(--warn);display:block;margin-bottom:6px">자동 승인 모드가 되면 AI가 묻지 않고 PC의 파일을 바꾸거나 명령을 실행합니다. 그대로 하려면 지금 PIN을 넣어 주세요.</small><div class="pin-row"><input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" id="permPin" class="pin-in" placeholder="지금 PIN" aria-label="지금 PIN"><button type="button" class="pin-btn" onclick="confirmPerm()">자동 승인 모드로 바꾸기</button><button type="button" class="pin-btn ghost" onclick="cancelPerm()">취소</button></div></div></div>';
  // 2-5 PIN 변경 (PO 2026-09-22: 버튼 하나 → 누르면 새 PIN 두 번 입력 칸이 나온다)
  h += '<div class="srow"><div class="sl">PIN 변경<small>PIN을 변경하려면 새 숫자 6개를 두 번 입력해야 하며, 다른 기기나 PC 브라우저에서 새 PIN으로 다시 로그인 필요</small></div><div class="sc"><button type="button" class="pin-btn" id="pinStartBtn" onclick="startPinChange()">PIN 변경하기</button></div></div>';
  h += '<div class="srow" id="pinPanel" style="display:none;min-height:0"><div class="sl" style="flex:1"><div class="pin-row"><input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" id="pinNew1" class="pin-in" placeholder="새 PIN" aria-label="새 PIN 6자리"><input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" id="pinNew2" class="pin-in" placeholder="한 번 더" aria-label="새 PIN 다시"><button type="button" class="pin-btn" onclick="changePin()">확인</button><button type="button" class="pin-btn ghost" onclick="cancelPinChange()">취소</button></div></div></div>';
  h += '</div>';
  b.innerHTML = h;
  refreshGetApp();
}
// 권한 모드: 안전 → 즉시 저장, 전체 → PIN 확인 줄을 펼친다
var _permPendingEl = null;
function permSelect(v, el) {
  var box = document.getElementById('permConfirm');
  if (v === 'safe') { box.style.display = 'none'; saveSettings({ perm_mode: 'safe' }, '권한 모드').then(function (d) { if (d && d.success) { CS.permMode = 'safe'; markSeg(el); } }); return; }
  _permPendingEl = el; box.style.display = ''; var i = document.getElementById('permPin'); if (i) { i.value = ''; try { i.focus(); } catch (_) {} }
}
function cancelPerm() { document.getElementById('permConfirm').style.display = 'none'; _permPendingEl = null; }
async function confirmPerm() {
  var pin = (document.getElementById('permPin') || {}).value || '';
  if (!/^\d{4,8}$/.test(pin)) { showToast('지금 PIN 을 넣어 주세요'); return; }
  var d = await saveSettings({ perm_mode: 'full', pin: pin }, '권한 모드');
  if (d && d.success) { CS.permMode = 'full'; markSeg(_permPendingEl); cancelPerm(); showToast('자동 승인 모드로 바꿨습니다'); }
}
function markSeg(el) { if (el && el.parentElement) Array.prototype.forEach.call(el.parentElement.children, function (c) { c.classList.toggle('on', c === el); c.setAttribute('aria-checked', c === el); }); }
function startPinChange() { var p = document.getElementById('pinPanel'); if (!p) return; p.style.display = ''; var b = document.getElementById('pinStartBtn'); if (b) b.style.display = 'none'; var i = document.getElementById('pinNew1'); if (i) { i.value = ''; try { i.focus(); } catch (_) {} } var i2 = document.getElementById('pinNew2'); if (i2) i2.value = ''; }
function cancelPinChange() { var p = document.getElementById('pinPanel'); if (p) p.style.display = 'none'; var b = document.getElementById('pinStartBtn'); if (b) b.style.display = ''; }
async function changePin() {
  var n1 = (document.getElementById('pinNew1') || {}).value || '', n2 = (document.getElementById('pinNew2') || {}).value || '';
  var saved = document.getElementById('settingsSaved');
  var fail = function (m) { if (saved) { saved.style.color = 'var(--danger)'; saved.textContent = m; } showToast(m); };
  if (!/^\d{6}$/.test(n1)) return fail('새 PIN 은 숫자 6자리여야 합니다');
  if (n1 !== n2) return fail('새 PIN 두 번이 서로 다릅니다');
  try {
    var r = await fetch('/api/pin-change', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin_new: n1 }) });
    var d = await r.json();
    if (!d.success) return fail(d.error || 'PIN 을 바꾸지 못했습니다');
    if (d.token) { try { localStorage.setItem('m_auth_token', d.token); if (typeof token !== 'undefined') token = d.token; } catch (_) {} }
    try { window.parent && window.parent !== window && window.parent.postMessage({ type: 'onemacs:pin-changed', token: d.token }, '*'); } catch (_) {}
    try { if (window.OneMacsApp && OneMacsApp.pinChanged) OneMacsApp.pinChanged(n1, d.token || ''); } catch (_) {}
    ['pinNew1', 'pinNew2'].forEach(function (id) { var e = document.getElementById(id); if (e) e.value = ''; });
    cancelPinChange();
    if (saved) { saved.style.color = 'var(--win)'; saved.textContent = 'PIN을 변경했습니다 — 다른 기기나 PC 브라우저는 새 PIN으로 다시 로그인해야 합니다'; }
    showToast('PIN을 변경했습니다');
  } catch (_) { fail('PIN 을 바꾸지 못했습니다 — PC 콘솔 연결을 확인해 주세요'); }
}
// 핸드폰에 저장되는 설정(구역 1): 바꾸면 앱에도 알려 보관본을 갱신 → 다른 PC 에 연결할 때 같은 값을 밀어 넣는다 (앱 v1.4.19)
var PHONE_PREF_KEYS = { chat_view_mode: 1, theme: 1, notify_on_done: 1, delegate_default: 1, auto_retry: 1, show_quota: 1 };
function tellAppPref(key, v) { try { if (PHONE_PREF_KEYS[key] && window.OneMacsApp && OneMacsApp.prefChanged) OneMacsApp.prefChanged(key, JSON.stringify(v)); } catch (_) {} }
async function setSeg(key, v, el) {
  if (key === 'perm_mode') return permSelect(v, el);
  var patch = {}; patch[key] = v;
  var d = await saveSettings(patch, { chat_view_mode: 'AI 답변 보기 방식', delegate_default: '동시에 작업시킬 대상 AI', theme: '화면 테마' }[key] || key);
  if (!d || !d.success) return;
  tellAppPref(key, v);
  if (el && el.parentElement) { Array.prototype.forEach.call(el.parentElement.children, function (c) { c.classList.toggle('on', c === el); c.setAttribute('aria-checked', c === el); }); }
  if (key === 'theme') applyTheme(v);
  if (key === 'chat_view_mode' && typeof setChatViewMode === 'function') setChatViewMode(v);
}
async function setTog(key, el) {
  var next = !el.classList.contains('on'); var patch = {}; patch[key] = next;
  if (key === 'mirror_window') { var d0 = await saveSettings(patch, '핸드폰 글의 PC 터미널 미러링'); if (d0 && d0.success) { CS.mirror = !!d0.mirror_window; el.classList.toggle('on', CS.mirror); el.setAttribute('aria-checked', CS.mirror); } return; }
  var d = await saveSettings(patch, { notify_on_done: '알림', auto_retry: '실패 시 자동시도', show_quota: '남은 한도 표시' }[key] || key);
  if (!d || !d.success) return;
  tellAppPref(key, next);
  el.classList.toggle('on', next); el.setAttribute('aria-checked', next);
  if (key === 'show_quota' && typeof refreshQuota === 'function') refreshQuota();
}
async function stepTimeout(ai, delta) {
  var cur = CS.settings.timeout_min[ai]; var next = Math.max(CS.tdef[ai] || cur, Math.min(CS.tmax, cur + delta));
  if (next === cur) return;
  var patch = { timeout_min: {} }; patch.timeout_min[ai] = next;
  var d = await saveSettings(patch, AI_NAME[ai] + ' 제한 시간');
  if (d && d.success) renderSettings();
}
document.addEventListener('DOMContentLoaded', function () { loadSettings(true); });
function updateTopBar() {
  var tb = document.querySelector('.top-bar'); if (!tb) return;
  var sel = document.getElementById('projSel');
  var hasSel = !!(sel && sel.classList.contains('on') && sel.children.length);
  var right = tb.querySelector('.top-bar-right');
  var hasTool = !!(right && right.querySelector('button'));
  tb.classList.toggle('empty', !(hasSel || hasTool));
}
// 칩(div role=button) 키보드 활성화 — Enter/Space 로 클릭과 동일
document.addEventListener('keydown', function (e) { var t = e.target; if (t && t.classList && t.classList.contains('chip') && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); t.click(); } });
function toggleProjMenu(ev) { if (ev) ev.stopPropagation(); var m = document.getElementById('projMenu'); if (m) m.classList.toggle('open'); }
document.addEventListener('click', function () { var m = document.getElementById('projMenu'); if (m) m.classList.remove('open'); });
function gotoProject(name) {
  try { localStorage.setItem('c_project', name); } catch (_) {}
  var u = new URL(location.href); u.searchParams.set('project', name); if (token) u.searchParams.set('pin', token);
  location.replace(u.toString());
}
async function selectProject(name) {
  try {
    var r = await fetch('/api/project-select?name=' + encodeURIComponent(name) + '&project=' + encodeURIComponent(name)); var d = await r.json();
    if (!d.success) { showToast('전환 실패: ' + (d.error || '')); return; }
    showToast('프로젝트 → ' + name);
    try { localStorage.setItem('c_project', name); await fetch('/api/main-restart?project=' + encodeURIComponent(name), { method: 'POST' }); } catch (_) {}
    setTimeout(function () { gotoProject(name); }, 300);
  } catch (e) { showToast('전환 오류'); }
}
// ===== 2026-09-22 ④ 프로젝트 추가·관리 — 바텀시트 (허브 iframe 안에서 window.prompt 가 막혀 아무 일도 안 일어나던 문제) =====
function openProjSheet(title, html) {
  var pm = document.getElementById('projMenu'); if (pm) pm.classList.remove('open'); // 뒤에 열린 프로젝트 메뉴는 닫는다
  document.getElementById('projSheetTitle').textContent = title;
  document.getElementById('projSheetBody').innerHTML = html;
  document.getElementById('settingsSheet').classList.remove('open');
  document.getElementById('sheetBackdrop').classList.add('open');
  document.getElementById('projSheet').classList.add('open');
}
function closeProjSheet() { document.getElementById('projSheet').classList.remove('open'); if (!document.getElementById('settingsSheet').classList.contains('open')) document.getElementById('sheetBackdrop').classList.remove('open'); }
function pjMsg(text, cls) { var m = document.getElementById('pjMsg'); if (m) { m.textContent = text || ''; m.className = 'pj-msg' + (cls ? ' ' + cls : ''); } }
async function pjPost(url, body) {
  var r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  var d = null; try { d = await r.json(); } catch (_) {}
  return d || { success: false, error: 'HTTP ' + r.status };
}
// 경로는 onclick 속성의 JS 문자열에 직접 못 넣는다(백슬래시가 이스케이프로 사라짐) → 배열에 담아 인덱스로 참조
var pjPaths = [];
function pjRef(pth) { pjPaths.push(String(pth)); return 'pjPaths[' + (pjPaths.length - 1) + ']'; }
function projByName(name) { return (projList || []).find(function (p) { return p.name === name; }) || null; }

// ---- 추가: 1단계 분기 ----
function addProject() {
  var recent = (window.__recentRemoved || []);
  var html = '<p class="sheet-note">PC 에 이미 있는 폴더를 붙이거나, 새 폴더를 만듭니다.</p>'
    + '<button type="button" class="pj-opt" onclick="pjConnectStart()">📂 기존 폴더 연결<small>PC 의 폴더를 골라 프로젝트로 붙입니다 (파일은 그대로)</small></button>'
    + '<button type="button" class="pj-opt" onclick="pjNewStart()">🆕 새 폴더 만들기<small>이름을 정하면 지정한 위치에 빈 폴더를 만듭니다</small></button>';
  if (recent.length) {
    html += '<p class="sheet-note" style="margin-top:10px">최근 해제한 프로젝트 — 누르면 다시 연결 (대화 이어짐)</p><div class="pj-list">'
      + recent.map(function (r) { return '<div class="pj-row" onclick="pjReconnect(&quot;' + escapeHtml(r.name) + '&quot;, ' + pjRef(r.dir) + ')"><span class="pj-nm">↩ ' + escapeHtml(r.name) + '</span><span class="pj-tag">' + escapeHtml(r.dir) + '</span></div>'; }).join('') + '</div>';
  }
  openProjSheet('＋ 프로젝트 추가', html);
}
async function pjReconnect(name, dir) { pjAddDo({ name: name, dir: dir }, '다시 연결'); }

// ---- 폴더 탐색기 (공용): mode 'connect' = 이 폴더를 프로젝트로 / 'parent' = 새 폴더를 만들 위치 ----
var pjBrowse = { mode: 'connect', path: '', cb: null };
function pjBrowserHtml() {
  return '<div id="pjHere" class="pj-path"></div><div class="pj-bar" id="pjBar"></div><div class="pj-list" id="pjList"><div class="pj-row">불러오는 중…</div></div><div id="pjMsg" class="pj-msg"></div>';
}
async function pjLoadDir(p) {
  pjBrowse.path = p || '';
  var list = document.getElementById('pjList'), bar = document.getElementById('pjBar'), here = document.getElementById('pjHere');
  if (!list) return;
  try {
    var r = await fetch('/api/fs-browse' + (p ? '?path=' + encodeURIComponent(p) : '')); var d = await r.json();
    if (!d.success) { pjMsg(d.error || '열 수 없습니다', 'err'); return; }
    var rows = '';
    if (!p) {
      here.textContent = '어디서 고를까요?';
      bar.innerHTML = '<input class="pj-in" id="pjPathIn" placeholder="경로 직접 입력 (예: C:\\\\작업\\\\프로젝트)" style="margin:0;flex:1;min-width:0"><button type="button" onclick="pjLoadDir(document.getElementById(&#39;pjPathIn&#39;).value.trim())">이동</button>';
      rows += (d.favorites || []).map(function (f) { return pjRowHtml(f, '⭐'); }).join('');
      rows += (d.drives || []).map(function (dr) { return '<div class="pj-row" onclick="pjLoadDir(' + pjRef(dr.path) + ')"><span class="pj-nm">💽 ' + escapeHtml(dr.name) + '</span><span class="pj-tag">드라이브</span></div>'; }).join('');
    } else {
      here.textContent = d.path;
      var canPick = pjBrowse.mode === 'parent' ? true : !d.here.blocked;
      var pickLabel = pjBrowse.mode === 'parent' ? '여기에 만들기' : '이 폴더 연결';
      bar.innerHTML = '<button type="button" onclick="pjLoadDir(' + pjRef(d.parent || '') + ')">⬆ 위로</button><button type="button" onclick="pjLoadDir(&#39;&#39;)">⭐ 처음</button>'
        + '<button type="button" class="go" ' + (canPick ? '' : 'disabled') + ' onclick="pjPick(' + pjRef(d.path) + ')">' + pickLabel + '</button>';
      if (pjBrowse.mode === 'connect' && d.here.blocked) pjMsg(d.here.blocked, 'err'); else pjMsg('');
      rows += (d.dirs || []).map(function (f) { return pjRowHtml(f, '📁'); }).join('');
      if (!d.dirs || !d.dirs.length) rows += '<div class="pj-row" style="color:var(--dim)">하위 폴더 없음</div>';
    }
    list.innerHTML = rows;
  } catch (e) { pjMsg('탐색 오류', 'err'); }
}
function pjRowHtml(f, icon) {
  var tags = [];
  if (f.linked) tags.push('연결됨: ' + f.linked); else { if (f.hasConsole) tags.push('콘솔 있음'); if (f.hasGit) tags.push('git'); if (f.hasClaudeMd) tags.push('CLAUDE.md'); tags.push('파일 ' + f.files); }
  return '<div class="pj-row' + (f.linked ? ' blocked' : '') + '" onclick="pjLoadDir(' + pjRef(f.path) + ')"><span class="pj-nm">' + icon + ' ' + escapeHtml(f.name) + '</span><span class="pj-tag">' + escapeHtml(tags.join(' · ')) + '</span></div>';
}
function pjPick(p) { if (pjBrowse.cb) pjBrowse.cb(p); }

// ---- 2-A 기존 폴더 연결 ----
function pjConnectStart() {
  pjBrowse.mode = 'connect'; pjBrowse.cb = pjConnectChosen;
  openProjSheet('📂 기존 폴더 연결', '<p class="sheet-note">폴더를 열어 들어간 뒤 [이 폴더 연결]을 누르세요. 파일은 건드리지 않습니다.</p>' + pjBrowserHtml());
  pjLoadDir('');
}
function pjConnectChosen(dir) {
  var base = dir.split(/[\\\\/]/).filter(Boolean).pop() || '';
  openProjSheet('📂 기존 폴더 연결', '<div class="pj-path">' + escapeHtml(dir) + '</div><label class="sheet-note">프로젝트 이름 (폰 목록에 보이는 이름)</label><input class="pj-in" id="pjName" value="' + escapeHtml(base) + '" maxlength="40">'
    + '<div class="pj-bar"><button type="button" onclick="pjConnectStart()">← 다른 폴더</button><button type="button" class="go" onclick="pjAddDo({ name: document.getElementById(&#39;pjName&#39;).value.trim(), dir: ' + pjRef(dir) + ' }, &#39;연결&#39;)">연결</button></div><div id="pjMsg" class="pj-msg"></div>');
}

// ---- 2-B 새 폴더 만들기 ----
var pjNew = { parent: '' };
function pjNewStart(parent) {
  if (parent !== undefined) pjNew.parent = parent;
  var par = pjNew.parent;
  var preview = par ? (par.replace(/[\\\\/]+$/, '') + '\\\\' + '<span id="pjPrev">(이름)</span>') : '<span style="color:#f87171">위치를 먼저 고르세요</span>';
  openProjSheet('🆕 새 폴더 만들기', '<label class="sheet-note">프로젝트 이름 = 폴더 이름</label><input class="pj-in" id="pjName" placeholder="예: 신규기획" maxlength="40" oninput="var e=document.getElementById(&#39;pjPrev&#39;); if (e) e.textContent = this.value.trim() || &#39;(이름)&#39;">'
    + '<label class="sheet-note">만들 위치</label><div class="pj-path">' + preview + '</div>'
    + '<div class="pj-bar"><button type="button" onclick="pjParentPick()">📂 위치 고르기</button><button type="button" class="go" ' + (par ? '' : 'disabled') + ' onclick="pjAddDo({ name: document.getElementById(&#39;pjName&#39;).value.trim(), parent: pjNew.parent }, &#39;만들기&#39;)">만들기</button></div><div id="pjMsg" class="pj-msg"></div>');
  if (!par) {
    // 기본 위치(projects_root)가 실제로 있으면 자동 채움
    fetch('/api/fs-browse').then(function (r) { return r.json(); }).then(function (d) { if (d && d.projectsRoot) { var f = (d.favorites || []).find(function (x) { return x.path.toLowerCase() === String(d.projectsRoot).toLowerCase(); }); if (f) pjNewStart(f.path); } }).catch(function () {});
  }
}
function pjParentPick() {
  pjBrowse.mode = 'parent'; pjBrowse.cb = function (p) { pjNewStart(p); };
  openProjSheet('🆕 새 폴더를 만들 위치', '<p class="sheet-note">폴더를 열어 들어간 뒤 [여기에 만들기]를 누르세요.</p>' + pjBrowserHtml());
  pjLoadDir('');
}

// ---- 실제 추가 호출 + 진행 표시 ----
async function pjAddDo(body, verb) {
  if (!body.name) { pjMsg('이름을 입력하세요', 'err'); return; }
  pjMsg('① 폴더 검증 → ② 코드 복사 → ③ 서버 기동 → ④ Claude 준비 … 진행 중', '');
  var btns = document.querySelectorAll('#projSheet button'); btns.forEach(function (b) { b.disabled = true; });
  try {
    var d = await pjPost('/api/project-add', body);
    btns.forEach(function (b) { b.disabled = false; });
    if (!d.success) { pjMsg((verb || '추가') + ' 실패: ' + (d.error || ''), 'err'); if (d.needParent) setTimeout(pjParentPick, 900); return; }
    pjMsg('✅ ' + d.name + ' ' + (verb || '추가') + '됨' + (d.created ? ' (새 폴더: ' + d.dir + ')' : '') + (d.alive ? ' — 열어갑니다' : ' — 서버 기동 중: ' + (d.error || '')), 'ok');
    showToast('프로젝트 ' + (verb || '추가') + ': ' + d.name);
    setTimeout(function () { closeProjSheet(); gotoProject(d.name); }, d.alive ? 900 : 2500);
  } catch (e) { btns.forEach(function (b) { b.disabled = false; }); pjMsg('오류: ' + e.message, 'err'); }
}

// ---- 항목 ⋯ 관리 시트: 1번 지정 · 이름 바꾸기 · 연결 해제 ----
function openProjActions(name) {
  var p = projByName(name); if (!p) return;
  var html = '<div class="pj-path">' + escapeHtml(p.dir || '') + '</div>'
    + '<button type="button" class="pj-opt" ' + (p.primary ? 'disabled' : '') + ' onclick="pjPrimaryConfirm(&quot;' + escapeHtml(name) + '&quot;)">🖥 1번(PC 창)으로 지정<small>' + (p.primary ? '이미 1번입니다' : 'PC 에 대화형 Claude 창이 열리고, 지금 1번은 데몬으로 바뀝니다 (대화 유지)') + '</small></button>'
    + '<button type="button" class="pj-opt" ' + (p.home ? 'disabled' : '') + ' onclick="pjRenameStart(&quot;' + escapeHtml(name) + '&quot;)">✏️ 이름 바꾸기<small>' + (p.home ? '원맥스(홈) 이름은 고정' : '폰 목록의 이름만 바뀝니다 (폴더·대화 그대로)') + '</small></button>'
    + '<button type="button" class="pj-opt danger" ' + ((p.home || p.primary) ? 'disabled' : '') + ' onclick="pjRemoveConfirm(&quot;' + escapeHtml(name) + '&quot;)">⛔ 연결 해제<small>' + (p.home ? '원맥스(홈)는 해제 불가' : (p.primary ? '1번(PC 창)은 해제 불가 — 먼저 다른 프로젝트를 1번으로' : '목록에서만 뺍니다. 폴더·대화는 남아 다시 연결하면 이어집니다')) + '</small></button>'
    + '<div id="pjMsg" class="pj-msg"></div>';
  openProjSheet(name, html);
}
function pjPrimaryConfirm(name) {
  openProjSheet(name + ' → 1번', '<p class="sheet-note"><b>' + escapeHtml(name) + '</b>을(를) 1번(PC 창)으로 바꿉니다. 두 프로젝트 서버가 재시작되고(약 10초), 각자 대화는 세션 그대로 이어집니다.</p>'
    + '<div class="pj-bar"><button type="button" onclick="openProjActions(&quot;' + escapeHtml(name) + '&quot;)">취소</button><button type="button" class="go" onclick="pjPrimaryDo(&quot;' + escapeHtml(name) + '&quot;)">1번으로 지정</button></div><div id="pjMsg" class="pj-msg"></div>');
}
async function pjPrimaryDo(name) {
  pjMsg('바꾸는 중… (두 프로젝트 재시작)', '');
  var d = await pjPost('/api/project-primary', { name: name });
  if (!d.success) { pjMsg('실패: ' + (d.error || ''), 'err'); return; }
  pjMsg('✅ 1번 = ' + d.primary + (d.previous ? ' (전: ' + d.previous + ' → 데몬)' : ''), 'ok'); showToast('1번(PC 창) → ' + d.primary);
  setTimeout(function () { closeProjSheet(); loadProjects(); }, 1200);
}
function pjRenameStart(name) {
  openProjSheet('이름 바꾸기', '<label class="sheet-note">새 이름</label><input class="pj-in" id="pjName" value="' + escapeHtml(name) + '" maxlength="40">'
    + '<div class="pj-bar"><button type="button" onclick="openProjActions(&quot;' + escapeHtml(name) + '&quot;)">취소</button><button type="button" class="go" onclick="pjRenameDo(&quot;' + escapeHtml(name) + '&quot;)">바꾸기</button></div><div id="pjMsg" class="pj-msg"></div>');
}
async function pjRenameDo(name) {
  var nn = document.getElementById('pjName').value.trim(); if (!nn) { pjMsg('새 이름을 입력하세요', 'err'); return; }
  pjMsg('바꾸는 중…', '');
  var d = await pjPost('/api/project-rename', { name: name, newName: nn });
  if (!d.success) { pjMsg('실패: ' + (d.error || ''), 'err'); return; }
  showToast('이름 변경: ' + name + ' → ' + d.name);
  var cur = projByName(name); var wasCurrent = cur && cur.current;
  setTimeout(function () { closeProjSheet(); if (wasCurrent) gotoProject(d.name); else loadProjects(); }, 800);
}
function pjRemoveConfirm(name) {
  openProjSheet('연결 해제', '<p class="sheet-note"><b>' + escapeHtml(name) + '</b>을(를) 콘솔 목록에서 뺍니다.<br>· 폴더는 지우지 않습니다<br>· 대화 세션은 폴더에 남아 다시 연결하면 이어집니다<br>· 실행 중인 작업이 있으면 끊깁니다</p>'
    + '<label class="pj-chk"><input type="checkbox" id="pjDelConsole"> 폴더 안 콘솔 파일(_mobile_remote)도 삭제 (대화 기록은 남음)</label>'
    + '<div class="pj-bar"><button type="button" onclick="openProjActions(&quot;' + escapeHtml(name) + '&quot;)">취소</button><button type="button" class="go" style="background:#dc2626" onclick="pjRemoveDo(&quot;' + escapeHtml(name) + '&quot;)">해제</button></div><div id="pjMsg" class="pj-msg"></div>');
}
async function pjRemoveDo(name) {
  pjMsg('해제 중…', '');
  var d = await pjPost('/api/project-remove', { name: name, deleteConsoleFiles: !!(document.getElementById('pjDelConsole') || {}).checked });
  if (!d.success) { pjMsg('실패: ' + (d.error || ''), 'err'); return; }
  showToast('연결 해제: ' + d.name);
  var cur = projByName(name); var wasCurrent = cur && cur.current;
  setTimeout(function () { closeProjSheet(); if (wasCurrent) gotoProject(d.current); else loadProjects(); }, 800);
}

// ===== W9 말로 입력 (2026-09-22) =====
//  앱(안드로이드): WebView 는 Web Speech API 가 없으므로 네이티브 SpeechRecognizer 를 부른다 — window.OneMacsApp.startVoice(inputId)
//    → 앱이 인식 결과를 window.onVoiceText(text, isFinal, inputId) 로 돌려준다 (키보드가 뜨지 않는다)
//  브라우저(허브·PC): webkitSpeechRecognition (ko-KR, 중간 결과)
//  둘 다 없으면 버튼을 숨긴 채 둔다. 전송은 사람이 누른다 — 자동 전송하지 않는다(오전송 방지, PO 정책)
var voiceRec = null, voiceTargetId = null, voiceBtnEl = null;
// voiceBase = 듣기 시작 전 입력창 내용 + 앞 인식기들에서 **확정된** 말
// voiceSessionFinal = 지금 인식기에서 확정된 말 (인식기가 끝날 때 voiceBase 로 옮긴다)
var voiceBase = '', voiceSessionFinal = '';
// PO 2026-09-23 "말하고 있는데 꺼져 버려": 인식기는 잠깐 쉬면(무음 1~2초) 스스로 끝난다(브라우저 continuous=false, 안드로이드 SpeechRecognizer 기본 동작).
// → 사람이 멈춤을 누를 때까지(voiceWanted) 끝날 때마다 다시 켠다. 최대 3분, 5초 안에 6번 끊기면 중단(무한 재시작 방지).
var voiceWanted = false, voiceKind = '', voiceStartedAt = 0, voiceRestarts = [], voiceLastResultAt = 0;
// 사람이 멈춤을 누를 때까지 기다린다. PO 2026-09-23 「마이크가 계속 기다리고 있어야 되는데 금방 끊겨 버려」
//  - 10분까지 듣는다(전에는 3분).
//  - 재시작 횟수는 **말이 안 들어올 때만** 센다. 말하다 쉬어서 인식기가 끝나는 것은 정상이고, 그걸 고장으로
//    세면 생각하느라 몇 번 쉬는 사이에 스스로 멈춰 버린다 — 전에 「5초에 6번」이 그래서 자꾸 걸렸다.
//    글자가 한 번이라도 들어오면 그때까지의 재시작 기록을 지운다.
var VOICE_MAX_MS = 10 * 60 * 1000;
function voiceCanRestart() {
  if (!voiceWanted) return false;
  var now = Date.now();
  if (now - voiceStartedAt > VOICE_MAX_MS) { voiceWanted = false; showToast('말로 입력: 10분이 지나 멈췄습니다. 다시 누르면 이어서 됩니다'); return false; }
  // 최근에 말이 들어왔으면 정상으로 돌고 있는 것이다 — 헛돌이 셈을 비운다
  if (voiceLastResultAt && now - voiceLastResultAt < 15000) voiceRestarts = [];
  voiceRestarts = voiceRestarts.filter(function (t) { return now - t < 10000; });
  if (voiceRestarts.length >= 10) { voiceWanted = false; showToast('마이크가 계속 끊겨 멈췄습니다. 마이크 권한과 다른 앱의 마이크 사용을 확인해 주세요'); return false; }
  voiceRestarts.push(now); return true;
}
function inOneMacsApp() { try { return /ConsoleSystemApp/.test(navigator.userAgent || ''); } catch (_) { return false; } }
function voiceAvailable() {
  try { if (window.OneMacsApp && typeof window.OneMacsApp.startVoice === 'function') return 'app'; } catch (_) {}
  // 앱(WebView) 안에서는 브라우저 음성 인식이 동작하지 않는다 — 생성자는 있어도 결과가 오지 않는다. 앱 브리지가 있어야 한다
  if (inOneMacsApp()) return '';
  if (window.webkitSpeechRecognition || window.SpeechRecognition) return 'web';
  return '';
}
function voiceShowButtons() {
  var kind = voiceAvailable();
  var btns = document.querySelectorAll('.btn-voice');
  for (var i = 0; i < btns.length; i++) btns[i].style.display = kind ? 'inline-flex' : 'none';
}
function voiceSetListening(on) {
  if (!voiceBtnEl) return;
  voiceBtnEl.classList.toggle('listening', !!on);
  voiceBtnEl.setAttribute('aria-label', on ? '말로 입력 — 듣는 중, 누르면 멈춤' : '말로 입력');
}
/** 앱·브라우저 공통 진입점: 인식된 글자를 입력창에 넣는다 (isFinal 이면 확정)
 *  말하는 동안 글자가 바로 들어가고 입력창이 늘어난다 — autoGrow 가 높이를 키우는 함수다(resizeComposer 는 38px 로 되돌리는 것) */
function voiceJoin(a, b) {
  a = String(a || '').trim(); b = String(b || '').trim();
  return a && b ? (a + ' ' + b) : (a || b);
}
/**
 * 입력창을 **통째로 다시 그린다.** 글자를 더해 붙이면 안 된다 —
 * 인식기는 같은 구간을 여러 번 보내므로 더해 붙이면 같은 말이 겹쳐 쌓인다.
 * (PO 폰 실측 2026-09-23: 「근데 근데 근데 정산 근데 정산 근데 정산 표라는게 뭐야…」)
 *   voiceBase         = 듣기 시작 전 입력창 내용 + 앞 인식기들에서 확정된 말
 *   sessionText       = 지금 인식기에서 확정된 말 + 지금 말하는 중인 말
 */
function voiceShow(sessionText, inputId) {
  var el = document.getElementById(inputId || voiceTargetId || 'chatInput');
  if (!el) return;
  el.value = voiceJoin(voiceBase, sessionText);
  try { autoGrow(el); } catch (_) {}
  try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}   // 다른 곳의 input 처리도 같이 돌게
  try { el.scrollTop = el.scrollHeight; } catch (_) {}
}
/** 앱(안드로이드 네이티브 인식기)이 부르는 자리 — 한 번에 「이번에 말한 것 전체」를 준다 */
function onVoiceText(text, isFinal, inputId) {
  var t = String(text || '').trim();
  if (t) voiceLastResultAt = Date.now();   // 말이 들어오고 있다 = 정상. 헛돌이 셈을 비우는 근거가 된다
  voiceShow(t, inputId);
  if (isFinal) {
    voiceBase = voiceJoin(voiceBase, t);   // 확정된 것만 누적으로 옮긴다
    voiceSessionFinal = '';
    if (voiceKind === 'app' && voiceCanRestart()) {
      setTimeout(function () { if (!voiceWanted) return; try { window.OneMacsApp.startVoice(voiceTargetId); } catch (_) { voiceWanted = false; voiceSetListening(false); } }, 200);
    } else if (voiceKind !== 'web' || !voiceWanted) { voiceWanted = false; voiceSetListening(false); }
  }
}
window.onVoiceText = onVoiceText;
function toggleVoice(inputId, btn) {
  var kind = voiceAvailable();
  if (!kind) { showToast(inOneMacsApp() ? '앱을 v1.5.1 이상으로 업데이트하면 말로 입력할 수 있습니다' : '이 브라우저는 말로 입력을 지원하지 않습니다 (크롬을 쓰거나 앱에서 사용하세요)'); return; }
  var el = document.getElementById(inputId);
  if (!el) return;
  // 듣는 중이면 멈춤
  if (voiceBtnEl === btn && voiceBtnEl.classList.contains('listening')) { stopVoice(); return; }
  voiceTargetId = inputId; voiceBtnEl = btn; voiceBase = (el.value || '').trim(); voiceSessionFinal = '';
  voiceWanted = true; voiceKind = kind; voiceStartedAt = Date.now(); voiceRestarts = []; voiceLastResultAt = 0;
  voiceSetListening(true);
  if (kind === 'app') {
    try { window.OneMacsApp.startVoice(inputId); }
    catch (e) { voiceSetListening(false); showToast('말로 입력을 시작하지 못했습니다'); }
    return;
  }
  try {
    (function webStart() {
      var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      var rec = new SR(); voiceRec = rec;
      // continuous=false — 쉬면 인식기가 끝나고 onend 가 새로 켜서 이어 간다.
      // (PC1 2026-09-23 11:15 PO 실사용) 안드로이드 크롬은 continuous=true 에서 「그때까지 문장 전체」를 확정 결과로
      // 여러 번 올린다(A / A B / A B C) → 통째로 다시 그려도 겹친다. 데스크톱 크롬에서는 재현되지 않는다.
      rec.lang = 'ko-KR'; rec.interimResults = true; rec.continuous = false; rec.maxAlternatives = 1;
      rec.onresult = function (ev) {
        // **매번 처음부터 다시 읽는다.** resultIndex 부터만 읽어 더해 붙이면, 이미 확정된 말이
        // 다시 들어와 겹친다(continuous 에서는 결과가 계속 쌓인다). 통째로 다시 그리면 겹칠 수 없다.
        var fin = '', itm = '';
        for (var i = 0; i < ev.results.length; i++) {
          var r = ev.results[i];
          if (r.isFinal) fin = voiceJoin(fin, r[0].transcript);
          else itm = voiceJoin(itm, r[0].transcript);
        }
        voiceSessionFinal = fin;
        if (fin || itm) voiceLastResultAt = Date.now();
        voiceShow(voiceJoin(fin, itm), inputId);
      };
      rec.onerror = function (ev) {
        var e = ev && ev.error;
        if (e === 'not-allowed' || e === 'service-not-allowed' || e === 'audio-capture') { voiceWanted = false; voiceSetListening(false); if (e === 'not-allowed') showToast('마이크 권한이 필요합니다'); }
      };
      rec.onend = function () {
        if (voiceRec === rec) voiceRec = null;
        // 이 인식기에서 확정된 말을 누적으로 옮긴다. 다음 인식기는 빈 결과로 새로 시작하므로
        // 이렇게 해야 앞말이 남고, 겹치지도 않는다.
        voiceBase = voiceJoin(voiceBase, voiceSessionFinal);
        voiceSessionFinal = '';
        if (voiceCanRestart()) { try { webStart(); } catch (_) { voiceWanted = false; voiceSetListening(false); } }
        else { voiceWanted = false; voiceSetListening(false); }
      };
      rec.start();
    })();
  } catch (e) { voiceSetListening(false); showToast('말로 입력을 시작하지 못했습니다: ' + e.message); }
}
function stopVoice() {
  voiceWanted = false;
  voiceBase = voiceJoin(voiceBase, voiceSessionFinal); voiceSessionFinal = '';   // 멈출 때도 확정된 말은 남긴다
  try { if (voiceRec) { var r = voiceRec; voiceRec = null; r.stop(); } } catch (_) {}
  try { if (window.OneMacsApp && typeof window.OneMacsApp.stopVoice === 'function') window.OneMacsApp.stopVoice(); } catch (_) {}
  voiceSetListening(false);
}
window.stopVoice = stopVoice;
/** 앱이 기동 직후 브리지를 붙이므로 조금 늦게 한 번 더 확인 */
voiceShowButtons(); [400, 1200, 2500, 5000].forEach(function (ms) { setTimeout(voiceShowButtons, ms); });

// 선택형 질문 보기 버튼 → PC 창 위젯 조작 (DOWN × n → ENTER)
var askBusy = false;
async function askKeys(keys) {
  if (askBusy) return; askBusy = true;
  try { var r = await fetch('/api/main-keys', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ keys: keys }) }); var d = await r.json(); if (!d.success) showToast('전송 실패: ' + (d.error || '')); }
  catch (_) { showToast('전송 오류'); } finally { askBusy = false; }
}
function askPick(i, n, multi) {
  // PC 창 선택 위젯: 단일 선택은 ENTER 가 곧 답. 복수 선택은 ENTER 가 체크/해제(토글)이고, 제출은 → 로 Submit 에 간 뒤 ENTER.
  // 복수 선택은 커서가 마지막 토글 위치에 남으므로 UP×n 으로 맨 위로 올린 뒤 DOWN×i 로 절대 위치를 잡는다.
  var keys = [];
  if (multi) { for (var u = 0; u < n + 1; u++) keys.push('UP'); }
  for (var k = 0; k < i; k++) keys.push('DOWN'); keys.push('ENTER');
  showToast(multi ? ((i + 1) + '번 체크/해제 → 다 고르면 [제출]') : ((i + 1) + '번 선택 → PC 창'));
  askKeys(keys);
}
function askSubmitMulti() { showToast('제출 → PC 창'); askKeys(['RIGHT', 'ENTER']); }

// 구독 잔여 한도(5h/7d) 표시 — 남은 % 기준. 조회 불가 워커는 빈칸
function fmtReset(iso) {
  if (!iso) return '';
  var d = new Date(iso); if (isNaN(d)) return '';
  var hh = ('0' + d.getHours()).slice(-2), mm = ('0' + d.getMinutes()).slice(-2);
  var today = new Date();
  var sameDay = d.getFullYear() === today.getFullYear() && d.getMonth() === today.getMonth() && d.getDate() === today.getDate();
  return sameDay ? (hh + ':' + mm) : ((d.getMonth() + 1) + '/' + d.getDate() + ' ' + hh + ':' + mm);
}
function quotaText(w) {
  if (!w || w.supported === false) return '';
  if (!w.ok) return ''; // 조회 실패는 조용히 숨김 (비공식 경로)
  var col = function (p) { return p <= 10 ? '#f87171' : (p <= 30 ? '#fbbf24' : '#a7f3d0'); };
  var part = function (name, o) { return o ? name + ' <b style="color:' + col(o.left) + ';">' + o.left + '%</b>' : ''; };
  var t = '남은 ' + part('5h', w.h5) + (w.h5 && w.d7 ? ' · ' : '') + part('7d', w.d7);
  // 리셋 시각은 폭 절약을 위해 표시 생략 (fmtReset 은 필요 시 사용)
  return t;
}
async function refreshQuota() {
  try {
    var res = await fetch('/api/quota');
    var q = await res.json();
    if (!q || q.hidden || q.error) { ['assistant', 'codex', 'agy', 'grok'].forEach(function (k) { var el = document.getElementById('quota-' + k); if (el) el.innerHTML = ''; }); return; }
    var map = { assistant: q.claude, codex: q.codex, agy: q.agy, grok: q.grok };
    Object.keys(map).forEach(function (k) { var el = document.getElementById('quota-' + k); if (el) el.innerHTML = quotaText(map[k]); });
  } catch (_) {}
}

async function triggerScannerScan() {
  var badge = document.getElementById('scannerRunningBadge');
  if (badge) {
    badge.innerText = '⚡ 스캔 중...';
    badge.style.borderColor = '#f59e0b';
    badge.style.color = 'var(--warn)';
  }
  try {
    await fetch('/api/scanner-scan', { method: 'POST' });
    setTimeout(refreshScannerTab, 1500);
  } catch (_) {}
}

// ---- 스캐너 전략 탭 (strategies/*.json) ----
var stratState = { data: null, sel: null };
function stratTag(st) { var t = []; if (st.sample) t.push('샘플'); if (st.candidate) t.push('전진검증'); if (st.live) t.push('실매매'); return t.join(' · '); }
function stratTf(st) { return st.timeframe === '1d' ? '<span style="background:#6366f1; color:#fff; font-size:10px; padding:1px 5px; border-radius:6px; margin-left:4px;">일봉</span>' : ''; }
async function loadStrategies() {
  try {
    var r = await fetch('/api/scanner-strategies'); var d = await r.json();
    stratState.data = d;
    var list = d.strategies || [];
    var meta = document.getElementById('stratMeta'); if (meta) meta.innerText = list.length ? (list.filter(function (x) { return x.enabled; }).length + '/' + list.length + '개 켜짐' + (d.finished_at ? ' · ' + String(d.finished_at).slice(11, 16) + ' 스캔' : '')) : '';
    var kisEl = document.getElementById('stratKis'); if (kisEl) kisEl.innerHTML = (d.kis_configured === false) ? '⚠️ 증권사(KIS) 앱키 미등록 — 1단계(네이버 분봉) 스캔만 동작하고 2단계 정밀 신호·실매매는 꺼져 있습니다. <b>.env</b> 에 KIS_APP_KEY / KIS_APP_SECRET / KIS_ACCOUNT 를 넣으면 켜집니다.' : '';
    if (!stratState.sel || !list.some(function (x) { return x.id === stratState.sel; })) stratState.sel = list.length ? list[0].id : null;
    var tabs = document.getElementById('stratTabs');
    if (tabs) tabs.innerHTML = list.map(function (st) {
      return '<div class="strat-tab' + (st.id === stratState.sel ? ' active' : '') + (st.enabled ? '' : ' off') + '" onclick="selectStrategy(&quot;' + escapeHtml(st.id) + '&quot;)">' + escapeHtml(st.name || st.id) + stratTf(st) + '<span class="cnt">' + (st.hits ? st.hits.length : 0) + '</span></div>';
    }).join('');
    renderStrategyDetail();
    var ov = document.getElementById('stratOverlap');
    if (ov) { var keys = Object.keys(d.overlap || {}); ov.innerHTML = keys.length ? '⭐ 겹침 ' + keys.length + '종목: ' + keys.map(function (k) { var o = d.overlap[k]; return escapeHtml(o.name || k) + '(' + o.strategies.map(escapeHtml).join('+') + ')'; }).join(', ') : ''; }
  } catch (_) {}
}
function selectStrategy(id) { stratState.sel = id; loadStrategies(); }
function renderStrategyDetail() {
  var box = document.getElementById('stratDetail'); if (!box || !stratState.data) return;
  var st = (stratState.data.strategies || []).find(function (x) { return x.id === stratState.sel; });
  if (!st) { box.innerHTML = '<p style="color:var(--dim); font-size:12px; text-align:center; padding:8px;">strategies/ 폴더에 전략 파일이 없습니다. Claude Code에게 "전략 만들어줘"라고 말하세요.</p>'; return; }
  var isDaily = st.timeframe === '1d';
  var head = '<div class="strat-row" style="background:rgba(16,185,129,0.06);"><div><b style="color:#fff;">' + escapeHtml(st.name || st.id) + '</b>' + stratTf(st) + ' <span style="color:var(--dim); font-size:11px;">' + escapeHtml(st.direction || '') + ' · ' + (isDaily ? '일봉' : '1분봉') + ' · 대장 ' + st.n_bosses + ' · 졸병 ' + st.n_soldiers + ' · ' + st.min_score + '점↑' + (stratTag(st) ? ' · ' + stratTag(st) : '') + '</span>'
    + (st.scoring_rule ? '<div style="color:var(--dim); font-size:11px; margin-top:3px;">점수: ' + escapeHtml(st.scoring_rule) + (st.exit_rule ? ' · 청산: ' + escapeHtml(st.exit_rule) : '') + '</div>' : '')
    + (st.validation ? '<div style="color:#a5b4fc; font-size:11px; margin-top:3px;">검증: ' + escapeHtml(st.validation) + '</div>' : '')
    + (isDaily ? '<div style="color:var(--dim); font-size:11px; margin-top:3px;">오늘 후보 ' + (st.hits ? st.hits.length : 0) + '건' + (st.last_eval ? ' (' + escapeHtml(String(st.last_eval).slice(11, 16)) + ' 봇 평가)' : ' (봇이 09시 첫 스캔에 평가)') + (st.market ? ' · KODEX200 ' + Number(st.market.idx_close).toLocaleString() + ' / 200일선 ' + Number(st.market.idx_ma200).toLocaleString() + ' / 250일고점 ' + Number(st.market.idx_dd250).toFixed(1) + '%' : '') + '</div>' : '')
    + (st.description ? '<div style="color:var(--dim); font-size:11px; margin-top:3px;">' + escapeHtml(st.description) + '</div>' : '')
    + (st.errors && st.errors.length ? '<div style="color:#f87171; font-size:11px; margin-top:3px;">오류: ' + escapeHtml(st.errors.join(' / ')) + '</div>' : '') + '</div>'
    + '<button class="strat-switch' + (st.enabled ? ' on' : '') + '" onclick="toggleStrategy(&quot;' + escapeHtml(st.id) + '&quot;, ' + (st.enabled ? 'false' : 'true') + ')">' + (st.enabled ? '켜짐' : '꺼짐') + '</button></div>';
  var hits = st.hits || [];
  var rows = hits.length ? hits.map(function (h) {
    var rc = (h.rate || 0) > 0 ? '#ef4444' : ((h.rate || 0) < 0 ? '#3b82f6' : '#94a3b8');
    return '<div class="strat-row"><div><b style="color:#fff;">' + escapeHtml(h.name || h.code) + '</b> <span style="color:var(--dim); font-size:11px;">' + escapeHtml(h.code || '') + '</span>' + (h.reason ? '<div style="color:var(--dim); font-size:10px; margin-top:2px;">' + escapeHtml(h.reason) + '</div>' : '') + '</div><div style="text-align:right;"><div style="font-weight:800; color:#34d399;">' + h.score + '점</div><div style="font-size:11px; color:' + rc + ';">' + (h.price ? Number(h.price).toLocaleString() + '원 ' : '') + (h.rate == null ? '' : (((h.rate || 0) > 0 ? '+' : '') + (h.rate || 0) + '%')) + '</div></div></div>';
  }).join('') : '<p style="color:var(--dim); font-size:12px; text-align:center; padding:8px;">' + (st.enabled ? (isDaily ? '오늘 후보 없음 (봇이 09시 첫 스캔에 전일 확정 일봉으로 평가)' : '최근 스캔에서 이 전략을 통과한 종목 없음') : '꺼진 전략 — 켜면 다음 스캔부터 평가') + '</p>';
  box.innerHTML = head + rows;
}
async function toggleStrategy(id, on) {
  try {
    var r = await fetch('/api/scanner-strategy-toggle/' + encodeURIComponent(id), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ enabled: on }) });
    var d = await r.json(); showToast(d.success ? ('전략 ' + id + (d.enabled ? ' 켜짐' : ' 꺼짐') + ' (다음 스캔부터)') : ('실패: ' + (d.error || '')));
    loadStrategies();
  } catch (_) { showToast('전환 오류'); }
}

// 안내 자료 — 인증 헤더가 붙는 fetch 로 받아 화면 위 덮개에 띄운다 (새 탭은 허브 iframe·쿠키 사정으로 불안정)
async function openDoc(key) {
  var titles = { map: '🧩 파일 관계도', flow: '🔀 신호 흐름도', setup: '📘 설치 안내' };
  var ov = document.getElementById('docOverlay');
  if (!ov) {
    ov = document.createElement('div'); ov.id = 'docOverlay';
    ov.innerHTML = '<div class="doc-head"><span id="docTitle"></span><button type="button" aria-label="닫기" onclick="document.getElementById(\\'docOverlay\\').classList.remove(\\'on\\')">✕</button></div><iframe id="docFrame" title="안내 자료"></iframe>';
    document.body.appendChild(ov);
  }
  document.getElementById('docTitle').textContent = titles[key] || '안내 자료';
  var fr = document.getElementById('docFrame');
  fr.srcdoc = '<p style="font-family:sans-serif;padding:16px;color:#555">불러오는 중…</p>';
  ov.classList.add('on');
  try {
    var r = await fetch('/api/docs/' + key);
    var html = await r.text();
    fr.srcdoc = r.ok ? html : '<p style="font-family:sans-serif;padding:16px">' + html.replace(/</g, '&lt;') + '</p>';
  } catch (_) { fr.srcdoc = '<p style="font-family:sans-serif;padding:16px">문서를 불러오지 못했습니다.</p>'; }
}

async function refreshScannerTab() {
  loadStrategies();
  var listEl = document.getElementById('scannerTopCallsList');
  var stage2ListEl = document.getElementById('scannerStage2List');
  var stage2CountEl = document.getElementById('scannerStage2Count');
  var badge = document.getElementById('scannerRunningBadge');
  var logsEl = document.getElementById('scannerLogsArea');
  var countEl = document.getElementById('scannerCallCount');
  try {
    var res = await fetch('/api/scanner-status');
    var data = await res.json();
    if (!data) return;

    if (badge) {
      if (data.running) {
        badge.innerText = '⚡ 스캔 분석 진행 중...';
        badge.style.borderColor = '#f59e0b';
        badge.style.color = 'var(--warn)';
      } else {
        badge.innerText = '● 정상 가동 (스캔 완료)';
        badge.style.borderColor = '#10b981';
        badge.style.color = 'var(--win)';
      }
    }

    if (logsEl && data.logs && data.logs.length > 0) {
      logsEl.innerHTML = data.logs.map(l => '<div>' + escapeHtml(l) + '</div>').join('');
      logsEl.scrollTop = logsEl.scrollHeight;
    }

    // 1. Stage 2 5대장 2졸병 통과 종목 렌더링
    if (stage2ListEl) {
      var s2 = data.stage2 || [];
      if (stage2CountEl) stage2CountEl.innerText = s2.length + '종목';
      if (s2.length === 0) {
        stage2ListEl.innerHTML = '<p style="color:var(--dim); font-size:12px; text-align:center; padding:10px;">현재 5대장/2졸병 조건을 모두 충족한 Stage 2 종목이 없습니다.</p>';
      } else {
        var s2Html = '';
        s2.forEach((item, idx) => {
          var rateColor = item.rate > 0 ? '#ef4444' : (item.rate < 0 ? '#3b82f6' : '#94a3b8');
          var rateSign = item.rate > 0 ? '+' : '';
          s2Html += '<div style="background:rgba(56,189,248,0.06); border:1px solid rgba(56,189,248,0.3); border-radius:8px; padding:10px 12px; display:flex; justify-content:space-between; align-items:center;">';
          s2Html += '  <div>';
          s2Html += '    <div style="font-weight:800; font-size:13.5px; color:#fff; display:flex; align-items:center; gap:6px;">';
          s2Html += '      <span style="color:#38bdf8;">' + (idx+1) + '. ' + escapeHtml(item.name || item.code) + '</span>';
          s2Html += '      <span style="font-size:10px; color:var(--dim); font-family:monospace;">' + item.code + '</span>';
          s2Html += '    </div>';
          s2Html += '    <div style="font-size:11px; color:#94a3b8; margin-top:3px;">5대장: <b style="color:#38bdf8;">' + (item.boss || 0) + '/5</b> | 2졸병: <b style="color:#38bdf8;">' + (item.soldier || 0) + '/2</b> | 점수: <b style="color:#10b981;">' + (item.score || 0) + '점</b></div>';
          s2Html += '  </div>';
          s2Html += '  <div style="text-align:right;">';
          s2Html += '    <div style="font-weight:800; font-size:13px; color:#fff;">' + Number(item.price || 0).toLocaleString() + '원</div>';
          s2Html += '    <div style="font-weight:700; font-size:11.5px; color:' + rateColor + ';">' + rateSign + (item.rate || 0).toFixed(2) + '%</div>';
          s2Html += '  </div>';
          s2Html += '</div>';
        });
        stage2ListEl.innerHTML = s2Html;
      }
    }

    // 2. Stage 1 CALL 우세 종목 렌더링
    var calls = [];
    if (data.stage1 && data.stage1.length > 0) {
      calls = data.stage1.filter(s => (s.call_score >= 40 || s.passed));
      calls.sort((a,b) => (b.call_score - a.call_score) || (b.rate - a.rate));
    }

    if (countEl) countEl.innerText = '총 ' + calls.length + '종목 포착';

    if (listEl) {
      if (calls.length === 0) {
        listEl.innerHTML = '<p style="color:var(--dim); font-size:12px; text-align:center; padding:15px;">현재 조건을 만족하는 CALL 종목이 없습니다.</p>';
      } else {
        var html = '';
        calls.slice(0, 20).forEach((c, idx) => {
          var rateColor = c.rate > 0 ? '#ef4444' : (c.rate < 0 ? '#3b82f6' : '#94a3b8');
          var rateSign = c.rate > 0 ? '+' : '';
          html += '<div style="background:rgba(255,255,255,0.03); border:1px solid var(--border); border-radius:8px; padding:9px 12px; display:flex; justify-content:space-between; align-items:center;">';
          html += '  <div>';
          html += '    <div style="font-weight:800; font-size:13px; color:#fff; display:flex; align-items:center; gap:6px;">';
          html += '      <span>' + (idx+1) + '. ' + escapeHtml(c.name || c.code) + '</span>';
          html += '      <span style="font-size:10px; color:var(--dim); font-family:monospace;">' + c.code + '</span>';
          html += '    </div>';
          html += '    <div style="font-size:11px; color:#10b981; margin-top:2px; font-weight:700;">★ CALL 점수: ' + (c.call_score || 50) + '점</div>';
          html += '  </div>';
          html += '  <div style="text-align:right;">';
          html += '    <div style="font-weight:800; font-size:13px; color:#fff;">' + Number(c.price || 0).toLocaleString() + '원</div>';
          html += '    <div style="font-weight:700; font-size:11.5px; color:' + rateColor + ';">' + rateSign + (c.rate || 0).toFixed(2) + '%</div>';
          html += '  </div>';
          html += '</div>';
        });
        listEl.innerHTML = html;
      }
    }
  } catch (e) {
    if (listEl) listEl.innerHTML = '<p style="color:var(--danger); font-size:12px; text-align:center; padding:15px;">스캐너 조회 중 오류가 발생했습니다.</p>';
  }
}

async function loadSystemView() {
  refreshHostSystemStats();
  refreshSysFilesList();
}

async function refreshHostSystemStats() {
  try {
    var res = await fetch('/api/info');
    var data = await res.json();
    if (data) {
      if (document.getElementById('statHostname')) document.getElementById('statHostname').innerText = data.hostname || 'Windows';
      if (document.getElementById('statUptime')) document.getElementById('statUptime').innerText = (data.uptimeHours || 0) + '시간';
      if (document.getElementById('statRam')) document.getElementById('statRam').innerText = (data.freeMemMB || 0) + 'MB / ' + (data.totalMemMB || 0) + 'MB';
      if (document.getElementById('statCores')) document.getElementById('statCores').innerText = (navigator.hardwareConcurrency || 8) + ' Cores';
      if (document.getElementById('statWorkDir')) document.getElementById('statWorkDir').innerText = data.workDir || '';
    }
  } catch (_) {}
}

let allSysFiles = [];
async function refreshSysFilesList() {
  var listEl = document.getElementById('sysFileList');
  if (!listEl) return;
  listEl.innerHTML = '<p style="color: var(--dim); text-align: center; padding: 15px;">파일 로딩 중...</p>';
  try {
    var res = await fetch('/api/files');
    var data = await res.json();
    if (data.success && data.files) {
      allSysFiles = data.files;
      renderSysFiles(allSysFiles);
    } else {
      listEl.innerHTML = '<p style="color: var(--dim); text-align: center; padding: 15px;">파일이 없습니다.</p>';
    }
  } catch (err) {
    listEl.innerHTML = '<p style="color: var(--danger); text-align: center; padding: 15px;">파일 조회 오류</p>';
  }
}

function renderSysFiles(files) {
  var listEl = document.getElementById('sysFileList');
  if (!listEl) return;
  if (!files || files.length === 0) {
    listEl.innerHTML = '<p style="color: var(--dim); text-align: center; padding: 15px;">파일이 없습니다.</p>';
    return;
  }
  var html = '';
  files.forEach(function(f) {
    var isDir = f.isDir || f.isDirectory;
    var icon = isDir ? '📁' : '📄';
    var clickAction = isDir ? '' : 'data-fname="' + encodeURIComponent(f.name) + '" onclick="openFileFromSystemTab(this.getAttribute(&quot;data-fname&quot;))" style="cursor:pointer;"';
    html += '<div class="m-card" ' + clickAction + ' style="margin-bottom: 4px; padding: 8px 10px; display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 8px;">';
    html += '  <div style="display: flex; align-items: center; gap: 8px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">';
    html += '    <span>' + icon + '</span>';
    html += '    <span style="font-size: 12px; font-weight: 600; color: #e2e8f0;">' + escapeHtml(f.name) + '</span>';
    html += '  </div>';
    html += '  <span style="font-size: 10px; color: var(--dim);">' + (isDir ? '폴더' : (f.size ? Math.round(f.size/1024) + ' KB' : '')) + '</span>';
    html += '</div>';
  });
  listEl.innerHTML = html;
}

function filterSysFilesList() {
  var q = (document.getElementById('sysFileSearch')?.value || '').toLowerCase().trim();
  if (!q) {
    renderSysFiles(allSysFiles);
    return;
  }
  var filtered = allSysFiles.filter(function(f) {
    return f.name.toLowerCase().indexOf(q) !== -1;
  });
  renderSysFiles(filtered);
}

function openFileFromSystemTab(encodedName) {
  var fileName = decodeURIComponent(encodedName);
  openFileEditor(fileName);
}

var isAppInitialized = false;
async function initApp() {
  if (isAppInitialized) return;
  isAppInitialized = true;
  try {
    var res = await fetch('/api/info', { headers: { 'Authorization': token } });
    var info = await res.json();
    if (info.hostname) {
      var hostEl = document.getElementById('hostName'); if (hostEl) hostEl.innerText = info.hostname;
      document.getElementById('memStatus').innerText = 'RAM: ' + info.freeMemMB + 'MB free';
    }
  } catch (_) {}

  // 실시간 대화 트랜스크립트 1.2초 주기 자동 동기화 가동
  syncLiveTranscript();
  setInterval(syncLiveTranscript, 1200);

  // Codex 실시간 상태 및 대화내역 1.5초 주기 자동 동기화 가동
  syncCodexStatus();
  setInterval(syncCodexStatus, 1500);

  // Antigravity(서브 워커 2) 실시간 상태 및 대화내역 1.5초 주기 자동 동기화 가동
  syncAgyStatus();
  setInterval(syncAgyStatus, 1500);
  syncGrokStatus();
  setInterval(syncGrokStatus, 1500);

  autoOpenAgentFromUrl();

  // 실시간 스캐너 상태 및 포착 종목 3초 주기 자동 동기화 가동
  refreshScannerTab();
  setInterval(refreshScannerTab, 3000);
}

// ===== 시스템 상태(버전·헬스·마지막 실패) + 실패 카드 (2026-09-21) =====
var aiHealth = {};      // { codex:true/false, ... } — false 면 "업데이트 후 점검 중"
var sysStatus = null;
var AI_TAB_SUB = { codex: 'GPT-5.6-terra', agy: 'Gemini 3.8 Flash', grok: 'grok-4.6', claude: 'Opus 5' };
async function refreshSysStatus() {
  try {
    var res = await fetch('/api/status'); if (!res.ok) return;
    var d = await res.json(); sysStatus = d;
    var h = d.health || {};
    ['claude', 'codex', 'agy', 'grok'].forEach(function (k) { aiHealth[k] = h[k] ? !!h[k].ok : true; });
    // 탭 아래 작은 글씨: 점검 중이면 표시
    var tabCls = { claude: 'w-claude', codex: 'w-codex', agy: 'w-agy', grok: 'w-grok' };
    Object.keys(tabCls).forEach(function (k) {
      var b = document.querySelector('.tab-btn.' + tabCls[k]); if (!b) return;
      var sub = b.querySelector('.tab-sub'); if (!sub) return;
      if (aiHealth[k] === false) { sub.textContent = '점검 중'; sub.style.color = 'var(--notice-b)'; }
      else if (sub.textContent === '점검 중') { sub.textContent = AI_TAB_SUB[k]; sub.style.color = ''; }
    });
    // 배너·배지는 띄우지 않는다 — 권한 모드·미확인 버전은 ⚙ 설정 시트 안에서만 (renderSettings)
  } catch (_) {}
}
function healthIdleText(ai) { return aiHealth[ai] === false ? '점검 중 — 다른 AI에게 맡겨 주세요' : '대기'; }
function retryingText(data) { return data && data.retrying ? String(data.retrying) : ''; }
/** 실패 안내 카드(메시지에 fail 객체가 있을 때): 제목·도움말·액션 칩·"자세히" 접기. 원문은 접힌 곳에만 */
function renderFailCard(m, ai, messages, idx) {
  var f = m.fail || {};
  var prev = '';
  var list = messages || [];
  var at = typeof idx === 'number' ? idx : list.indexOf(m);
  for (var i = (at >= 0 ? at : list.length) - 1; i >= 0; i--) { if (list[i] && list[i].role === 'user') { prev = list[i].text || ''; break; } }
  var enc = encodeURIComponent(prev);
  var cid = 'fail-' + ai + '-' + (m.id || at);
  var html = '<div class="msg-bubble msg-ai fail-card">';
  html += '<div class="fail-title">' + escapeHtml(f.title || m.text || '작업을 끝내지 못했습니다.') + '</div>';
  if (f.hint) html += '<div class="fail-hint">' + escapeHtml(f.hint) + '</div>';
  if (f.retried) html += '<div class="fail-hint" style="color:var(--dim);">한 번 더 자동으로 시켜 봤지만 같은 결과였습니다.</div>';
  html += '<div class="fail-actions">';
  if (prev) html += '<span class="fail-chip primary" role="button" tabindex="0" onclick="failRetry(&quot;' + ai + '&quot;, &quot;' + enc + '&quot;)">다시 시키기</span>';
  if (prev && ai !== 'claude') html += '<span class="fail-chip" role="button" tabindex="0" onclick="failToClaude(&quot;' + ai + '&quot;, &quot;' + enc + '&quot;)">Claude Code에게</span>';
  html += '</div>';
  if (f.detail) html += '<details class="fail-detail" id="' + cid + '"><summary>자세히</summary><pre>' + escapeHtml(f.detail) + '</pre></details>';
  html += '</div>';
  return html;
}
function failRetry(ai, enc) {
  var text = decodeURIComponent(enc || ''); if (!text) return;
  if (ai === 'codex') return sendCodexQuick(text);
  if (ai === 'agy') return sendAgyQuick(text);
  if (ai === 'grok') return sendGrokQuick(text);
  return sendQuickInput(text);
}
function failToClaude(ai, enc) {
  var text = decodeURIComponent(enc || ''); if (!text) return;
  var who = { codex: 'Codex', agy: 'Antigravity', grok: 'Grok' }[ai] || ai;
  try { var mb = document.querySelector('.tab-btn.w-claude'); if (mb) switchTab('assistant', mb); } catch (_) {}
  sendQuickInput(who + '가 끝내지 못한 작업입니다. 직접 처리해 주세요:' + NL + text);
}
document.addEventListener('keydown', function (e) { var t = e.target; if (t && t.classList && t.classList.contains('fail-chip') && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); t.click(); } });

function escapeHtml(text) {
  var map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
  return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
}

function resizeComposer(input) {
  if (!input) return;
  input.style.height = '38px';
}

function autoGrow(el) {
  if (!el) return;
  if (!el.value) { el.style.height = '38px'; return; }
  el.style.height = 'auto';
  el.style.height = Math.min(160, Math.max(38, el.scrollHeight)) + 'px';
}
function resetComposer(input) {
  if (!input) return;
  input.value = '';
  autoGrow(input);
}

function bindComposer(id, submitFn) {
  var input = document.getElementById(id);
  if (!input) return;
  input.addEventListener('input', function() { autoGrow(input); });
  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submitFn();
    }
  });
  autoGrow(input);
}

function formatMarkdownToHtml(md) {
  if (!md) return '';
  var text = escapeHtml(md);
  var tick3 = String.fromCharCode(96, 96, 96);
  var tick1 = String.fromCharCode(96);

  // Mermaid 다이어그램 변환
  var mParts = text.split(tick3 + 'mermaid');
  if (mParts.length > 1) {
    var mergedM = mParts[0];
    for (var mi = 1; mi < mParts.length; mi++) {
      var endM = mParts[mi].indexOf(tick3);
      if (endM !== -1) {
        mergedM += '<div style="background:rgba(79,127,255,0.12); border:1px solid rgba(79,127,255,0.3); padding:6px 10px; border-radius:8px; font-size:11.5px; color:var(--accent-light); margin:6px 0; font-weight:600;">📊 [구조 다이어그램 요약]</div>' + mParts[mi].substring(endM + 3);
      } else {
        mergedM += mParts[mi];
      }
    }
    text = mergedM;
  }

  // 코드 블록 변환
  var cParts = text.split(tick3);
  if (cParts.length > 1) {
    var mergedC = '';
    for (var ci = 0; ci < cParts.length; ci++) {
      if (ci % 2 === 1) {
        var rawCode = cParts[ci];
        var firstBreak = rawCode.indexOf(NL);
        if (firstBreak !== -1 && firstBreak < 15) {
          rawCode = rawCode.substring(firstBreak + 1);
        }
        mergedC += '<pre style="background:#090d16; border:1px solid #202a42; border-radius:8px; padding:8px; overflow-x:auto; font-size:11.5px; font-family:monospace; margin:6px 0; color:#e2e8f0; max-height:220px;"><code>' + rawCode.trim() + '</code></pre>';
      } else {
        mergedC += cParts[ci];
      }
    }
    text = mergedC;
  }

  // 인라인 코드
  var iParts = text.split(tick1);
  if (iParts.length > 1) {
    var mergedI = '';
    for (var ii = 0; ii < iParts.length; ii++) {
      if (ii % 2 === 1) {
        mergedI += '<code style="background:rgba(255,255,255,0.08); padding:1px 5px; border-radius:4px; font-size:11.5px; color:#93c5fd; font-family:monospace;">' + iParts[ii] + '</code>';
      } else {
        mergedI += iParts[ii];
      }
    }
    text = mergedI;
  }

  // 볼드체 (**text**)
  var bParts = text.split('**');
  if (bParts.length > 1) {
    var mergedB = '';
    for (var bi = 0; bi < bParts.length; bi++) {
      if (bi % 2 === 1) {
        mergedB += '<b style="color:#fff;">' + bParts[bi] + '</b>';
      } else {
        mergedB += bParts[bi];
      }
    }
    text = mergedB;
  }

  // 마크다운 링크: [title](url)
  var lParts = text.split('[');
  if (lParts.length > 1) {
    var mergedL = lParts[0];
    for (var li = 1; li < lParts.length; li++) {
      var closeB = lParts[li].indexOf('](');
      var closeP = lParts[li].indexOf(')');
      if (closeB !== -1 && closeP > closeB) {
        var label = lParts[li].substring(0, closeB);
        var url = lParts[li].substring(closeB + 2, closeP);
        var rest = lParts[li].substring(closeP + 1);
        if (url.indexOf('http://') === 0 || url.indexOf('https://') === 0) {
          mergedL += '<a href="' + url + '" target="_blank" style="color:var(--accent-light); font-weight:700; text-decoration:underline;">' + label + '</a>' + rest;
        } else {
          mergedL += '<span style="color:var(--accent-light); font-weight:600;">' + label + '</span>' + rest;
        }
      } else {
        mergedL += '[' + lParts[li];
      }
    }
    text = mergedL;
  }

  // 줄 단위 헤더, 불릿, 구분선 처리
  var lines = text.split(NL);
  var outLines = [];
  for (var li = 0; li < lines.length; li++) {
    var l = lines[li];
    var trimL = l.trim();
    if (trimL.indexOf('### ') === 0) {
      outLines.push('<div style="font-weight:700; color:var(--accent-light); margin:6px 0 2px; font-size:12.5px;">' + trimL.substring(4) + '</div>');
    } else if (trimL.indexOf('## ') === 0) {
      outLines.push('<div style="font-weight:800; color:#fff; margin:8px 0 4px; font-size:13.5px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:2px;">' + trimL.substring(3) + '</div>');
    } else if (trimL.indexOf('# ') === 0) {
      outLines.push('<div style="font-weight:800; color:#fff; margin:10px 0 6px; font-size:14.5px;">' + trimL.substring(2) + '</div>');
    } else if (trimL.charAt(0) === '|' && trimL.charAt(trimL.length - 1) === '|'
               && li + 1 < lines.length && /^\|[\s:|-]+\|$/.test(lines[li + 1].trim())) {
      // 표 — 여기 없으면 「| 항목 | 값 |」 이 글자 그대로 찍힌다 (PO 2026-09-23 폰 화면 지적).
      // 칸이 많으면 폰 폭을 넘으므로 가로로만 밀어 볼 수 있게 감싼다. 세로 스크롤은 건드리지 않는다.
      var tCells = function (row) {
        var r = row.trim();
        if (r.charAt(0) === '|') r = r.substring(1);
        if (r.charAt(r.length - 1) === '|') r = r.substring(0, r.length - 1);
        return r.split('|').map(function (c) { return c.trim(); });
      };
      var tHead = tCells(trimL);
      var tRows = [];
      li += 2;
      while (li < lines.length && lines[li].trim().charAt(0) === '|') { tRows.push(tCells(lines[li])); li++; }
      li--;   // 바깥 for 문이 다시 ++ 한다
      var tdS = 'border:1px solid var(--border); padding:5px 7px; text-align:left; vertical-align:top;';
      var tH = '<tr>' + tHead.map(function (c) {
        return '<th style="' + tdS + ' background:rgba(255,255,255,0.07); color:#fff; font-weight:700; white-space:nowrap;">' + c + '</th>';
      }).join('') + '</tr>';
      var tB = tRows.map(function (r) {
        return '<tr>' + r.map(function (c) { return '<td style="' + tdS + '">' + c + '</td>'; }).join('') + '</tr>';
      }).join('');
      outLines.push('<div style="overflow-x:auto; margin:6px 0; -webkit-overflow-scrolling:touch;">'
        + '<table style="border-collapse:collapse; font-size:11.5px; min-width:100%;">' + tH + tB + '</table></div>');
    } else if (trimL.indexOf('* ') === 0 || trimL.indexOf('- ') === 0) {
      outLines.push('<div style="padding-left:6px; margin:2px 0; font-size:12px;">• ' + trimL.substring(2) + '</div>');
    } else if (trimL === '---') {
      outLines.push('<hr style="border:none; border-top:1px solid var(--border); margin:6px 0;">');
    } else {
      outLines.push(l);
    }
  }
  return outLines.join('<br>');
}

var lastActiveStep = -1;
var lastLiveStateKey = '';
var isSyncing = false;
var isSimplifiedMode = true;
var showAllLiveHistory = false;
var showAllCodexHistory = false;
var showAllAgyHistory = false;
var showAllGrokHistory = false;
var foldedMessages = {};
var lastLiveData = null;
var lastCodexData = null;
var lastAgyData = null;
var lastGrokData = null;

function toggleSimplifyMode() {
  isSimplifiedMode = !isSimplifiedMode;
  var btn = document.getElementById('btnSimplifyMode');
  if (btn) {
    btn.className = 'mode-switch-btn' + (isSimplifiedMode ? ' active' : '');
    btn.innerText = isSimplifiedMode ? '⚡ 단순화 모드 ON' : '📋 전체 상세 모드';
  }
  if (lastLiveData) renderLiveMessages(lastLiveData.messages, lastLiveData.isWorking, lastLiveData.lastAction);
  if (lastCodexData) renderCodexMessages(lastCodexData.messages, lastCodexData.isWorking, lastCodexData.currentTask);
  if (lastAgyData) renderAgyMessages(lastAgyData.messages, lastAgyData.isWorking, lastAgyData.currentTask);
}

function toggleMsgFold(msgId) {
  var body = document.getElementById('body-' + msgId);
  var btn = document.getElementById('btn-' + msgId);
  if (!body) return;
  if (body.classList.contains('collapsed-body')) {
    body.classList.remove('collapsed-body');
    foldedMessages[msgId] = false;
    if (btn) btn.innerText = '접기 ▴';
  } else {
    body.classList.add('collapsed-body');
    foldedMessages[msgId] = true;
    if (btn) btn.innerText = '펼치기 ▾';
  }
}

function toggleLiveHistory() {
  showAllLiveHistory = !showAllLiveHistory;
  if (lastLiveData) renderLiveMessages(lastLiveData.messages, lastLiveData.isWorking, lastLiveData.lastAction);
}

function toggleCodexHistory() {
  showAllCodexHistory = !showAllCodexHistory;
  lastCodexMsgHash = '';
  if (lastCodexData) renderCodexMessages(lastCodexData.messages, lastCodexData.isWorking, lastCodexData.currentTask);
}

function toggleAgyHistory() {
  showAllAgyHistory = !showAllAgyHistory;
  lastAgyMsgHash = '';
  if (lastAgyData) renderAgyMessages(lastAgyData.messages, lastAgyData.isWorking, lastAgyData.currentTask);
}

function toggleGrokHistory() {
  showAllGrokHistory = !showAllGrokHistory;
  lastGrokMsgHash = '';
  if (lastGrokData) renderGrokMessages(lastGrokData.messages, lastGrokData.isWorking, lastGrokData.currentTask);
}

async function syncLiveTranscript() {
  if (isSyncing) return;
  isSyncing = true;
  try {
    var res = await fetch('/api/live-transcript');
    var data = await res.json();
    if (!data.success) {
      isSyncing = false;
      return;
    }

    lastLiveData = data;

    var statusEl = document.getElementById('syncSessionStatus');
    if (statusEl) {
      if (data.isWorking) {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#f59e0b;box-shadow:0 0 6px #f59e0b;"></span><span>' + (retryingText(data) || ('작업 중' + (data.queued ? ' (대기 ' + data.queued + '건)' : '') + '...')) + '</span>';
        statusEl.style.color = 'var(--warn)';
      } else {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:var(--c-claude);"></span><span>대기</span>';
        statusEl.style.color = 'var(--win)';
      }
    }

    var liveStateKey = data.activeStep + '_' + (data.isWorking ? '1' : '0') + '_' + (data.messages ? data.messages.length : 0) + '_' + (data.lastAction || '');
    if (liveStateKey !== lastLiveStateKey) {
      lastLiveStateKey = liveStateKey;
      lastActiveStep = data.activeStep;
      renderLiveMessages(data.messages, data.isWorking, data.lastAction);
    }
  } catch (err) {
    console.error('syncLiveTranscript error:', err);
  }
  isSyncing = false;
}

var chatViewMode = 'summary'; // 'summary' | 'detail' | 'full'

function setChatViewMode(mode, byUser) {
  if (byUser) window._userPickedMode = true;
  var sel = document.getElementById('chatModeSel');
  if (sel && sel.value !== mode) sel.value = mode;
  ['summary', 'detail', 'full'].forEach(function(m) {
    var btn = document.getElementById('modeBtn-' + m);
    if (btn) {
      if (m === mode) btn.classList.add('active');
      else btn.classList.remove('active');
    }
  });
  chatViewMode = mode;
  syncChatModeMenu(mode);
  lastLiveStateKey = '';
  if (lastLiveData) {
    renderLiveMessages(lastLiveData.messages, lastLiveData.isWorking, lastLiveData.lastAction);
  }
}

// 답 표시 방식 커스텀 펼침 메뉴 (표준 select 숨김 유지 — 값·저장 로직은 setChatViewMode 그대로)
var CHAT_MODE_LABEL = { summary: '요약', detail: '상세', full: '전체' };
function syncChatModeMenu(mode) {
  var lb = document.getElementById('chatModeLabel');
  if (lb) lb.textContent = CHAT_MODE_LABEL[mode] || '요약';
  var pop = document.getElementById('chatModePop');
  if (!pop) return;
  Array.prototype.forEach.call(pop.querySelectorAll('.mode-menu-item'), function (it) {
    var on = it.getAttribute('data-v') === mode;
    it.setAttribute('aria-checked', on ? 'true' : 'false');
    var c = it.querySelector('.chk'); if (c) c.textContent = on ? '\u2713' : '';
  });
}
function openChatModeMenu(open) {
  var pop = document.getElementById('chatModePop'), btn = document.getElementById('chatModeBtn');
  if (!pop || !btn) return;
  pop.setAttribute('data-open', open ? '1' : '0');
  btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  if (open) {
    var cur = pop.querySelector('.mode-menu-item[aria-checked="true"]') || pop.querySelector('.mode-menu-item');
    if (cur) { try { cur.focus(); } catch (_) {} }
  }
}
function toggleChatModeMenu(e) {
  if (e) e.stopPropagation();
  var pop = document.getElementById('chatModePop');
  openChatModeMenu(!(pop && pop.getAttribute('data-open') === '1'));
}
function pickChatMode(v) {
  openChatModeMenu(false);
  setChatViewMode(v, true);
  var btn = document.getElementById('chatModeBtn'); if (btn) { try { btn.focus(); } catch (_) {} }
}
document.addEventListener('click', function (e) {
  var menu = document.getElementById('chatModeMenu');
  if (menu && !menu.contains(e.target)) openChatModeMenu(false);
});
document.addEventListener('keydown', function (e) {
  var pop = document.getElementById('chatModePop');
  if (!pop || pop.getAttribute('data-open') !== '1') return;
  var items = Array.prototype.slice.call(pop.querySelectorAll('.mode-menu-item'));
  var i = items.indexOf(document.activeElement);
  if (e.key === 'Escape') { e.preventDefault(); openChatModeMenu(false); var b = document.getElementById('chatModeBtn'); if (b) b.focus(); }
  else if (e.key === 'ArrowDown') { e.preventDefault(); (items[(i + 1) % items.length] || items[0]).focus(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); (items[(i - 1 + items.length) % items.length] || items[0]).focus(); }
  else if ((e.key === 'Enter' || e.key === ' ') && i >= 0) { e.preventDefault(); pickChatMode(items[i].getAttribute('data-v')); }
});

// ===== 채팅창 공통 렌더 헬퍼 (스크롤 튐 방지) =====
// - 내용이 안 바뀌면 innerHTML을 건드리지 않는다 (폴링마다 통째로 갈아끼우던 것이 스크롤 튐의 원인)
// - 손가락으로 스크롤 중이면 렌더를 보류한다 (다음 폴링에서 재시도)
// - 맨 아래 근처(≤90px)에 있을 때만 새 메시지를 따라 내려간다
function markUserScrolling(el) {
  el._userScrollUntil = Date.now() + 1500;
}
function bindChatScrollGuards() {
  ['chatContainer', 'codexChatContainer', 'agyChatContainer', 'grokChatContainer'].forEach(function(id) {
    var el = document.getElementById(id);
    if (!el || el._scrollGuardBound) return;
    el._scrollGuardBound = true;
    ['touchstart', 'touchmove', 'wheel'].forEach(function(ev) {
      el.addEventListener(ev, function() { markUserScrolling(el); }, { passive: true });
    });
    el.addEventListener('touchend', function() { el._userScrollUntil = Date.now() + 800; }, { passive: true });
    el.addEventListener('scroll', function() {
      // 프로그램적 스크롤이 아닌 사용자 스크롤만 감지 (직전 300ms 내 우리가 움직인 경우 제외)
      if (!el._progScrollAt || Date.now() - el._progScrollAt > 300) markUserScrolling(el);
    }, { passive: true });
  });
}
function applyChatHtml(container, html, isInitial) {
  if (container._lastHtml === html) return;               // 변경 없음 → 아무것도 안 함
  var userScrolling = container._userScrollUntil && Date.now() < container._userScrollUntil;
  var isNearBottom = (container.scrollHeight - container.scrollTop - container.clientHeight) <= 90;
  if (userScrolling && !isInitial) return;               // 손가락 스크롤 중 → 이번 주기는 보류
  var prevScrollTop = container.scrollTop;
  container.innerHTML = html;
  container._lastHtml = html;
  container._progScrollAt = Date.now();
  if (isNearBottom || isInitial) {
    container.scrollTop = container.scrollHeight;
  } else {
    container.scrollTop = prevScrollTop;
  }
}
document.addEventListener('DOMContentLoaded', bindChatScrollGuards);
if (document.readyState !== 'loading') bindChatScrollGuards();

function renderLiveMessages(messages, isWorking, lastAction) {
  var container = document.getElementById('chatContainer');
  if (!container) return;

  var countBadge = document.getElementById('transMsgCountBadge');
  if (countBadge && messages) {
    if (chatViewMode === 'summary') {
      var userAiCount = messages.filter(function(m) { return m.role === 'user' || m.role === 'ai'; }).length;
      countBadge.innerText = userAiCount + '개 메시지';
    } else if (chatViewMode === 'detail') {
      countBadge.innerText = messages.length + '개 이벤트';
    } else {
      countBadge.innerText = messages.length + '개 전체 기록';
    }
  }

  var html = '';
  if (!messages || messages.length === 0) {
    html = '<div style="color:var(--dim); text-align:center; padding:30px;">대화 기록이 없습니다. 아래 입력창에 첫 지시를 입력하세요!</div>';
  } else {
    var filteredList = messages;

    if (chatViewMode === 'summary') {
      // 1. 요약 모드: 도구 호출 제외, 최근 6개 대화만 표시, 긴 글 접기
      // 요약 모드에서도 선택형 질문 카드는 남긴다 (폰에서 보기를 눌러 답해야 하므로)
      filteredList = messages.filter(function(m) { return m.role === 'user' || m.role === 'ai' || (m.role === 'tool' && m.toolName === 'AskUserQuestion'); });
      var total = filteredList.length;
      var limit = 6;
      if (total > limit && !showAllLiveHistory) {
        var hiddenCount = total - limit;
        html += '<div class="history-banner">';
        html += '  <button class="history-toggle-btn" onclick="toggleLiveHistory()">';
        html += '    ⚡ [요약 모드] 이전 대화 ' + hiddenCount + '개 더보기';
        html += '  </button>';
        html += '</div>';
        filteredList = filteredList.slice(-limit);
      } else if (total > limit && showAllLiveHistory) {
        html += '<div class="history-banner">';
        html += '  <button class="history-toggle-btn" onclick="toggleLiveHistory()">';
        html += '    👇 최근 대화만 보기 (' + limit + '개로 축소)';
        html += '  </button>';
        html += '</div>';
      }
    } else if (chatViewMode === 'detail') {
      // 2. 상세 모드: 도구 실행/터미널 명령 포함, 최근 30개 이벤트, 자동 펼침
      var total = messages.length;
      var limit = 30;
      if (total > limit && !showAllLiveHistory) {
        var hiddenCount = total - limit;
        html += '<div class="history-banner">';
        html += '  <button class="history-toggle-btn" onclick="toggleLiveHistory()">';
        html += '    📋 [상세 모드] 이전 실행 로그 ' + hiddenCount + '개 더보기';
        html += '  </button>';
        html += '</div>';
        filteredList = messages.slice(-limit);
      } else {
        html += '<div style="text-align:center; padding:5px; font-size:11px; color:#38bdf8; font-weight:700;">📋 상세 실행 모드 (도구 및 터미널 액션 포함)</div>';
        filteredList = messages;
      }
    } else if (chatViewMode === 'full') {
      // 3. 전체 모드: 세션의 모든 대화 및 실행 로그 100% 전체 무제한 펼침 표시
      html += '<div style="text-align:center; padding:6px; font-size:11px; color:#10b981; font-weight:700; background:rgba(16,185,129,0.08); border-radius:8px; margin-bottom:8px;">🌐 세션 전체 무제한 보기 (총 ' + messages.length + '개 항목 전체 출력 중)</div>';
      filteredList = messages;
    }

    var lastAskIdx = -1;
    filteredList.forEach(function (m, i) { if (m.role === 'tool' && m.toolName === 'AskUserQuestion') lastAskIdx = i; });
    // 질문 뒤에 이미 사용자/AI 메시지가 이어졌으면 답한 것 → 버튼 비활성
    if (lastAskIdx >= 0 && lastAskIdx < filteredList.length - 1 && filteredList.slice(lastAskIdx + 1).some(function (x) { return x.role === 'user' || x.role === 'ai'; })) lastAskIdx = -1;
    filteredList.forEach(function(m, idx) {
      if (m.role === 'user') {
        var badge = m.isMobile ? ' <span style="font-size:10px; opacity:0.75; margin-left:4px;">📱 모바일</span>' : '';
        html += '<div class="msg-bubble msg-user">' + escapeHtml(m.text).split(NL).join('<br>') + badge + '</div>';
      } else if (m.role === 'tool') {
        // 도구 실행 및 터미널 작업 카드
        html += '<div class="msg-bubble" style="background:rgba(15,23,42,0.75); border:1px solid rgba(56,189,248,0.25); border-left:3.5px solid #38bdf8; padding:8px 12px; font-family:monospace; font-size:11.5px; align-self:stretch; max-width:96%;">';
        html += '  <div style="display:flex; justify-content:space-between; color:#38bdf8; font-weight:700; margin-bottom:3px;">';
        html += '    <span>⚙️ [' + escapeHtml(m.toolName || 'Action') + '] ' + escapeHtml(m.summary || '') + '</span>';
        html += '    <span style="color:var(--dim); font-size:9.5px;">' + (m.time ? m.time.substring(11, 19) : '') + '</span>';
        html += '  </div>';
        if (m.toolName === 'AskUserQuestion' && m.questions && m.questions.length) {
          var isLatestAsk = (idx === lastAskIdx);
          m.questions.forEach(function (q, qi) {
            html += '  <div style="margin:6px 0 4px; color:#fff; font-family:-apple-system,BlinkMacSystemFont,Pretendard,sans-serif; font-size:12.5px; font-weight:700; white-space:pre-wrap;">' + (m.questions.length > 1 ? (qi + 1) + '. ' : '') + escapeHtml(q.question) + '</div>';
            html += '  <div style="display:flex; flex-direction:column; gap:5px;">';
            q.options.forEach(function (o, oi) {
              html += '<button class="ask-opt" ' + (isLatestAsk ? 'onclick="askPick(' + oi + ', ' + q.options.length + ', ' + (q.multi ? 'true' : 'false') + ')"' : 'disabled') + '><b>' + (q.multi ? '☐ ' : '') + (oi + 1) + ') ' + escapeHtml(o.label) + '</b>' + (o.description ? '<span>' + escapeHtml(o.description) + '</span>' : '') + '</button>';
            });
            html += '  </div>';
            if (isLatestAsk && q.multi) html += '  <button class="ask-opt" style="margin-top:6px; align-items:center; background:var(--accent); color:#fff;" onclick="askSubmitMulti()"><b>✔ 제출 (고른 것 확정)</b><span style="color:#dbe4ff;">복수 선택 — 항목을 눌러 체크/해제한 뒤 이 버튼</span></button>';
          });
          if (isLatestAsk) html += '  <div style="display:flex; gap:6px; margin-top:6px;"><button class="ask-opt ask-mini" onclick="askKeys([&quot;UP&quot;])">↑</button><button class="ask-opt ask-mini" onclick="askKeys([&quot;DOWN&quot;])">↓</button><button class="ask-opt ask-mini" onclick="askKeys([&quot;TAB&quot;])">Tab</button><button class="ask-opt ask-mini" onclick="askKeys([&quot;ENTER&quot;])">↵ 확인</button><button class="ask-opt ask-mini" onclick="askKeys([&quot;ESC&quot;])">Esc</button></div><div style="color:var(--dim); font-size:10.5px; margin-top:4px;">보기를 누르면 PC 창에서 그 항목이 선택됩니다. 직접 쓰려면 채팅창에 답을 입력하세요.</div>';
        } else if (m.detail) {
          html += '  <div style="color:#cbd5e1; word-break:break-all; white-space:pre-wrap; font-size:11px; line-height:1.45; max-height:110px; overflow-y:auto; background:rgba(0,0,0,0.35); padding:5px 8px; border-radius:4px;">' + escapeHtml(m.detail) + '</div>';
        }
        html += '</div>';
      } else {
        if (m.fail) { html += renderFailCard(m, 'claude', filteredList, filteredList.indexOf(m)); return; }
        var msgId = 'live-' + (m.id || idx);
        var formatted = formatMarkdownToHtml(m.text);
        var isLastMsg = (idx === filteredList.length - 1);
        var isLong = (chatViewMode === 'summary') && ((m.text && m.text.length > 260) || (m.text && m.text.split(NL).length > 6));
        var isFolded = isLong && (!isLastMsg ? (foldedMessages[msgId] !== false) : (foldedMessages[msgId] === true));

        // PO 2026-09-23 지시: 「요약본 → 요약 모드」, 「전체 전문 → 전체 모드」 — 셋을 같은 말결로 맞춘다
        var modeBadgeText = (chatViewMode === 'full') ? '전체 모드' : (chatViewMode === 'detail' ? '상세 모드' : '요약 모드');
        var modeBadgeColor = (chatViewMode === 'full') ? '#10b981' : (chatViewMode === 'detail' ? '#38bdf8' : '#a855f7');
        var modeBadgeBg = (chatViewMode === 'full') ? 'rgba(16,185,129,0.15)' : (chatViewMode === 'detail' ? 'rgba(56,189,248,0.15)' : 'rgba(168,85,247,0.15)');
        var modeBadgeBorder = (chatViewMode === 'full') ? 'rgba(16,185,129,0.3)' : (chatViewMode === 'detail' ? 'rgba(56,189,248,0.3)' : 'rgba(168,85,247,0.3)');

        html += '<div class="msg-bubble msg-ai">';
        html += '  <div class="msg-title" style="display:flex; justify-content:space-between; align-items:center;">';
        html += '    <div style="display:flex; align-items:center; gap:6px;">';
        html += '      <span>Claude Code (Opus 5)</span>';
        html += '      <span style="font-size:10px; font-weight:700; color:' + modeBadgeColor + '; opacity:0.85;">· ' + modeBadgeText + '</span>';
        html += '    </div>';
        if (isLong) {
          html += '    <span class="fold-btn" onclick="toggleMsgFold(&quot;' + msgId + '&quot;)" id="btn-' + msgId + '">' + (isFolded ? '펼치기 ▾' : '접기 ▴') + '</span>';
        }
        html += '  </div>';

        if (isLong && isFolded) {
          html += '  <div id="body-' + msgId + '" class="msg-body collapsed-body">' + formatted + '</div>';
        } else {
          html += '  <div id="body-' + msgId + '" class="msg-body">' + formatted + '</div>';
        }
        html += '</div>';
      }
    });
  }

  if (isWorking) {
    html += '<div class="msg-bubble msg-ai" style="border:none; border-left:3px solid #F2A48A; border-radius:6px; background:rgba(242,164,138,0.07);">';
    html += '  <div class="msg-title" style="color:#F2A48A;">⚡ 실시간 PC 연산 및 작업 진행 중...</div>';
    html += '  <div class="msg-body" style="color:var(--dim); font-size:12.5px;">' + (lastAction ? escapeHtml(lastAction) : '자율 완주 중입니다...') + '</div>';
    html += '</div>';
  }

  applyChatHtml(container, html, (container.innerHTML.indexOf('세션을 실시간으로') !== -1 || container.innerHTML.indexOf('대화 기록이 없습니다') !== -1));
}

// 앱(안드로이드 셸)이 첫 지시 카드로 문장을 넣을 때 사용하는 진입점 — 메인(Claude Code) 탭 입력창에 채워 전송
function sendChatText(text) {
  try { if (typeof switchTab === 'function') { var mb = document.querySelector('.tab-btn.w-claude'); if (mb) switchTab('assistant', mb); } } catch (_) {}
  var i = document.getElementById('chatInput'); if (!i) return false;
  i.value = String(text || ''); sendChatFromInput(); return true;
}
async function sendChatFromInput() {
  var input = document.getElementById('chatInput');
  var text = input.value.trim();
  if (!text) return;
  resetComposer(input);
  sendQuickInput(text);
}

async function sendQuickInput(text) {
  if (!text) return;
  var container = document.getElementById('chatContainer');
  var bubble = document.createElement('div');
  bubble.className = 'msg-bubble msg-user';
  bubble.innerHTML = escapeHtml(text).split(NL).join('<br>') + ' <span style="font-size:10px; opacity:0.75; margin-left:4px;">📱 모바일</span>';
  container.appendChild(bubble);
  container._lastHtml = null;
  container._progScrollAt = Date.now();
  container.scrollTop = container.scrollHeight;

  try {
    await fetch('/api/send-mobile-input', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    });
    setTimeout(syncLiveTranscript, 200);
  } catch (_) {}
}

bindComposer('chatInput', sendChatFromInput);


// Codex 연동 함수
var isCodexSyncing = false;
var lastCodexMsgHash = '';

async function syncCodexStatus() {
  if (isCodexSyncing) return;
  isCodexSyncing = true;
  try {
    var res = await fetch('/api/codex-status');
    var data = await res.json();
    lastCodexData = data;
    var statusEl = document.getElementById('codexStatus');
    if (statusEl) {
      if (data.isWorking) {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#f59e0b;box-shadow:0 0 6px #f59e0b;"></span><span>' + (retryingText(data) || '작업 중...') + '</span>';
        statusEl.style.color = 'var(--warn)';
      } else {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:' + (aiHealth.codex === false ? '#fbbf24' : '#3ED2A8') + ';"></span><span>' + healthIdleText('codex') + '</span>';
        statusEl.style.color = aiHealth.codex === false ? 'var(--notice-b)' : 'var(--c-agy)';
      }
    }
    var msgHash = (data.messages ? data.messages.length : 0) + '_' + (data.isWorking ? '1' : '0') + '_' + (data.currentTask || '') + '_' + (data.retrying || '') + '_' + (showAllCodexHistory ? 'all' : 'limit') + '_' + (isSimplifiedMode ? 'sim' : 'full');
    if (msgHash !== lastCodexMsgHash) {
      lastCodexMsgHash = msgHash;
      renderCodexMessages(data.messages, data.isWorking, data.currentTask);
    }
  } catch (_) {}
  isCodexSyncing = false;
}

function renderCodexMessages(messages, isWorking, currentTask) {
  var container = document.getElementById('codexChatContainer');
  if (!container) return;
  var isInitial = (container.innerHTML.indexOf('대기 중입니다') !== -1);

  var html = '';
  if (!messages || messages.length === 0) {
    html = '<div style="color:var(--dim); text-align:center; padding:30px;">Codex 대기 중입니다. 코딩 명령을 내려보세요.</div>';
  } else {
    var total = messages.length;
    var visibleLimit = 5;
    var hiddenCount = total - visibleLimit;

    if (isSimplifiedMode && hiddenCount > 0 && !showAllCodexHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleCodexHistory()">';
      html += '    👆 이전 대화 ' + hiddenCount + '개 더보기';
      html += '  </button>';
      html += '</div>';
    } else if (isSimplifiedMode && hiddenCount > 0 && showAllCodexHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleCodexHistory()">';
      html += '    👇 최근 대화만 보기 (' + visibleLimit + '개로 축소)';
      html += '  </button>';
      html += '</div>';
    }

    var displayMessages = (isSimplifiedMode && hiddenCount > 0 && !showAllCodexHistory)
      ? messages.slice(-visibleLimit)
      : messages;

    displayMessages.forEach(function(m, idx) {
      if (m.role === 'user') {
        html += '<div class="msg-bubble msg-user">' + escapeHtml(m.text).split(NL).join('<br>') + '</div>';
      } else {
        if (m.fail) { html += renderFailCard(m, 'codex', messages, messages.indexOf(m)); return; }
        var msgId = 'codex-' + (m.id || idx);
        var formatted = formatMarkdownToHtml(m.text);
        var isLastMsg = (idx === displayMessages.length - 1);
        var isLong = isSimplifiedMode && ((m.text && m.text.length > 260) || (m.text && m.text.split(NL).length > 6));
        var isFolded = isLong && (!isLastMsg ? (foldedMessages[msgId] !== false) : (foldedMessages[msgId] === true));

        html += '<div class="msg-bubble msg-ai" style="border-color: rgba(96,165,250,0.3);">';
        html += '  <div class="msg-title" style="color:#3ED2A8; display:flex; justify-content:space-between; align-items:center;">';
        html += '    <span>Codex (GPT-5.6-terra)</span>';
        if (isLong) {
          html += '    <span class="fold-btn" onclick="toggleMsgFold(&quot;' + msgId + '&quot;)" id="btn-' + msgId + '">' + (isFolded ? '펼치기 ▾' : '접기 ▴') + '</span>';
        }
        html += '  </div>';

        if (isLong && isFolded) {
          html += '  <div id="body-' + msgId + '" class="msg-body collapsed-body">' + formatted + '</div>';
        } else {
          html += '  <div id="body-' + msgId + '" class="msg-body">' + formatted + '</div>';
        }
        html += '</div>';
      }
    });
  }

  if (isWorking) {
    html += '<div class="msg-bubble msg-ai" style="border-color:#2563eb; background:rgba(37,99,235,0.08);">';
    html += '  <div class="msg-title" style="color:#3ED2A8;">⚡ Codex 자율 작업 진행 중...</div>';
    html += '  <div class="msg-body" style="color:var(--dim); font-size:12.5px;">' + (currentTask ? escapeHtml(currentTask) : '실행 중...') + '</div>';
    html += '</div>';
  }

  applyChatHtml(container, html, isInitial);
}

async function sendCodexFromInput() {
  var input = document.getElementById('codexInput');
  var text = input.value.trim();
  if (!text) return;
  resetComposer(input);
  sendCodexQuick(text);
}

async function sendCodexQuick(text) {
  if (!text) return;
  var container = document.getElementById('codexChatContainer');
  var bubble = document.createElement('div');
  bubble.className = 'msg-bubble msg-user';
  bubble.innerHTML = escapeHtml(text).split(NL).join('<br>');
  container.appendChild(bubble);
  container._lastHtml = null;
  container._progScrollAt = Date.now();
  container.scrollTop = container.scrollHeight;

  try {
    await fetch('/api/codex-send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    });
    lastCodexMsgHash = ''; // 전송 직후 강제 갱신
    setTimeout(syncCodexStatus, 500);
  } catch (_) {}
}

var codexIn = document.getElementById('codexInput');
if (codexIn) {
  bindComposer('codexInput', sendCodexFromInput);
}

// Antigravity(서브 워커 2) 연동 함수
var isAgySyncing = false;
var lastAgyMsgHash = '';

async function syncAgyStatus() {
  if (isAgySyncing) return;
  isAgySyncing = true;
  try {
    var res = await fetch('/api/agy-status');
    var data = await res.json();
    lastAgyData = data;
    var statusEl = document.getElementById('agyStatus');
    if (statusEl) {
      if (data.isWorking) {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#f59e0b;box-shadow:0 0 6px #f59e0b;"></span><span>' + (retryingText(data) || '작업 중...') + '</span>';
        statusEl.style.color = 'var(--warn)';
      } else {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:' + (aiHealth.agy === false ? '#fbbf24' : '#8AB4F8') + ';"></span><span>' + healthIdleText('agy') + '</span>';
        statusEl.style.color = aiHealth.agy === false ? 'var(--notice-b)' : 'var(--warn)';
      }
    }
    var msgHash = (data.messages ? data.messages.length : 0) + '_' + (data.isWorking ? '1' : '0') + '_' + (data.currentTask || '') + '_' + (data.retrying || '') + '_' + (showAllAgyHistory ? 'all' : 'limit') + '_' + (isSimplifiedMode ? 'sim' : 'full');
    if (msgHash !== lastAgyMsgHash) {
      lastAgyMsgHash = msgHash;
      renderAgyMessages(data.messages, data.isWorking, data.currentTask);
    }
  } catch (_) {}
  isAgySyncing = false;
}

function renderAgyMessages(messages, isWorking, currentTask) {
  var container = document.getElementById('agyChatContainer');
  if (!container) return;
  var isInitial = (container.innerHTML.indexOf('대기 중입니다') !== -1);

  var html = '';
  if (!messages || messages.length === 0) {
    html = '<div style="color:var(--dim); text-align:center; padding:30px;">Antigravity (Gemini 3.8 Flash) 대기 중입니다. 코딩·분석 명령을 내려보세요.</div>';
  } else {
    var total = messages.length;
    var visibleLimit = 5;
    var hiddenCount = total - visibleLimit;

    if (isSimplifiedMode && hiddenCount > 0 && !showAllAgyHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleAgyHistory()">';
      html += '    👆 이전 대화 ' + hiddenCount + '개 더보기';
      html += '  </button>';
      html += '</div>';
    } else if (isSimplifiedMode && hiddenCount > 0 && showAllAgyHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleAgyHistory()">';
      html += '    👇 최근 대화만 보기 (' + visibleLimit + '개로 축소)';
      html += '  </button>';
      html += '</div>';
    }

    var displayMessages = (isSimplifiedMode && hiddenCount > 0 && !showAllAgyHistory)
      ? messages.slice(-visibleLimit)
      : messages;

    displayMessages.forEach(function(m, idx) {
      if (m.role === 'user') {
        html += '<div class="msg-bubble msg-user">' + escapeHtml(m.text).split(NL).join('<br>') + '</div>';
      } else {
        if (m.fail) { html += renderFailCard(m, 'agy', messages, messages.indexOf(m)); return; }
        var msgId = 'agy-' + (m.id || idx);
        var formatted = formatMarkdownToHtml(m.text);
        var isLastMsg = (idx === displayMessages.length - 1);
        var isLong = isSimplifiedMode && ((m.text && m.text.length > 260) || (m.text && m.text.split(NL).length > 6));
        var isFolded = isLong && (!isLastMsg ? (foldedMessages[msgId] !== false) : (foldedMessages[msgId] === true));

        html += '<div class="msg-bubble msg-ai" style="border-color: rgba(245,158,11,0.3);">';
        html += '  <div class="msg-title" style="color:#8AB4F8; display:flex; justify-content:space-between; align-items:center;">';
        html += '    <span>Antigravity (Gemini 3.8 Flash)</span>';
        if (isLong) {
          html += '    <span class="fold-btn" onclick="toggleMsgFold(&quot;' + msgId + '&quot;)" id="btn-' + msgId + '">' + (isFolded ? '펼치기 ▾' : '접기 ▴') + '</span>';
        }
        html += '  </div>';

        if (isLong && isFolded) {
          html += '  <div id="body-' + msgId + '" class="msg-body collapsed-body">' + formatted + '</div>';
        } else {
          html += '  <div id="body-' + msgId + '" class="msg-body">' + formatted + '</div>';
        }
        html += '</div>';
      }
    });
  }

  if (isWorking) {
    html += '<div class="msg-bubble msg-ai" style="border-color:#d97706; background:rgba(217,119,6,0.08);">';
    html += '  <div class="msg-title" style="color:#8AB4F8;">Antigravity (Gemini 3.8 Flash) · 자율 작업 진행 중...</div>';
    html += '  <div class="msg-body" style="color:var(--dim); font-size:12.5px;">' + (currentTask ? escapeHtml(currentTask) : '실행 중...') + '</div>';
    html += '</div>';
  }

  applyChatHtml(container, html, isInitial);
}

async function sendAgyFromInput() {
  var input = document.getElementById('agyInput');
  var text = input.value.trim();
  if (!text) return;
  resetComposer(input);
  sendAgyQuick(text);
}

async function sendAgyQuick(text) {
  if (!text) return;
  var container = document.getElementById('agyChatContainer');
  var bubble = document.createElement('div');
  bubble.className = 'msg-bubble msg-user';
  bubble.innerHTML = escapeHtml(text).split(NL).join('<br>');
  container.appendChild(bubble);
  container._lastHtml = null;
  container._progScrollAt = Date.now();
  container.scrollTop = container.scrollHeight;

  try {
    await fetch('/api/agy-send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    });
    lastAgyMsgHash = '';
    setTimeout(syncAgyStatus, 500);
  } catch (_) {}
}

var agyIn = document.getElementById('agyInput');
if (agyIn) {
  bindComposer('agyInput', sendAgyFromInput);
}

// ===== Grok(서브 워커 3) — Antigravity 블록 복제 =====
var isGrokSyncing = false;
var lastGrokMsgHash = '';

async function syncGrokStatus() {
  if (isGrokSyncing) return;
  isGrokSyncing = true;
  try {
    var res = await fetch('/api/grok-status');
    var data = await res.json();
    lastGrokData = data;
    var statusEl = document.getElementById('grokStatus');
    if (statusEl) {
      if (data.isWorking) {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:#f59e0b;box-shadow:0 0 6px #f59e0b;"></span><span>' + (retryingText(data) || '작업 중...') + '</span>';
        statusEl.style.color = 'var(--warn)';
      } else {
        statusEl.innerHTML = '<span class="status-dot" style="width:6px;height:6px;background:' + (aiHealth.grok === false ? '#fbbf24' : '#D1D5DB') + ';"></span><span>' + healthIdleText('grok') + '</span>';
        statusEl.style.color = aiHealth.grok === false ? '#fbbf24' : '#f59e0b';
      }
    }
    var msgHash = (data.messages ? data.messages.length : 0) + '_' + (data.isWorking ? '1' : '0') + '_' + (data.currentTask || '') + '_' + (data.retrying || '') + '_' + (showAllGrokHistory ? 'all' : 'limit') + '_' + (isSimplifiedMode ? 'sim' : 'full');
    if (msgHash !== lastGrokMsgHash) {
      lastGrokMsgHash = msgHash;
      renderGrokMessages(data.messages, data.isWorking, data.currentTask);
    }
  } catch (_) {}
  isGrokSyncing = false;
}

function renderGrokMessages(messages, isWorking, currentTask) {
  var container = document.getElementById('grokChatContainer');
  if (!container) return;
  var isInitial = (container.innerHTML.indexOf('대기 중입니다') !== -1);

  var html = '';
  if (!messages || messages.length === 0) {
    html = '<div style="color:var(--dim); text-align:center; padding:30px;">Grok (grok-4.6) 대기 중입니다. 코딩·분석 명령을 내려보세요.</div>';
  } else {
    var total = messages.length;
    var visibleLimit = 5;
    var hiddenCount = total - visibleLimit;

    if (isSimplifiedMode && hiddenCount > 0 && !showAllGrokHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleGrokHistory()">';
      html += '    👆 이전 대화 ' + hiddenCount + '개 더보기';
      html += '  </button>';
      html += '</div>';
    } else if (isSimplifiedMode && hiddenCount > 0 && showAllGrokHistory) {
      html += '<div class="history-banner">';
      html += '  <button class="history-toggle-btn" onclick="toggleGrokHistory()">';
      html += '    👇 최근 대화만 보기 (' + visibleLimit + '개로 축소)';
      html += '  </button>';
      html += '</div>';
    }

    var displayMessages = (isSimplifiedMode && hiddenCount > 0 && !showAllGrokHistory)
      ? messages.slice(-visibleLimit)
      : messages;

    displayMessages.forEach(function(m, idx) {
      if (m.role === 'user') {
        html += '<div class="msg-bubble msg-user">' + escapeHtml(m.text).split(NL).join('<br>') + '</div>';
      } else {
        if (m.fail) { html += renderFailCard(m, 'grok', messages, messages.indexOf(m)); return; }
        var msgId = 'grok-' + (m.id || idx);
        var formatted = formatMarkdownToHtml(m.text);
        var isLastMsg = (idx === displayMessages.length - 1);
        var isLong = isSimplifiedMode && ((m.text && m.text.length > 260) || (m.text && m.text.split(NL).length > 6));
        var isFolded = isLong && (!isLastMsg ? (foldedMessages[msgId] !== false) : (foldedMessages[msgId] === true));

        html += '<div class="msg-bubble msg-ai" style="border-color: rgba(245,158,11,0.3);">';
        html += '  <div class="msg-title" style="color:#D1D5DB; display:flex; justify-content:space-between; align-items:center;">';
        html += '    <span>Grok (grok-4.6)</span>';
        if (isLong) {
          html += '    <span class="fold-btn" onclick="toggleMsgFold(&quot;' + msgId + '&quot;)" id="btn-' + msgId + '">' + (isFolded ? '펼치기 ▾' : '접기 ▴') + '</span>';
        }
        html += '  </div>';

        if (isLong && isFolded) {
          html += '  <div id="body-' + msgId + '" class="msg-body collapsed-body">' + formatted + '</div>';
        } else {
          html += '  <div id="body-' + msgId + '" class="msg-body">' + formatted + '</div>';
        }
        html += '</div>';
      }
    });
  }

  if (isWorking) {
    html += '<div class="msg-bubble msg-ai" style="border-color:#d97706; background:rgba(217,119,6,0.08);">';
    html += '  <div class="msg-title" style="color:#D1D5DB;">Grok (grok-4.6) · 자율 작업 진행 중...</div>';
    html += '  <div class="msg-body" style="color:var(--dim); font-size:12.5px;">' + (currentTask ? escapeHtml(currentTask) : '실행 중...') + '</div>';
    html += '</div>';
  }

  applyChatHtml(container, html, isInitial);
}

async function sendGrokFromInput() {
  var input = document.getElementById('grokInput');
  var text = input.value.trim();
  if (!text) return;
  resetComposer(input);
  sendGrokQuick(text);
}

async function sendGrokQuick(text) {
  if (!text) return;
  var container = document.getElementById('grokChatContainer');
  var bubble = document.createElement('div');
  bubble.className = 'msg-bubble msg-user';
  bubble.innerHTML = escapeHtml(text).split(NL).join('<br>');
  container.appendChild(bubble);
  container._lastHtml = null;
  container._progScrollAt = Date.now();
  container.scrollTop = container.scrollHeight;

  try {
    await fetch('/api/grok-send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    });
    lastGrokMsgHash = '';
    setTimeout(syncGrokStatus, 500);
  } catch (_) {}
}

var grokIn = document.getElementById('grokInput');
if (grokIn) {
  bindComposer('grokInput', sendGrokFromInput);
}

// 터미널 관련 함수
function printTerm(text, className) {
  const out = document.getElementById('termOutput');
  const div = document.createElement('div');
  if (className) div.className = className;
  div.innerText = text;
  out.appendChild(div);
  out.scrollTop = out.scrollHeight;
}

function clearTerm() {
  document.getElementById('termOutput').innerHTML = '';
}

async function quickTerm(cmd) {
  document.getElementById('termInput').value = cmd;
  resizeComposer(document.getElementById('termInput'));
  sendTermFromInput();
}

async function sendTermFromInput() {
  const input = document.getElementById('termInput');
  const cmd = input.value.trim();
  if (!cmd) return;
  resetComposer(input);
  printTerm('PS > ' + cmd, 'prompt-line');
  try {
    const res = await fetch('/api/exec', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': token },
      body: JSON.stringify({ cmd })
    });
    const data = await res.json();
    if (data.isSmart && data.smart) {
      printTerm(data.smart.reply);
    } else if (data.output) {
      printTerm(data.output);
    } else if (data.error) {
      printTerm(data.error, 'err-line');
    }
  } catch (e) {
    printTerm('통신 오류: ' + e.message, 'err-line');
  }
}

bindComposer('termInput', sendTermFromInput);

let allProjectFiles = [];

function openFileManager() {
  document.getElementById('fileModalOverlay').style.display = 'flex';
  loadFiles();
}

function closeFileManager() {
  document.getElementById('fileModalOverlay').style.display = 'none';
}

function filterFilesList() {
  const q = (document.getElementById('fileSearchInput').value || '').trim().toLowerCase();
  renderFileListHtml(q ? allProjectFiles.filter(f => f.name.toLowerCase().includes(q)) : allProjectFiles);
}

async function loadFiles() {
  const container = document.getElementById('fileList');
  container.innerHTML = '<p style="color: var(--dim); text-align: center; padding: 20px;">파일 로딩 중...</p>';
  try {
    const res = await fetch('/api/files', { headers: { 'Authorization': token } });
    const data = await res.json();
    if (data.files) {
      allProjectFiles = data.files;
      renderFileListHtml(data.files);
    }
  } catch (e) {
    container.innerHTML = '<p style="color:var(--danger);padding:20px;">파일 목록 로드 실패: ' + e.message + '</p>';
  }
}

function renderFileListHtml(files) {
  const container = document.getElementById('fileList');
  if (!files || files.length === 0) {
    container.innerHTML = '<p style="color:var(--dim);text-align:center;padding:20px;">일치하는 파일이 없습니다.</p>';
    return;
  }
  let html = '';
  files.forEach(f => {
    const icon = f.isDir ? '📁' : (f.name.endsWith('.html') ? '🌐' : (f.name.endsWith('.md') ? '📝' : (f.name.endsWith('.json') ? '📊' : '📄')));
    const sizeStr = f.isDir ? '폴더' : (f.size > 1024 ? Math.round(f.size/1024) + ' KB' : f.size + ' B');
    const actionBtn = !f.isDir ? '<button class="action-btn" style="padding:4px 9px; font-size:11px; background:rgba(37,99,235,0.25); color:#93c5fd; border:1px solid rgba(37,99,235,0.4); cursor:pointer;" onclick="openEditor(&quot;' + f.name + '&quot;)">✏️ 편집/보기</button>' : '';
    html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:9px 12px;background:var(--card);border:1px solid var(--border);border-radius:10px;font-size:12px;">' +
            '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:62%;font-weight:600;">' + icon + ' ' + f.name + '</span>' +
            '<div style="display:flex;align-items:center;gap:8px;">' +
            '<span style="color:var(--dim);font-size:11px;">' + sizeStr + '</span>' +
            actionBtn +
            '</div>' +
            '</div>';
  });
  container.innerHTML = html;
}

async function openEditor(fileName) {
  currentEditFile = fileName;
  document.getElementById('editFileName').innerText = fileName;
  document.getElementById('fileEditorArea').value = '파일 내용을 불러오는 중...';
  document.getElementById('editorOverlay').style.display = 'flex';
  try {
    const res = await fetch('/api/file-content?file=' + encodeURIComponent(fileName), {
      headers: { 'Authorization': token }
    });
    const data = await res.json();
    if (data.content !== undefined) {
      document.getElementById('fileEditorArea').value = data.content;
    } else {
      document.getElementById('fileEditorArea').value = '파일을 불러오지 못했습니다: ' + (data.error || '');
    }
  } catch (e) {
    document.getElementById('fileEditorArea').value = '오류 발생: ' + e.message;
  }
}

function closeEditor() {
  document.getElementById('editorOverlay').style.display = 'none';
  currentEditFile = '';
}

async function saveCurrentFile(andDeploy) {
  if (!currentEditFile) return;
  const content = document.getElementById('fileEditorArea').value;
  try {
    const res = await fetch('/api/save-file', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': token },
      body: JSON.stringify({ file: currentEditFile, content })
    });
    const data = await res.json();
    if (data.success) {
      if (andDeploy) {
        alert('✅ PC에 저장 완료! Vercel 배포를 자동 실행합니다.');
        closeEditor();
        switchTab('assistant');
        sendUserMsg('vercel --prod --yes');
      } else {
        alert('✅ PC에 성공적으로 저장되었습니다!');
      }
    } else {
      alert('저장 실패: ' + (data.error || ''));
    }
  } catch (e) {
    alert('저장 통신 오류: ' + e.message);
  }
}

// 🍞 토스트 알림
function showToast(msg) {
  var t = document.getElementById('globalToast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'globalToast';
    t.style.cssText = 'position:fixed;bottom:78px;left:50%;transform:translateX(-50%);background:rgba(15,23,42,0.92);color:#fff;border:1px solid rgba(255,255,255,0.2);padding:8px 16px;border-radius:20px;font-size:12.5px;z-index:99999;box-shadow:0 6px 20px rgba(0,0,0,0.5);pointer-events:none;transition:opacity 0.2s ease;backdrop-filter:blur(8px);';
    document.body.appendChild(t);
  }
  t.innerHTML = msg;
  t.style.opacity = '1';
  clearTimeout(t._timer);
  t._timer = setTimeout(function() {
    t.style.opacity = '0';
  }, 3000);
}

// 🛑 긴급 정지 (Kill Switch)
async function triggerEmergencyStop() {
  if (!confirm('🛑 [긴급 정지]\\n\\nPC에서 실행 중인 모든 AI 작업 및 스크립트를 즉시 강제 중단하시겠습니까?')) {
    return;
  }
  showToast('🛑 긴급 정지 명령 하달 중...');
  try {
    var res = await fetch('/api/emergency-stop', { method: 'POST' });
    var data = await res.json();
    alert(data.message || '🛑 모든 프로세스가 긴급 중단되었습니다.');
    if (typeof syncLiveTranscript === 'function') syncLiveTranscript();
    if (typeof syncCodexStatus === 'function') syncCodexStatus();
    if (typeof syncAgyStatus === 'function') syncAgyStatus();
    if (typeof syncGrokStatus === 'function') syncGrokStatus();
  } catch (err) {
    alert('긴급 정지 통신 오류: ' + err.message);
  }
}

// 📱 모바일 네이티브 파일 탐색기 ("내 파일" / 갤러리) 호출 함수
function triggerFilePicker(targetAi, type) {
  var id = 'filePicker-' + targetAi + '-' + type;
  var input = document.getElementById(id);
  if (!input) return;
  // 기존 선택값 초기화 (동일 파일 재선택 시에도 onchange 정상 발화)
  input.value = '';
  // 모바일 네이티브 Intent (Samsung 내 파일 / iOS 파일 탐색기 / 갤러리) 즉시 호출
  input.click();
}

// 📎 스마트폰 파일/사진 통합 모바일 업로드 처리 함수 (단일 📎 클립)
async function handleMobileFileUpload(inputEl, targetAi, uploadType) {
  var fileList = Array.from(inputEl.files || []);
  if (fileList.length === 0) return;
  var hasImg = fileList.some(function(f) { return /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(f.name); });
  var allImg = fileList.every(function(f) { return /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(f.name); });
  var icon = allImg ? '🖼️' : '📁';
  var typeName = allImg ? '사진' : (hasImg ? '파일/사진' : '파일');

  var previewEl = document.getElementById('uploadPreview-' + targetAi);
  if (previewEl) {
    previewEl.style.display = 'flex';
    previewEl.innerHTML = '<span style="color:#60a5fa;">⏳ ' + icon + ' [핸드폰 ' + typeName + ' ' + fileList.length + '개] 전송 중...</span>';
  }

  showToast(icon + ' [핸드폰 ' + typeName + ' ' + fileList.length + '개] PC 전송 시작!');

  var authToken = token || localStorage.getItem('m_auth_token') || '';
  var uploadedFiles = [];
  var failedCount = 0;

  for (var i = 0; i < fileList.length; i++) {
    var f = fileList[i];
    var isFImg = /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(f.name);
    var sizeKb = Math.round(f.size / 1024);
    var sizeStr = sizeKb > 1024 ? (sizeKb / 1024).toFixed(1) + ' MB' : sizeKb + ' KB';
    if (previewEl) {
      previewEl.innerHTML = '<span>⏳ ' + (isFImg ? '🖼️' : '📁') + ' [' + (i + 1) + '/' + fileList.length + ' 전송 중]: <b>' + escapeHtml(f.name) + '</b> (' + sizeStr + ')</span>';
    }
    try {
      var base64Data = await new Promise(function(resolve, reject) {
        var reader = new FileReader();
        reader.onload = function(e) { resolve(e.target.result); };
        reader.onerror = reject;
        reader.readAsDataURL(f);
      });

      var res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': authToken
        },
        body: JSON.stringify({
          filename: f.name,
          base64: base64Data,
          targetAi: targetAi,
          uploadType: isFImg ? 'image' : 'file'
        })
      });
      var data = await res.json();
      if (data.success) {
        uploadedFiles.push(data);
      } else {
        failedCount++;
      }
    } catch (err) {
      failedCount++;
    }
  }

  if (uploadedFiles.length > 0) {
    var finalAllImg = uploadedFiles.every(function(u) { return /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(u.filename); });
    var finalHasImg = uploadedFiles.some(function(u) { return /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(u.filename); });
    var finalIcon = finalAllImg ? '🖼️' : '📁';
    var finalLabel = finalAllImg ? '사진' : (finalHasImg ? '파일/사진' : '파일');

    showToast('✅ ' + finalIcon + ' ' + uploadedFiles.length + '개 ' + finalLabel + ' PC 저장 완료!');
    if (previewEl) {
      previewEl.innerHTML = '<span style="color:#34d399;font-weight:700;">✅ ' + finalIcon + ' [' + uploadedFiles.length + '개 ' + finalLabel + ' PC 저장 완료]</span> <button onclick="clearUploadPreview(this)" style="background:none;border:none;color:#94a3b8;font-size:11.5px;cursor:pointer;padding:2px 6px;">[닫기]</button>';
      setTimeout(function() { if (previewEl) previewEl.style.display = 'none'; }, 7000);
    }

    // 채팅창에 즉시 시각적 성공 확인 버블 추가
    var containerId = targetAi === 'assistant' ? 'chatContainer' : (targetAi === 'codex' ? 'codexChatContainer' : (targetAi === 'grok' ? 'grokChatContainer' : 'agyChatContainer'));
    var container = document.getElementById(containerId);
    if (container) {
      var bubble = document.createElement('div');
      bubble.className = 'msg-bubble msg-user';
      bubble.style.borderLeft = '3.5px solid #10b981';
      bubble.style.background = 'rgba(16,185,129,0.12)';
      var filesHtml = uploadedFiles.map(function(u, idx) {
        var subIcon = /\.(jpe?g|png|gif|webp|heic|bmp)$/i.test(u.filename) ? '🖼️' : '📁';
        return subIcon + ' ' + (idx + 1) + '. <b>' + escapeHtml(u.filename) + '</b> (' + u.sizeStr + ')';
      }).join('<br>');
      bubble.innerHTML = '<div>' + finalIcon + ' <b>[핸드폰 ' + finalLabel + ' 전송 성공]</b></div><div style="margin-top:5px;font-size:12.5px;line-height:1.5;">' + filesHtml + '</div><div style="color:var(--dim);font-size:11px;margin-top:4px;">💻 PC 저장 위치: uploads/ 폴더에 안전하게 저장되었습니다.</div>';
      container.appendChild(bubble);
      container.scrollTop = container.scrollHeight;
    }

    // 분석 지시는 서버(/api/upload)가 업로드 직후 한 번 보낸다 — 입력창 자동 채움은 같은 지시가 두 번 가게 하므로 제거

    if (targetAi === 'codex' && typeof syncCodexStatus === 'function') syncCodexStatus();
    if (targetAi === 'agy' && typeof syncAgyStatus === 'function') syncAgyStatus();
    if (targetAi === 'grok' && typeof syncGrokStatus === 'function') syncGrokStatus();
    if (targetAi === 'assistant' && typeof syncLiveTranscript === 'function') syncLiveTranscript();
  } else {
    alert('파일 전송 실패: 서버 오류가 발생했습니다.');
    if (previewEl) previewEl.style.display = 'none';
  }

  inputEl.value = '';
}

function clearUploadPreview(btn) {
  var p = btn ? (btn.closest ? btn.closest('.upload-preview-bar') : btn) : null;
  if (p) {
    p.style.display = 'none';
    p.innerHTML = '';
  }
}

function openFileEditor(fileName) {
  if (typeof openEditor === 'function') {
    openEditor(fileName);
  }
}

var currentClipTargetAi = 'assistant';

function openClipModal(targetAi) {
  currentClipTargetAi = targetAi;
  // 라벨의 for 를 현재 채팅창의 input 으로 연결 (브라우저 네이티브로 선택기 오픈 → JS click() 차단 회피)
  ['image', 'camera', 'file'].forEach(function(t) {
    var lb = document.getElementById('clipLabel-' + t);
    if (lb) lb.setAttribute('for', 'filePicker-' + targetAi + '-' + t);
  });
  var modal = document.getElementById('clipChoiceModal');
  if (modal) modal.classList.add('show');
}

// 팝업 항목 탭: 선택기는 label 기본동작으로 열리고, 여기서는 초기화·닫기·안내만 한다
function onClipPick(type) {
  var input = document.getElementById('filePicker-' + currentClipTargetAi + '-' + type);
  if (input) input.value = '';
  var modal = document.getElementById('clipChoiceModal');
  if (modal) setTimeout(function() { modal.classList.remove('show'); }, 150);
  if (typeof showToast === 'function') showToast({ image: '🖼️ 갤러리 여는 중...', camera: '📷 카메라 여는 중...', file: '📁 파일 선택 여는 중...' }[type]);
}

function closeClipModal(e) {
  if (e && e.target && e.target.id !== 'clipChoiceModal' && !e.target.classList.contains('clip-modal-close') && !e.target.classList.contains('clip-pick-cancel-btn')) {
    return;
  }
  var modal = document.getElementById('clipChoiceModal');
  if (modal) modal.classList.remove('show');
}

function triggerPickOption(type, targetAi) {
  if (targetAi) currentClipTargetAi = targetAi;
  var modal = document.getElementById('clipChoiceModal');
  if (modal) modal.classList.remove('show');
  var inputId = 'filePicker-' + currentClipTargetAi + '-' + type;
  var input = document.getElementById(inputId);
  if (input) {
    input.value = '';
    input.click();
  }
}

// 아이프레임(Hub 내부)에서 동작 중일 때 중복 PC 전환 버튼 자동 숨김
if (window.self !== window.top) {
  var switchBtns = document.querySelectorAll('.btn-pc-switch');
  switchBtns.forEach(function(b) { b.style.display = 'none'; });
}

if (token) {
  initApp();
} else {
  showLoginOverlay();
}
</script>

</body>
</html>`;
}

server.on('error', (err) => {
  console.error('❌ [Server Error]', err);
  try {
    fs.writeFileSync(path.join(__dirname, 'server_error.txt'), 'ERROR: ' + err.stack);
  } catch (_) {}
  if (err.code === 'EADDRINUSE') {
    console.error(`⚠️ 포트 ${PORT}가 이미 사용 중입니다. 1.5초 후 재시도합니다...`);
    setTimeout(() => {
      try { server.close(); } catch (_) {}
      server.listen(PORT);
    }, 1500);
  }
});

// 메인 워커 = PC의 진짜 Claude Code 창. 없으면 하나 띄운다 (있으면 그 창을 그대로 미러링)
mainBridge.ensureWindow().then((pid) => console.log(PROJECT_ROLE === 'daemon' ? `🤖 메인 워커 = 창 없는 데몬 (claude -p --resume, 세션 ${mainBridge.getStatus().conversationId})` : (pid ? `🪟 메인 워커 창(claude.exe PID ${pid}) 연결` : '⚠️ 메인 워커 창을 찾지/띄우지 못했습니다'))).catch(() => {});

server.listen(PORT, () => {
  try {
    fs.writeFileSync(path.join(__dirname, 'server_started.txt'), 'RUNNING_AT_' + new Date().toISOString() + '_PORT_' + PORT);
  } catch (_) {}
  const ips = getLocalIpAddresses();
  console.log('=====================================================');
  console.log(`🚀 [Mobile Remote Console] 서버가 시작되었습니다!`);
  console.log(`🔑 기본 보안 PIN 코드: ${PIN_CODE}`);
  console.log('-----------------------------------------------------');
  console.log(`📱 [같은 Wi-Fi 접속용 로컬 주소]:`);
  ips.forEach(ip => {
    console.log(`   👉 http://${ip}:${PORT}`);
  });
  console.log(`💻 [PC 로컬 주소]: http://localhost:${PORT}`);
  console.log('=====================================================');
});
