/**
 * set_fixed_address.js — 이 PC 에 고정 주소를 넣거나 뺀다 (PO 2026-09-23: 「고정 주소로 바꿔」)
 *
 *   node set_fixed_address.js <https://주소> <토큰>    넣기 → 콘솔을 다시 켜면 그 주소로 뜬다
 *   node set_fixed_address.js --show                   지금 설정(토큰은 가리고 보여 준다)
 *   node set_fixed_address.js --clear                  빼기 → 다음부터 임시 터널
 *   node set_fixed_address.js --license <키>           라이선스로 분양 서버에서 받기(판매본 — 고객 PC 가 스스로)
 *
 *  주소와 토큰은 콘솔 HQ 가 클라우드플레어에 터널을 만들 때 한 쌍으로 나온다. 둘은 함께 가야 한다.
 *  토큰은 비밀이다 — 이 토큰만 있으면 그 주소로 터널을 띄울 수 있다. 남에게 보내지 않는다.
 *  설정이 틀려도 걱정할 것 없다: 콘솔이 고정 주소로 90초 안에 못 서면 임시 터널로 물러선다.
 */
'use strict';
const fs = require('fs');
const path = require('path');

const RESTART = path.join(process.env.CONSOLE_HOME || __dirname, 'restart_console.cmd'); // 설치 폴더가 C:\OneMACS 가 아닐 수도 있다
const FILE = path.join(process.env.CONSOLE_HOME || __dirname, 'console_config.json');

function load() { return JSON.parse(fs.readFileSync(FILE, 'utf8').replace(/^\uFEFF/, '')); }
function save(c) { fs.writeFileSync(FILE, JSON.stringify(c, null, 2), 'utf8'); }
const mask = (t) => t ? (t.slice(0, 6) + '…' + t.slice(-4) + ' (' + t.length + '자)') : '(없음)';

const a = process.argv.slice(2);
let c;
try { c = load(); } catch (e) { console.error('console_config.json 을 읽지 못했습니다: ' + e.message); process.exit(2); }

if (!a.length || a[0] === '--show') {
  console.log('고정 주소 : ' + (c.fixed_url || '(없음 — 임시 터널을 씁니다)'));
  console.log('토큰      : ' + mask(c.tunnel_token || ''));
  process.exit(0);
}

if (a[0] === '--clear') {
  delete c.fixed_url; delete c.tunnel_token;
  save(c);
  console.log('고정 주소를 뺐습니다. 콘솔을 다시 켜면 임시 터널로 뜹니다: ' + RESTART);
  process.exit(0);
}

// 라이선스로 받기 (판매본 — 고객 PC 가 스스로 주소를 받는다): node set_fixed_address.js --license XXXX-XXXX-XXXX-XXXX
//   분양 서버가 이 PC 에 <코드>-<n>.onemacs.com 을 준다. 같은 PC 가 다시 부르면 같은 주소(기기 id 는 설정에 남는다).
if (a[0] === '--license') {
  const lic = String(a[1] || '').trim();
  if (!lic) { console.error('라이선스 키를 주십시오: node set_fixed_address.js --license XXXX-XXXX-XXXX-XXXX'); process.exit(2); }
  if (!c.fixed_machine) c.fixed_machine = require('crypto').randomBytes(16).toString('hex');
  const issuer = String(c.issuer_url || 'https://onemacs-issuer.consolesystem.workers.dev').replace(/\/+$/, '');
  const body = JSON.stringify({ license: lic, machine: c.fixed_machine, label: c.pc_label || require('os').hostname(), port: Number(c.port) || 7890 });
  const u = new URL(issuer + '/v1/claim');
  const req = require('https').request({ host: u.host, path: u.pathname, method: 'POST', timeout: 60000,
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), 'User-Agent': 'OneMACS-Console/1.0' } }, (res) => {
    const bufs = []; res.on('data', d => bufs.push(d));
    res.on('end', () => {
      let j = {}; try { j = JSON.parse(Buffer.concat(bufs).toString('utf8')); } catch (_) {}
      if (res.statusCode !== 200 || !j.url || !j.token) { console.error('주소를 받지 못했습니다: ' + (j.error || ('HTTP ' + res.statusCode))); process.exit(3); }
      c.fixed_url = j.url; c.tunnel_token = j.token; c.fixed_license = lic;
      save(c);
      console.log('받았습니다.');
      console.log('  고정 주소 : ' + j.url);
      console.log('  토큰      : ' + mask(j.token));
      console.log('이제 콘솔을 다시 켜십시오: ' + RESTART);
    });
  });
  req.on('timeout', () => req.destroy(new Error('분양 서버 응답 시간 초과')));
  req.on('error', (e) => { console.error('분양 서버에 닿지 않습니다: ' + e.message); process.exit(3); });
  req.end(body);
  return;
}

const url = String(a[0] || '').trim().replace(/\/+$/, '');
const token = String(a[1] || '').trim();
if (!/^https:\/\/[a-z0-9-]+\.[a-z0-9.-]+$/i.test(url)) { console.error('주소 모양이 이상합니다 — https://이름.도메인 이어야 합니다: ' + url); process.exit(2); }
if (url.split('://')[1].split('.').length > 3) {
  // 무료 인증서는 *.도메인 한 단계만 덮는다. 두 단계면 브라우저가 「안전하지 않음」을 띄운다.
  // (.co.kr 처럼 도메인 자체가 세 마디인 경우도 있어 막지는 않고 알리기만 한다)
  console.log('⚠️ 주소가 여러 단계입니다(' + url + '). 무료 인증서는 한 단계(이름.도메인)만 덮으므로, 이름 부분에 점이 있으면 「안전하지 않음」이 뜰 수 있습니다.');
}
if (token.length < 40) { console.error('토큰이 너무 짧습니다(' + token.length + '자). 클라우드플레어 터널 토큰을 그대로 붙여 넣으십시오.'); process.exit(2); }

c.fixed_url = url;
c.tunnel_token = token;
save(c);
console.log('넣었습니다.');
console.log('  고정 주소 : ' + url);
console.log('  토큰      : ' + mask(token));
console.log('이제 콘솔을 다시 켜십시오(재시작 전에 일하는 데몬이 없는지 먼저 보십시오):');
console.log('  node C:\\OneMACS\\console\\daemon_ask.js --list');
console.log('  ' + RESTART);
console.log('90초 안에 고정 주소로 서지 않으면 콘솔이 알아서 임시 터널로 물러섭니다(start_all.log 에 이유가 남습니다).');
