@echo off
rem
chcp 65001 >nul
cd /d "%~dp0"
set CLAUDECODE=
set CLAUDE_PID=
set CLAUDE_EFFORT=
if not exist logs mkdir logs
start "" /b cmd /c "node start_all.js >> logs\console.log 2>&1"
