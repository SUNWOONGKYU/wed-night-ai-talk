@echo off
rem stop console started from THIS home only (console.pid) - see stop_console.ps1
rem pass the exit code through (3 = could not stop) so restart_console.cmd can abort
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0stop_console.ps1" -Home_ "%~dp0."
exit /b %errorlevel%
