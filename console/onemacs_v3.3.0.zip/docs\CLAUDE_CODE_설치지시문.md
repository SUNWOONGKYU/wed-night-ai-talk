<!-- 원맥스 배포판 v3 · 2026-09-22 초안(W2) · 리드 검수 전 -->
# Claude Code 자동 설치 지시문 — 원맥스(One MACS) 배포판 v3

> **사용자는 이것만 하면 된다**: 배포판 zip 을 아무 폴더에 풀고, 그 폴더에서 Claude Code 를 켠 뒤(`claude`) 아래 한 줄을 붙여넣는다.
>
> ```
> 이 폴더의 CLAUDE_CODE_설치지시문.md 를 읽고, 그 안의 지시를 순서대로 전부 수행해서 원맥스 콘솔을 이 PC 에 설치해줘.
> ```
>
> 이 파일의 나머지는 Claude Code 가 읽고 실행하는 절차다. 중간에 몇 가지를 물어보면 답만 하면 된다.

---

## Claude Code 에게 (실행 절차)

너는 지금 원맥스(One MACS) 콘솔을 이 PC 에 설치한다. 원맥스는 스마트폰에서 이 PC 의 AI CLI(Claude Code 필수 · Codex/Antigravity/Grok 선택)를 지휘하는 콘솔이다.

용어
- `DIST` = 이 지시문이 들어 있는 폴더(zip 을 푼 곳). `install.ps1`, `hub_selfhost\`, `addons\` 가 여기 있다.
- `HOME` = `C:\OneMACS` (콘솔 실행 홈. 설치 후 `HOME\console\`, `HOME\general\uploads\`, `HOME\CLAUDE.md` 가 생긴다)

아래 단계를 **순서대로** 수행한다. 1~2 단계에서 사용자에게 값을 묻고, 3 단계에서 `install.ps1` **한 줄**을 실행하고, 4 단계 이후에 확인한다. 각 단계 결과를 한 줄씩 사용자에게 보고한다. 실패한 단계는 원인과 사용자가 직접 해야 할 일을 정확히 알려주고 멈춘다. 추측으로 넘어가지 않는다.

### 0. 원칙
- 각 AI 계정 로그인(claude / codex / agy / grok / cloudflare)은 **절대 대신 하지 않는다**. 명령만 알려주고, 사용자가 끝냈다고 하면 이어간다. 자격증명·결제수단·2단계 인증은 사용자가 직접 입력한다.
- `HOME` 과 사용자가 지정한 프로젝트 폴더 밖의 파일은 건드리지 않는다. `DIST` 의 파일은 수정하지 않는다(읽기·복사만).
- PIN·페어링 코드·API 키 값은 보고서 한 곳에만 적고 그 밖에서는 화면에 출력하지 않는다.
- Windows 10/11 전용. 명령은 PowerShell 로 실행한다.
- `HOME\console\` 안의 코드·설정은 설치가 끝난 뒤 손으로 고치지 않는다(설정 변경은 폰 ⚙ 설정 시트 또는 `install.ps1` 재실행). 설치 도중 필요한 설정은 전부 `install.ps1` 매개변수와 콘솔 API 로 넣는다.

### 1. 환경 점검
1. `node -v` — 없거나 v20 미만이면 사용자에게 https://nodejs.org LTS 설치를 요청하고 중단. (설치 후 새 터미널에서 다시 시작)
2. `claude --version` — 없으면 공식 설치 한 줄 `irm https://claude.ai/install.ps1 | iex` (네이티브 설치, 자동 업데이트) 를 사용자에게 안내한다. 지금 이 창이 Claude Code 이므로 보통은 이미 있다.
3. `Test-Path "$env:USERPROFILE\.claude\.credentials.json"` — `False` 면 Claude Code 로그인이 안 된 것. 사용자에게 다른 터미널에서 `claude` 를 실행해 브라우저 로그인을 마치라고 안내하고 기다린다.
4. `Test-Path "$DIST\install.ps1"`, `Test-Path "$DIST\console\cloudflared.exe"` — 둘 중 하나라도 `False` 면 zip 이 덜 풀린 것. 다시 풀라고 안내하고 중단.
5. **기존 설치 감지**: `Test-Path "C:\OneMACS\console\console_config.json"` 이 `True` 면 이미 원맥스가 설치된 PC 다. 사용자에게 "기존 설정·세션·로그를 보존하고 코드만 갱신할까요(업데이트)?" 라고 묻고, 예 → **7 단계(업데이트)** 로 건너뛴다. 아니오 → 새로 설치(기존 `console_config.json` 은 `install.ps1` 이 `.bak` 으로 남긴다).
6. 포트 확인: `Get-NetTCPConnection -LocalPort 7890 -State Listen -ErrorAction SilentlyContinue` — 결과가 있으면 다른 프로그램이 7890 을 쓰는 것. 3 단계에서 `-Port 7891` 을 쓴다(그 포트도 같은 방법으로 확인).

### 2. 문답 (값을 모으기만 하고 아직 실행하지 않는다)
사용자에게 아래를 **하나씩** 묻는다. 답이 없거나 "기본" 이면 괄호 안 기본값을 쓴다.

**① PC 이름표** — 폰 허브에서 이 PC 를 부를 이름. (기본: `$env:COMPUTERNAME`) 예: `집 데스크톱`, `PC 1`. → `PC_LABEL`

**② 쓸 AI 선택과 로그인 확인**
- Claude Code 는 필수(1 단계에서 확인 끝).
- Codex / Antigravity / Grok 은 선택. 각각 쓸지 묻고, 쓴다고 하면 설치·로그인 여부를 확인한다.
  | AI | 설치 확인 | 없을 때 설치 명령 | 로그인(사용자 직접) |
  |---|---|---|---|
  | Codex | `codex --version` | `npm install -g @openai/codex` | `codex login` (ChatGPT 계정) |
  | Antigravity | `agy --version` | Antigravity 설치(agy CLI 포함) | 터미널에서 `agy` 실행 후 Google 로그인 |
  | Grok | `grok --version` | `npm install -g @xai-official/grok` | `grok login` (브라우저 인증) |
- 설치 명령(npm 전역)은 사용자가 허락하면 네가 실행해도 된다. 로그인은 사용자가 한다. 사용자가 "로그인 했다"고 하면 넘어간다. 로그인 여부를 확인하는 명령이 CLI 에 있으면(예: `codex login status`) 그것으로 확인한다.
- 안 쓰는 AI 는 "폰에서 해당 탭이 비활성으로 남는다"고만 알리고 계속한다. → `WORKERS` (예: claude, codex)

**③ 첫 프로젝트** — 폰에서 지휘할 작업 폴더. 둘 중 하나.
- (a) **기존 폴더 연결**: 사용자가 경로를 준다(예: `C:\내프로젝트`). `Test-Path` 로 존재 확인. 폴더 안에 `_mobile_remote\` 는 **만들지 않는다** — 콘솔이 기동할 때 자동으로 만든다.
- (b) **새 폴더 만들기**: 이름만 받는다. `C:\콘솔프로젝트\<이름>` 에 콘솔이 만든다.
- 사용자가 "나중에" 라고 하면 건너뛴다(폰 프로젝트 메뉴 ＋ 로 언제든 추가 가능). → `PROJECT_NAME`, `PROJECT_DIR`(a 일 때)

**④ 허브** — 폰이 이 PC 를 찾는 방법. 아래 순서로 제시하고 하나를 고르게 한다.
1. **원맥스 허브 (기본, 권장)** — 구매 시 받은 **페어링 코드 8자리**(예: `XXXXXXXX`)를 입력받는다. 구매일부터 3개월 무료, 이후 1년 9,900원(고정 주소 및 허브 사용료). 상세는 `「원맥스 사용설명서.html」의 「허브 이용권」장`. → `HUB_MODE=onemacs`, `PAIR_CODE`
   - 코드 형식: 영문 대문자·숫자 8자리(`I O 0 1` 은 쓰지 않음). 형식이 안 맞으면 다시 묻는다.
   - **고정 주소**: 같은 구매 메일의 **라이선스 키**(`XXXX-XXXX-XXXX-XXXX`)도 받는다. 이 키로 이 PC 에 바뀌지 않는 주소(`<코드>-<번호>.onemacs.com`)가 나온다. 없으면 건너뛴다(주소가 켤 때마다 바뀌는 임시 주소로 동작). → `LICENSE`
2. **직접 구축 (무료)** — 사용자 자기 Cloudflare 무료 계정에 허브 워커를 올린다. `「원맥스 사용설명서.html」의 「허브 직접 만들기」장` 를 지금 읽고 그 절차를 먼저 끝낸 뒤(허브 주소와 코드가 나온다) 여기로 돌아온다. → `HUB_MODE=self`, `HUB_URL=https://<내허브>.workers.dev`, `PAIR_CODE`
3. **허브 없이** — 폰 앱/브라우저에 터널 주소를 직접 입력한다(주소가 콘솔을 켤 때마다 바뀜). → `HUB_MODE=none`

**⑤ PIN** — 폰 로그인 비밀번호. 사용자가 6자리를 정하거나 "만들어줘" 라고 하면 네가 무작위 6자리를 만든다.
- 거부 규칙: `000000`, `123456`, `654321`, 같은 숫자 반복(`111111`), 연속 숫자, 생년월일로 보이는 6자리(`19xxxx`, `20xxxx`, `MMDD` 반복)는 "약한 PIN" 으로 거부하고 다시 받는다. `install.ps1` 도 같은 규칙으로 한 번 더 거르되, 약하면 되묻지 않고 **무작위 6자리를 새로 만들어 출력**한다(그 값을 사용자에게 알린다).
- 값은 마지막 보고서에 한 번만 적는다. → `PIN`

**⑥ 워치독** — 5분마다 콘솔 생존을 확인하고 죽어 있으면 자동 재기동하는 Windows 예약 작업(`OneMACS-Watchdog`). 기본은 등록. 사용자가 원치 않으면 3 단계 뒤에 `schtasks /Delete /TN OneMACS-Watchdog /F` 로 지운다고 알린다.

**⑦ Jev 판단 자문 (선택)** — 워커 선택·계속/중단·결과 평가를 확률로 답하는 자문 도구. 사용자 자기 **Vercel AI Gateway 키**가 필요하다(원맥스 쪽 키는 제공되지 않는다). 쓰겠다고 하면 5 단계에서 처리. 아니면 건너뛴다. → `JEV=yes|no`

**⑧ 추가 패키지 (선택)** — 기본은 콘솔만 설치. 아래 패키지는 **이 배포판 안에 들어 있다**(`DIST\addons\`). 쓰겠다고 하면 6 단계에서 처리.
- 매매 자동화 봇 (`addons\trading-bot\`, 원맥스 상품에 포함)
- **ARWA(보고서 작성 에이전트)는 여기서 설치하지 않는다.** 원맥스와 별도로 판매하는 상품이며 자기 폴더에 따로 설치한다. 사용자가 물으면 마켓 「에이전트」 카테고리에서 따로 구매할 수 있다고만 알린다.
- 쓰겠다는 것만 6 단계에서 처리. → `ADDONS`

문답이 끝나면 모은 값을 표로 한 번 보여주고 "이대로 설치할까요?" 확인을 받는다.

### 3. 설치 실행 (한 줄)
`DIST` 에서 아래 한 줄을 만든다. 선택 항목은 해당할 때만 붙인다.
```
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -PcLabel "<PC_LABEL>" -Pin <PIN> -Port <7890|7891> -HubMode <onemacs|self|none> [-PairCode <PAIR_CODE>] [-HubUrl <HUB_URL>]
```
- `-HubMode onemacs` 이면 `-PairCode` 필수. `-HubMode self` 이면 `-PairCode` 와 `-HubUrl` 둘 다 필수. `-HubMode none` 이면 둘 다 생략.
- 실행 전에 이 한 줄을 사용자에게 보여준다(PIN 은 `******` 로 가려서).
- 실행 결과(`[install HH:MM:SS] …` 줄들)를 그대로 보여준다. 스크립트는 다음을 한다: `HOME\console\`·`HOME\general\uploads\`·`HOME\CLAUDE.md` 생성 → 코드 복사(외부 npm 의존성 없음 — package.json 에 dependencies 가 생기는 버전에서만 `npm install`) → `console_config.json` 작성 → 워치독 등록 → 콘솔 기동 → 포트 응답 확인.
- 마지막 줄이 `✅ 라우터 포트 <port> 응답` 이면 성공. `⚠️ 포트 … 안 열림` 이면 `HOME\console\logs\console.log` 끝 40줄을 읽고 원인을 사용자에게 알린다(흔한 원인: 포트 충돌 → `-Port 7891` 로 재실행, npm install 실패 → 인터넷·프록시 확인).
- 실패 시 같은 명령을 그대로 다시 실행해도 안전하다(멱등).

**3-1. 고정 주소 (④ 에서 `LICENSE` 를 받았을 때만)**
```
node "$HOME\console\set_fixed_address.js" --license <LICENSE>
powershell -NoProfile -ExecutionPolicy Bypass -File "$HOME\console\stop_console.ps1"; & "$HOME\console\start_console.cmd"
```
- `받았습니다. 고정 주소 : https://<코드>-<번호>.onemacs.com` 이 나오면 성공. 그 주소를 사용자에게 알린다(토큰 줄은 가려져 나온다 — 그대로 둔다).
- 재기동 뒤 `HOME\console\start_all.log` 끝에 `터널 URL 발급 성공: https://<코드>-…onemacs.com` 이 찍히는지 본다. 90초 안에 못 서면 콘솔이 임시 주소로 물러서며 로그에 이유가 남는다 — 그 줄을 사용자에게 보여준다.
- `없는 라이선스` · `PC ○대를 모두 썼습니다` · `라이선스 상태: expired` 는 사용자가 판매처에 문의할 일이다. 설치는 임시 주소로 계속한다.
- 라이선스 키는 이 단계에서만 쓰고 보고서에는 앞 4자리만 적는다.

### 4. 첫 프로젝트 등록 (③ 에서 정했을 때만)
콘솔이 떠 있는 상태에서 콘솔 API 로 넣는다(설정 파일을 직접 고치지 않는다).
```powershell
$port = <port>
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$port/api/login" -ContentType 'application/json' -Body ('{"pin":"' + $pin + '"}') -SessionVariable s | Out-Null
# (a) 기존 폴더 연결
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$port/api/project-add" -ContentType 'application/json' -WebSession $s -Body (@{ name = "<PROJECT_NAME>"; dir = "<PROJECT_DIR>" } | ConvertTo-Json)
# (b) 새 폴더 (C:\콘솔프로젝트\<이름>)
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$port/api/project-add" -ContentType 'application/json' -WebSession $s -Body (@{ name = "<PROJECT_NAME>" } | ConvertTo-Json)
# 이 프로젝트를 1번(PC 창)으로
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:$port/api/project-primary" -ContentType 'application/json' -WebSession $s -Body (@{ name = "<PROJECT_NAME>" } | ConvertTo-Json)
```
- 응답 `success:true` 확인. `alive:false` 면 10초 뒤 `GET /api/projects` 로 다시 본다.
- (b) 에서 `needParent:true` 가 오면 `C:\콘솔프로젝트` 가 없는 것 — `New-Item -ItemType Directory C:\콘솔프로젝트` 후 재시도.
- 등록되면 그 폴더에 `_mobile_remote\` 가 자동으로 생긴 것을 `Test-Path` 로 확인한다.

### 5. Jev 자문 (⑦ 에서 yes 일 때만)
1. 사용자에게 https://vercel.com/ 의 AI Gateway 에서 API 키를 발급해 달라고 안내한다(사용자 직접). 키 값은 **채팅에 붙이지 말고** 파일에 넣으라고 한다.
2. `New-Item -ItemType Directory -Force "$env:USERPROFILE\.onemacs"` 후, 사용자가 `%USERPROFILE%\.onemacs\jev.env` 에 `AI_GATEWAY_API_KEY=<키>` 한 줄을 저장하도록 안내한다(메모장으로). 저장했다고 하면 `Test-Path` 와 줄 형식(`AI_GATEWAY_API_KEY=` 로 시작)만 확인한다. 값은 출력하지 않는다.
3. `claude mcp add --scope user jev -- node C:/OneMACS/console/jev_mcp/server.js` 실행. `claude mcp list` 에 `jev` 가 보이면 완료.
4. 키 없이 등록만 하면 Jev 호출이 실패만 하므로, 키 파일이 없으면 등록하지 않고 "나중에 키를 넣은 뒤 3 번 명령을 실행" 하라고 안내한다.

### 6. 추가 패키지 (⑧ 에서 고른 것만)
각 패키지는 자체 설치 지시문을 갖는다. 순서대로 읽고 그 지시를 따른다. 콘솔 설정은 건드리지 않는다.
- 주식매매 자동화 봇 실행기: `DIST\addons\trading-bot\CLAUDE_CODE_봇설치지시문.md` (기본 모의 모드, 실매매 전환은 그 문서의 절차)
- 패키지는 보통 특정 프로젝트 폴더에 풀린다. 4 단계에서 만든 프로젝트 폴더를 쓰거나, 없으면 프로젝트를 먼저 하나 만든다.

### 7. 업데이트 (1 단계 5 번에서 "예" 일 때)
```
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Update
```
- 설정(`console_config.json`)·세션·로그·`general\` 은 보존되고 `console\` 코드만 새 zip 것으로 바뀐 뒤 콘솔이 재시작된다.
- 끝나면 `Get-Content C:\OneMACS\console\VERSION` 으로 새 버전을 보고하고 8 단계로 간다.
- 업데이트 때는 문답을 하지 않는다. PIN·허브·프로젝트를 바꾸려면 폰 ⚙ 설정 시트 또는 `-Update` 없이 재설치.

### 8. 기동·폰 접속 확인 (⑨)
1. `Get-NetTCPConnection -LocalPort <port> -State Listen` 결과가 있어야 한다. 없으면 `C:\OneMACS\console\restart_console.cmd` 실행 후 40초 대기.
2. `Get-Content C:\OneMACS\console\logs\console.log -Tail 40` 에서 확인할 줄:
   - `trycloudflare.com` 주소가 찍힌 줄(터널). 없거나 `530` 이 반복되면 → 설치가이드 "문제 해결 · 터널 530".
   - `-HubMode onemacs|self` 일 때 `페어링 허브 등록 실패` 가 없어야 한다. 있으면 코드·허브 주소를 다시 확인.
3. `schtasks /Query /TN OneMACS-Watchdog` 에 `Ready` 가 보이면 워치독 OK.
4. **사용자에게 폰으로 확인시킨다** (아래 3 가지를 순서대로 하고 결과를 말해 달라고 한다):
   - 허브 페이지(원맥스 허브 또는 자기 허브 주소)를 폰에서 열어 페어링 코드를 넣으면 **이 PC 이름표(①)** 가 보인다. `-HubMode none` 이면 2 번의 터널 주소를 폰에 직접 입력한다.
   - PIN 으로 로그인된다.
   - 프로젝트 목록 맨 위 **"원맥스"**(홈 배지) 채널을 열고 `안녕` 을 보내면 답이 온다.
   - 4 단계에서 프로젝트를 등록했으면 그 항목에 **1번(PC창)** 배지가 붙어 있다.
5. 셋 중 하나라도 실패하면 설치가이드 "문제 해결" 표에 따라 조치하고, 못 고치면 로그 끝 40줄과 함께 사용자에게 알린다.

### 9. 완료 보고 (이 형식 그대로)
```
원맥스 설치 완료 (배포판 v3, 콘솔 v<VERSION 파일 값>)
- 콘솔 홈: C:\OneMACS\console   작업 폴더: C:\OneMACS\general
- PC 이름표: <PC_LABEL>   포트: <port>
- 허브: 원맥스 허브(코드 <PAIR_CODE>) / 직접 구축(<HUB_URL>, 코드 <PAIR_CODE>) / 없음(주소 직접 입력)
- PIN: <PIN>   ← 이 줄 외에는 어디에도 남기지 않음
- AI: Claude Code OK · Codex OK/없음 · Antigravity OK/없음 · Grok OK/없음
- 첫 프로젝트: <이름> (<경로>) = 1번(PC창) / 없음(폰에서 ＋ 로 추가)
- 고정 주소: https://<코드>-<번호>.onemacs.com / 없음(임시 주소)
- 워치독: 등록됨(5분) / 미등록
- Jev 자문: 등록됨 / 미설치
- 추가 패키지: 봇 실행기 설치/미설치
- 폰 확인: 허브에 PC 보임 OK · PIN 로그인 OK · 원맥스 채널 응답 OK
```

### 10. 이후 사용법 (사용자에게 한 번 알려줄 것)
- **폰에서 여는 법 — 브라우저면 충분하다.** 위 허브 주소를 폰 브라우저로 열고 코드·PIN 을 넣으면 그때부터 전부 된다.
  안드로이드 앱은 **마켓에서 따로** 받는 것이며(이 설치로 앱이 생기지 않는다), **없어도 모든 기능을 쓴다.**
  앱은 ① 작업이 끝났을 때 알림 ② PIN 자동 로그인 ③ 네이티브 말로 입력 ④ 주소창이 없어 넓은 화면 — 이 넷 때문에 쓴다.
  아이폰·아이패드·Mac 에서는 같은 주소·같은 PIN 으로 브라우저로 들어간다(앱은 안드로이드용).
  브라우저로 쓸 때 **「홈 화면에 추가」** 를 해 두면 아이콘으로 열린다. 자세한 것은 `원맥스 사용설명서.html`.
- 폰 화면: 프로젝트 목록 맨 위가 **원맥스**(홈, 해제 불가) — 프로젝트와 무관한 잡일·질문·파일 정리를 맡기는 채널. 그 아래가 프로젝트들. 항목의 ⋯ 로 **1번 지정 / 이름 바꾸기 / 연결 해제**, ＋ 로 **프로젝트 추가**(기존 폴더 연결 / 새 폴더).
- 1번(PC창) 프로젝트는 PC 화면의 Claude Code 창을 그대로 비춘다. 나머지는 백그라운드에서 돈다.
- PC 를 껐다 켜면 워치독이 5분 안에 콘솔을 다시 띄운다. 바로 띄우려면 `C:\OneMACS\console\restart_console.cmd`.
- 새 버전이 나오면 새 zip 을 풀고 그 폴더에서 이 지시문을 다시 읽히면 된다(자동으로 업데이트 경로로 간다).
- 설정 변경(PIN·워커·테마 등)은 폰 ⚙ 설정 시트. `C:\OneMACS\console\` 안의 파일은 손으로 고치지 않는다.
