/**
 * Worker 허브 페이지(hub_page.js)의 배너 블록을 정본(_deploy_console_hub/index.html)에서 생성한다.
 *  두 페이지는 UI 가 다르다(Vercel index.html = Gist 장부·고정 PIN·슬롯 탭 / Worker hub_page.js = 페어링 코드 입력·/devices 폴링·PIN 프롬프트)
 *  → 통째 생성은 불가하고, 공통인 "맨 위 배너 줄"(CSS + HTML)만 마커 사이에 복사한다.
 *  사용: node _console_hub_worker/build_hub_page.js [--check]   (--check: 다르면 exit 1, 파일 안 바꿈)
 */
const fs = require('fs');
const path = require('path');
const SRC = path.join(__dirname, '..', '_deploy_console_hub', 'index.html');
const DST = path.join(__dirname, 'hub_page.js');

function block(text, startMark, endMark, keepMarks) {
  const a = text.indexOf(startMark); const b = text.indexOf(endMark, a);
  if (a < 0 || b < 0) throw new Error('마커 없음: ' + startMark);
  const inner = text.slice(a + startMark.length, b);
  return { a, b: b + endMark.length, inner };
}
function main() {
  const check = process.argv.includes('--check');
  const src = fs.readFileSync(SRC, 'utf8');
  let dst = fs.readFileSync(DST, 'utf8');
  // CSS: 정본의 마커 줄 사이(주석 줄 포함)를 그대로
  const cssSrc = src.match(/[ \t]*\/\* hub-banner-css:start[^\n]*\n([\s\S]*?)\n[ \t]*\/\* hub-banner-css:end \*\//);
  const htmlSrc = src.match(/[ \t]*<!-- hub-banner:start[^\n]*\n([\s\S]*?)\n[ \t]*<!-- hub-banner:end -->/);
  if (!cssSrc || !htmlSrc) throw new Error('정본에 hub-banner 마커가 없습니다: ' + SRC);
  const css = cssSrc[1]; const html = htmlSrc[1].replace(/^  /gm, ''); // Worker 페이지는 body 직속(들여쓰기 2칸 제거)
  const out = dst
    .replace(/([ \t]*\/\* hub-banner-css:start[^\n]*\n)[\s\S]*?(\n?[ \t]*\/\* hub-banner-css:end \*\/)/, (m, s1, s2) => s1 + css + '\n' + s2.replace(/^\n/, ''))
    .replace(/(<!-- hub-banner:start[^\n]*\n)[\s\S]*?(\n?<!-- hub-banner:end -->)/, (m, s1, s2) => s1 + html + '\n' + s2.replace(/^\n/, ''));
  if (out === dst) { console.log('hub_page.js 배너 블록이 정본과 같습니다'); return; }
  if (check) { console.error('hub_page.js 배너 블록이 정본과 다릅니다 — node _console_hub_worker/build_hub_page.js 로 생성하세요'); process.exit(1); }
  fs.writeFileSync(DST, out, 'utf8');
  console.log('hub_page.js 배너 블록을 정본에서 생성했습니다 (' + path.relative(process.cwd(), SRC) + ' → ' + path.relative(process.cwd(), DST) + ')');
}
main();
