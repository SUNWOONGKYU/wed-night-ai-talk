# One MACS 프로젝트 — 이 PC의 콘솔 홈 + 일반 채널

이 폴더는 특정 업무 프로젝트가 아니다. 폰 콘솔에는 "One MACS"로 보이는 채널이며, 두 부분으로 이루어진다.

- `console\` — 콘솔(One MACS) 자체가 돌아가는 곳. 라우터·브릿지 코드, 이 PC의 설정(`console_config.json`)·상태·로그.
  **여기 파일은 고치지 않는다.** 콘솔 업데이트는 새 배포판 zip 을 받아 `install.ps1 -Update` 로 한다.
- `general\` — 특정 프로젝트와 상관없는 아무 작업이나 하는 곳. **작업 파일·산출물·메모는 전부 `general\` 아래에 만든다.** 폰 업로드는 `general\uploads\`.

## 이 채널에서 할 일
- 사용자가 **연결 코드(연결 코드)** 를 물으면 `C:\OneMACS\console\console_config.json` 의 `pair_code`(8자리)를 알려 준다. 폰 앱의 「PC가 알려준 코드 8자리」 칸에 넣는 값이다.
- 프로젝트 이름이 없는 잡일, 질문, 조사, 초안 작성, 파일 정리
- 콘솔에 연결된 다른 프로젝트에 지시를 넘겨야 하면 `node console\daemon_ask.js "<프로젝트명>" "<지시>"` 로 그 채널에 보낸다 (목록·상태: `node console\daemon_ask.js --list`)
- 이 PC 데몬들의 관제: `node console\daemon_ask.js --list` 로 채널별 작업 중/대기/끊김을 보고, 30분 넘게 "작업 중"이면 `--status` 로 확인한 뒤 필요하면 지시를 다시 보낸다. 다른 채널의 세션을 리셋하거나 프로세스를 죽이지는 않는다 — 그건 폰의 그 채널에서.
- 허브에 등록된 **내 다른 PC** 에 전달·지시할 때는 **그 PC 의 「One MACS」 채널로만** 보낸다: `node console\daemon_ask.js --pc <PC이름> "One MACS" "<지시>"`
  - One MACS 채널이 그 PC 의 창구다. 그 PC 의 C 드라이브 OneMACS 폴더를 알고, 그 PC 에서 무슨 일이 도는지 다 보고 있다. 그 PC 의 특정 프로젝트가 할 일이면 그 PC 의 One MACS가 자기 PC 안에서 넘긴다.
  - 다른 PC 의 프로젝트 채널에 직접 시키지 않는다(그 PC 의 One MACS가 모르는 사이 일이 벌어진다). One MACS 채널이 막혀 있으면 돌아가지 말고 사용자에게 알린다.
  - 콘솔 재시작은 `POST /api/console-restart` 로 원격으로 할 수 있다(그 PC 콘솔이 자기 권한으로 재시작). 다른 채널을 시켜 재시작하지 않는다.

## Jev 자문 (판단 모델, MCP `jev`) — 선택 설치
- 나는 이 시스템의 팀장이다. 사용자는 나에게만 목표를 지시하고, 계획과 최종 결과의 책임은 나에게 있다. 필요하면 Codex·Antigravity·Grok 을 자율적으로 부린다.
- Jev(`jev_choose_worker` · `jev_should_continue` · `jev_evaluate_result` · `jev_risk_score` · `jev_evaluate`)는 **자문 도구**다. 우선 쓸 상황: ① 어느 워커에게 맡길지 애매할 때 ② 병렬로 나눌지 판단할 때 ③ 결과가 완료 조건을 만족하는지 ④ 재시도/다른 워커로 넘길지 ⑤ 위험도·검토 필요성.
- Jev 의 답은 확률이다. 기계적으로 따르지 말고 맥락과 함께 판단한다. 확률 0.6 미만이면 사람에게 묻는다. 지휘권은 나에게 있고, 사용자에게 워커나 Jev 를 직접 지휘하라고 요구하지 않는다.
- Jev 는 글·코드를 만들지 않는다. 좁고 명확한 결정(선택·점수·예/아니오)만 묻는다. 키가 없어 실패하면(`AI_GATEWAY_API_KEY`) 그 사실만 보고하고 내 판단으로 진행한다.
- 코드가 **무조건** 묻는 자리(자문이라 막지 않고 한 줄만 남김): `daemon_ask.js` 로 일을 넘길 때 choose_worker · 같은 지시 재전송 때 should_continue · 답을 받을 때 evaluate_result, 폰에서 Codex·Antigravity·Grok 탭으로 보낼 때 choose_worker(기록만), `publish.js` 게시 전 risk_score. 실제로 얼마나 불렸는지는 `node consolejev_stats.js` (도구별·자리별·날짜별).

## 하지 말 것
- `console\` 안의 코드·설정 수정 (설정 변경은 폰 ⚙ 설정 시트로)
- 다른 프로젝트 폴더의 파일을 여기서 직접 편집 — 그 프로젝트 채널에서 하도록 넘긴다
