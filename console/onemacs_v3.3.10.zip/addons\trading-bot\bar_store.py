# -*- coding: utf-8 -*-
"""3분봉 원본 쌓기. (PO 2026-09-24)

    python bar_store.py fill 20260923     지난 거래일 자료로 채우기
    python bar_store.py stat              쌓인 것 보기

왜 원본만 쌓나 — PO 지시. 지표를 미리 계산해 쌓으면 나중에 지표를 바꿀 때 다시
만들 수 없다. 시가·고가·저가·종가·거래량만 두면 지표는 언제든 다시 계산한다.

하루치 얼마나 되나 — 290종목 × 3분봉 약 125개 = 36,000행. 1년이면 900만 행.
SQLite 로 충분하다(행당 약 40바이트, 1년 약 400MB).
"""
import sys
try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass
import os
import sqlite3

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'bars3m.db')

SCHEMA = '''
CREATE TABLE IF NOT EXISTS bars3m (
  code   TEXT NOT NULL,      -- 종목코드
  ts     TEXT NOT NULL,      -- YYYYMMDDHHMM (3분 버킷의 시작)
  o REAL, h REAL, l REAL, c REAL,
  v      INTEGER,
  PRIMARY KEY (code, ts)
);
CREATE INDEX IF NOT EXISTS ix_bars3m_ts ON bars3m(ts);
'''


def conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    cx = sqlite3.connect(DB)
    cx.executescript(SCHEMA)
    return cx


def to_3m(bars, day8):
    """1분봉 → 3분봉. 진행 중인 마지막 구간은 버린다(완성된 것만 쌓는다)."""
    buckets = {}
    for b in bars:
        ts = str(b.get('ts') or '')
        if not ts.startswith(day8) or len(ts) < 12:
            continue
        hh, mm = int(ts[8:10]), int(ts[10:12])
        key = f'{day8}{hh:02d}{(mm // 3) * 3:02d}'
        g = buckets.setdefault(key, [])
        g.append(b)
    out = []
    for key in sorted(buckets):
        g = sorted(buckets[key], key=lambda x: x['ts'])
        if len(g) < 3:
            continue            # 1분봉 셋이 다 있는 구간만 완성봉으로 본다
        o = float(g[0].get('open') or g[0]['close'])
        c = float(g[-1]['close'])
        h = max(float(x.get('high') or x['close']) for x in g)
        l = min(float(x.get('low') or x['close']) for x in g)
        v = sum(int(x.get('volume') or 0) for x in g)
        out.append((key, o, h, l, c, v))
    return out


def save(code, rows):
    if not rows:
        return 0
    cx = conn()
    cx.executemany('INSERT OR REPLACE INTO bars3m(code,ts,o,h,l,c,v) VALUES (?,?,?,?,?,?,?)',
                   [(code, t, o, h, l, c, v) for (t, o, h, l, c, v) in rows])
    cx.commit()
    n = cx.total_changes
    cx.close()
    return n


def fill(day8, codes=None, limit=None):
    """지난 거래일 1분봉을 받아 3분봉으로 접어 쌓는다."""
    from scanner_262_52 import get_minute_bars_naver, STOCK_CODES
    codes = codes or list(STOCK_CODES)
    if limit:
        codes = codes[:limit]
    ok = bad = total = 0
    for i, code in enumerate(codes, 1):
        try:
            b = get_minute_bars_naver(code) or []
            r = to_3m(b, day8)
            if r:
                save(code, r)
                total += len(r)
                ok += 1
            else:
                bad += 1
        except Exception:
            bad += 1
        if i % 50 == 0:
            print(f'  {i}/{len(codes)} · 담은 봉 {total:,}')
    print(f'{day8}: 종목 {ok}개 · 3분봉 {total:,}개 (못 받은 종목 {bad})')
    return total


def stat():
    cx = conn()
    q = cx.execute('SELECT COUNT(*), COUNT(DISTINCT code), COUNT(DISTINCT substr(ts,1,8)),'
                   ' MIN(ts), MAX(ts) FROM bars3m').fetchone()
    print(f'쌓인 3분봉 {q[0]:,}개 · 종목 {q[1]}개 · 날짜 {q[2]}일')
    if q[3]:
        print(f'  {q[3]} ~ {q[4]}')
    for d, n, c in cx.execute('SELECT substr(ts,1,8), COUNT(*), COUNT(DISTINCT code)'
                              ' FROM bars3m GROUP BY 1 ORDER BY 1'):
        print(f'   {d}  {n:>7,}봉  {c:>3}종목')
    sz = os.path.getsize(DB) / 1024 / 1024 if os.path.exists(DB) else 0
    print(f'  파일 {sz:.1f}MB')
    cx.close()


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'stat'
    if cmd == 'fill':
        day = sys.argv[2] if len(sys.argv) > 2 else ''
        lim = int(sys.argv[3]) if len(sys.argv) > 3 else None
        if not day:
            print('날짜를 주십시오: python bar_store.py fill 20260923')
            sys.exit(2)
        fill(day, limit=lim)
    else:
        stat()
