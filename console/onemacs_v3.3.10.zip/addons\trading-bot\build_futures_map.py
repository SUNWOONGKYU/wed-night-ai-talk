# -*- coding: utf-8 -*-
"""
주식선물 코드 매핑 빌더 (KIS 마스터 파일)
형식: 1|단축코드|표준코드|종목명|...|순서|기초자산코드|기초자산명
실행: python build_futures_map.py
"""
import sys
try:            # 윈도우 한국어 콘솔(cp949)에서 '—' 같은 글자에 로그가 터지지 않게
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass
import sys, os, json, io, zipfile, requests
from datetime import datetime, date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

OUT_FILE = os.path.join(os.path.dirname(__file__), 'futures_code_map.json')
MST_URL = 'https://new.real.download.dws.co.kr/common/master/fo_stk_code_mts.mst.zip'


def _second_thursday(year, month):
    """주식선물 만기일 = 해당 월 둘째 목요일."""
    d = date(year, month, 1)
    first_thu = 1 + (3 - d.weekday()) % 7   # Mon=0..Thu=3
    return date(year, month, first_thu + 7)


def month_priority(today=None):
    """오늘 기준 만료 안 된 분기물(3/6/9/12) 최선월부터 우선순위 리스트 반환.
    만기일(둘째 목요일)이 지난 월물은 건너뛴다 → 매 분기 자동 롤오버."""
    today = today or date.today()
    out = []
    # 2026-09-21 수정: 주식선물은 매월물이 상장된다(9월물 만기 9/10 뒤 최근월물은 10월물). 분기물만 보면 12월물로 튀어
    # 유동성이 나쁘고, 재빌드를 안 하면 만기 지난 코드로 주문해 '선물옵션종목이 없습니다'(APBK0818) 가 난다.
    for yr in (today.year, today.year + 1):
        for m in range(1, 13):
            if _second_thursday(yr, m) >= today:
                ms = f'{m:02d}'
                if ms not in out:
                    out.append(ms)
    return out[:4] or ['03']


MONTH_PRIORITY = month_priority()  # 날짜 기반 자동 산출 (만기 지난 월물 자동 제외)


def download_and_parse():
    """마스터 파일 다운로드 → 파싱"""
    print(f'  다운로드: {MST_URL}')
    r = requests.get(MST_URL, timeout=30)
    r.raise_for_status()
    z = zipfile.ZipFile(io.BytesIO(r.content))
    data = z.read(z.namelist()[0])
    lines = data.split(b'\n')
    print(f'  총 {len(lines):,}줄')

    # base_code -> [(short_code, month)]
    by_base = {}
    for line in lines:
        try:
            txt = line.decode('cp949', errors='replace').strip()
            if not txt:
                continue
            cols = txt.split('|')
            if len(cols) < 8:
                continue
            short_code = cols[1].strip()   # A11604
            base_code  = cols[7].strip()   # 005930
            if not (short_code.startswith('A') and len(base_code) == 6 and base_code.isdigit()):
                continue
            month = short_code[4:6]        # '04'
            if base_code not in by_base:
                by_base[base_code] = []
            by_base[base_code].append((short_code, month))
            # 기초자산 이름(마스터 9번째 열) — 262 고정 목록 밖 종목도 이름을 갖게 (2026-09-21 유니버스 자동화)
            if len(cols) >= 9 and cols[8].strip():
                NAMES.setdefault(base_code, cols[8].strip())
        except Exception:
            continue

    print(f'  파싱된 기초자산: {len(by_base)}개')
    return by_base


NAMES = {}  # base_code → 종목명 (마스터에서)


def build_map():
    print(f"\n{'='*60}")
    print(f'  주식선물 코드 매핑 빌더 v3')
    print('  대상: 마스터에 상장된 주식선물 기초자산 전체 (262 목록은 이름 보조)')
    print(f"{'='*60}\n")

    by_base = download_and_parse()

    # 2026-09-21 PO: 유니버스는 손으로 고른 262가 아니라 '지금 주식선물이 상장된 전 종목'(마스터 기준, 현재 ~292).
    # 262 목록은 이름 보조용으로만 쓴다. (262 중 21종은 선물 폐지, 마스터에는 262에 없는 51종이 있음)
    target = set(by_base.keys())
    found = {}
    reverse = {}
    found_next = {}  # 차근월물

    for stock_code in sorted(target):
        candidates = by_base.get(stock_code, [])
        if not candidates:
            continue
        # 최근월물 우선 선택
        best = None
        for pm in MONTH_PRIORITY:
            for fcode, month in candidates:
                if month == pm:
                    best = fcode
                    break
            if best:
                break
        if not best:
            best = candidates[0][0]
        # 차근월물(롤오버용): MONTH_PRIORITY 에서 best 다음 순위의 월물 (2026-09-22: 20영업일 보유가 만기에 잘리지 않게 같은 종목 익월물로 롤오버)
        nxt = None
        try:
            bi = MONTH_PRIORITY.index(best[4:6])
            for pm in MONTH_PRIORITY[bi + 1:]:
                for fcode, month in candidates:
                    if month == pm:
                        nxt = fcode; break
                if nxt: break
        except ValueError:
            pass
        if nxt:
            found_next[stock_code] = nxt

        found[stock_code] = best
        reverse[best] = stock_code
        name = NAMES.get(stock_code, stock_code)
        print(f'  {stock_code} {name:12s} → {best}')

    print(f"\n{'='*60}")
    print(f'  매핑 완료: {len(found)}/{len(target)}개 (마스터 기초자산 전체)')

    months = {}
    for fc in found.values():
        m = fc[4:6]
        months[m] = months.get(m, 0) + 1
    for m, cnt in sorted(months.items()):
        print(f'  {m}월물: {cnt}개')

    names = {c: NAMES.get(c, c) for c in found}
    with open(OUT_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            'stock_to_futures': found,
            'futures_to_stock': reverse,
            'stock_to_futures_next': found_next,
            'names': names,
            'month': sorted(months.keys())[0] if months else '04',
            'built_at': datetime.now().isoformat(),
        }, f, ensure_ascii=False, indent=2)
    # 이름 캐시(data/stock_names.json)도 갱신 — futures_map.get_futures_universe 가 읽음
    try:
        npath = os.path.join(os.path.dirname(__file__), 'data', 'stock_names.json')
        old = {}
        if os.path.exists(npath):
            with open(npath, encoding='utf-8') as f:
                old = json.load(f)
        old.update(names)
        with open(npath, 'w', encoding='utf-8') as f:
            json.dump(old, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f'  이름 캐시 갱신 실패(무시): {e}')

    print(f'  저장: {OUT_FILE}')
    print(f"{'='*60}\n")
    return found


if __name__ == '__main__':
    build_map()
