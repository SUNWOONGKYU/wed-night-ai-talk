# -*- coding: utf-8 -*-
"""
스캐너 웹뷰어 - 1단계(네이버) | 2단계(KIS) 좌우 나란히 표시
localhost:5050
"""
import sys
try:            # 윈도우 한국어 콘솔(cp949)에서 '—' 같은 글자에 로그가 터지지 않게
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass
import sys, os, json, threading, time, webbrowser, subprocess, re
from datetime import datetime
from flask import Flask, render_template_string, jsonify, request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scanner_262_52 import scan_all, get_kospi200_kodex

app = Flask(__name__)

# ── 매매 자동화 봇 상태 ──
sentry_state = {
    'running': False,
    'proc': None,
    'logs': [],
    'positions': [],
    'daily_trades': 0,
    'daily_pnl': 0.0,
    'started_at': None,
}

def _sentry_reader(proc):
    """sentry.py stdout/stderr 읽기 스레드"""
    pos_map = {}  # code -> position dict

    for raw in iter(proc.stdout.readline, b''):
        line = raw.decode('utf-8', errors='ignore').strip()
        if not line:
            continue

        ts = datetime.now().strftime('%H:%M:%S')
        sentry_state['logs'].append(f'[{ts}] {line}')
        sentry_state['logs'] = sentry_state['logs'][-100:]

        # 포지션 파싱
        # "주문 체결: 삼성전자 CALL x1 @ 75,000"
        m = re.search(r'주문 체결: (.+?) (CALL|PUT) x(\d+) @ ([\d,]+)', line)
        if m:
            name, side, qty, price = m.group(1), m.group(2), int(m.group(3)), int(m.group(4).replace(',', ''))
            pos_map[name] = {'name': name, 'side': side, 'qty': qty, 'entry': price, 'current': price, 'pnl': 0.0}
            sentry_state['positions'] = list(pos_map.values())

        # 청산 파싱
        m = re.search(r'청산: (.+?) (CALL|PUT) @ ([\d,]+) \(([+-][\d.]+)%\)', line)
        if m:
            name = m.group(1)
            pos_map.pop(name, None)
            sentry_state['positions'] = list(pos_map.values())

        # 일일 매매 통계
        m = re.search(r'일일매매: (\d+)건.*일일손익: ([+-]?[\d,]+)원', line)
        if m:
            sentry_state['daily_trades'] = int(m.group(1))
            sentry_state['daily_pnl'] = float(m.group(2).replace(',', ''))

    sentry_state['running'] = False
    sentry_state['proc'] = None

scan_state = {
    'running': False,
    'stage1': [],
    'stage2': [],
    'futures': None,
    'logs': [],
    'started_at': None,
    'finished_at': None,
    'stage1_loaded': False,
}

# ── KOSPI200 선물 실시간 30틱 차트 ──
_K200_TICK_SIZE  = 0.05   # 최소 호가단위 (0.05pt)
_K200_TICKS_BAR  = 30     # 봉당 틱 수
_K200_MA_PERIOD  = 20     # 이평 기간
_K200_MAX_BARS   = 120    # 보관 최대 봉 수

k200_state = {
    'price': 0.0,       # 현재가 (pt)
    'rate':  0.0,       # 등락률 (%)
    'ts':    '',        # 마지막 업데이트 시각
    'tick_acc': 0.0,    # 현재 봉 누적 틱 (절대값)
    'bar':  None,       # 진행 중 봉 {o,h,l,c,ticks}
    'bars': [],         # 완성된 봉 리스트
    'ma':   [],         # 20MA 값 리스트 (bars와 동일 인덱스)
    'signal': None,     # 'UP'(골든) / 'DOWN'(데드) / None
    'signal_ts': '',
    'alert':  False,    # JS가 소리 낼 때 True → JS 읽은 후 False
}

def _k200_close_bar():
    """진행 중 봉 확정 + 20MA 계산 + 크로스 감지"""
    bar = k200_state['bar']
    if not bar:
        return
    k200_state['bars'].append(bar)
    if len(k200_state['bars']) > _K200_MAX_BARS:
        k200_state['bars'] = k200_state['bars'][-_K200_MAX_BARS:]

    closes = [b['c'] for b in k200_state['bars']]
    if len(closes) >= _K200_MA_PERIOD:
        ma_vals = []
        for i in range(len(closes)):
            if i + 1 >= _K200_MA_PERIOD:
                ma_vals.append(round(sum(closes[i+1-_K200_MA_PERIOD:i+1])/_K200_MA_PERIOD, 2))
            else:
                ma_vals.append(None)
        k200_state['ma'] = ma_vals
    else:
        k200_state['ma'] = [None] * len(closes)

    # 크로스 감지 (최소 2봉 필요)
    ma = k200_state['ma']
    bars = k200_state['bars']
    if len(bars) >= 2 and ma[-1] is not None and ma[-2] is not None:
        prev_c, cur_c = bars[-2]['c'], bars[-1]['c']
        prev_m, cur_m = ma[-2], ma[-1]
        now_s = datetime.now().strftime('%H:%M:%S')
        if prev_c <= prev_m and cur_c > cur_m:
            if k200_state['signal'] != 'UP':
                k200_state['signal'] = 'UP'
                k200_state['signal_ts'] = now_s
                k200_state['alert'] = True
                print(f'[K200] ▲ 골든크로스 {cur_c:.2f}pt > MA{cur_m:.2f}pt ({now_s})')
        elif prev_c >= prev_m and cur_c < cur_m:
            if k200_state['signal'] != 'DOWN':
                k200_state['signal'] = 'DOWN'
                k200_state['signal_ts'] = now_s
                k200_state['alert'] = True
                print(f'[K200] ▼ 데드크로스 {cur_c:.2f}pt < MA{cur_m:.2f}pt ({now_s})')

    k200_state['bar'] = None
    k200_state['tick_acc'] = 0.0

def _futures_basis(spot):
    """KOSPI200 현물지수 → 선물 추정가 (베이시스 보정)
    basis = spot × rf × T/365  (rf=3.5%, T=만기까지 달력일수)
    KOSPI200 선물 만기: 3/6/9/12월 두 번째 목요일
    """
    from datetime import date, timedelta
    today = date.today()
    # 다음 분기 만기일 계산
    def _second_thursday(y, m):
        d = date(y, m, 1)
        dow = d.weekday()  # 0=Mon
        first_thu = d + timedelta(days=(3 - dow) % 7)
        return first_thu + timedelta(weeks=1)

    expiries = []
    for mo in [3, 6, 9, 12]:
        yr = today.year
        exp = _second_thursday(yr, mo)
        if exp >= today:
            expiries.append(exp)
    if not expiries:
        expiries = [_second_thursday(today.year + 1, 3)]
    exp = min(expiries)
    T = max((exp - today).days, 1)
    basis = spot * 0.035 * T / 365
    return round(spot + basis, 2)


_k200_source = '-'  # 현재 사용 중인 소스 추적

def _fetch_kpi200():
    """KOSPI200 선물 추정가 실시간 조회 (2초 폴링용)
    1순위: KIS KOSPI200 현물지수(code=2001) + 베이시스 보정 → 선물 근사
           오차 0~2pt (KODEX200/100 대비 훨씬 정확)
    2순위: KIS KODEX200(069500) ETF / 100 (fallback)
    """
    global _k200_source

    # 1순위: KIS KOSPI200 현물지수 (FHPST02400000) + 베이시스
    try:
        import requests as _req
        from kis import get_access_token, KIS_API_URL, KIS_APP_KEY, KIS_APP_SECRET
        _tok = get_access_token()
        _h = {
            'Content-Type': 'application/json',
            'authorization': 'Bearer ' + _tok,
            'appkey': KIS_APP_KEY,
            'appsecret': KIS_APP_SECRET,
            'tr_id': 'FHPST02400000',
        }
        _p = {'fid_cond_mrkt_div_code': 'U', 'fid_input_iscd': '2001'}
        _r = _req.get(KIS_API_URL + '/uapi/domestic-stock/v1/quotations/inquire-index-price',
                      headers=_h, params=_p, timeout=3)
        _d = _r.json()
        if _d.get('rt_cd') == '0':
            _o = _d.get('output', {})
            _spot = float(_o.get('stck_prpr', '0').replace(',', ''))
            _rate = float(_o.get('prdy_ctrt', '0').replace(',', ''))
            if _spot > 0:
                fut = _futures_basis(_spot)
                if _k200_source != 'KPI200':
                    print(f'[K200] 소스 → KIS현물지수+베이시스: spot={_spot} fut={fut}')
                    _k200_source = 'KPI200'
                return fut, round(_rate, 2)
        else:
            _k200_source = 'ERR:' + str(_d.get('rt_cd')) + _d.get('msg1', '')[:30]
    except Exception as e:
        _k200_source = 'EXC:' + str(e)[:40]

    # 2순위: KIS KODEX200 ETF / 100 (fallback)
    try:
        import requests as _req
        from kis import get_access_token, KIS_API_URL, KIS_APP_KEY, KIS_APP_SECRET
        _tok = get_access_token()
        _h = {
            'Content-Type': 'application/json',
            'authorization': 'Bearer ' + _tok,
            'appkey': KIS_APP_KEY,
            'appsecret': KIS_APP_SECRET,
            'tr_id': 'FHKST01010100',
        }
        _p = {'fid_cond_mrkt_div_code': 'J', 'fid_input_iscd': '069500'}
        _r = _req.get(KIS_API_URL + '/uapi/domestic-stock/v1/quotations/inquire-price',
                      headers=_h, params=_p, timeout=3)
        _d = _r.json()
        if _d.get('rt_cd') == '0':
            _o = _d.get('output', {})
            _etf = float(_o.get('stck_prpr', '0').replace(',', ''))
            _rate = float(_o.get('prdy_ctrt', '0').replace(',', ''))
            if _etf > 0:
                if _k200_source != 'KODEX200':
                    print(f'[K200] 소스 → KODEX200 fallback: etf={_etf}')
                    _k200_source = 'KODEX200'
                return round(_etf / 100.0, 2), round(_rate, 2)
    except Exception:
        pass

    return None, None


def _k200_poller():
    """2초마다 KOSPI200 현물지수 폴링 → 틱 누적 → 30틱 봉 생성
    소스: Naver KPI200 polling API (nv/100 = KOSPI200 지수 pt, KODEX200 ETF 아님)
    """
    prev_price = 0.0
    while True:
        try:
            time.sleep(2)
            now = datetime.now()
            h, m = now.hour, now.minute
            # 장전/장후도 표시 — 9:00 전후 ±30분 허용
            in_mkt = (8 <= h <= 15) and now.weekday() < 5
            if not in_mkt:
                continue
            price, rate = _fetch_kpi200()
            if not price:
                continue
            k200_state['price']  = price
            k200_state['rate']   = rate
            k200_state['ts']     = now.strftime('%H:%M:%S')
            k200_state['source'] = _k200_source

            if prev_price == 0.0:
                prev_price = price
                continue

            # 틱 계산
            diff = abs(price - prev_price)
            ticks = diff / _K200_TICK_SIZE
            prev_price = price

            if ticks < 0.5:
                continue  # 변동 없음

            # 현재 봉 업데이트 or 생성
            if k200_state['bar'] is None:
                k200_state['bar'] = {'o': price, 'h': price, 'l': price, 'c': price, 'ticks': 0}
            bar = k200_state['bar']
            bar['h'] = max(bar['h'], price)
            bar['l'] = min(bar['l'], price)
            bar['c'] = price
            bar['ticks'] = bar.get('ticks', 0) + ticks
            k200_state['tick_acc'] += ticks

            if k200_state['tick_acc'] >= _K200_TICKS_BAR:
                _k200_close_bar()

        except Exception:
            pass

HTML = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>5대장2졸병 스캐너</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;overflow:hidden}
body{background:#0d1117;color:#e6edf3;font-family:'Malgun Gothic','Segoe UI',sans-serif;display:flex;flex-direction:column}
/* 상단 고정 영역 */
.topbar{display:flex;gap:6px;padding:1px 6px;background:#161b22;border-bottom:1px solid #30363d;align-items:center;flex-shrink:0;white-space:nowrap;overflow-x:auto;-webkit-overflow-scrolling:touch}
.topbar::-webkit-scrollbar{height:0}
.topbar a{padding:1px 7px;border-radius:4px;font-size:12px;font-weight:600;color:#c9d1d9;text-decoration:none;white-space:nowrap;flex:0 0 auto}
.topbar span{white-space:nowrap}
.topbar a.active{background:#21262d;color:#58a6ff}
.controls{padding:1px 6px;display:flex;gap:6px;align-items:center;border-bottom:1px solid #30363d;background:#161b22;flex-shrink:0}
.btn{padding:2px 8px;border:none;border-radius:4px;font-size:12px;cursor:pointer;font-weight:700}
.btn-scan{background:#238636;color:#fff}
.btn-scan:hover{background:#2ea043}
.btn-scan:disabled{background:#333;color:#666;cursor:not-allowed}
.badge{padding:1px 6px;border-radius:8px;font-size:11px;font-weight:700}
.badge-idle{background:#21262d;color:#8b949e}
.badge-run{background:#388bfd33;color:#58a6ff;animation:pulse 1.5s infinite}
.badge-done{background:#238636;color:#fff}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
.log-box{padding:0 6px;background:#0d1117;border-bottom:1px solid #21262d;height:16px;overflow:hidden;font-size:10px;color:#555;font-family:monospace;white-space:nowrap;text-overflow:ellipsis;flex-shrink:0;display:flex;align-items:center}
/* KOSPI200 바 (전체 너비) */
.kospi-bar{background:#1c2128;border-bottom:1px solid #d29922;padding:1px 8px;flex-shrink:0;min-height:22px;display:flex;align-items:center;gap:10px}
.kospi-bar.empty{border-color:#444;color:#666;font-size:12px}
/* 패널 */
.cmb{background:#0d1117;border-bottom:1px solid #30363d;padding:4px 6px;flex-shrink:0;max-height:38vh;overflow:auto}
.cmb-hdr{display:flex;justify-content:space-between;align-items:center;font-size:11px;font-weight:800;color:#e6edf3;margin-bottom:3px}
.cmb-hdr .win{color:#8b949e;font-weight:600}
.cmb table{width:100%;border-collapse:collapse;font-size:11px}
.cmb th{color:#8b949e;font-weight:600;text-align:left;padding:2px 4px;border-bottom:1px solid #21262d;white-space:nowrap}
.cmb td{padding:2px 4px;border-bottom:1px solid #161b22;white-space:nowrap}
.cmb .fam{font-size:10px;padding:1px 5px;border-radius:4px;font-weight:700}
.cmb .fam.call{background:#12362a;color:#3fb950} .cmb .fam.put{background:#3a1d18;color:#ff7b72} .cmb .fam.trend{background:#14273f;color:#79c0ff}
.cmb .ty{display:inline-block;min-width:22px;text-align:center;padding:1px 4px;border-radius:4px;font-weight:800;font-size:10.5px;background:#21262d;color:#484f58}
.cmb .ty.on{background:#1f6feb;color:#fff} .cmb .ty.no{color:#6e7681}
.cmb .s1ok{color:#3fb950} .cmb .s1no{color:#8b949e}
.cmb .st{font-size:10px;color:#8b949e} .cmb .st.entered{color:#3fb950;font-weight:700} .cmb .st.requested{color:#d29922;font-weight:700}
.cmb .empty{color:#484f58;font-size:11px;padding:4px}
table{width:100%;border-collapse:collapse}
th{background:#161b22;color:#8b949e;font-size:12px;padding:1px 4px;text-align:left;border-bottom:1px solid #30363d;position:sticky;top:0;z-index:1;white-space:nowrap}
td{padding:0px 4px;border-bottom:1px solid #21262d;font-size:12px;color:#e6edf3;line-height:1.15;white-space:nowrap}
tr:hover{background:#1c2128}
.call{color:#ff6b6b;font-weight:800}
.put{color:#4fc3f7;font-weight:800}
.s-low{color:#555}
.s-call-mid{color:#ffa726;font-weight:700}
.s-call-high{color:#ff5252;font-weight:800}
.s-put-mid{color:#ce93d8;font-weight:700}
.s-put-high{color:#4fc3f7;font-weight:800}
.up{color:#ff5252;font-weight:700}
.down{color:#4fc3f7;font-weight:700}
.tag{display:inline-block;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700}
.tag-pass{background:#0d2818;color:#3fb950}
.tag-fail{background:#21262d;color:#555}
.empty{text-align:center;padding:6px;color:#555;font-size:13px}
.n-60{color:#ff5252}.n-50{color:#ce93d8}.n-30{color:#666}.n-tot{color:#3fb950}
/* 포지션 바 */
.pos-bar{background:#1a1a2e;border-bottom:1px solid #30363d;padding:0 8px;flex-shrink:0;display:flex;align-items:center;gap:8px;height:18px;font-size:11px}
.pos-bar.empty-pos{color:#484f58}
.pos-item{display:inline-flex;align-items:center;gap:4px;padding:1px 6px;border-radius:3px;background:#21262d}
.pos-call{border-left:2px solid #ff6b6b}
.pos-put{border-left:2px solid #4fc3f7}
.pos-pnl-p{color:#3fb950;font-weight:700}
.pos-pnl-n{color:#f85149;font-weight:700}
/* KOSPI200 30틱 차트 */
.k200-wrap{flex-shrink:0;background:#12151d;border-bottom:1px solid #21262d;height:130px;display:flex;overflow:hidden}
.k200-info{width:116px;flex-shrink:0;padding:5px 8px;border-right:1px solid #21262d;display:flex;flex-direction:column;justify-content:center;gap:1px}
.k200-info .lbl{font-size:9px;color:#555;font-weight:600;letter-spacing:.5px}
.k200-info .price{font-size:15px;font-weight:800;color:#e6edf3;line-height:1.15}
.k200-info .rate{font-size:12px;font-weight:700}
.k200-info .sig{font-size:10px;font-weight:700;padding:1px 4px;border-radius:3px;margin-top:1px;min-height:14px}
.k200-info .ts{font-size:9px;color:#444;margin-top:1px}
.k200-svg-wrap{flex:1;overflow:hidden;position:relative}

/* ① 시장 · 미국장 · 밤사이 (PO 2026-09-24) */
.mkt{background:#161b22;border:1px solid #30363d;border-radius:8px;margin:6px 0;padding:8px 10px}
.mkt-row{display:flex;align-items:baseline;gap:8px;padding:3px 0;flex-wrap:wrap}
.mkt-nm{color:#8b949e;font-size:12px;min-width:104px}
.mkt-v{color:#e6edf3;font-size:19px;font-weight:800;font-variant-numeric:tabular-nums}
.mkt-r{font-size:13px;font-weight:700;font-variant-numeric:tabular-nums}
.mkt-r.up{color:#3fb950}.mkt-r.dn{color:#f85149}
.mkt-sub{color:#6e7681;font-size:11px;margin-left:auto}
.us-row{color:#8b949e;font-size:12px;padding:4px 10px 6px;border-bottom:1px solid #21262d}
.us-row b{color:#c9d1d9;font-weight:700}
.us-row .up{color:#3fb950}.us-row .dn{color:#f85149}
.ovn{font-size:11px;font-variant-numeric:tabular-nums;white-space:nowrap}
.ovn .up{color:#3fb950}.ovn .dn{color:#f85149}
.ovn .vol{color:#d29922;font-weight:700}
.ovn .flat{color:#6e7681}
/* ③ 타입별 */
.tyg{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:6px;padding:8px}
.tyc{background:#0d1117;border:1px solid #21262d;border-radius:6px;padding:6px 8px}
.tyc h4{margin:0 0 4px;font-size:12px;color:#58a6ff;font-weight:800}
.tyc .n{color:#6e7681;font-weight:400}
.tyc div{font-size:12px;color:#c9d1d9;padding:1px 0;font-variant-numeric:tabular-nums}
.tyc .none{color:#484f58}

.jev{font-size:12px;font-weight:800;font-variant-numeric:tabular-nums}
.jev.hi{color:#3fb950}.jev.mid{color:#d29922}.jev.lo{color:#f85149}.jev.none{color:#484f58;font-weight:400}

.mkt-j{border-top:1px solid #21262d;margin-top:5px;padding-top:5px;font-size:12px;color:#8b949e}
.mkt-j b{color:#58a6ff;font-weight:800;margin-right:4px}
.jev-note{color:#484f58;font-size:11px;margin-left:6px}
.j2{font-size:12px;font-weight:700;color:#a5a5ff;font-variant-numeric:tabular-nums}

/* 폰 폭(392px)에서 표가 잘리던 것 — 상자 안에서만 옆으로 밀린다 (HQ 실측 2026-09-24) */
#cmbBody{overflow-x:auto;-webkit-overflow-scrolling:touch}
#cmbBody table{min-width:560px}
#cmbBody th,#cmbBody td{white-space:nowrap}
#cmbBody th:first-child,#cmbBody td:first-child{position:sticky;left:0;background:#161b22;z-index:1}
@media (max-width:480px){
  .mkt-v{font-size:17px}
  .mkt-nm{min-width:88px;font-size:11px}
  .mkt-sub{margin-left:0;width:100%;padding-left:88px}
  .tyg{grid-template-columns:1fr 1fr}
}

/* ④ 290종목 한 열 — 옛 두 열(.panels)을 대신한다 (PO 2026-09-24) */
.uni{background:#161b22;border:1px solid #30363d;border-radius:8px;margin:6px 8px;
     display:flex;flex-direction:column;min-height:0;flex:1}
.uni-hdr{display:flex;align-items:baseline;gap:8px;padding:7px 10px;border-bottom:1px solid #21262d;
         font-size:12px;font-weight:700;color:#c9d1d9;flex-wrap:wrap}
.uni-meta{margin-left:auto;color:#6e7681;font-size:11px;font-weight:400}
.uni-body{overflow:auto;-webkit-overflow-scrolling:touch;min-height:0;flex:1}
.uni-body table{width:100%;border-collapse:collapse;font-size:12px;min-width:420px}
.uni-body th{position:sticky;top:0;background:#161b22;color:#8b949e;font-weight:600;
             text-align:right;padding:5px 6px;border-bottom:1px solid #21262d;
             white-space:nowrap;z-index:2}
.uni-body th:first-child{text-align:left;left:0;z-index:3}
.uni-body td{padding:4px 6px;text-align:right;border-bottom:1px solid #1b2129;
             font-variant-numeric:tabular-nums;white-space:nowrap}
.uni-body td:first-child{text-align:left;position:sticky;left:0;background:#161b22;z-index:1}
.uni-body .up{color:#3fb950}
.uni-body .dn{color:#f85149}
.uni-body .hot{color:#d29922;font-weight:700}
.uni-src{font-size:10px;color:#484f58}
</style>
</head>
<body>
<!-- 콘솔(iframe) 안에서는 이 줄을 감춘다 — PO 2026-09-24 "버튼은 설명서하고 스캐너 두 개만".
     그리고 여기 있던 K200선물 숫자는 뺐다. 아래 ① 시장 카드와 값이 달라 더 헷갈렸다. -->
<div class="topbar" id="topbar">
  <a href="/" class="active">스캐너</a>
  <a href="/trading">매매 자동화 봇</a>
  <a href="/system">시스템</a>
  <a href="#" onclick="openGuide();return false">설명서</a>
  <span style="margin-left:auto;display:flex;align-items:center;gap:8px">
    <span style="color:#555;font-size:10px" id="clock"></span>
  </span>
</div>
<div class="controls">
  <button class="btn btn-scan" id="btnScan" onclick="scanNow()">지금 한 바퀴</button>
  <span class="badge badge-idle" id="sBadge">대기</span>
  <span style="color:#555;font-size:11px" id="elapsed"></span>
</div>
<div class="log-box" id="logBox">290종목을 3분마다 한 바퀴 돕니다.</div>

<!-- 보유 포지션 바 -->
<div class="pos-bar empty-pos" id="posBar">포지션 없음</div>
<!-- ① 시장 — 코스피200 지수(KODEX200÷100) + 선물 근월물 실거래 (PO 2026-09-24) -->
<div class="mkt" id="mktBox">
  <div class="mkt-row"><span class="mkt-nm">코스피200 지수</span><span class="mkt-v" id="mkIdx">—</span>
    <span class="mkt-r" id="mkIdxR"></span><span class="mkt-sub" id="mkIdxSub"></span></div>
  <div class="mkt-row"><span class="mkt-nm">코스피200 선물</span><span class="mkt-v" id="mkFut">—</span>
    <span class="mkt-r" id="mkFutR"></span><span class="mkt-sub" id="mkFutSub"></span></div>
  <div class="mkt-j" id="mkJ1"></div>
</div>
<!-- 2026-09-24 PO: 코스피200 중복 제거. 9/23 에 폐지한 6대장2졸병
     CALL/PUT 점수를 보여 주던 자리다. 지수는 ① 시장 카드 한 곳에만. -->

<!-- KOSPI200 30틱 실시간 차트 -->
<div class="k200-wrap">
  <div class="k200-info">
    <div class="lbl">KOSPI200 30틱 MA20</div>
    <div class="sig" id="k200Sig"></div>
    <div class="ts" id="k200Ts">대기중</div>
  </div>
  <div class="k200-svg-wrap">
    <svg id="k200Svg" style="width:100%;height:130px;display:block"></svg>
  </div>
</div>

<!-- 종합 신호 (2026-09-22 PO): 일봉 후보만 → 1단계(네이버 1분봉 선별) → 2단계 타이밍 타입 A/B/C/D — 점수 합산 없이 기준 통과제 -->
<div class="cmb" id="cmbBox">
  <div class="cmb-hdr"><span>② 오늘의 후보</span><span class="win" id="cmbWin">봇 대기</span></div>
  <div class="us-row" id="usRow"></div>
  <div id="cmbBody"><div class="empty">08:45 봇이 오늘의 후보를 뽑으면 여기에 표시됩니다.</div></div>
</div>

<!-- ③ 타입별 — 어느 종목이 몇 시에 떴는지만 (내역은 위 ② 에 다 있다) -->
<div class="cmb" id="tyBox">
  <div class="cmb-hdr"><span>③ 타이밍 — 유형별</span><span class="win" id="tyWin"></span></div>
  <div id="tyBody"><div class="empty">아직 뜬 시점이 없습니다.</div></div>
</div>
<div class="cmb" id="uniHdr">
  <div class="cmb-hdr"><span>④ 290종목 현황</span><span class="win">3분봉 · 쌓아서 규칙을 찾는 재료</span></div>
</div>
<div class="uni">
  <div class="uni-hdr">
    <span id="uniCount">아직 한 바퀴도 안 돌았습니다</span>
    <span class="uni-meta" id="uniMeta"></span>
  </div>
  <div class="uni-body" id="uniBody">
    <div class="empty">3분마다 한 바퀴 돕니다. 첫 바퀴는 2~3분 걸립니다.</div>
  </div>
</div>

<script>
function tick(){document.getElementById('clock').textContent=new Date().toLocaleString('ko-KR')}
setInterval(tick,1000);tick();

let scanning=false, pollT=null, t0=null, autoT=null;

window.onload=function(){
  // 스캔 자동 시작 안 함 (trader.py가 제어) — 화면 갱신만
  pollT=setInterval(poll,2000);
  poll();
};

function scanNow(){
  // 3분 주기를 기다리지 않고 290종목을 지금 한 바퀴 돌린다 (PO 2026-09-24)
  if(scanning) return;
  scanning=true; t0=Date.now();
  document.getElementById('btnScan').disabled=true;
  document.getElementById('sBadge').className='badge badge-run';
  document.getElementById('sBadge').textContent='도는 중...';
  document.getElementById('logBox').textContent='290종목 한 바퀴 시작 — 2~3분 걸립니다.';
  document.getElementById('uniCount').textContent='첫 바퀴를 도는 중입니다';
  fetch('/api/universe/now',{method:'POST'}).then(r=>r.json()).then(d=>{
    scanning=false;
    document.getElementById('btnScan').disabled=false;
    const ok=d&&d.ok;
    document.getElementById('sBadge').className='badge '+(ok?'badge-done':'badge-idle');
    document.getElementById('sBadge').textContent=ok?'완료':'대기';
    if(d&&d.msg) document.getElementById('logBox').textContent=d.msg;
    poll();
  }).catch(()=>{
    scanning=false;
    document.getElementById('btnScan').disabled=false;
    document.getElementById('sBadge').className='badge badge-idle';
    document.getElementById('sBadge').textContent='대기';
    document.getElementById('logBox').textContent='한 바퀴를 못 돌았습니다. 봇이 떠 있는지 보세요.';
  });
  elTick();
}

function elTick(){
  if(!scanning)return;
  document.getElementById('elapsed').textContent=((Date.now()-t0)/1000|0)+'초';
  setTimeout(elTick,500);
}


// ① 시장 — 지수는 눈금(살 수 없음), 선물은 실제 거래되는 물건 (PO 2026-09-24)
function renderMarket(m){
  if(!m) return;
  const put=(vId,rId,sId,o,isFut)=>{
    const v=document.getElementById(vId), r=document.getElementById(rId), sub=document.getElementById(sId);
    if(!o){ v.textContent='—'; r.textContent=''; sub.textContent=''; return; }
    v.textContent=Number(o.price).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
    const d=isFut?o.change:o.rate;
    r.textContent=(d>0?'▲':d<0?'▼':'')+Math.abs(d).toFixed(2)+(isFut?'':'%');
    r.className='mkt-r '+(d>0?'up':d<0?'dn':'');
    sub.textContent=isFut
      ? (o.month||'')+'('+(o.code||'')+') · '+Number(o.volume).toLocaleString()+'계약'
      : (o.from||'');
  };
  put('mkIdx','mkIdxR','mkIdxSub',m.index,false);
  put('mkFut','mkFutR','mkFutSub',m.futures,true);
  if(m.basis!==null&&m.basis!==undefined){
    const sub=document.getElementById('mkFutSub');
    sub.textContent=(sub.textContent?sub.textContent+' · ':'')+'베이시스 '+(m.basis>0?'+':'')+m.basis.toFixed(2);
  }
}
// 미국장 — 이름 먼저, 값 나중 (PO 2026-09-24 "나스닥을 먼저 놓고")
function renderUS(us){
  const el=document.getElementById('usRow');
  if(!el) return;
  if(!us||!us.length){ el.textContent=''; return; }
  el.innerHTML='미국장 &nbsp;'+us.map(u=>{
    const c=u.rate>0?'up':u.rate<0?'dn':'';
    return '<b>'+u.name+'</b> <span class="'+c+'">'+(u.rate>0?'▲':u.rate<0?'▼':'')+Math.abs(u.rate).toFixed(2)+'%</span>';
  }).join(' · ');
}
// 밤사이 변화 상황 — 보여만 준다. 이것으로 후보를 거르지 않는다
function ovnCell(o){
  if(!o) return '<span class="ovn flat">—</span>';
  const c=o.rate>0.3?'up':o.rate<-0.3?'dn':'flat';
  let t='<span class="'+c+'">'+(o.rate>0?'+':'')+o.rate.toFixed(1)+'%</span>';
  if(o.volume>0){
    const man=o.volume>=10000?(o.volume/10000).toFixed(1)+'만':o.volume.toLocaleString();
    t+=' <span class="'+(o.volume>=50000?'vol':'flat')+'">'+man+'</span>';
  }
  return '<span class="ovn" title="장전 '+(o.from||'')+'~'+(o.to||'')+' · '+(o.bars||0)+'봉">'+t+'</span>';
}
// ③ 타입별 — 시간만. 내역은 ② 에 다 있다 (PO 2026-09-24)
function renderTypes(c){
  const b=document.getElementById('tyBody'), w=document.getElementById('tyWin');
  if(!c||!c.rows){ return; }
  const T=c.types||{}, buckets={A:[],B:[],C:[],D:[]};
  for(const r of c.rows){
    for(const k of ['A','B','C','D']){
      const t=(r.types||{})[k];
      if(t&&t.ok) buckets[k].push({name:r.name, at:(r.at||c.at||''), j3:r.j3});
    }
  }
  const tot=['A','B','C','D'].reduce((a,k)=>a+buckets[k].length,0);
  w.textContent=tot?tot+'건 떴습니다':'아직 없음';
  let h='<div class="tyg">';
  for(const k of ['A','B','C','D']){
    const L=buckets[k];
    h+='<div class="tyc"><h4>'+k+' <span class="n">('+L.length+')</span></h4>';
    h+=L.length? L.map(x=>{
        let j='';
        if(x.j3!==null&&x.j3!==undefined){
          const c=x.j3>=0.6?'hi':x.j3<=0.35?'lo':'mid';
          j=' <span class="jev '+c+'" title="J3 파이널 필터 — 규칙이 낸 이 시점을 그날 그림도 받쳐 주는가">J '+Number(x.j3).toFixed(2)+'</span>';
        }
        return '<div>'+x.name+(x.at?' <span class="n">'+x.at+'</span>':'')+j+'</div>';
      }).join('')
              : '<div class="none">—</div>';
    h+='</div>';
  }
  b.innerHTML=h+'</div>';
}

// J — Jev 판단. 뜨고 안 뜨고가 아니라 확률이므로 숫자로 보인다.
// 지금은 기록만 한다 — 이것으로 주문을 막거나 띄우지 않는다 (검증 0건).
function jevCell(v){
  if(v===null||v===undefined) return '<span class="jev none">—</span>';
  const c = v>=0.6?'hi' : v<=0.35?'lo' : 'mid';
  return '<span class="jev '+c+'">'+Number(v).toFixed(2)+'</span>';
}

// J1 — 오늘 매매할 만한 날인가. ① 시장 칸 아래 한 줄 (PO 2026-09-24)
function renderJ1(j){
  const el=document.getElementById('mkJ1');
  if(!el) return;
  if(!j||j.trade_today===null||j.trade_today===undefined){ el.innerHTML=''; return; }
  const p=Number(j.trade_today), c=p>=0.6?'hi':p<=0.35?'lo':'mid';
  const MOOD=['매우 나쁨','나쁨','보통','좋음','매우 좋음'];
  let mood='';
  if(j.mood!==null&&j.mood!==undefined){
    const i=Math.round(Number(j.mood));
    mood=' · 분위기 '+(MOOD[Math.max(0,Math.min(4,i))]||'')+' ('+Number(j.mood).toFixed(2)+')';
  }
  el.innerHTML='<b>J1</b> 오늘 매매할 만한가 <span class="jev '+c+'">'+p.toFixed(2)+'</span>'+mood
             +' <span class="jev-note">기록만 합니다</span>';
}
// J2 — Jev 가 매긴 순위. 규칙 순위(표의 줄 차례)와 다르면 그 자리가 값지다
function j2Cell(rank, score){
  if(!rank) return '<span class="jev none">—</span>';
  const t=(score===null||score===undefined)?'':' title="Jev 기대값 '+Number(score).toFixed(2)+'"';
  return '<span class="j2"'+t+'>'+rank+'위</span>';
}

// 콘솔(iframe) 안에서는 윗줄 메뉴를 감춘다 — 폰에는 콘솔 버튼 두 개만 있어야 한다.
// PC 브라우저로 5050 을 직접 열 때는 그대로 보인다. (PO 2026-09-24)
(function(){
  var embed = false;
  try { embed = (new URLSearchParams(location.search).get('embed') === '1') || (window.self !== window.top); }
  catch(e){ embed = true; }   // 교차출처라 window.top 을 못 보면 iframe 안이다
  if (embed) {
    var tb = document.getElementById('topbar');
    if (tb) tb.style.display = 'none';
    document.documentElement.classList.add('embed');
  }
})();
// 설명서 — 콘솔 버튼과 같은 문서를 연다 (PO 2026-09-24 "설명서를 탭에 연결")
function openGuide(){ window.open('/guide', '_blank'); }
// ④ 290종목 3분봉 현황 — 점수도 신호도 내지 않는다. 있는 그대로 보여주고 쌓는다.
//    (후보 고르기는 일봉이, 타이밍은 A·B·C·D 가 한다)
function renderUniverse(u){
  const hdr=document.getElementById('uniCount'), meta=document.getElementById('uniMeta'),
        body=document.getElementById('uniBody');
  if(!hdr||!body) return;
  if(!u||!u.rows||!u.rows.length){
    hdr.textContent = (u&&u.running) ? '첫 바퀴를 도는 중입니다' : '아직 한 바퀴도 안 돌았습니다';
    if(meta) meta.textContent='';
    return;
  }
  hdr.textContent = u.rows.length+'종목';
  const src=u.source||{};
  meta.textContent = (u.at?u.at+' · ':'')+(u.took?u.took+'초 · ':'')
    +'네이버 '+(src.naver||0)+' · KIS '+(src.kis||0)
    +((src.fail)? ' · 못 받음 '+src.fail : '')
    +((u.saved)? ' · 쌓은 봉 '+Number(u.saved).toLocaleString() : '');
  let h='<table><tr><th>종목</th><th>현재가</th><th>당일</th><th>전일대비</th>'
       +'<th>거래량비</th><th>봉</th></tr>';
  for(const r of u.rows){
    const dc=r.day_rate>0?'up':(r.day_rate<0?'dn':'');
    const rc=r.rate>0?'up':(r.rate<0?'dn':'');
    const vc=r.vol_ratio>=2?'hot':'';
    h+='<tr><td><b>'+r.name+'</b> <span class="uni-src">'+r.code+'</span></td>'
      +'<td>'+Number(r.price).toLocaleString()+'</td>'
      +'<td class="'+dc+'">'+(r.day_rate>0?'+':'')+r.day_rate.toFixed(2)+'%</td>'
      +'<td class="'+rc+'">'+(r.rate>0?'+':'')+r.rate.toFixed(2)+'%</td>'
      +'<td class="'+vc+'">'+r.vol_ratio.toFixed(2)+'</td>'
      +'<td class="uni-src">'+r.bars+'</td></tr>';
  }
  body.innerHTML=h+'</table>';
}
function renderCombined(c){
  let w=document.getElementById('cmbWin'), b=document.getElementById('cmbBody');
  if(!c||!c.rows){ return; }
  renderTypes(c);
  w.textContent = c.preview
    ? (c.date||'')+' 기준 · 다음 거래일 예고 (아직 장이 서지 않았습니다)'
    : (c.date||'')+' '+(c.at||'')+' · 타이밍 창 '+(c.window||'')+(c.in_window?' (감시 중)':' (창 밖)');
  if(!c.rows.length){ b.innerHTML='<div class="empty">오늘 후보 없음 — 봇은 쉼</div>'; return; }
  let T=c.types||{};
  let h='<table><tr><th>종목</th><th>유형</th><th>점수</th><th>현재가</th><th>밤사이</th><th>1단계</th>';
  for(const k of ['A','B','C','D']) h+='<th title="'+(T[k]||'')+'">'+k+'</th>';
  h+='<th title="Jev 가 매긴 순위 (J2). 기록만 합니다 — 주문을 막거나 띄우지 않습니다">J 순위</th>';
  h+='<th>상태</th></tr>';
  for(const r of c.rows){
    let famCls=r.family==='추세형'?'trend':(r.direction==='PUT'?'put':'call');
    let s1=r.stage1? (r.stage1.ok?'<span class="s1ok">통과</span>':'<span class="s1no">'+(r.stage1.why||'')+'</span>') : '<span class="s1no">-</span>';
    let ty='';
    for(const k of ['A','B','C','D']){ let t=(r.types||{})[k]; let cls=t? (t.ok?'on':'no'):''; let tip=t? Object.entries(t.info||{}).map(e=>e[0]+'='+e[1]).join(' ') : '';
      ty+='<td><span class="ty '+cls+'" title="'+tip.replace(/"/g,'')+'">'+k+'</span></td>'; }
    ty+='<td>'+j2Cell(r.j2_rank, r.j2_score)+'</td>';
    let stMap={'대기':'대기','requested':'승인 요청','entered':'진입','declined':'거절/무응답','no_timing':'창 종료·포기','chase':'추격 금지','price_cap':'가격 상한','risk':'한도 도달','margin':'증거금 부족','held':'보유 중'};
    let st=r.status||'대기';
    h+='<tr><td><b>'+r.name+'</b> <span style="color:#484f58">'+r.code+'</span></td><td><span class="fam '+famCls+'">'+(r.family||'')+' '+r.direction+'</span></td><td>'+r.score+'</td><td>'+(r.price?Number(r.price).toLocaleString():'-')+'</td><td>'+ovnCell(r.overnight)+'</td><td>'+s1+'</td>'+ty+'<td class="st '+st+'">'+(stMap[st]||st)+'</td></tr>';
  }
  h+='</table>';
  b.innerHTML=h;
}
function renderPositions(positions, dailyPnl){
  let bar=document.getElementById('posBar');
  if(!positions||!positions.length){
    bar.className='pos-bar empty-pos';
    bar.innerHTML='포지션 없음';
    return;
  }
  bar.className='pos-bar';
  let pnlCls=dailyPnl>=0?'pos-pnl-p':'pos-pnl-n';
  let pnlStr=(dailyPnl>=0?'+':'')+dailyPnl.toLocaleString()+'원';
  let html='<span style="color:#8b949e">보유('+positions.length+')</span> ';
  html+=positions.map(p=>{
    let cls=p.side==='CALL'?'pos-call':'pos-put';
    let dc=p.side==='CALL'?'call':'put';
    return '<span class="pos-item '+cls+'"><span class="'+dc+'">'+p.side+'</span> '+p.name+'</span>';
  }).join('');
  html+=' <span style="color:#555">|</span> 일손익 <span class="'+pnlCls+'">'+pnlStr+'</span>';
  bar.innerHTML=html;
}

function poll(){
  fetch('/api/status').then(r=>r.json()).then(d=>{
    let lb=document.getElementById('logBox');
    let logs=d.logs||[];
    lb.textContent=logs.length?logs[logs.length-1]:'';
    renderPositions(d.positions||[], d.daily_pnl||0);
    if(d.universe) renderUniverse(d.universe);
    if(d.market) renderMarket(d.market);
    if(d.us) renderUS(d.us);
    if(d.combined) { renderCombined(d.combined); renderJ1(d.combined.j1); }
    if(d.futures) renderKospi(d.futures);
    if(!d.running&&d.finished_at){
      scanning=false;
      // 폴링 유지(clearInterval 제거) — trader.py가 백그라운드로 트리거하는 스캔 결과를
      // 화면이 계속 반영하도록. 멈추면 첫 완료 스냅샷에서 화면이 굳어 '내역 안 보임' 버그.
      document.getElementById('btnScan').disabled=false;
      document.getElementById('sBadge').className='badge badge-done';
      document.getElementById('sBadge').textContent='완료';
      if(d.futures) renderKospi(d.futures);
    }
  });
}

function renderKospi(f){
  _lastFutures = f;
  let bar=document.getElementById('kospiBar');
  if(!bar) return;   // 2026-09-24 에 뺀 자리
  let csc=f.call_score>=60?'s-call-high':(f.call_score>=45?'s-call-mid':'s-low');
  let psc=f.put_score>=60?'s-put-high':(f.put_score>=45?'s-put-mid':'s-low');
  let ts=f.last_ts?(' <span style="color:#f85149;font-size:10px">'+f.last_ts+'</span>'):'';
  bar.className='kospi-bar';
  // 가격은 topbar(K200선물)에서만 표시 — 여기서는 CALL/PUT 신호 점수만
  bar.innerHTML='<span style="color:#d29922;font-weight:800;font-size:12px">'+(f.name||'KOSPI200')+'</span>'
    +'<span style="color:#666;font-size:10px;margin-left:4px">('+f.bars+'봉'+ts+')</span>'
    +'<span style="color:#e6edf3;font-size:13px;font-weight:800;margin-left:10px">CALL <span class="'+csc+'">'+f.call_score+'</span>점(대'+f.call_boss+'/6 쫄'+f.call_soldier+'/2)'
    +' &nbsp; PUT <span class="'+psc+'">'+f.put_score+'</span>점(대'+f.put_boss+'/6 쫄'+f.put_soldier+'/2)</span>';
}

// ── KOSPI200 30틱 차트 ──
let _k200AudioCtx = null;

function _k200Audio() {
  if (!_k200AudioCtx) {
    try { _k200AudioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch(e) {}
  }
  return _k200AudioCtx;
}

function k200Alarm(sig) {
  const ctx = _k200Audio();
  if (!ctx) return;
  const freqs = sig === 'UP' ? [600, 900, 1200] : [1200, 900, 600];
  const t = ctx.currentTime;
  freqs.forEach((f, i) => {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type = 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0.28, t + i*0.16);
    g.gain.exponentialRampToValueAtTime(0.001, t + i*0.16 + 0.18);
    o.start(t + i*0.16); o.stop(t + i*0.16 + 0.22);
  });
}

function k200Render(d) {
  const svg = document.getElementById('k200Svg');
  if (!svg) return;
  const W = svg.getBoundingClientRect().width || svg.parentElement.clientWidth || 600;
  const H = 130;
  const bars = d.bars || [], maArr = d.ma || [];
  const N = bars.length;
  if (!N) {
    svg.innerHTML = '<text x="50%" y="68" text-anchor="middle" fill="#555" font-size="11" font-family="Malgun Gothic,sans-serif">30틱 봉 누적 중... (봉 1개 = 30틱)</text>';
    return;
  }
  const PAD_L=42, PAD_R=8, PAD_T=8, PAD_B=14;
  const cW=W-PAD_L-PAD_R, cH=H-PAD_T-PAD_B;
  const slotW=cW/N, bW=Math.max(1, Math.floor(slotW*0.72));
  let lo=Infinity, hi=-Infinity;
  bars.forEach(b=>{lo=Math.min(lo,b.l);hi=Math.max(hi,b.h);});
  maArr.forEach(v=>{if(v!=null){lo=Math.min(lo,v);hi=Math.max(hi,v);}});
  if(d.bar){lo=Math.min(lo,d.bar.l);hi=Math.max(hi,d.bar.h);}
  if(d.price){lo=Math.min(lo,d.price);hi=Math.max(hi,d.price);}
  const buf=(hi-lo||0.5)*0.06; lo-=buf; hi+=buf;
  const rng=hi-lo||0.5;
  const py=v=>PAD_T+(hi-v)/rng*cH;
  const bx=i=>PAD_L+(i+0.5)*slotW-bW/2;
  let h='';
  // grid
  [0.25,0.5,0.75].forEach(pct=>{
    const gp=lo+rng*pct, gy=py(gp).toFixed(1);
    h+=`<line x1="${PAD_L}" y1="${gy}" x2="${(W-PAD_R).toFixed(1)}" y2="${gy}" stroke="#1e2430" stroke-width="1"/>`;
    h+=`<text x="${(PAD_L-2).toFixed(1)}" y="${(parseFloat(gy)+3).toFixed(1)}" text-anchor="end" fill="#3a3f4a" font-size="8" font-family="Consolas,monospace">${gp.toFixed(2)}</text>`;
  });
  // bars
  bars.forEach((b,i)=>{
    const x=bx(i).toFixed(1), midX=(bx(i)+bW/2).toFixed(1);
    const isUp=b.c>=b.o, col=isUp?'#f85149':'#4fc3f7';
    const t=Math.min(py(b.o),py(b.c)).toFixed(1), bh=Math.max(1,Math.abs(py(b.o)-py(b.c))).toFixed(1);
    h+=`<line x1="${midX}" y1="${py(b.h).toFixed(1)}" x2="${midX}" y2="${py(b.l).toFixed(1)}" stroke="${col}" stroke-width="1"/>`;
    h+=`<rect x="${x}" y="${t}" width="${bW}" height="${bh}" fill="${col}" opacity="0.9"/>`;
  });
  // current bar (dashed)
  if(d.bar){
    const b=d.bar, x=bx(N).toFixed(1), midX=(bx(N)+bW/2).toFixed(1);
    if(parseFloat(x)<W-PAD_R){
      const isUp=b.c>=b.o, col=isUp?'#f85149':'#4fc3f7';
      const t=Math.min(py(b.o),py(b.c)).toFixed(1), bh=Math.max(1,Math.abs(py(b.o)-py(b.c))).toFixed(1);
      h+=`<line x1="${midX}" y1="${py(b.h).toFixed(1)}" x2="${midX}" y2="${py(b.l).toFixed(1)}" stroke="${col}" stroke-width="1" stroke-dasharray="2,1"/>`;
      h+=`<rect x="${x}" y="${t}" width="${bW}" height="${bh}" fill="${col}" opacity="0.35"/>`;
    }
  }
  // 20MA line
  let pathD='', prevNull=true;
  maArr.forEach((v,i)=>{
    if(v==null){prevNull=true;return;}
    const px2=(bx(i)+bW/2).toFixed(1), py2=py(v).toFixed(1);
    pathD+=prevNull?`M${px2},${py2}`:`L${px2},${py2}`;
    prevNull=false;
  });
  if(pathD) h+=`<path d="${pathD}" fill="none" stroke="#d29922" stroke-width="1.5" stroke-linejoin="round"/>`;
  // current price line
  if(d.price){
    const cpY=py(d.price).toFixed(1);
    h+=`<line x1="${PAD_L}" y1="${cpY}" x2="${(W-PAD_R).toFixed(1)}" y2="${cpY}" stroke="#555" stroke-width="0.5" stroke-dasharray="3,3"/>`;
  }
  svg.innerHTML=h;
}

// 단일 가격 소스 — k200Poll이 업데이트, renderKospi도 이 값 사용
let _gK200Price = 0, _gK200Rate = 0;
let _lastFutures = null;  // 마지막 스캔 futures 데이터 캐시

function k200Poll() {
  fetch('/api/k200_ticks').then(r=>r.json()).then(d=>{
    const sigEl=document.getElementById('k200Sig');
    const tsEl=document.getElementById('k200Ts');
    // ── topbar 실시간 K200 (가격 표시 유일한 곳) ──
    if(d.price){
      const rt=d.rate||0;
      const col=rt>=0?'#f85149':'#4fc3f7';
      _gK200Price = d.price;
      _gK200Rate = rt;
      if(_lastFutures) renderKospi(_lastFutures);
      // topbar — 유일한 K200선물 가격 표시 위치
    }
    if(d.signal==='UP'){
      sigEl.textContent='▲ 골든크로스';
      sigEl.style.background='#0d2818'; sigEl.style.color='#3fb950';
      if(d.signal_ts) tsEl.textContent=d.signal_ts;
    } else if(d.signal==='DOWN'){
      sigEl.textContent='▼ 데드크로스';
      sigEl.style.background='#2d1014'; sigEl.style.color='#f85149';
      if(d.signal_ts) tsEl.textContent=d.signal_ts;
    } else {
      sigEl.textContent=''; sigEl.style.background='transparent';
      if(d.ts) tsEl.textContent=d.ts;
    }
    if(d.alert && d.signal) k200Alarm(d.signal);
    k200Render(d);
  }).catch(()=>{});
}

// AudioContext 초기화 (브라우저 정책: 사용자 클릭 후)
document.addEventListener('click', ()=>_k200Audio(), {once:true});
setInterval(k200Poll, 2000);
k200Poll();
</script>
</body>
</html>"""


SYSTEM_HTML = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trader Bot - 시스템 현황</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0d1117;color:#c9d1d9;font-family:'Malgun Gothic','Segoe UI',sans-serif;padding:20px}
a{color:#58a6ff;text-decoration:none}
a:hover{text-decoration:underline}
.nav{display:flex;gap:16px;margin-bottom:20px;padding-bottom:12px;border-bottom:1px solid #30363d}
.nav a{padding:6px 14px;border-radius:6px;font-size:13px;font-weight:600}
.nav a.active{background:#21262d;color:#58a6ff}
h1{font-size:20px;color:#58a6ff;margin-bottom:20px}
h2{font-size:15px;color:#d29922;margin:24px 0 12px;padding-bottom:6px;border-bottom:1px solid #30363d}
.arch{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:20px;font-family:'Consolas','Courier New',monospace;font-size:13px;line-height:1.8;white-space:pre;overflow-x:auto;color:#333;margin-bottom:16px}
.arch .hi{color:#58a6ff;font-weight:700}
.arch .ok{color:#3fb950}
.arch .warn{color:#d29922}
table{width:100%;border-collapse:collapse;margin-bottom:16px}
th{background:#161b22;color:#333;font-size:11px;text-transform:uppercase;padding:8px 12px;text-align:left;border-bottom:2px solid #30363d}
td{padding:8px 12px;border-bottom:1px solid #21262d;font-size:13px}
.tag{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.tag-ok{background:#0f5323;color:#3fb950}
.tag-warn{background:#3d2e00;color:#d29922}
.tag-off{background:#21262d;color:#484f58}
.tag-dev{background:#1a1040;color:#bc8cff}
.status-row{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px}
.scard{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:14px 18px;min-width:180px;flex:1}
.scard .label{font-size:11px;color:#333;margin-bottom:4px}
.scard .val{font-size:16px;font-weight:700}
.scard .val.green{color:#3fb950}
.scard .val.yellow{color:#d29922}
.scard .val.gray{color:#484f58}
</style>
</head>
<body>
<div class="nav">
  <a href="/system" class="active">시스템 현황</a>
  <a href="/">스캐너</a>
</div>

<h1>Trader Bot 시스템 현황</h1>

<div class="status-row" id="statusCards">
  <div class="scard"><div class="label">KIS API</div><div class="val" id="kisStatus">확인중...</div></div>
  <div class="scard"><div class="label">스캐너 웹</div><div class="val green">가동중</div></div>
  <div class="scard"><div class="label">트레이더</div><div class="val green">매매 자동화 봇</div></div>
</div>

<h2>아키텍처</h2>
<div class="arch"><span class="hi">[trader.py]</span> 매매 자동화 봇
    |-- 시장 레짐 필터 (급등장 CALL 억제)
    |-- 진입 직전 신호 재검증 + 거래 전 텔레그램 승인
    v
<span class="hi">[scanner_web.py]</span> localhost:5050
    |-- scanner_262_52.py (262개 종목 스캔)
    |-- 1단계 네이버 1분봉 -> 2단계 KIS OHLCV
    v
<span class="hi">[분석/주문]</span>
    |-- kis.py (KIS REST API)
    |-- analysis.py (6대장2졸병 IndicatorEngine)
    |-- vault_writer.py (Obsidian vault 기록)
    |-- knowledge/ (전략/관심종목/규칙/휴장일)</div>

<h2>파일 구성</h2>
<table>
<tr><th>파일</th><th>역할</th><th>상태</th></tr>
<tr><td>trader.py</td><td>매매 자동화 봇 (스캔/주문/승인)</td><td><span class="tag tag-ok">가동중</span></td></tr>
<tr><td>scanner_web.py</td><td>스캐너 웹뷰어 (이 페이지)</td><td><span class="tag tag-ok">가동중</span></td></tr>
<tr><td>scanner_262_52.py</td><td>262개 종목 6대장2졸병 2단계 스캐너</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>kis.py</td><td>KIS REST API (시세/주문/잔고)</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>analysis.py</td><td>6대장2졸병 지표 엔진 (IndicatorEngine)</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>vault_writer.py</td><td>Obsidian vault 신호/결과 기록</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>knowledge.py</td><td>로컬 지식 파일 CRUD</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>config.py</td><td>설정 (KIS/Sentry/레짐 필터)</td><td><span class="tag tag-ok">완료</span></td></tr>
</table>

<h2>5대장2졸병 신호 체계</h2>
<table>
<tr><th>구분</th><th>지표</th><th>CALL 조건</th><th>PUT 조건</th><th>배점</th></tr>
<tr><td rowspan="5">5대장</td><td>소나 크로스</td><td>K &gt; D, K &lt; 0 (골든)</td><td>K &lt; D, K &gt; 0 (데드)</td><td>10점</td></tr>
<tr><td>DI</td><td>DI- &lt; 42</td><td>DI+ &lt; 38</td><td>10점</td></tr>
<tr><td>ADX</td><td>ADX &lt; 40</td><td>ADX &lt; 45</td><td>10점</td></tr>
<tr><td>RSI</td><td>RSI &gt; 22</td><td>RSI &lt; 72</td><td>10점</td></tr>
<tr><td>스토캐스틱 K</td><td>K &gt; 5</td><td>K &lt; 90</td><td>10점</td></tr>
<tr><td rowspan="2">2졸병</td><td>볼륨/Williams</td><td>Vol &gt;= 0.3x / %R &gt; -90</td><td>MACD Hist &lt; 0.5</td><td>5점</td></tr>
<tr><td>Williams/%R / MACD</td><td>Williams %R &gt; -90</td><td>MACD Hist &lt; 2.0</td><td>5점</td></tr>
<tr><td colspan="4" style="text-align:right;font-weight:700">최대</td><td><strong>60점</strong></td></tr>
</table>

<h2>스캐너 동작 흐름</h2>
<div class="arch">1단계 <span class="hi">[네이버 1분봉]</span> 262개 종목 빠른 필터
  - Close + Volume만 (O=H=L=C 근사)
  - CALL/PUT 양방향 체크
  - 30점 이상 통과 -> 2단계로
  - 소요: ~4분

2단계 <span class="hi">[KIS 1분봉 OHLCV]</span> 통과 종목 정밀 분석
  - 정확한 Open/High/Low/Close/Volume
  - validate_signal() 승률 50%+ 검증
  - 최종 신호 종목 표시
  - 소요: 종목당 ~5초

점수 색상:
  30점 = <span style="color:#333">회색</span>
  CALL 45점 = <span style="color:#f0883e">주황</span>  /  PUT 45점 = <span style="color:#bc8cff">보라</span>
  CALL 60점 = <span style="color:#ff4444">빨강</span>  /  PUT 60점 = <span style="color:#58a6ff">파랑</span></div>

<h2>외부 연결</h2>
<table>
<tr><th>서비스</th><th>URL</th><th>용도</th></tr>
<tr><td>KIS API</td><td>openapi.koreainvestment.com:9443</td><td>시세/주문/잔고</td></tr>
<tr><td>스캐너 웹</td><td><a href="http://localhost:5050">localhost:5050</a></td><td>262개 종목 스캔 결과</td></tr>
</table>

<script>
// KIS는 토큰 필요해서 간접 확인
document.getElementById('kisStatus').textContent='설정됨';
document.getElementById('kisStatus').className='val green';
</script>
</body>
</html>"""


@app.route('/')
def index():
    from flask import make_response
    resp = make_response(render_template_string(HTML))
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    return resp


@app.route('/system')
def system_page():
    return render_template_string(SYSTEM_HTML)





TRADING_HTML = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>매매 자동화 봇</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0d1117;color:#c9d1d9;font-family:'Segoe UI',sans-serif;font-size:13px}
.nav{display:flex;gap:16px;padding:8px 20px;background:#161b22;border-bottom:1px solid #30363d}
.nav a{padding:4px 12px;border-radius:6px;font-size:13px;font-weight:600;color:#333;text-decoration:none}
.nav a.active{background:#21262d;color:#58a6ff}
.header{padding:16px 20px;border-bottom:1px solid #21262d;display:flex;align-items:center;gap:16px}
.header h1{font-size:18px;color:#f0f6fc}
.container{display:flex;height:calc(100vh - 100px)}
.sidebar{width:280px;padding:16px;border-right:1px solid #21262d;overflow-y:auto}
.main{flex:1;padding:16px;overflow-y:auto}
.section{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:16px;margin-bottom:16px}
.section h3{color:#58a6ff;margin-bottom:12px;font-size:14px}
.param{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #21262d}
.param .label{color:#333;font-size:12px}
.param .value{color:#f0f6fc;font-weight:600}
.status-badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.status-ready{background:#1a3a1a;color:#3fb950}
.status-off{background:#3a1a1a;color:#f85149}
.btn{padding:8px 16px;border-radius:6px;border:none;font-size:13px;font-weight:600;cursor:pointer;width:100%;margin-top:8px}
.btn-start{background:#238636;color:#fff}
.btn-start:hover{background:#2ea043}
.btn-stop{background:#da3633;color:#fff}
.btn-stop:hover{background:#f85149}
.positions{display:grid;gap:12px}
.pos-card{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:12px}
.pos-card .name{font-size:14px;font-weight:600;color:#f0f6fc}
.pos-card .dir-call{color:#ff4444}.pos-card .dir-put{color:#58a6ff}
.pos-card .pnl-pos{color:#3fb950}.pos-card .pnl-neg{color:#f85149}
.log-area{background:#0d1117;border:1px solid #30363d;border-radius:6px;padding:8px;max-height:300px;overflow-y:auto;font-family:monospace;font-size:11px;line-height:1.6}
.log-entry{padding:2px 4px}
.stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.stat-box{background:#0d1117;border:1px solid #30363d;border-radius:6px;padding:12px;text-align:center}
.stat-box .val{font-size:20px;font-weight:700;color:#f0f6fc}
.stat-box .lbl{font-size:11px;color:#333;margin-top:4px}
</style>
</head>
<body>
<div class="nav">
  <a href="/">스캐너</a>
  <a href="/trading" class="active">매매 자동화 봇</a>
  <a href="/system">시스템 현황</a>
</div>
<div class="header">
  <h1>매매 자동화 봇</h1>
  <span class="status-badge status-ready" id="statusBadge">대기중</span>
</div>
<div class="container">
  <div class="sidebar">
    <div class="section">
      <h3>매매 규칙</h3>
      <div class="param"><span class="label">종목당 투자금</span><span class="value">300만원</span></div>
      <div class="param"><span class="label">최대 종목수</span><span class="value">3종목</span></div>
      <div class="param"><span class="label">손절</span><span class="value">-3% 또는 -10만원</span></div>
      <div class="param"><span class="label">트레일링 활성화</span><span class="value">+3%</span></div>
      <div class="param"><span class="label">3~10% 구간</span><span class="value">50% 되돌림 익절</span></div>
      <div class="param"><span class="label">10%+ 구간</span><span class="value">30% 되돌림 익절</span></div>
    </div>
    <div class="section">
      <h3>진입 조건 (CALL)</h3>
      <div class="param"><span class="label">RSI</span><span class="value">&lt; 30</span></div>
      <div class="param"><span class="label">Bollinger %B</span><span class="value">&lt; 20</span></div>
      <div class="param"><span class="label">CCI</span><span class="value">&lt; -100</span></div>
      <div class="param"><span class="label">Williams %R</span><span class="value">&lt; -80</span></div>
      <div class="param"><span class="label">AROON Down</span><span class="value">&gt; 80</span></div>
    </div>
    <div class="section">
      <h3>진입 조건 (PUT)</h3>
      <div class="param"><span class="label">RSI</span><span class="value">&gt; 80</span></div>
      <div class="param"><span class="label">CCI</span><span class="value">&gt; 150</span></div>
      <div class="param"><span class="label">Bollinger %B</span><span class="value">&gt; 80</span></div>
      <div class="param"><span class="label">연속상승</span><span class="value">&gt;= 3봉</span></div>
      <div class="param"><span class="label">UO</span><span class="value">&gt; 70</span></div>
    </div>
    <button class="btn btn-start" id="btnStart" onclick="startTrading()">매매 시작</button>
    <button class="btn btn-stop" id="btnStop" onclick="stopTrading()" style="display:none">매매 중지</button>
  </div>
  <div class="main">
    <div class="section">
      <h3>오늘 실적</h3>
      <div class="stats-grid">
        <div class="stat-box"><div class="val" id="totalTrades">0</div><div class="lbl">총 매매</div></div>
        <div class="stat-box"><div class="val" id="winRate">-</div><div class="lbl">승률</div></div>
        <div class="stat-box"><div class="val" id="totalPnl">0원</div><div class="lbl">총 손익</div></div>
      </div>
    </div>
    <div class="section">
      <h3>보유 포지션</h3>
      <div class="positions" id="positions">
        <div style="color:#333;text-align:center;padding:20px">포지션 없음</div>
      </div>
    </div>
    <div class="section">
      <h3>매매 로그</h3>
      <div class="log-area" id="tradeLog">
        <div class="log-entry" style="color:#333">매매를 시작하면 로그가 표시됩니다.</div>
      </div>
    </div>
  </div>
</div>
<script>
let pollT=null;

function startTrading(){
  fetch('/api/trading/start',{method:'POST'}).then(r=>r.json()).then(d=>{
    if(d.error){alert(d.error);return;}
    document.getElementById('btnStart').style.display='none';
    document.getElementById('btnStop').style.display='block';
    document.getElementById('statusBadge').textContent='실행중';
    document.getElementById('statusBadge').className='status-badge status-ready';
    startPoll();
  });
}

function stopTrading(){
  fetch('/api/trading/stop',{method:'POST'}).then(()=>{
    document.getElementById('btnStart').style.display='block';
    document.getElementById('btnStop').style.display='none';
    document.getElementById('statusBadge').textContent='대기중';
    document.getElementById('statusBadge').className='status-badge status-off';
  });
}

function startPoll(){
  if(pollT) clearInterval(pollT);
  pollT=setInterval(fetchStatus,2000);
}

function fetchStatus(){
  fetch('/api/trading/status').then(r=>r.json()).then(d=>{
    // 상태 배지
    if(!d.running){
      document.getElementById('btnStart').style.display='block';
      document.getElementById('btnStop').style.display='none';
      document.getElementById('statusBadge').textContent='대기중';
      document.getElementById('statusBadge').className='status-badge status-off';
    }
    // 통계
    document.getElementById('totalTrades').textContent=d.daily_trades||0;
    let pnl=d.daily_pnl||0;
    document.getElementById('totalPnl').textContent=(pnl>=0?'+':'')+pnl.toLocaleString()+'원';
    document.getElementById('totalPnl').style.color=pnl>=0?'#3fb950':'#f85149';
    // 포지션
    let pDiv=document.getElementById('positions');
    if(d.positions&&d.positions.length){
      pDiv.innerHTML=d.positions.map(p=>{
        let dc=p.side==='CALL'?'dir-call':'dir-put';
        let pc=p.pnl>=0?'pnl-pos':'pnl-neg';
        let kindStr=p.kind?(' ['+p.kind+']'):'';
        return '<div class="pos-card"><div class="name">'+p.name+kindStr+' <span class="'+dc+'">'+p.side+'</span></div>'+
          '<div style="font-size:12px;color:#8b949e">진입 '+p.entry.toLocaleString()+'원 × '+p.qty+'계약</div>'+
          '<div class="'+pc+'" style="font-size:12px">'+(p.pnl>=0?'+':'')+p.pnl.toFixed(2)+'%</div></div>';
      }).join('');
    } else {
      pDiv.innerHTML='<div style="color:#555;text-align:center;padding:20px">포지션 없음</div>';
    }
    // 로그
    let logDiv=document.getElementById('tradeLog');
    if(d.logs&&d.logs.length){
      logDiv.innerHTML=d.logs.slice().reverse().map(l=>'<div class="log-entry">'+l+'</div>').join('');
    }
  });
}

// 페이지 로드 시 상태 확인
fetchStatus();
startPoll();
</script>
</body>
</html>"""


@app.route('/api/trading/start', methods=['POST'])
def api_trading_start():
    if sentry_state['running']:
        return jsonify({'error': 'already running'}), 409
    sentry_dir = os.path.dirname(os.path.abspath(__file__))
    proc = subprocess.Popen(
        [sys.executable, 'trader.py'],
        cwd=sentry_dir,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=1,
    )
    sentry_state['proc'] = proc
    sentry_state['running'] = True
    sentry_state['logs'] = ['[매매 시작]']
    sentry_state['positions'] = []
    sentry_state['daily_trades'] = 0
    sentry_state['daily_pnl'] = 0.0
    sentry_state['started_at'] = datetime.now().isoformat()
    t = threading.Thread(target=_sentry_reader, args=(proc,), daemon=True)
    t.start()
    return jsonify({'status': 'started'})


@app.route('/api/trading/stop', methods=['POST'])
def api_trading_stop():
    proc = sentry_state.get('proc')
    if proc:
        proc.terminate()
        sentry_state['running'] = False
        sentry_state['proc'] = None
        sentry_state['logs'].append('[매매 중지]')
    return jsonify({'status': 'stopped'})


@app.route('/api/trading/status')
def api_trading_status():
    return jsonify({
        'running': sentry_state['running'],
        'logs': sentry_state['logs'][-50:],
        'positions': sentry_state['positions'],
        'daily_trades': sentry_state['daily_trades'],
        'daily_pnl': sentry_state['daily_pnl'],
        'started_at': sentry_state['started_at'],
    })


@app.route('/trading')
def trading_page():
    return render_template_string(TRADING_HTML)


@app.route('/api/sentry/update', methods=['POST'])
def api_sentry_update():
    """sentry.py에서 상태 푸시"""
    data = request.get_json(silent=True) or {}
    # sentry.py가 독립 실행 중이어도 running=True로 자동 갱신
    sentry_state['running'] = True
    sentry_state['positions'] = data.get('positions', sentry_state['positions'])
    sentry_state['daily_trades'] = data.get('daily_trades', sentry_state['daily_trades'])
    sentry_state['daily_pnl'] = data.get('daily_pnl', sentry_state['daily_pnl'])
    if not sentry_state['started_at']:
        sentry_state['started_at'] = datetime.now().isoformat()
    if data.get('log'):
        ts = datetime.now().strftime('%H:%M:%S')
        sentry_state['logs'].append(f'[{ts}] {data["log"]}')
        sentry_state['logs'] = sentry_state['logs'][-100:]
    if data.get('logs'):
        for msg in data['logs']:
            ts = datetime.now().strftime('%H:%M:%S')
            sentry_state['logs'].append(f'[{ts}] {msg}')
        sentry_state['logs'] = sentry_state['logs'][-100:]
    return jsonify({'ok': True})


SCAN_COOLDOWN_SEC = 30   # 스캔 완료 후 최소 대기 (병렬화로 스캔 ~15s → 단축)
AUTO_RESCAN_SEC  = 45   # 스캔 완료 후 자동 재스캔 대기 (쿨다운 30s 이후)

_rescan_timer = None  # 자동 재스캔 타이머

def _schedule_next_scan():
    """스캔 완료 후 AUTO_RESCAN_SEC 뒤 자동 재스캔 예약"""
    global _rescan_timer
    if _rescan_timer and _rescan_timer.is_alive():
        _rescan_timer.cancel()

    def _do_rescan():
        if not scan_state['running']:
            # 장 시간(평일 08:45~15:45) 체크
            now = datetime.now()
            weekday = now.weekday()  # 0=월 6=일
            if weekday >= 5:  # 주말
                return
            h, m = now.hour, now.minute
            cur = h * 60 + m
            if not (8 * 60 + 45 <= cur <= 15 * 60 + 45):
                return
            print(f'[AutoScan] 자동 재스캔 시작 ({now.strftime("%H:%M:%S")})')
            # api_scan 직접 호출 (Flask context 없이)
            _start_scan_internal()

    _rescan_timer = threading.Timer(AUTO_RESCAN_SEC, _do_rescan)
    _rescan_timer.daemon = True
    _rescan_timer.start()


def _start_scan_internal():
    """api_scan 로직을 Flask context 없이 직접 실행"""
    if scan_state['running']:
        return
    scan_state['running'] = True
    scan_state['stage1'] = []
    scan_state['stage2'] = []
    scan_state['futures'] = None
    scan_state['logs'] = ['스캔 시작 (자동)...']
    scan_state['started_at'] = datetime.now().isoformat()
    scan_state['finished_at'] = None

    def run():
        class LogCapture:
            def __init__(self): self.lines = []
            def write(self, s):
                if s.strip():
                    self.lines.append(s.strip())
                    scan_state['logs'] = self.lines[-40:]
                sys.__stdout__.write(s)
                return len(s)
            def flush(self): pass

        old_stdout = sys.stdout
        sys.stdout = LogCapture()
        def on_stage1(items): scan_state['stage1'] = items
        def on_stage2(items): scan_state['stage2'] = items
        def on_futures(f):    scan_state['futures'] = f
        try:
            result = scan_all(on_stage1=on_stage1, on_stage2=on_stage2, on_futures=on_futures,
                              k200_rate=k200_state.get('rate', 0.0))
            if isinstance(result, dict):
                scan_state['stage1'] = result.get('stage1', [])
                scan_state['stage2'] = result.get('stage2', [])
                scan_state['futures'] = result.get('futures')
        except Exception as e:
            scan_state['logs'].append(f'[ERROR] {str(e)[:100]}')
        finally:
            sys.stdout = old_stdout
            scan_state['running'] = False
            scan_state['finished_at'] = datetime.now().isoformat()
            _schedule_next_scan()

    threading.Thread(target=run, daemon=True).start()

@app.route('/api/universe/now', methods=['POST'])
def api_universe_now():
    """3분 주기를 기다리지 않고 지금 한 바퀴 (PO 2026-09-24)."""
    try:
        import universe_scan
    except Exception as e:
        return jsonify({'ok': False, 'msg': f'290종목 모듈을 못 불렀습니다: {e}'}), 500
    try:
        st = universe_scan.scan_once()
    except Exception as e:
        return jsonify({'ok': False, 'msg': f'한 바퀴를 못 돌았습니다: {e}'}), 500
    src = st.get('source') or {}
    return jsonify({'ok': True, 'msg': f"{len(st['rows'])}종목 · {st['took']}초 · "
                                       f"쌓은 봉 {st['saved']:,} · 못 받음 {src.get('fail', 0)}"})


@app.route('/api/scan', methods=['POST'])
def api_scan():
    if scan_state['running']:
        return jsonify({'error': 'already running'}), 409

    # 쿨다운: 이전 스캔 완료 후 SCAN_COOLDOWN_SEC 이내면 거부
    finished_at = scan_state.get('finished_at')
    if finished_at:
        try:
            elapsed = (datetime.now() - datetime.fromisoformat(finished_at)).total_seconds()
            if elapsed < SCAN_COOLDOWN_SEC:
                return jsonify({'error': 'cooldown', 'wait': int(SCAN_COOLDOWN_SEC - elapsed)}), 429
        except Exception:
            pass

    scan_state['running'] = True
    scan_state['stage1'] = []
    scan_state['stage2'] = []
    scan_state['futures'] = None
    scan_state['logs'] = ['스캔 시작 (최대 15분 소요)...']
    scan_state['started_at'] = datetime.now().isoformat()
    scan_state['finished_at'] = None

    def run():
        class LogCapture:
            def __init__(self):
                self.lines = []
            def write(self, s):
                if s.strip():
                    self.lines.append(s.strip())
                    scan_state['logs'] = self.lines[-40:]
                sys.__stdout__.write(s)
                return len(s)
            def flush(self):
                pass

        old_stdout = sys.stdout
        sys.stdout = LogCapture()
        def on_stage1(items):
            scan_state['stage1'] = items
            s1_pass = len([x for x in items if x.get('passed')])
            scan_state['logs'].append(f'[1단계 완료] {s1_pass}/{len(items)}개 통과 → 2단계 KIS 분석 시작...')

        def on_stage2(items):
            scan_state['stage2'] = items

        def on_futures(f):
            scan_state['futures'] = f

        result = None
        try:
            result = scan_all(on_stage1=on_stage1, on_stage2=on_stage2, on_futures=on_futures,
                              k200_rate=k200_state.get('rate', 0.0))

            if isinstance(result, dict):
                scan_state['stage1'] = result.get('stage1', [])
                scan_state['stage2'] = result.get('stage2', [])
                scan_state['futures'] = result.get('futures')
                s1_cnt = len([x for x in scan_state['stage1'] if x.get('passed')])
                scan_state['logs'].append(f'[완료] 1단계: {s1_cnt}개 통과/{len(scan_state["stage1"])}개 스캔')
                scan_state['logs'].append(f'[완료] 2단계: {len(scan_state["stage2"])}개 신호 확정')
            elif isinstance(result, list):
                scan_state['stage2'] = result
                scan_state['logs'].append(f'[완료] 신호 {len(result)}개')
            else:
                scan_state['logs'].append('[경고] 스캔 결과 형식 오류')
        except Exception as e:
            scan_state['logs'].append(f'[ERROR] {str(e)[:100]}')
        finally:
            sys.stdout = old_stdout
            scan_state['running'] = False
            scan_state['finished_at'] = datetime.now().isoformat()
            # 스캔 완료 후 AUTO_RESCAN_SEC 뒤 자동 재스캔
            _schedule_next_scan()

    t = threading.Thread(target=run, daemon=True)
    t.start()
    return jsonify({'status': 'started'})


def _to_json_safe(obj):
    """numpy bool/int/float → Python 기본 타입 변환 (JSON 직렬화 오류 방지)"""
    import numpy as np
    if isinstance(obj, dict):
        return {k: _to_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_to_json_safe(v) for v in obj]
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    return obj



# ── 설명서 (PO 2026-09-24 "설명서를 탭에 연결") ──
# 콘솔 버튼과 같은 문서를 연다. 이름이 몇 번 바뀌어서 후보를 차례로 찾는다.
GUIDE_NAMES = [
    'docs/주식 매매 자동화 시스템 설명서.html',   # 내 PC (tools/build_docs.py 산출물)
    '주식 매매 자동화 시스템 설명서.html',        # 손님 PC (봇 폴더 맨 위)
    'docs/주식 매매 자동화 시스템.html',
    '주식 매매 자동화 시스템.html',
]


def _guide_path():
    import os as _o
    base = _o.path.dirname(_o.path.abspath(__file__))
    for n in GUIDE_NAMES:
        f = _o.path.join(base, n.replace('/', _o.sep))
        if _o.path.exists(f):
            return f
    return ''


@app.route('/guide')
def guide_page():
    """설명서를 그대로 내보낸다. 없으면 왜 없는지 알려 준다."""
    f = _guide_path()
    if not f:
        return ('<div style="font-family:system-ui;padding:24px;color:#c9d1d9;background:#0d1117;'
                'min-height:100vh"><h2>설명서를 찾지 못했습니다</h2>'
                '<p>봇 폴더에 「주식 매매 자동화 시스템 설명서.html」 이 있어야 합니다.</p>'
                '<p style="color:#8b949e;font-size:13px">직접 만들려면 '
                '<code>python tools/build_docs.py</code></p></div>', 404)
    with open(f, encoding='utf-8') as fh:
        return fh.read()


@app.route('/api/status')
def api_status():
    return jsonify(_to_json_safe({
        'running': scan_state['running'],
        'stage1': scan_state['stage1'],
        'stage2': scan_state['stage2'],
        'futures': scan_state['futures'],
        'logs': scan_state['logs'],
        'started_at': scan_state['started_at'],
        'finished_at': scan_state['finished_at'],
        'stage1_loaded': scan_state.get('stage1_loaded', False),
        'positions': sentry_state['positions'],
        'daily_pnl': sentry_state['daily_pnl'],
        'daily_trades': sentry_state['daily_trades'],
        'strategies': _strategy_list(),
        'kis_configured': _kis_configured(),
        **_status_extra(),
    }))



# ─────────────────────────────────────────────────────────────
#  ① 시장 · 밤사이 변화 상황 (PO 2026-09-24)
#  화면 4층 중 ①②에 쓰는 자료. 전부 이미 있던 통로를 엮은 것이라 새 조회가 거의 없다.
# ─────────────────────────────────────────────────────────────
_us_cache = {'at': 0, 'data': None}
_ovn_cache = {'day': '', 'data': {}}


def _us_market():
    """미국장 — 나스닥·S&P500 전일 대비. 10분 캐시(하루 한 번 바뀌는 값이다)."""
    import time as _t
    if _us_cache['data'] and _t.time() - _us_cache['at'] < 600:
        return _us_cache['data']
    out = []
    try:
        import yfinance as yf
        for tk, nm in (('^IXIC', '나스닥'), ('^GSPC', 'S&P500')):
            try:
                h = yf.Ticker(tk).history(period='5d')
                if len(h) >= 2:
                    c, pv = float(h['Close'].iloc[-1]), float(h['Close'].iloc[-2])
                    out.append({'name': nm, 'close': round(c, 2),
                                'rate': round((c / pv - 1) * 100, 2)})
            except Exception:
                pass
    except ImportError:
        pass
    _us_cache.update(at=_t.time(), data=out)
    return out



def _universe():
    """④ 290종목 3분봉 현황. universe_scan 이 3분마다 채운다 (PO 2026-09-24).

    화면에는 많이 움직인 앞 120개만 보낸다 — 290개를 통째로 실으면 폰에서 무겁다.
    쌓는 것은 290개 전부이고, 그것은 data/bars3m.db 에 들어간다.
    """
    try:
        import universe_scan
        st = universe_scan.state
        return {'running': st['running'], 'at': st['at'], 'took': st['took'],
                'saved': st['saved'], 'source': st['source'], 'rows': st['rows'][:120]}
    except Exception:
        return None


def _status_extra():
    """① 시장 · 미국장 · 후보(+Jev) 를 한 번에 만든다. Jev 는 하루 1회만 부른다."""
    mkt = _index_and_futures()
    us = _us_market()
    c = _combined_live()
    try:
        c = _jev_attach(c, mkt, us)
    except Exception:
        pass
    return {'combined': c, 'market': mkt, 'us': us, 'universe': _universe()}


def _index_and_futures():
    """코스피200 지수(KODEX200 ÷ 100)와 코스피200 선물 근월물(실거래).

    지수는 살 수 없는 눈금이고, 선물은 실제로 거래되는 물건이다 (PO 2026-09-24).
    둘을 나란히 두고 베이시스(선물 - 지수)를 함께 보인다.
    """
    out = {'index': None, 'futures': None, 'basis': None}
    try:
        from scanner_262_52 import get_kospi200_kodex, _get_futures_code
        nm, px, rate, _bars, ts = get_kospi200_kodex()
        if px:
            out['index'] = {'name': '코스피200 지수', 'price': round(px, 2),
                            'rate': round(rate, 2), 'at': ts, 'from': 'KODEX200 ÷ 100'}
        try:
            from kis import get_futures_price
            fc = _get_futures_code()
            f = get_futures_price(fc) or {}
            if f.get('price'):
                out['futures'] = {'name': '코스피200 선물', 'code': fc,
                                  'month': fc[-2:] + '월물' if len(fc) >= 6 else '',
                                  'price': round(float(f['price']), 2),
                                  'change': round(float(f.get('change') or 0), 2),
                                  'volume': int(f.get('volume') or 0)}
                if out['index']:
                    out['basis'] = round(out['futures']['price'] - out['index']['price'], 2)
        except Exception:
            pass
    except Exception:
        pass
    return out


def _overnight(code, prev_close=None):
    """밤사이 변화 상황 — 장전(08:00~09:00) 움직임과 거래량.

    넥스트레이드가 8시부터 거래되므로, 09:00 정규장이 열리기 전에 이미
    '밤사이 무슨 일이 있었나' 를 값으로 알 수 있다 (PO 2026-09-24).
    ※ 보여만 준다. 이것으로 후보를 거르지 않는다 — 검증된 적이 없는 기준이다.
    """
    try:
        from scanner_262_52 import get_minute_bars_union, get_minute_bars_naver, _kst_now
        day8 = _kst_now().strftime('%Y%m%d')
        un = get_minute_bars_union(code) or []
        pre = [b for b in un if b['ts'].startswith(day8) and b['ts'][8:12] < '0900']
        if not pre:
            return None
        if prev_close is None:
            nv = get_minute_bars_naver(code) or []
            prev = [b for b in nv if not b['ts'].startswith(day8)]
            prev_close = prev[-1]['close'] if prev else 0
        if not prev_close:
            return None
        last = pre[-1]['close']
        vol = sum(int(b.get('volume') or 0) for b in pre)
        return {'rate': round((last / prev_close - 1) * 100, 2),
                'price': last, 'volume': vol, 'bars': len(pre),
                'from': pre[0]['ts'][8:12], 'to': pre[-1]['ts'][8:12]}
    except Exception:
        return None




# ── Jev 판단을 화면에 붙인다 (PO 2026-09-24) ──
#   J1 → ① 시장 칸    J2 → ② 후보 랭킹    J3 → ③ 타입별, 신호 시간 옆
#   하루 1회면 되는 것(J1·J2)은 날짜로 캐시한다. 화면은 몇 초마다 부르므로
#   캐시가 없으면 Jev 를 종일 두들기게 된다.
_jev_cache = {'day': '', 'j1': None, 'j2': None, 'j3': {}}


def _jev_day(day):
    if _jev_cache['day'] != day:
        _jev_cache.update(day=day, j1=None, j2=None, j3={})


def _jev_attach(c, mkt, us):
    """후보 표(c)에 J1·J2·J3 를 붙인다. 실패하면 그냥 비워 둔다 — 화면은 그대로 돈다."""
    if not c or not c.get('rows'):
        return c
    try:
        import jev_judge as JJ
    except Exception:
        return c
    day = c.get('date') or ''
    _jev_day(day)
    rows = c['rows']

    # J1 — 오늘 매매할 만한 날인가 (하루 1회)
    if _jev_cache['j1'] is None:
        _jev_cache['j1'] = JJ.j1_market(mkt, us, len(rows)) or {}
    c['j1'] = _jev_cache['j1'] or None

    # J2 — 후보 랭킹 (하루 1회). 너무 많으면 앞쪽만 — Jev 한 번에 40개까지
    if _jev_cache['j2'] is None:
        _jev_cache['j2'] = {x['code']: x for x in (JJ.j2_rank(rows[:40], mkt, us) or [])}
    j2 = _jev_cache['j2'] or {}
    for r in rows:
        x = j2.get(r.get('code'))
        r['j2_rank'] = x.get('rank') if x else None
        r['j2_score'] = x.get('jev') if x else None

    # J3 — 타이밍이 뜬 것만. 종목당 한 번 (뜬 순간의 판단을 남긴다)
    peers = sum(1 for r in rows if r.get('hit'))
    for r in rows:
        if not r.get('hit'):
            continue
        code = r.get('code')
        if code not in _jev_cache['j3']:
            _jev_cache['j3'][code] = JJ.j3_filter(r, r['hit'], mkt, us, peers=peers) or {}
        r['j3'] = (_jev_cache['j3'][code] or {}).get('go')
    return c


def _cand_preview():
    """휴장일·장 전에는 '다음 거래일 예고' 로 후보를 보여준다 (PO 2026-09-24).

    봇이 쓰는 종합 신호(combined_live.json)는 거래일에만 생긴다. 그래서 휴장일에
    스캐너를 열면 ② 가 통째로 비어 화면을 볼 수가 없었다.
    일봉 후보(daily_strategy_last.json)는 전날 확정 일봉으로 계산한 것이라
    휴장일에도 값이 있다 — 그것으로 채운다. '예고' 라고 밝힌다.
    """
    try:
        import json as _j, os as _o
        p2 = _o.path.join(_o.path.dirname(_o.path.abspath(__file__)),
                          'data', 'daily_strategy_last.json')
        with open(p2, encoding='utf-8') as f:
            d = _j.load(f)
        rows = []
        for fam, lst in (d.get('candidates') or {}).items():
            put = 'PUT' in fam
            for c in (lst or []):
                v = c.get('values') or {}
                rows.append({
                    'code': c.get('code'), 'name': c.get('name'),
                    'score': c.get('score'), 'price': c.get('price'),
                    'direction': 'PUT' if put else 'CALL',
                    'family': '추세형' if '추세형' in fam else '반등형',
                    'dev_ma60': round(v.get('dev_ma60'), 1) if v.get('dev_ma60') is not None else None,
                    'stage1': None, 'types': {}, 'hit': None,
                    'status': '예고', 'overnight': None, 'jev': None,
                })
        rows.sort(key=lambda r: (r['direction'] != 'CALL', -(r['score'] or 0)))
        return {'date': d.get('date'), 'at': d.get('computed_at'),
                'preview': True, 'market': d.get('market'),
                'window': '다음 거래일', 'in_window': False,
                'types': {'A': '3분봉 5/20 평균선 상향 교차', 'B': '장 초반 강세',
                          'C': '후보 분봉 5대장2졸병 65점', 'D': '평균가+거래량'},
                'rows': rows[:60]}
    except Exception:
        return None


def _combined_live():
    """봇이 매 스캔 남기는 종합 신호 상태(data/combined_live.json). 오늘 것만, 없으면 None"""
    try:
        import json as _j, os as _o, datetime as _dt
        p = _o.path.join(_o.path.dirname(_o.path.abspath(__file__)), 'data', 'combined_live.json')
        with open(p, encoding='utf-8') as f:
            d = _j.load(f)
        if d.get('date') != _dt.date.today().isoformat():
            return _cand_preview()     # 휴장일·장 전에는 다음 거래일 예고로
        # 밤사이 변화 상황을 후보마다 붙인다 (PO 2026-09-24).
        # 한 번 잰 값은 하루 종일 바뀌지 않으므로(장전 구간은 09:00 에 닫힌다) 캐시한다.
        _day = d.get('date') or ''
        if _ovn_cache.get('day') != _day:
            _ovn_cache.update(day=_day, data={})
        for r in (d.get('rows') or []):
            c = r.get('code')
            if not c:
                continue
            if c not in _ovn_cache['data']:
                _ovn_cache['data'][c] = _overnight(c)
            r['overnight'] = _ovn_cache['data'][c]
        return d
    except Exception:
        return _cand_preview()


def _kis_configured():
    """사용자 KIS 앱키가 .env 에 있는지 (없으면 2단계 정밀 신호·실매매 비활성, 1단계 네이버 스캔만)"""
    try:
        import config as _c
        return bool((_c.KIS_APP_KEY or '').strip() and (_c.KIS_APP_SECRET or '').strip())
    except Exception:
        return False


def _strategy_list():
    """strategies/*.json 목록 (전략 탭용): 분봉(1m, strategy_engine) + 일봉(1d, daily_strategy_engine). 엔진 없으면 []"""
    out = []
    try:
        import strategy_engine
        out += strategy_engine.strategy_summary()
    except Exception:
        pass
    try:
        import daily_strategy_engine
        out += daily_strategy_engine.strategy_summary()   # hits = 오늘 봇이 09시에 평가해 남긴 후보(data/daily_strategy_last.json)
    except Exception:
        pass
    return out


@app.route('/api/strategies')
def api_strategies():
    """전략 목록 + 전략별 현재 통과 종목(최근 스캔 stage2 기준)"""
    strategies = _strategy_list()
    hits = {}
    for it in scan_state.get('stage2', []) or []:
        for st in it.get('strategies', []) or []:
            if st.get('passed'):
                hits.setdefault(st['id'], []).append({'code': it.get('code'), 'name': it.get('name'), 'price': it.get('price'),
                                                      'rate': it.get('rate'), 'score': st.get('score'), 'direction': st.get('direction')})
    for st in strategies:
        if st.get('timeframe') == '1d':
            continue   # 일봉 전략의 hits 는 daily_strategy_engine.strategy_summary 가 이미 채움
        st['hits'] = sorted(hits.get(st['id'], []), key=lambda x: -(x.get('score') or 0))
    # 겹침: 2개 이상 전략에 동시에 걸린 종목
    overlap = {}
    for it in scan_state.get('stage2', []) or []:
        ids = [st['id'] for st in (it.get('strategies') or []) if st.get('passed')]
        if len(ids) >= 2:
            overlap[it['code']] = {'name': it.get('name'), 'strategies': ids}
    return jsonify(_to_json_safe({'strategies': strategies, 'overlap': overlap, 'finished_at': scan_state['finished_at'], 'kis_configured': _kis_configured()}))


@app.route('/api/strategies/<sid>/enabled', methods=['POST'])
def api_strategy_toggle(sid):
    """전략 켜기/끄기: 파일의 enabled 만 바꾼다 (폰에서 토글)"""
    import os, json as _json
    try:
        import strategy_engine
        target = None
        for st in strategy_engine.load_strategies(force=True):
            if st['id'] == sid:
                target = st['_file']
        if not target:
            try:
                import daily_strategy_engine
                for st in daily_strategy_engine.load_strategies(force=True):
                    if st['id'] == sid:
                        target = st['_file']
            except Exception:
                pass
        if not target:
            return jsonify({'success': False, 'error': '없는 전략'}), 404
        body = request.get_json(silent=True) or {}
        with open(target, encoding='utf-8-sig') as fp:
            spec = _json.load(fp)
        spec['enabled'] = bool(body.get('enabled', not spec.get('enabled', True)))
        with open(target, 'w', encoding='utf-8') as fp:
            _json.dump(spec, fp, ensure_ascii=False, indent=2)
        strategy_engine.load_strategies(force=True)
        return jsonify({'success': True, 'id': sid, 'enabled': spec['enabled']})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/k200_debug')
def api_k200_debug():
    """KOSPI200 소스 디버그 — FHPST02400000 raw 응답 확인"""
    import requests as _req
    try:
        from kis import get_access_token, KIS_API_URL, KIS_APP_KEY, KIS_APP_SECRET
        _tok = get_access_token()
        _h = {
            'Content-Type': 'application/json',
            'authorization': 'Bearer ' + _tok,
            'appkey': KIS_APP_KEY,
            'appsecret': KIS_APP_SECRET,
            'tr_id': 'FHPST02400000',
        }
        _p = {'fid_cond_mrkt_div_code': 'U', 'fid_input_iscd': '2001'}
        _r = _req.get(KIS_API_URL + '/uapi/domestic-stock/v1/quotations/inquire-index-price',
                      headers=_h, params=_p, timeout=5)
        _d = _r.json()
        _o = _d.get('output', {})
        _spot_raw = _o.get('stck_prpr', '?')
        _spot = float(_spot_raw.replace(',', '')) if _spot_raw != '?' else 0
        _fut = _futures_basis(_spot) if _spot > 0 else 0
        return jsonify({
            'rt_cd': _d.get('rt_cd'),
            'msg1': _d.get('msg1', ''),
            'stck_prpr': _spot_raw,
            'spot': _spot,
            'futures_estimate': _fut,
            'basis': round(_fut - _spot, 2),
            'source': _k200_source,
            'k200_state_price': k200_state.get('price'),
            'output_keys': list(_o.keys()),
        })
    except Exception as e:
        return jsonify({'error': str(e)})


@app.route('/api/k200_ticks')
def api_k200_ticks():
    """KOSPI200 30틱 차트 데이터 반환 (alert 플래그 소비)"""
    data = dict(k200_state)
    if k200_state['alert']:
        k200_state['alert'] = False
    if data.get('bar'):
        data['bar'] = dict(data['bar'])
    data['bars'] = list(data.get('bars', []))[-80:]
    data['ma']   = list(data.get('ma',   []))[-80:]
    return jsonify(data)


if __name__ == '__main__':
    port = 5050
    print(f"\n  Scanner Web Viewer: http://localhost:{port}")
    print("  ① 시장 · ② 오늘의 후보 · ③ 타이밍 · ④ 290종목 3분봉 현황\n")
    threading.Thread(target=_k200_poller, daemon=True, name='k200-tick-poller').start()
    try:
        import universe_scan
        universe_scan.start()          # 290종목 3분 주기 (PO 2026-09-24)
    except Exception as e:
        print(f"  (290종목 3분 주기를 못 켰습니다: {e})")
    webbrowser.open(f'http://localhost:{port}')
    app.run(host='0.0.0.0', port=port, debug=False)
