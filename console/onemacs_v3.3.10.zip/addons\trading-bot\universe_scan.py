# -*- coding: utf-8 -*-
"""290종목 3분봉 현황 — 3분마다 한 바퀴. (PO 2026-09-24)

PO: "290 종목 스캔은 3분봉 기준으로 3분마다 한 번씩 돌려 기본 현황만 보여주면
     좋겠어. 그래서 이 데이터를 쌓아서 3분봉에서 신호 규칙 찾는 작업을
     지속적으로 앞으로 했으면 좋겠어."

옛 1단계(네이버)·2단계(KIS) 두 열은 없앴다. PO: "이제 열 하나면 되잖아.
3분이면 아무거나 해도 되는 거 아니야. 두 개 중에 하나를 폴백으로."

  받는 곳   네이버 먼저 → 실패하면 KIS 통합시세
            네이버는 무료·빠르고, KIS 는 장전(08:00~) 넥스트레이드까지 준다.
  하는 일   3분봉으로 접어 화면에 보여주고, 원본을 그대로 쌓는다
  안 하는 일 점수 매기기·신호 내기. 그건 후보 선정(일봉)과 타이밍(A~D)이 한다.

쌓는 것은 원본뿐이다 (PO: "그냥 데이터만 쌓는 거지"). 지표를 미리 계산해 넣으면
나중에 지표를 바꿀 때 다시 만들 수 없다.
"""
import sys
try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass
import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

log = logging.getLogger(__name__)
SRC = os.path.dirname(os.path.abspath(__file__))

INTERVAL = 180          # 3분 (PO)
WORKERS = 12            # 네이버는 이 정도면 한 바퀴 1~2분
MIN_BARS = 3            # 3분봉 하나가 되려면 1분봉 셋

state = {
    'running': False,
    'at': '',            # 마지막 한 바퀴 끝난 시각
    'took': 0.0,
    'rows': [],          # 화면에 보내는 것
    'saved': 0,          # 이번 바퀴에 쌓은 3분봉 수
    'source': {},        # 어디서 받았나 {'naver': n, 'kis': n, 'fail': n}
}
_lock = threading.Lock()
_stop = threading.Event()


def _kst():
    from datetime import datetime, timedelta, timezone
    return datetime.now(timezone.utc) + timedelta(hours=9)


def _fetch(code):
    """1분봉을 받는다. 네이버 먼저, 안 되면 KIS 통합시세 (PO: 하나를 폴백으로)."""
    from scanner_262_52 import get_minute_bars_naver, get_minute_bars_union
    try:
        b = get_minute_bars_naver(code) or []
        if len(b) >= MIN_BARS:
            return b, 'naver'
    except Exception:
        pass
    try:
        b = get_minute_bars_union(code) or []
        if len(b) >= MIN_BARS:
            return b, 'kis'
    except Exception:
        pass
    return [], 'fail'


def _one(code, name, day8):
    """한 종목 — 3분봉으로 접고 화면에 보낼 한 줄을 만든다.

    휴장일에는 오늘 봉이 없다. 그때는 받은 봉 중 **가장 최근 거래일**로 접는다.
    그래야 휴장일에도 화면을 볼 수 있고, 쌓을 때도 그 날짜로 정확히 들어간다.
    """
    import bar_store
    bars, src = _fetch(code)
    if not bars:
        return None, src, 0
    have = {str(b.get('ts', ''))[:8] for b in bars if b.get('ts')}
    day = day8 if day8 in have else (max(have) if have else day8)
    r3 = bar_store.to_3m(bars, day)
    saved = bar_store.save(code, r3) if r3 else 0
    if not r3:
        return None, src, 0

    ts, o, h, l, c, v = r3[-1]
    first_open = r3[0][1]
    # 전일 종가 — 어제 봉이 있으면 그 마지막 종가
    prev = [b for b in bars if not str(b.get('ts', '')).startswith(day)]
    pc = float(prev[-1]['close']) if prev else first_open
    vol_day = sum(x[5] for x in r3)
    # 최근 20개 3분봉 평균 거래량 대비 (지금 얼마나 붐비나)
    tail = [x[5] for x in r3[-20:]]
    avg = (sum(tail) / len(tail)) if tail else 0
    return {
        'code': code, 'name': name, 'ts': ts, 'day': day,
        'price': c, 'open': first_open,
        'rate': round((c / pc - 1) * 100, 2) if pc else 0.0,
        'day_rate': round((c / first_open - 1) * 100, 2) if first_open else 0.0,
        'high': h, 'low': l,
        'vol': vol_day,
        'vol_ratio': round(v / avg, 2) if avg else 0.0,
        'bars': len(r3), 'src': src,
    }, src, saved


def scan_once():
    """290종목 한 바퀴."""
    from scanner_262_52 import STOCK_CODES
    day8 = _kst().strftime('%Y%m%d')
    codes = list(STOCK_CODES.items())
    t0 = time.time()
    rows, src_n, saved = [], {'naver': 0, 'kis': 0, 'fail': 0}, 0

    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        futs = {ex.submit(_one, c, n, day8): c for c, n in codes}
        for f in as_completed(futs):
            try:
                row, src, n = f.result()
            except Exception:
                src, row, n = 'fail', None, 0
            src_n[src] = src_n.get(src, 0) + 1
            saved += n
            if row:
                rows.append(row)

    rows.sort(key=lambda r: -abs(r['day_rate']))   # 많이 움직인 순
    with _lock:
        state.update(at=_kst().strftime('%H:%M:%S'), took=round(time.time() - t0, 1),
                     rows=rows, saved=saved, source=src_n)
    log.info(f'[290] {len(rows)}종목 · {state["took"]}초 · 쌓은 봉 {saved} · '
             f'네이버 {src_n["naver"]} KIS {src_n["kis"]} 실패 {src_n["fail"]}')
    return state


def _loop():
    while not _stop.is_set():
        try:
            import config as _c
            from trader import MarketClock          # 휴장일·장 시간 판단은 봇 것을 쓴다
            open_now = MarketClock().is_market_open()
        except Exception:
            open_now = True
        if open_now:
            try:
                scan_once()
            except Exception as e:
                log.warning(f'[290] 한 바퀴 실패: {e}')
        _stop.wait(INTERVAL)


def start():
    """3분마다 도는 것을 켠다. 이미 돌고 있으면 그냥 둔다."""
    with _lock:
        if state['running']:
            return
        state['running'] = True
    threading.Thread(target=_loop, daemon=True, name='universe3m').start()
    log.info(f'[290] {INTERVAL}초마다 3분봉 현황을 받습니다')


def stop():
    _stop.set()
    with _lock:
        state['running'] = False


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    print('290종목 3분봉 한 바퀴 — 네이버 먼저, 안 되면 KIS')
    s = scan_once()
    print()
    print(f"  {len(s['rows'])}종목 · {s['took']}초 · 쌓은 3분봉 {s['saved']:,}개")
    print(f"  받은 곳 — 네이버 {s['source']['naver']} · KIS {s['source']['kis']} · 실패 {s['source']['fail']}")
    print()
    print('  많이 움직인 순 10')
    print(f"  {'종목':14s}{'현재가':>10}{'당일':>8}{'전일대비':>9}{'거래량비':>9}  봉")
    for r in s['rows'][:10]:
        print(f"  {r['name'][:13]:14s}{r['price']:>10,.0f}{r['day_rate']:>+8.2f}%"
              f"{r['rate']:>+8.2f}%{r['vol_ratio']:>9.2f}  {r['bars']}")
