/**
 * One MACS 주소 분양 서버 (onemacs-issuer) — Cloudflare Worker + KV
 *   PO 2026-09-23: 「고정 주소로 바꿔」「에이전트를 팔면 주소도 분양해야」「One MACS 콘솔이 없이도 분양을 할 수 있어야」
 *
 * 한 라이선스 = 한 사용자코드(6자). 그 라이선스로 켜는 PC(또는 에이전트 연결기)마다 <코드>-<n>.<도메인> 을 하나씩 준다.
 * 콘솔(set_fixed_address)도, 콘솔 없는 에이전트(onemacs_connect.py)도 같은 /v1/claim 을 쓴다.
 *
 *  POST /v1/claim   { license, machine, label?, port? }  → { url, token, code, n }
 *        - 같은 machine 이 다시 부르면 같은 주소를 돌려준다(재설치·재시작). port 가 바뀌었으면 연결 규칙을 갱신한다.
 *        - 새 machine 이면 한도(max_pcs) 안에서 번호를 새로 준다.
 *  GET  /v1/status?license=…                             → 라이선스 상태·발급된 주소(토큰 없음)
 *  POST /v1/admin/license  { key?, max_pcs, plan, days, note? }   (Authorization: Bearer ADMIN_KEY) → 라이선스 발급
 *  POST /v1/admin/revoke   { license }                    → 주소·터널 전부 회수, 라이선스 정지(미납·해지)
 *  POST /v1/admin/release  { license, machine }           → PC 한 대 분 회수(기기 교체)
 *  GET  /v1/admin/list                                    → 라이선스 목록
 *  GET  /health
 *
 * 시크릿: CF_API_TOKEN(Tunnel Edit + DNS Edit), ADMIN_KEY / 변수: CF_ACCOUNT_ID, CF_ZONE_ID, DOMAIN
 * KV(ISS): lic:<key> = { key, code, plan, max_pcs, expires_at, status, machines: { <machine>: { n, tunnel, label, at } } }
 *          code:<code> = <key>   (코드 중복 방지)
 *
 * 한도: 도메인 하나에 DNS 이름 200개(무료) · 계정당 터널 1,000개 → 이 방식은 PC 200대까지. 그 뒤는 중계 방식(주소 모양은 그대로).
 */

const ALPH = 'abcdefghjkmnpqrstuvwxyz23456789';   // 헷갈리는 글자(0 o 1 l i) 뺌
const KEY_ALPH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const CLAIM_PER_MIN = 10;

const json = (obj, status = 200) => new Response(JSON.stringify(obj), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
});

function rand(alph, n) {
  const b = new Uint8Array(n); crypto.getRandomValues(b);
  let s = ''; for (const x of b) s += alph[x % alph.length]; return s;
}
const newKey = () => 'OM-' + [rand(KEY_ALPH, 5), rand(KEY_ALPH, 5), rand(KEY_ALPH, 5), rand(KEY_ALPH, 5)].join('-');
// 달력 기준 N개월 뒤 — 안내문이 「3개월」이라 90일로 세면 손님과 날짜가 어긋난다(보조 2026-09-23)
function addMonths(ms, n) { const d = new Date(ms); const day = d.getUTCDate(); d.setUTCMonth(d.getUTCMonth() + n); if (d.getUTCDate() < day) d.setUTCDate(0); return d.getTime(); }
const clean = (v, max) => String(v == null ? '' : v).replace(/[\u0000-\u001f]/g, '').trim().slice(0, max);

const counters = new Map();
function limited(key, limit) {
  const k = key + ':' + Math.floor(Date.now() / 60000);
  if (counters.size > 5000) counters.clear();
  const n = (counters.get(k) || 0) + 1; counters.set(k, n);
  return n > limit;
}

// ---------- 클라우드플레어 API ----------
async function cf(env, method, p, body) {
  const r = await fetch('https://api.cloudflare.com/client/v4' + p, {
    method, headers: { authorization: 'Bearer ' + env.CF_API_TOKEN, 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  let j = null; try { j = await r.json(); } catch (_) {}
  if (!j || !j.success) throw new Error('cloudflare ' + r.status + ' ' + ((j && j.errors || []).map(e => e.code + ' ' + e.message).join(' / ')));
  return j.result;
}
const acct = (env) => '/accounts/' + env.CF_ACCOUNT_ID;
const zone = (env) => '/zones/' + env.CF_ZONE_ID;

async function setIngress(env, tid, host, port) {
  await cf(env, 'PUT', acct(env) + '/cfd_tunnel/' + tid + '/configurations', {
    config: { ingress: [{ hostname: host, service: 'http://127.0.0.1:' + port, originRequest: {} }, { service: 'http_status:404' }] },
  });
}

async function createAddress(env, code, n, port, label) {
  const name = code + '-' + n;
  const host = name + '.' + env.DOMAIN;
  const exists = await cf(env, 'GET', zone(env) + '/dns_records?name=' + encodeURIComponent(host));
  if (exists.length) throw new Error('이미 있는 주소: ' + host);
  const t = await cf(env, 'POST', acct(env) + '/cfd_tunnel', { name: 'onemacs-' + name, config_src: 'cloudflare' });
  try {
    await setIngress(env, t.id, host, port);
    await cf(env, 'POST', zone(env) + '/dns_records', {
      type: 'CNAME', proxied: true, name: host, content: t.id + '.cfargotunnel.com',
      comment: 'onemacs ' + clean(label, 40) + ' ' + new Date().toISOString().slice(0, 10),
    });
  } catch (e) {
    try { await cf(env, 'DELETE', acct(env) + '/cfd_tunnel/' + t.id); } catch (_) {}
    throw e;
  }
  return { tunnel: t.id, host };
}

async function removeAddress(env, host, tid) {
  try {
    const recs = await cf(env, 'GET', zone(env) + '/dns_records?name=' + encodeURIComponent(host));
    for (const r of recs) await cf(env, 'DELETE', zone(env) + '/dns_records/' + r.id);
  } catch (_) {}
  if (tid) {
    try { await cf(env, 'DELETE', acct(env) + '/cfd_tunnel/' + tid + '/connections'); } catch (_) {}
    try { await cf(env, 'DELETE', acct(env) + '/cfd_tunnel/' + tid); } catch (_) {}
  }
}

// ---------- 라이선스 ----------
const getLic = (env, key) => env.ISS.get('lic:' + key, 'json');
const putLic = (env, lic) => env.ISS.put('lic:' + lic.key, JSON.stringify(lic));
function licState(lic) {
  if (!lic) return 'none';
  if (lic.status !== 'active') return lic.status || 'suspended';
  if (lic.expires_at && Date.now() > lic.expires_at) return 'expired';
  return 'active';
}
function publicView(env, lic) {
  return {
    license: lic.key, code: lic.code, plan: lic.plan, products: lic.products || [], status: licState(lic), max_pcs: lic.max_pcs,
    expires_at: lic.expires_at || null,
    days_left: lic.expires_at ? Math.max(0, Math.ceil((lic.expires_at - Date.now()) / 86400000)) : null,
    addresses: Object.values(lic.machines || {}).map(m => ({ n: m.n, url: 'https://' + lic.code + '-' + m.n + '.' + env.DOMAIN, label: m.label || '' })),
  };
}

async function claim(env, b) {
  const key = clean(b.license, 60).toUpperCase();
  const machine = clean(b.machine, 64);
  const label = clean(b.label, 40);
  const port = parseInt(b.port, 10) || 7890;
  if (!key || !/^[A-Za-z0-9_-]{8,64}$/.test(machine)) return json({ error: 'license·machine 이 필요합니다' }, 400);
  if (port < 1 || port > 65535) return json({ error: 'port 범위 오류' }, 400);
  const lic = await getLic(env, key);
  const st = licState(lic);
  if (st !== 'active') return json({ error: st === 'none' ? '없는 라이선스입니다' : ('라이선스 상태: ' + st), status: st }, 403);
  lic.machines = lic.machines || {};
  let m = lic.machines[machine];
  if (!m) {
    const used = Object.values(lic.machines).map(x => x.n);
    if (used.length >= lic.max_pcs) return json({ error: '이 라이선스로 쓸 수 있는 PC ' + lic.max_pcs + '대를 모두 썼습니다. 안 쓰는 PC 를 풀어 주십시오.' }, 409);
    let n = 1; while (used.includes(n)) n++;
    const made = await createAddress(env, lic.code, n, port, label || ('PC ' + n));
    m = { n, tunnel: made.tunnel, label, port, at: Date.now() };
    lic.machines[machine] = m;
    await putLic(env, lic);
  } else if (m.port !== port) {
    await setIngress(env, m.tunnel, lic.code + '-' + m.n + '.' + env.DOMAIN, port);
    m.port = port; await putLic(env, lic);
  }
  const token = await cf(env, 'GET', acct(env) + '/cfd_tunnel/' + m.tunnel + '/token');
  return json({ url: 'https://' + lic.code + '-' + m.n + '.' + env.DOMAIN, token, code: lic.code, n: m.n, plan: lic.plan, expires_at: lic.expires_at || null });
}

async function adminLicense(env, b) {
  let code;
  for (let i = 0; i < 20; i++) { const c = rand(ALPH, 6); if (!(await env.ISS.get('code:' + c))) { code = c; break; } }
  if (!code) return json({ error: '코드 생성 실패' }, 500);
  const key = b.key ? clean(b.key, 60).toUpperCase() : newKey();
  if (await getLic(env, key)) return json({ error: '이미 있는 라이선스 키' }, 409);
  const days = parseInt(b.days, 10) || 0;
  const months = parseInt(b.months, 10) || 0;
  const lic = {
    key, code, plan: clean(b.plan || 'trial', 20), max_pcs: Math.max(1, Math.min(20, parseInt(b.max_pcs, 10) || 3)),
    expires_at: months > 0 ? addMonths(Date.now(), months) : (days > 0 ? Date.now() + days * 86400000 : null), status: 'active', note: clean(b.note, 120),
    machines: {}, created_at: Date.now(),
  };
  await env.ISS.put('code:' + code, key);
  await putLic(env, lic);
  return json({ ok: true, ...publicView(env, lic) });
}

// 마켓 주문 — 마켓(waat.community api/send-download)이 결제 뒤 부른다. 라이선스 키의 정본은 마켓이고
// 여기는 그 키로 **주소 권리만** 등록한다. 같은 order_id 는 한 번만 처리(재전송 안전).
// PO 2026-09-23: 보고서 작성 에이전트(ARWA)는 One MACS와 별도 상품 — 정정: One MACS에 끼워 주지 않고 따로 판다.
const PRODUCTS = {
  // PO 2026-09-22: 대당 과금 안 함 — 「개인 1명 기준, PC 대수와 상관없음(남용 방지선 5대)」. 판매 문구와 같은 숫자여야 한다.
  'onemacs':      { plan: 'onemacs',      max_pcs: 5, months: 3, includes: ['onemacs'] },
  'report-agent': { plan: 'report-agent', max_pcs: 1, months: 3, includes: ['report-agent'] },
};
async function marketOrder(env, b) {
  const orderId = clean(b.order_id, 80);
  const key = clean(b.license, 60).toUpperCase();
  const spec = PRODUCTS[clean(b.product, 30)];
  if (!orderId || !key || !spec) return json({ error: 'order_id·license·product(onemacs|report-agent) 가 필요합니다' }, 400);
  const done = await env.ISS.get('order:' + orderId, 'json');
  if (done) { const l = await getLic(env, done.license); return json({ ok: true, repeat: true, ...(l ? publicView(env, l) : {}) }); }
  let lic = await getLic(env, key);
  if (lic) {
    // 이미 있는 키에 상품을 더 산 경우 — 권리를 합친다(더 큰 PC 수, 더 긴 기간)
    lic.products = Array.from(new Set([...(lic.products || []), ...spec.includes]));
    lic.max_pcs = Math.max(lic.max_pcs || 1, spec.max_pcs);
    if (spec.plan === 'onemacs') lic.plan = 'onemacs';
    const until = addMonths(Date.now(), spec.months);
    if (lic.expires_at && lic.expires_at < until) lic.expires_at = until;
    if (lic.status !== 'revoked') lic.status = 'active';
    await putLic(env, lic);
  } else {
    const made = await adminLicense(env, { key, plan: spec.plan, max_pcs: spec.max_pcs, months: spec.months, note: 'market ' + orderId });
    if (made.status !== 200) return made;
    lic = await getLic(env, key);
    lic.products = spec.includes; await putLic(env, lic);
  }
  await env.ISS.put('order:' + orderId, JSON.stringify({ license: key, product: b.product, at: Date.now() }));
  return json({ ok: true, ...publicView(env, lic), products: lic.products });
}

async function adminRevoke(env, b, onlyMachine) {
  const key = clean(b.license, 40).toUpperCase();
  const lic = await getLic(env, key);
  if (!lic) return json({ error: '없는 라이선스' }, 404);
  const targets = Object.entries(lic.machines || {}).filter(([mid]) => !onlyMachine || mid === onlyMachine);
  if (onlyMachine && !targets.length) return json({ error: '그 기기는 이 라이선스에 없습니다' }, 404);
  for (const [mid, m] of targets) {
    await removeAddress(env, lic.code + '-' + m.n + '.' + env.DOMAIN, m.tunnel);
    delete lic.machines[mid];
  }
  if (!onlyMachine) lic.status = 'revoked';
  await putLic(env, lic);
  return json({ ok: true, removed: targets.length, ...publicView(env, lic) });
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const ip = req.headers.get('cf-connecting-ip') || '0.0.0.0';
    try {
      if (url.pathname === '/health') return json({ ok: true, t: Date.now() });

      if (url.pathname === '/v1/claim' && req.method === 'POST') {
        if (limited('claim:' + ip, CLAIM_PER_MIN)) return json({ error: '요청이 너무 많습니다' }, 429);
        let b = {}; try { b = await req.json(); } catch (_) { return json({ error: 'JSON 필요' }, 400); }
        return await claim(env, b);
      }

      if (url.pathname === '/v1/status' && req.method === 'GET') {
        if (limited('status:' + ip, 30)) return json({ error: '요청이 너무 많습니다' }, 429);
        const lic = await getLic(env, clean(url.searchParams.get('license'), 40).toUpperCase());
        if (!lic) return json({ error: '없는 라이선스입니다' }, 404);
        return json(publicView(env, lic));
      }

      if (url.pathname === '/v1/market/order' && req.method === 'POST') {
        const auth = req.headers.get('authorization') || '';
        if (!env.MARKET_KEY || auth !== 'Bearer ' + env.MARKET_KEY) return json({ error: '마켓 인증 필요' }, 401);
        let b = {}; try { b = await req.json(); } catch (_) { return json({ error: 'JSON 필요' }, 400); }
        return await marketOrder(env, b);
      }

      if (url.pathname.startsWith('/v1/admin/')) {
        const auth = req.headers.get('authorization') || '';
        if (!env.ADMIN_KEY || auth !== 'Bearer ' + env.ADMIN_KEY) return json({ error: '관리자 인증 필요' }, 401);
        let b = {}; if (req.method === 'POST') { try { b = await req.json(); } catch (_) {} }
        if (url.pathname === '/v1/admin/license' && req.method === 'POST') return await adminLicense(env, b);
        if (url.pathname === '/v1/admin/revoke' && req.method === 'POST') return await adminRevoke(env, b, null);
        if (url.pathname === '/v1/admin/release' && req.method === 'POST') return await adminRevoke(env, b, clean(b.machine, 64) || '-');
        if (url.pathname === '/v1/admin/list' && req.method === 'GET') {
          const out = []; let cursor;
          do {
            const page = await env.ISS.list({ prefix: 'lic:', cursor });
            for (const k of page.keys) { const l = await env.ISS.get(k.name, 'json'); if (l) out.push(publicView(env, l)); }
            cursor = page.list_complete ? null : page.cursor;
          } while (cursor);
          return json({ licenses: out });
        }
      }
      return json({ error: 'not found' }, 404);
    } catch (e) {
      return json({ error: '분양 서버 오류: ' + String(e && e.message || e).slice(0, 200) }, 502);
    }
  },
};
