<!-- One MACS 배포판 v3 · 2026-09-22 · W8 · 2026-09-24 updates\ 버전별 보관 -->
# One MACS 업데이트 — Claude Code 지시문

사용자가 "One MACS 업데이트해줘"라고 하면 이 절차대로 한다. 설정(PIN 번호·프로젝트·허브)·대화 세션·로그는 그대로 남고 코드만 바뀐다.
사용자에게 말할 때는 「콘솔」 대신 제품 이름 **One MACS** 를 쓴다.

## 폴더 규칙
- 받은 배포판은 늘 `C:\OneMACS\updates\v<버전>\` 에 푼다. 풀면 그 안에 `One MACS\`·`주식 매매 자동화 시스템\`·설명서 세 장이 있다(설치 스크립트가 첫 설치 때 `updates\` 를 만들고, 설치한 판을 여기에 보관한다).
- `C:\OneMACS\console\` 안에는 절대 풀지 않는다 — 덮어쓰기 대상이다(설치 스크립트가 거부한다).
- 옛 버전 폴더는 지우지 않는다. 되돌리기에 쓴다.

## 절차
1. 현재 버전 확인: `type C:\OneMACS\console\VERSION`
2. 새 버전 확인: 폰 상태줄의 "One MACS 새 버전 x.y.z" 또는 `C:\OneMACS\console\compat_remote.json` 의 `data.console_latest` (`version`, `zip_url`, `summary`). 없으면 사용자에게 판매 페이지에서 받은 zip 이 있는지 묻는다.
3. 배포판 준비:
   - **사용자가 이미 푼 폴더에서 부탁했으면**(지금 폴더에 `One MACS\install.ps1` 이 있거나, 지금 폴더가 그 `One MACS\` 이고, `console\VERSION` 이 설치된 것보다 높으면) 그 폴더를 그대로 쓴다. 그 폴더가 `updates\v<버전>\` 이 아니어도 설치 스크립트가 거기로 한 벌 보관한다.
   - **zip 파일만 있으면** `C:\OneMACS\updates\v<버전>\` 에 푼다 (`Expand-Archive -LiteralPath <zip> -DestinationPath C:\OneMACS\updates\v<버전>`).
   - **zip_url 이 있으면** `C:\OneMACS\updates\v<버전>.zip` 으로 내려받아(`Invoke-WebRequest -Uri <zip_url> -OutFile ...`) 같은 자리에 푼다.
   풀린 폴더 맨 위에 `One MACS\`(안에 `console\`·`install.ps1`)와 `주식 매매 자동화 시스템\` 이 있어야 한다. 사람용 안내는 zip 맨 위 「One MACS 업데이트하는 법.html」.
4. 업데이트 실행 (그 버전 폴더 안의 `One MACS\` 에서 — 명령마다 같은 줄에 cd 를 붙인다):
   ```
   powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Update
   ```
   → 실행 중인 One MACS 를 잠깐 세우고 코드를 덮은 뒤 다시 기동한다 (1~2분 끊김).
5. 확인: `type C:\OneMACS\console\VERSION` 이 새 버전, `C:\OneMACS\console\start_all.log` 에 `터널 URL 발급 성공`, 폰에서 One MACS 채널에 "안녕" → 답.
6. 사용자에게 보고: 이전 버전 → 새 버전, 바뀐 점(`summary`), 이상 유무, 보관 위치(`updates\v<버전>\`).

## 안 되면
- 포트가 안 열리면 `C:\OneMACS\console\restart_console.cmd` 한 번 더. 그래도 안 되면 `start_all.log` 마지막 30줄을 사용자에게 보여 준다.
- 되돌리기: `C:\OneMACS\updates\` 에서 돌아갈 버전 폴더를 골라 그 안의 `One MACS\` 에서 같은 명령(`install.ps1 -Update`)을 실행한다. 사용자가 「v3.3.12 로 되돌려줘」라고 하면 이것이다. (옛 판은 zip 맨 위에 One MACS 폴더가 없고 바로 `install.ps1` 이 있다 — 그러면 그 폴더에서) 바로 전 판은 `console\_prev\` 에도 있다.
