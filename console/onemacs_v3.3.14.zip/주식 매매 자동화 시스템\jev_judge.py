# -*- coding: utf-8 -*-
"""Jev(판단 모델) 를 매매에 붙인다 — J1·J2·J3. (PO 2026-09-24)

Jev 는 시세를 보지 못한다. 여기서 써 주는 글(state)만 읽는다.
그래서 "Jev 가 지켜본다" 는 없고 "우리가 보다가 Jev 에게 묻는다" 만 있다.
무엇을 묻느냐가 답을 정하므로, 규칙(A·B·C·D)이 이미 보는 것은 되묻지 않는다.

  J1  오늘 전체 시장       하루 1회   오늘 매매할 만한 날인가
  J2  오늘의 후보 랭킹     하루 1회   후보 여럿을 놓고 어느 것이 나은가
  J3  파이널 필터          A~D 뜰 때  규칙이 사라는데 그날 그림도 그런가

■ 지금은 기록만 한다
J1·J2·J3 어느 것도 주문을 막거나 띄우지 않는다. 검증이 0건이기 때문이다.
A~D 는 8년치로 쟀지만 Jev 는 과거로 돌아가 물을 수 없다.
매일 확률을 남기고, 쌓인 뒤 "얼마 이상일 때만 따를지" 를 재서 정한다 (PO 지시).
"""
import sys
try:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
except Exception:
    pass
import json
import logging
import os
import subprocess
import time

log = logging.getLogger(__name__)
SRC = os.path.dirname(os.path.abspath(__file__))
GATEWAY = os.getenv('AI_GATEWAY_URL') or 'https://ai-gateway.vercel.sh/v1/evaluate'
MODEL = 'typesafe-ai/jev'
TIMEOUT = 25
REC = os.path.join(SRC, 'data', 'jev_log.jsonl')   # 쌓기 — 나중에 임계값을 재는 재료


def _key():
    """Jev 열쇠. 없으면 ''. 값은 어디에도 찍지 않는다."""
    try:
        from config import AI_GATEWAY_API_KEY as k      # .env 를 config 가 읽는다
        if k:
            return k.strip()
    except Exception:
        pass
    k = os.getenv('AI_GATEWAY_API_KEY') or ''
    return k.strip()


def _call(state, questions):
    """Jev 한 번 호출. 실패하면 None — 매매는 그대로 돈다(막지 않는다).

    예전에는 node 로 MCP 서버를 띄웠다. 그 서버가 하는 일이 HTTPS 한 번이라
    여기서 바로 부른다 — 손님 PC 에 node 가 없어도 된다 (PO 2026-09-24).
    """
    key = _key()
    if not key:
        return None
    try:
        import requests
        r = requests.post(GATEWAY,
                          headers={'Authorization': 'Bearer ' + key,
                                   'Content-Type': 'application/json'},
                          json={'model': MODEL, 'state': state, 'questions': questions},
                          timeout=TIMEOUT)
    except Exception as e:
        log.debug(f'[Jev] 연결 실패: {e}')
        return None
    if r.status_code != 200:
        # 열쇠가 틀렸는지 잠깐 막힌 것인지는 손님도 알아야 한다
        msg = f'HTTP {r.status_code}'
        if r.status_code in (401, 403):
            msg += ' — AI_GATEWAY_API_KEY 를 확인하십시오'
        elif r.status_code == 429:
            msg += ' — 잠시 뒤 다시 묻습니다'
        log.warning(f'[Jev] 묻지 못했습니다: {msg}')
        return None
    try:
        # 부르는 쪽이 r.get('answers') 로 꺼낸다 — 게이트웨이 응답을 그대로 준다
        d = r.json()
        return d if d.get('answers') else None
    except Exception:
        return None


def _prob(ans):
    """boolean 답 → 확률."""
    return None if not ans else ans.get('probability')


def _ev(ans):
    """score 답 → 기대값(0=가장 낮음). 라벨이 다섯이면 0~4."""
    if not ans:
        return None
    pr = ans.get('probabilities') or {}
    if not pr:
        return None
    return round(sum(float(k) * float(v) for k, v in pr.items()), 3)


def _record(kind, payload):
    """남긴다. 이 줄들이 나중에 '얼마 이상이면 따를까' 를 재는 재료가 된다."""
    try:
        os.makedirs(os.path.dirname(REC), exist_ok=True)
        with open(REC, 'a', encoding='utf-8') as f:
            f.write(json.dumps({'at': time.strftime('%Y-%m-%d %H:%M:%S'),
                                'kind': kind, **payload}, ensure_ascii=False) + '\n')
    except Exception:
        pass


def _market_line(mkt, us):
    """시장 한 줄 — J1·J2·J3 가 함께 쓴다."""
    bits = []
    if (mkt or {}).get('index'):
        i = mkt['index']
        bits.append(f"코스피200 {i['price']:,.2f} ({i['rate']:+.2f}%)")
    if (mkt or {}).get('futures'):
        f = mkt['futures']
        bits.append(f"선물 {f['price']:,.2f} {f['volume']:,}계약")
    if (mkt or {}).get('basis') is not None:
        bits.append(f"베이시스 {mkt['basis']:+.2f}")
    for u in (us or []):
        bits.append(f"{u['name']} {u['rate']:+.2f}%")
    return ' · '.join(bits) or '시장 자료 없음'


# ── J1 · 오늘 전체 시장 ────────────────────────────────────────
def j1_market(mkt, us, n_cand):
    """오늘 매매할 만한 날인가. 하루 1회."""
    state = (f'한국 주식선물 승인형 매매 봇. 오늘 시장 — {_market_line(mkt, us)}. '
             f'오늘의 후보 {n_cand}건. 하루에 새로 살 수 있는 종목은 2개, 손실 한도 35,000원. '
             f'사람이 텔레그램으로 승인해야 주문이 나간다.')
    r = _call(state, {
        'trade_today': {'type': 'boolean',
                        'instructions': '오늘은 매매할 만한 날인가?',
                        'criteria': {'true': '시장이 받쳐 주거나 적어도 해롭지 않다',
                                     'false': '오늘은 쉬는 편이 낫다'}},
        'mood': {'type': 'score', 'instructions': '오늘 시장의 분위기',
                 'criteria': ['매우 나쁨', '나쁨', '보통', '좋음', '매우 좋음']}})
    if not r:
        return None
    a = r.get('answers') or {}
    out = {'trade_today': _prob(a.get('trade_today')), 'mood': _ev(a.get('mood')),
           'market': _market_line(mkt, us)}
    _record('J1', out)
    return out


# ── J2 · 오늘의 후보 랭킹 ──────────────────────────────────────
def j2_rank(rows, mkt=None, us=None, max_new=2):
    """후보 여럿을 한 번에 놓고 Jev 가 순위를 매긴다. 하루 1회.

    규칙은 '많이 빠진 순' 하나로 줄을 세운다. Jev 는 여러 가지를 한꺼번에
    저울질할 수 있다 — 그 점이 다르다.
    """
    rows = [r for r in (rows or []) if r.get('name')][:40]
    if not rows:
        return None
    lines = []
    for r in rows:
        bit = f"{r['name']} {r.get('score', '?')}점"
        if r.get('dev_ma60') is not None:
            bit += f" 60일선 {r['dev_ma60']:+.0f}%"
        if r.get('direction'):
            bit += f" {r['direction']}"
        o = r.get('overnight') or {}
        if o.get('rate') is not None:
            bit += f" 장전 {o['rate']:+.1f}%"
            if o.get('volume'):
                bit += f" 거래량 {o['volume']:,}"
        lines.append(bit)
    state = (f'한국 주식선물 승인형 매매 봇. 오늘 시장 — {_market_line(mkt, us)}. '
             f'오늘의 후보 {len(rows)}건(일봉 3대장4졸병): ' + ' / '.join(lines) +
             f'. 하루에 새로 살 수 있는 종목은 {max_new}개뿐이다.')
    qs = {f'r{i}': {'type': 'score',
                    'instructions': f"{r['name']} — 오늘 이 종목을 사는 것이 얼마나 나은가",
                    'criteria': ['매우 나쁨', '나쁨', '보통', '좋음', '매우 좋음']}
          for i, r in enumerate(rows)}
    res = _call(state, qs)
    if not res:
        return None
    a = res.get('answers') or {}
    out = []
    for i, r in enumerate(rows):
        ans = a.get(f'r{i}')
        out.append({'code': r.get('code'), 'name': r['name'],
                    'jev': _ev(ans),
                    'confidence': (ans or {}).get('confidence')})
    out.sort(key=lambda x: (x['jev'] is None, -(x['jev'] or 0)))
    for i, x in enumerate(out, 1):
        x['rank'] = i
    _record('J2', {'n': len(out), 'rank': out})
    return out


# ── J3 · 파이널 필터 ───────────────────────────────────────────
def j3_filter(row, hit, mkt=None, us=None, peers=None):
    """A~D 가 떴을 때 한 번 더 묻는다.

    규칙이 보는 것(그 종목의 분봉)을 되묻지 않는다. 규칙이 못 보는 것만 준다 —
    그날 시장, 미국장, 후보들 사이의 자리, 밤사이 움직임, 오늘 이미 몇 건 떴는지.
    """
    o = row.get('overnight') or {}
    bits = [f"{row.get('name')} {row.get('score', '?')}점 {row.get('direction', '')}"]
    if row.get('dev_ma60') is not None:
        bits.append(f"60일선 {row['dev_ma60']:+.0f}%")
    if o.get('rate') is not None:
        bits.append(f"밤사이 {o['rate']:+.1f}%" + (f" 거래량 {o['volume']:,}" if o.get('volume') else ''))
    if row.get('rank_in_cand'):
        bits.append(f"오늘 후보 {row.get('n_cand', '?')}건 중 낙폭 {row['rank_in_cand']}위")
    if peers:
        bits.append(f"오늘 이미 {peers}건이 타이밍이 떴다")
    state = (f'한국 주식선물 승인형 매매 봇. 오늘 시장 — {_market_line(mkt, us)}. '
             f'규칙이 방금 이 종목에 매수 시점({hit})을 냈다: ' + ' · '.join(bits) +
             '. 손절 -10%, 20거래일 뒤 청산, 1계약. 사람이 승인해야 주문이 나간다. '
             '규칙은 이 종목의 분봉만 본다 — 그날 전체 그림을 놓고 다시 판단하라.')
    r = _call(state, {
        'go': {'type': 'boolean',
               'instructions': '규칙이 낸 이 시점을 그대로 따라도 되는가?',
               'criteria': {'true': '그날 그림도 이 매수를 받쳐 준다',
                            'false': '규칙은 맞지만 오늘 그림이 아니다'}}})
    if not r:
        return None
    a = r.get('answers') or {}
    out = {'code': row.get('code'), 'name': row.get('name'), 'hit': hit,
           'go': _prob(a.get('go'))}
    _record('J3', out)
    return out


if __name__ == '__main__':
    mkt = {'index': {'price': 1131.45, 'rate': 1.13},
           'futures': {'price': 1127.75, 'volume': 81070}, 'basis': -3.7}
    us = [{'name': '나스닥', 'rate': -0.69}, {'name': 'S&P500', 'rate': -0.76}]
    rows = [
        {'code': '214150', 'name': '클래시스', 'score': 80, 'dev_ma60': -22, 'direction': 'CALL',
         'overnight': {'rate': -0.4, 'volume': 12000}},
        {'code': '078340', 'name': '컴투스', 'score': 70, 'dev_ma60': -14, 'direction': 'CALL',
         'overnight': {'rate': 1.2, 'volume': 22000}},
        {'code': '010060', 'name': 'OCI홀딩스', 'score': 90, 'dev_ma60': -18, 'direction': 'CALL',
         'overnight': {'rate': 6.2, 'volume': 310000}},
    ]
    print('J1 — 오늘 매매할 만한 날인가')
    print('   ', j1_market(mkt, us, len(rows)))
    print()
    print('J2 — 후보 랭킹')
    for x in (j2_rank(rows, mkt, us) or []):
        print(f"    {x['rank']}위  {x['name']:10s} 기대값 {x['jev']}  확신 {x['confidence']}")
    print()
    print('J3 — 파이널 필터 (클래시스에 A타입이 떴다고 치고)')
    print('   ', j3_filter({**rows[0], 'rank_in_cand': 1, 'n_cand': 3},
                           'A:3분봉 5/20 상향교차', mkt, us, peers=2))
