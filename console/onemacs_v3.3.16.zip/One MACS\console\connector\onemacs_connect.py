# -*- coding: utf-8 -*-
"""
One MACS 주소 연결기 (onemacs_connect.py) — One MACS 콘솔 없이 에이전트 하나에 고정 주소를 붙인다.
  PO 2026-09-23: 「에이전트를 팔면 주소도 분양해야」「One MACS 콘솔이 없이도 분양을 할 수 있어야」

하는 일
  1) 라이선스 키로 분양 서버에 주소를 받는다 (한 PC 에 한 번 — 다음부터는 같은 주소)
  2) 에이전트를 켜고, 에이전트가 찍는 접속 주소(?t=토큰)를 읽어 인증 쿠키를 받아 둔다
  3) 앞문(PIN 번호 확인)을 127.0.0.1 에 연다 — 주소를 아는 사람이라도 PIN 번호 없이는 에이전트에 못 들어온다
  4) cloudflared 로 앞문을 그 고정 주소에 잇는다 (끊기면 다시 잇는다)

설정: 이 파일 옆 onemacs_connect.json
  { "license": "OM-XXXXX-...", "agent_cmd": "시작.bat", "agent_url": "", "label": "보고서 에이전트", "gate_port": 7790 }
  - agent_cmd : 에이전트를 켜는 파일(이 폴더 기준). 비우면 이미 켜져 있다고 보고 agent_url 을 쓴다
  - agent_url : 에이전트가 이미 떠 있을 때 접속 주소(토큰 포함 가능). 둘 다 있으면 agent_cmd 가 찍는 주소가 우선
상태(비밀 포함): %LOCALAPPDATA%\\OneMACS\\connect\\<폴더 이름 해시>\\state.json — 주소·터널 토큰·PIN 번호. 남에게 주지 않는다.

외부 패키지 없이 파이썬 표준 라이브러리만 쓴다(에이전트가 이미 파이썬을 요구하므로).
"""
import hashlib, http.client, http.cookies, http.server, json, os, re, secrets, socketserver, subprocess, sys, threading, time, urllib.request, uuid

HERE = os.path.dirname(os.path.abspath(__file__))
CFG_FILE = os.path.join(HERE, 'onemacs_connect.json')
DEFAULT_ISSUER = 'https://onemacs-issuer.consolesystem.workers.dev'
CLOUDFLARED_URL = 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe'
AGENT_URL_RE = re.compile(r'(https?://(?:127\.0\.0\.1|localhost|0\.0\.0\.0):\d+(?:/\S*)?)')
COOKIE = 'om_gate'
UA = 'OneMACS-Connect/1.0'   # 파이썬 기본 신분은 클라우드플레어가 막는다(오류 1010, 2026-09-23 실측)
SESSION_DAYS = 30

def say(msg):
    print('[One MACS 연결기 %s] %s' % (time.strftime('%H:%M:%S'), msg), flush=True)

def load_json(path, default):
    try:
        with open(path, encoding='utf-8-sig') as f:
            return json.load(f)
    except Exception:
        return default

def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

CFG = load_json(CFG_FILE, {})
STATE_DIR = os.path.join(os.environ.get('LOCALAPPDATA') or os.path.expanduser('~'), 'OneMACS', 'connect',
                         hashlib.sha256(HERE.lower().encode('utf-8')).hexdigest()[:12])
STATE_FILE = os.path.join(STATE_DIR, 'state.json')
STATE = load_json(STATE_FILE, {})

# ---------------- 1) 주소 받기 ----------------
def claim(gate_port):
    lic = str(CFG.get('license') or '').strip()
    if not lic:
        say('onemacs_connect.json 에 "license"(라이선스 키)가 없습니다. 구매 메일의 키를 넣어 주십시오.')
        sys.exit(2)
    if not STATE.get('machine'):
        STATE['machine'] = uuid.uuid4().hex
    body = json.dumps({'license': lic, 'machine': STATE['machine'], 'label': CFG.get('label') or os.path.basename(HERE),
                       'port': gate_port}).encode('utf-8')
    req = urllib.request.Request((CFG.get('issuer') or DEFAULT_ISSUER).rstrip('/') + '/v1/claim', data=body,
                                 headers={'Content-Type': 'application/json', 'User-Agent': UA})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            j = json.loads(r.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode('utf-8')).get('error')
        except Exception:
            msg = 'HTTP %d' % e.code
        say('주소를 받지 못했습니다: %s' % msg)
        if STATE.get('url') and STATE.get('token') and e.code >= 500:
            say('분양 서버가 잠시 안 됩니다 — 전에 받은 주소로 계속합니다.')
            return
        sys.exit(3)
    except Exception as e:
        if STATE.get('url') and STATE.get('token'):
            say('분양 서버에 닿지 않습니다(%s) — 전에 받은 주소로 계속합니다.' % e)
            return
        say('분양 서버에 닿지 않습니다: %s' % e)
        sys.exit(3)
    STATE.update({'url': j['url'], 'token': j['token'], 'code': j.get('code'), 'n': j.get('n'), 'expires_at': j.get('expires_at')})
    save_json(STATE_FILE, STATE)

# ---------------- 2) cloudflared ----------------
def ensure_cloudflared():
    for p in (os.path.join(HERE, 'cloudflared.exe'), os.path.join(STATE_DIR, '..', 'cloudflared.exe')):
        if os.path.isfile(p):
            return os.path.abspath(p)
    dst = os.path.abspath(os.path.join(STATE_DIR, '..', 'cloudflared.exe'))
    say('cloudflared 를 내려받습니다(처음 한 번, 약 60MB)…')
    tmp = dst + '.part'
    with urllib.request.urlopen(urllib.request.Request(CLOUDFLARED_URL, headers={'User-Agent': UA}), timeout=300) as r, open(tmp, 'wb') as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
    os.replace(tmp, dst)
    return dst

def run_tunnel(exe):
    fails = 0
    while True:
        started = time.time()
        env = dict(os.environ, TUNNEL_TOKEN=STATE['token'])     # 토큰은 명령줄이 아니라 환경변수로 — 프로세스 목록에 안 보이게
        p = subprocess.Popen([exe, 'tunnel', '--no-autoupdate', '--protocol', 'http2', 'run'], env=env,
                             stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        tail = []
        for line in iter(p.stderr.readline, b''):
            s = line.decode('utf-8', 'replace').rstrip()
            tail = (tail + [s])[-5:]
            if 'Registered tunnel connection' in s and fails >= 0:
                fails = -1
                say('연결됨 → %s' % STATE['url'])
        p.wait()
        fails = 0 if time.time() - started > 120 else max(fails, 0) + 1
        say('터널이 끊겼습니다 — 다시 잇습니다. (%s)' % (tail[-1][:120] if tail else 'exit %s' % p.returncode))
        time.sleep(min(60, 3 * max(1, fails)))

# ---------------- 3) 에이전트 ----------------
AGENT = {'base': '', 'cookie': ''}

def start_agent():
    cmd = str(CFG.get('agent_cmd') or '').strip()
    if CFG.get('agent_url'):
        AGENT['base'] = str(CFG['agent_url']).strip()
    if not cmd:
        return
    target = os.path.join(HERE, cmd)
    env = dict(os.environ, NO_BROWSER='1', PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONUNBUFFERED='1')
    p = subprocess.Popen(['cmd', '/d', '/c', target], cwd=os.path.dirname(target), env=env,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    say('에이전트를 켭니다: %s' % cmd)
    got = threading.Event()
    def reader():
        cand = ''
        for line in iter(p.stdout.readline, b''):
            s = line.decode('utf-8', 'replace')
            for u in AGENT_URL_RE.findall(s):
                u = u.rstrip(')]"\'<>').replace('0.0.0.0', '127.0.0.1')
                if re.search(r'\?\S+=', u):
                    AGENT['base'] = u; got.set()
                elif not cand:
                    cand = u
            if cand and not got.is_set() and not AGENT['base']:
                AGENT['base'] = cand
        say('에이전트가 끝났습니다 (exit %s)' % p.wait())
    threading.Thread(target=reader, daemon=True).start()
    got.wait(120)

def grab_cookie():
    """에이전트 첫 접속 주소(?t=)로 한 번 들어가 쿠키를 받아 둔다. 문이 늦게 열리면 0.5초 간격으로 다시 시도."""
    for _ in range(40):
        if not AGENT['base']:
            time.sleep(0.5); continue
        try:
            u = urllib.parse.urlsplit(AGENT['base'])
            c = http.client.HTTPConnection('127.0.0.1', u.port, timeout=8)
            c.request('GET', (u.path or '/') + ('?' + u.query if u.query else ''))
            r = c.getresponse(); r.read()
            sc = r.msg.get_all('Set-Cookie') or []
            if sc:
                AGENT['cookie'] = '; '.join(x.split(';')[0] for x in sc)
            return True
        except Exception:
            time.sleep(0.5)
    return False

# ---------------- 4) 앞문(PIN 번호) ----------------
SESSIONS = {}          # 토큰 → 만료시각
FAILS = {}             # IP → [시각…]
LOGIN_HTML = '''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>One MACS — PIN</title><style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0b0e17;color:#e2e8f0;font:16px -apple-system,"Pretendard",sans-serif}
form{width:min(320px,90vw);text-align:center}input{width:100%%;box-sizing:border-box;font-size:22px;letter-spacing:6px;text-align:center;padding:12px;border-radius:10px;border:1px solid #334155;background:#111827;color:#fff}
button{margin-top:12px;width:100%%;padding:12px;border:0;border-radius:10px;background:#4f7fff;color:#fff;font-size:16px}p{color:#94a3b8;font-size:13px}.e{color:#f87171}</style>
<form method="post" action="/__onemacs/login"><div style="font-size:18px;margin-bottom:6px">%s</div><p>이 PC 의 연결기 창에 적힌 PIN 번호를 넣으세요</p>
<input name="pin" type="password" inputmode="numeric" autocomplete="current-password" autofocus><button>열기</button><p class="e">%s</p></form></html>'''

def new_session():
    t = secrets.token_urlsafe(24)
    SESSIONS[t] = time.time() + SESSION_DAYS * 86400
    STATE.setdefault('sessions', {})[hashlib.sha256(t.encode()).hexdigest()] = SESSIONS[t]
    save_json(STATE_FILE, STATE)
    return t

def session_ok(tok):
    if not tok:
        return False
    exp = SESSIONS.get(tok) or (STATE.get('sessions') or {}).get(hashlib.sha256(tok.encode()).hexdigest())
    return bool(exp and exp > time.time())

HOP = {'connection', 'keep-alive', 'proxy-authenticate', 'proxy-authorization', 'te', 'trailers', 'transfer-encoding', 'upgrade'}

class Gate(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *a):
        pass
    def _ip(self):
        return self.headers.get('CF-Connecting-IP') or self.client_address[0]
    def _cookie(self):
        c = http.cookies.SimpleCookie()
        try:
            c.load(self.headers.get('Cookie') or '')
        except Exception:
            return ''
        return c[COOKIE].value if COOKIE in c else ''
    def _send(self, code, body, ctype='text/html; charset=utf-8', extra=None):
        b = body.encode('utf-8') if isinstance(body, str) else body
        self.send_response(code)
        self.send_header('Content-Type', ctype); self.send_header('Content-Length', str(len(b)))
        self.send_header('Cache-Control', 'no-store')
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers(); self.wfile.write(b)
    def _login(self, err=''):
        self._send(200 if not err else 401, LOGIN_HTML % (CFG.get('label') or 'One MACS 에이전트', err))

    def do_POST(self):
        if self.path.split('?')[0] == '/__onemacs/login':
            ip = self._ip(); now = time.time()
            FAILS[ip] = [t for t in FAILS.get(ip, []) if now - t < 600]
            if len(FAILS[ip]) >= 5:
                return self._login('잘못 넣은 횟수가 많습니다. 10분 뒤에 다시 하세요.')
            n = int(self.headers.get('Content-Length') or 0)
            form = urllib.parse.parse_qs(self.rfile.read(min(n, 4096)).decode('utf-8', 'replace'))
            if secrets.compare_digest((form.get('pin') or [''])[0].strip(), STATE['pin']):
                tok = new_session()
                return self._send(303, '', extra={'Location': '/', 'Set-Cookie': '%s=%s; Path=/; Max-Age=%d; HttpOnly; Secure; SameSite=Lax' % (COOKIE, tok, SESSION_DAYS * 86400)})
            FAILS[ip].append(now)
            return self._login('PIN 이 맞지 않습니다.')
        return self._proxy()

    def do_GET(self):
        if self.path.split('?')[0] == '/__onemacs/login':
            return self._login()
        return self._proxy()
    do_PUT = do_DELETE = do_PATCH = do_HEAD = do_OPTIONS = lambda self: self._proxy()

    def _proxy(self):
        if not session_ok(self._cookie()):
            if self.command == 'GET' and 'text/html' in (self.headers.get('Accept') or ''):
                return self._send(303, '', extra={'Location': '/__onemacs/login'})
            return self._send(401, '{"error":"PIN 필요"}', 'application/json')
        if not AGENT['base']:
            return self._send(503, '<meta http-equiv="refresh" content="3"><body style="background:#0b0e17;color:#8a99b5;font:15px sans-serif;text-align:center;padding-top:40vh">에이전트를 켜는 중입니다…')
        u = urllib.parse.urlsplit(AGENT['base'])
        n = int(self.headers.get('Content-Length') or 0)
        body = self.rfile.read(n) if n else None
        hdrs = {k: v for k, v in self.headers.items() if k.lower() not in HOP and k.lower() not in ('host', 'cookie', 'accept-encoding')}
        if AGENT['cookie']:
            hdrs['Cookie'] = AGENT['cookie']
        hdrs['Host'] = '127.0.0.1:%d' % u.port
        try:
            c = http.client.HTTPConnection('127.0.0.1', u.port, timeout=600)
            c.request(self.command, self.path, body=body, headers=hdrs)
            r = c.getresponse()
        except Exception as e:
            return self._send(502, '에이전트에 닿지 않습니다: %s' % e, 'text/plain; charset=utf-8')
        self.send_response(r.status)
        for k, v in r.getheaders():
            if k.lower() in HOP or k.lower() in ('content-length', 'set-cookie', 'x-frame-options'):
                continue
            self.send_header(k, v)
        # 길이를 모르는 응답(SSE 등)도 흘려보내려고 청크로 보낸다
        self.send_header('Transfer-Encoding', 'chunked'); self.end_headers()
        try:
            while True:
                chunk = r.read1(65536) if hasattr(r, 'read1') else r.read(65536)
                if not chunk:
                    break
                self.wfile.write(b'%x\r\n%s\r\n' % (len(chunk), chunk)); self.wfile.flush()
            self.wfile.write(b'0\r\n\r\n')
        except Exception:
            self.close_connection = True

class TServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = False

def main():
    import urllib.parse  # noqa: F401 (위 함수들이 쓴다)
    gate_port = int(CFG.get('gate_port') or 7790)
    if not STATE.get('pin'):
        STATE['pin'] = '%06d' % secrets.randbelow(1000000)
        save_json(STATE_FILE, STATE)
    claim(gate_port)
    try:
        srv = TServer(('127.0.0.1', gate_port), Gate)
    except OSError:
        say('포트 %d 를 이미 쓰고 있습니다. onemacs_connect.json 의 "gate_port" 를 다른 번호로 바꾸십시오.' % gate_port)
        sys.exit(4)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    start_agent()
    grab_cookie()
    exe = ensure_cloudflared()
    say('주소: %s' % STATE['url'])
    say('PIN : %s   (폰에서 처음 한 번 넣습니다. 바꾸려면 %s 의 "pin" 을 고치고 다시 켜십시오)' % (STATE['pin'], STATE_FILE))
    say('이 창을 닫으면 주소가 끊깁니다.')
    run_tunnel(exe)

if __name__ == '__main__':
    import urllib.parse
    main()
