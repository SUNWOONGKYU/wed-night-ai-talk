/**
 * jev_hook.js — 코드가 **무조건** Jev 에게 묻는 자리 (2026-09-24 PO: "Jev 가 특정 채널에만 적용되면 안 된다")
 *
 *  "애매할 때 물어라"는 규칙만으로는 사흘에 choose_worker 3번이었다(9/22~9/24 jev_mcp.log 실측).
 *  애매한지부터가 주관이라 안 걸린다. 그래서 지나갈 수 없는 자리(daemon_ask 전송·재전송·답 수신, publish, 콘솔 AI 탭 전송)에
 *  코드로 심는다. Jev 는 **자문**이다 — 막지 않는다. 확률을 한 줄 남기고, 실패하면 그 사실만 한 줄 남기고 진행한다.
 *
 *  const jev = require('./jev_hook');
 *  const r = await jev.ask('jev_choose_worker', { task, context }, 'daemon_ask');   // 실패·시간 초과면 null
 *  console.error(jev.line('jev_choose_worker', r, '워커 선택'));
 *
 *  끄기: 환경변수 JEV_OFF=1. 기록: ~/.onemacs/jev_mcp.log (MCP 서버와 같은 파일, "call <도구> [hook:<자리>]")
 */
let core = null;
function load() { if (core === null) { try { core = require('./jev_mcp/server.js'); } catch (_) { core = false; } } return core; }

async function ask(tool, args, where, timeoutMs) {
  if (process.env.JEV_OFF === '1') return null;
  const c = load(); if (!c) return null;
  c.log('call ' + tool + ' [hook:' + (where || '?') + '] ' + JSON.stringify(args).slice(0, 300));
  try {
    // 게이트웨이가 가끔 503(잠시 불가)을 낸다(2026-09-24 실측) — 한 번만 2초 뒤 다시
    const call = () => c.callTool(tool, args).catch(e => /Gateway 5\d\d/.test(e.message) ? new Promise(ok => setTimeout(ok, 2000)).then(() => c.callTool(tool, args)) : Promise.reject(e));
    const r = await Promise.race([call(),new Promise((_, rej) => setTimeout(() => rej(new Error('응답 없음(' + Math.round((timeoutMs || 20000) / 1000) + '초)')), timeoutMs || 20000))]);
    c.log('ok ' + tool + ' [hook:' + (where || '?') + '] ' + JSON.stringify(r).slice(0, 300));
    return r;
  } catch (e) {
    c.log('err ' + tool + ' [hook:' + (where || '?') + '] ' + e.message);
    if (/AI_GATEWAY_API_KEY/.test(e.message)) return null; // Jev 를 설치하지 않은 PC(배포판 선택 설치) — 조용히 넘어간다
    return { error: e.message };
  }
}

const pct = (p) => (typeof p === 'number' ? p.toFixed(2) : '?');
const RISK = ['낮음', '보통', '높음', '매우 높음'];
// 점수는 라벨 번호의 기댓값(0=낮음 … 3=매우 높음)이라 0.67 처럼 나온다 — 가까운 라벨과 값을 함께 보인다
const risk = (v) => typeof v === 'number' ? (RISK[Math.max(0, Math.min(3, Math.round(v)))] + ' ' + v.toFixed(2) + '/3') : String(v);
/** 보고용 한 줄: "Jev: <질문> → <답> <확률>" */
function line(tool, r, q) {
  if (!r) return '';
  if (r.error) return 'Jev: ' + q + ' → 묻지 못함(' + r.error + ') — 내 판단으로 진행';
  if (tool === 'jev_choose_worker') return 'Jev: ' + q + ' → ' + r.worker + ' ' + pct(r.confidence) + (r.split && r.split.recommend ? ' · 병렬 권장 ' + pct(r.split.probability) : '') + ' (' + r.advice + ')';
  if (tool === 'jev_should_continue') return 'Jev: ' + q + ' → ' + r.next + ' ' + pct(r.confidence) + ' · 이미 완료 ' + pct(r.done_probability) + ' (' + r.advice + ')';
  if (tool === 'jev_evaluate_result') return 'Jev: ' + q + ' → 완료 ' + pct(r.complete) + ' · 검토 필요 ' + pct(r.needs_review) + ' · 위험 ' + risk(r.risk_score) + ' (' + r.advice + ')';
  if (tool === 'jev_risk_score') return 'Jev: ' + q + ' → 위험 ' + risk(r.risk_score) + ' (' + r.advice + ')';
  return 'Jev: ' + q + ' → ' + JSON.stringify(r).slice(0, 200);
}

module.exports = { ask, line };

// 명령줄(동기 스크립트용):  node jev_hook.js risk "<행동>" "<맥락>" [자리]   → 한 줄 출력, 늘 exit 0
if (require.main === module && process.argv[2] === 'risk') {
  ask('jev_risk_score', { action: process.argv[3] || '', context: process.argv[4] || '' }, process.argv[5] || 'cli')
    .then(r => { const l = line('jev_risk_score', r, process.argv[3] || ''); if (l) console.log(l); process.exit(0); });
}
