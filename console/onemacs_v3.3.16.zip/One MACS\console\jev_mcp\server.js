#!/usr/bin/env node
/**
 * Jev MCP 서버 — Claude Code 가 TypeSafe AI 의 판단 모델 Jev 를 도구로 쓰게 한다 (2026-09-22, One MACS HQ)
 *
 *  경로: Claude Code ──(MCP stdio)──▶ 이 서버 ──(HTTPS)──▶ Vercel AI Gateway  POST https://ai-gateway.vercel.sh/v1/evaluate
 *        모델 typesafe-ai/jev · 인증 Bearer AI_GATEWAY_API_KEY (환경변수, 또는 %USERPROFILE%\.onemacs\jev.env 의 AI_GATEWAY_API_KEY=...)
 *
 *  Jev 는 글을 쓰지 않는다. state(상황) + questions(형식이 정해진 질문) 를 받아
 *    boolean → probability(0~1) · choice → choice + probabilities · score → score + probabilities
 *  를 돌려준다 (Vercel 문서 /docs/ai-gateway/modalities/evaluation, 2026-09-16 판 기준).
 *
 *  도구 (Claude Code 에 보이는 이름 = jev_*):
 *    jev_evaluate         — 원형: state + questions 그대로 (여러 질문 한 번에)
 *    jev_choose_worker    — 이 작업을 누구에게(claude-code/codex/antigravity/grok/…) 맡길까
 *    jev_should_continue  — 계속/재시도/중단
 *    jev_evaluate_result  — 완료 조건 충족? 추가 검증 필요? 위험도
 *    jev_risk_score       — 위험도 점수
 *  지휘권은 Claude Code 에 있다. Jev 는 자문이며 확률을 돌려줄 뿐이다 — 낮은 확률(<0.6)이면 사람에게 묻는 쪽으로.
 *
 *  의존성 0 (MCP stdio JSON-RPC 를 직접 구현) — 정본으로 세 PC 에 그대로 배포되기 위해서.
 *  등록:  claude mcp add --scope user jev -- node "C:\OneMACS\console\jev_mcp\server.js"
 */
'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');
const https = require('https');

const GATEWAY = process.env.AI_GATEWAY_URL || 'https://ai-gateway.vercel.sh/v1/evaluate';
const MODEL = process.env.JEV_MODEL || 'typesafe-ai/jev';
const LOG_FILE = path.join(os.homedir(), '.onemacs', 'jev_mcp.log');
const WORKERS = { 'claude-code': 'Claude Code — 코드 작성·수정·파일·터미널·테스트·전체 계획. 기본 팀장', codex: 'Codex(GPT) — 코드 리뷰·독립 검증·다른 시각의 구현', antigravity: 'Antigravity(Gemini) — UI/화면·문서·긴 자료 정리', grok: 'Grok — 외부 최신 정보·검색·브레인스토밍', human: '사람(PO) 판단이 필요' };

function log(m) { try { fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true }); fs.appendFileSync(LOG_FILE, '[' + new Date().toISOString() + '] ' + m + '\n'); } catch (_) {} }
function apiKey() {
  if (process.env.AI_GATEWAY_API_KEY) return process.env.AI_GATEWAY_API_KEY.trim();
  for (const f of [path.join(os.homedir(), '.onemacs', 'jev.env'), path.join(__dirname, 'jev.env')]) {
    try { const m = fs.readFileSync(f, 'utf8').match(/AI_GATEWAY_API_KEY\s*=\s*"?([^"\r\n]+)"?/); if (m) return m[1].trim(); } catch (_) {}
  }
  return '';
}

/** Vercel AI Gateway /v1/evaluate 호출 */
function evaluate(state, questions, opts) {
  return new Promise((resolve, reject) => {
    const key = apiKey();
    if (!key) return reject(new Error('AI_GATEWAY_API_KEY 가 없습니다. 환경변수로 두거나 ' + path.join(os.homedir(), '.onemacs', 'jev.env') + ' 에 AI_GATEWAY_API_KEY=... 를 적으세요 (Vercel 대시보드 → AI Gateway → API Keys)'));
    const body = JSON.stringify(Object.assign({ model: MODEL, state, questions }, (opts && opts.providerOptions) ? { providerOptions: opts.providerOptions } : {}));
    const u = new URL(GATEWAY);
    const req = https.request({ hostname: u.hostname, path: u.pathname, method: 'POST', headers: { 'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }, timeout: 30000 }, (res) => {
      let b = ''; res.on('data', d => b += d); res.on('end', () => {
        let j = null; try { j = JSON.parse(b); } catch (_) {}
        if (res.statusCode >= 200 && res.statusCode < 300 && j && j.answers) return resolve(j);
        reject(new Error('Gateway ' + res.statusCode + ': ' + (j && (j.error && (j.error.message || JSON.stringify(j.error)) || JSON.stringify(j)) || b).slice(0, 400)));
      });
    });
    req.on('timeout', () => { req.destroy(new Error('Gateway 응답 없음(30초)')); });
    req.on('error', reject); req.write(body); req.end();
  });
}

// ---------- 도구 정의 ----------
const TOOLS = [
  {
    name: 'jev_evaluate',
    description: 'Jev(판단 모델)에 상황(state)과 형식이 정해진 질문들(questions)을 한 번에 던져 확률로 답을 받는다. 질문 type: boolean(instructions, criteria{true,false}) / choice(instructions, criteria{옵션명:설명}) / score(instructions, criteria[낮음→높음 라벨 배열, 2개 이상]). 글을 생성하지 않는다 — 분류·라우팅·통과판정·점수 같은 좁은 결정에만 쓴다.',
    inputSchema: { type: 'object', required: ['state', 'questions'], properties: {
      state: { description: '판단 대상 상황. 문자열 또는 객체(구조화 상태·메시지 기록)', anyOf: [{ type: 'string' }, { type: 'object' }, { type: 'array' }] },
      questions: { type: 'object', description: '{ 질문키: { type: "boolean"|"choice"|"score", instructions: "...", criteria?: ... } }', additionalProperties: { type: 'object' } },
      zeroDataRetention: { type: 'boolean', description: '게이트웨이에 무보존 요구 (기본 false)' }
    } }
  },
  {
    name: 'jev_choose_worker',
    description: '이 작업을 어느 워커에게 맡길지 Jev 에게 묻는다. 후보 기본값: claude-code, codex, antigravity, grok, human. 확률 분포와 최선 후보를 돌려준다. 최고 확률이 0.6 미만이면 사람에게 확인하라.',
    inputSchema: { type: 'object', required: ['task'], properties: {
      task: { type: 'string', description: '작업 내용(사용자 지시 원문 포함)' },
      context: { type: 'string', description: '프로젝트·현재 상태·최근 결과·제약 (선택)' },
      candidates: { type: 'object', description: '{ 워커키: 설명 } — 생략하면 기본 5종', additionalProperties: { type: 'string' } },
      parallel_question: { type: 'boolean', description: 'true 면 "병렬로 나눠 시킬 가치가 있는가"도 같이 묻는다 (기본 true)' }
    } }
  },
  {
    name: 'jev_should_continue',
    description: '진행 중인 작업을 계속할지 / 재시도할지 / 중단하고 사람에게 넘길지 Jev 에게 묻는다.',
    inputSchema: { type: 'object', required: ['goal', 'progress'], properties: {
      goal: { type: 'string', description: '목표(완료 조건)' },
      progress: { type: 'string', description: '지금까지 한 일·결과·오류·시도 횟수' },
      last_error: { type: 'string', description: '마지막 오류/실패 (선택)' }
    } }
  },
  {
    name: 'jev_evaluate_result',
    description: '작업 결과가 완료 조건을 만족하는지, 추가 검증(다른 AI 리뷰)이 필요한지, 위험도는 어느 정도인지 Jev 에게 한 번에 묻는다.',
    inputSchema: { type: 'object', required: ['goal', 'result'], properties: {
      goal: { type: 'string', description: '완료 조건' },
      result: { type: 'string', description: '결과 요약: 변경 내역·테스트 결과·종료 코드·로그' },
      evidence: { type: 'string', description: '검증 근거(테스트 출력 등, 선택)' }
    } }
  },
  {
    name: 'jev_risk_score',
    description: '어떤 행동(배포·삭제·외부 전송·결제·설정 변경 등)의 위험도를 Jev 에게 점수로 묻는다 (낮음/보통/높음/매우 높음).',
    inputSchema: { type: 'object', required: ['action'], properties: {
      action: { type: 'string', description: '하려는 행동' },
      context: { type: 'string', description: '영향 범위·되돌리기 가능 여부 등 (선택)' }
    } }
  }
];

function best(probabilities) { let k = null, v = -1; for (const [a, b] of Object.entries(probabilities || {})) if (b > v) { v = b; k = a; } return { key: k, p: v }; }
function advice(p) { return p >= 0.8 ? '자동 진행 가능' : (p >= 0.6 ? '진행하되 결과 보고' : '확신 낮음 — 사람(PO)에게 확인'); }

async function callTool(name, a) {
  a = a || {};
  const zdr = a.zeroDataRetention ? { providerOptions: { gateway: { zeroDataRetention: true } } } : undefined;
  if (name === 'jev_evaluate') {
    const r = await evaluate(a.state, a.questions, zdr);
    return { answers: r.answers, usage: r.usage, cost: r.providerMetadata && r.providerMetadata.gateway ? r.providerMetadata.gateway.cost : undefined };
  }
  if (name === 'jev_choose_worker') {
    const cands = (a.candidates && Object.keys(a.candidates).length) ? a.candidates : WORKERS;
    const questions = { worker: { type: 'choice', instructions: '이 작업을 가장 잘 처리할 워커를 고르라. 후보 설명을 근거로 판단한다.', criteria: cands } };
    if (a.parallel_question !== false) questions.split = { type: 'boolean', instructions: '이 작업을 둘 이상의 워커에게 병렬로 나눠 시킬 가치가 있는가?', criteria: { true: '독립된 부분이 여럿이거나 교차 검증이 필요', false: '한 워커가 순서대로 하는 편이 낫다' } };
    const r = await evaluate({ task: a.task, context: a.context || '', candidates: cands }, questions);
    const w = r.answers.worker; const b = best(w.probabilities);
    return { worker: w.choice, probabilities: w.probabilities, confidence: b.p, advice: advice(b.p), split: r.answers.split ? { probability: r.answers.split.probability, recommend: r.answers.split.probability >= 0.6 } : undefined, usage: r.usage };
  }
  if (name === 'jev_should_continue') {
    const r = await evaluate({ goal: a.goal, progress: a.progress, last_error: a.last_error || '' }, {
      next: { type: 'choice', instructions: '다음 행동을 고르라.', criteria: { continue: '같은 방향으로 계속 진행', retry: '접근을 바꿔 다시 시도', stop: '중단하고 사람에게 보고' } },
      done: { type: 'boolean', instructions: '목표가 이미 달성됐는가?', criteria: { true: '완료 조건을 모두 만족', false: '남은 것이 있음' } }
    });
    const n = r.answers.next; const b = best(n.probabilities);
    return { next: n.choice, probabilities: n.probabilities, confidence: b.p, advice: advice(b.p), done_probability: r.answers.done.probability, usage: r.usage };
  }
  if (name === 'jev_evaluate_result') {
    const r = await evaluate({ goal: a.goal, result: a.result, evidence: a.evidence || '' }, {
      complete: { type: 'boolean', instructions: '결과가 완료 조건을 만족하는가?', criteria: { true: '조건을 전부 충족하고 근거가 있음', false: '미충족·근거 부족·실패 흔적' } },
      needs_review: { type: 'boolean', instructions: '다른 AI 나 사람의 추가 검토가 필요한가?', criteria: { true: '변경이 크거나 위험하거나 검증이 약함', false: '작고 검증이 충분' } },
      risk: { type: 'score', instructions: '이 결과를 그대로 반영했을 때의 위험도', criteria: ['낮음: 되돌리기 쉽고 영향 작음', '보통: 일부 영향', '높음: 데이터·외부·운영에 영향', '매우 높음: 되돌리기 어려움'] }
    });
    return { complete: r.answers.complete.probability, needs_review: r.answers.needs_review.probability, risk_score: r.answers.risk.score, risk_probabilities: r.answers.risk.probabilities, advice: r.answers.complete.probability >= 0.8 && r.answers.needs_review.probability < 0.5 ? '완료로 보고' : (r.answers.complete.probability < 0.5 ? '미완 — 추가 작업' : '완료 가능성은 있으나 검토 권장'), usage: r.usage };
  }
  if (name === 'jev_risk_score') {
    const r = await evaluate({ action: a.action, context: a.context || '' }, { risk: { type: 'score', instructions: '이 행동의 위험도를 매겨라.', criteria: ['낮음: 로컬·되돌리기 쉬움', '보통: 되돌릴 수 있으나 영향 있음', '높음: 외부·데이터·운영에 영향', '매우 높음: 되돌리기 어렵거나 금전·법적 영향'] } });
    return { risk_score: r.answers.risk.score, probabilities: r.answers.risk.probabilities, advice: r.answers.risk.score >= 2 ? '사람 확인 후 실행' : '진행 가능', usage: r.usage };
  }
  throw new Error('unknown tool: ' + name);
}

// ---------- MCP stdio (JSON-RPC 2.0, 줄 단위) ----------
const SERVER_INFO = { name: 'jev', version: '1.0.0' };
function send(msg) { process.stdout.write(JSON.stringify(msg) + '\n'); }
function reply(id, result) { send({ jsonrpc: '2.0', id, result }); }
function fail(id, code, message) { send({ jsonrpc: '2.0', id, error: { code, message } }); }

async function handle(msg) {
  const { id, method, params } = msg;
  if (method === 'initialize') return reply(id, { protocolVersion: (params && params.protocolVersion) || '2025-06-18', capabilities: { tools: {} }, serverInfo: SERVER_INFO, instructions: 'Jev 는 판단 자문 도구다. 워커 선택·계속/중단·완료 판정·위험도 같은 좁은 결정에만 쓰고, 지휘와 최종 판단은 Claude Code 가 한다. 확률이 0.6 미만이면 사람에게 확인하라.' });
  if (method === 'notifications/initialized' || method === 'notifications/cancelled') return;
  if (method === 'ping') return reply(id, {});
  if (method === 'tools/list') return reply(id, { tools: TOOLS });
  if (method === 'tools/call') {
    const name = params && params.name; const args = (params && params.arguments) || {};
    log('call ' + name + ' ' + JSON.stringify(args).slice(0, 300));
    try { const r = await callTool(name, args); log('ok ' + name + ' ' + JSON.stringify(r).slice(0, 300)); return reply(id, { content: [{ type: 'text', text: JSON.stringify(r, null, 2) }], structuredContent: r }); }
    catch (e) { log('err ' + name + ' ' + e.message); return reply(id, { content: [{ type: 'text', text: 'Jev 호출 실패: ' + e.message }], isError: true }); }
  }
  if (id !== undefined) fail(id, -32601, 'Method not found: ' + method);
}

// 코드에서 직접 부를 때(jev_hook.js)는 stdio 서버를 켜지 않는다 — 2026-09-24 PO: Jev 를 지나갈 수 없는 자리에
module.exports = { callTool, log, WORKERS };
if (require.main === module) {
let buf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  buf += chunk; let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
    if (!line) continue;
    let msg; try { msg = JSON.parse(line); } catch (_) { continue; }
    handle(msg).catch(e => { if (msg && msg.id !== undefined) fail(msg.id, -32603, e.message); });
  }
});
process.stdin.on('end', () => { if (!process.argv.includes('--selftest')) process.exit(0); }); // selftest 는 stdin 이 닫혀도 응답을 기다린다

// 직접 실행 점검:  node server.js --selftest  → 게이트웨이에 boolean 질문 1개
if (process.argv.includes('--selftest')) {
  evaluate('The build failed with exit code 1.', { passed: { type: 'boolean', instructions: 'Did the build succeed?', criteria: { true: 'exit code 0', false: 'any non-zero exit code' } } })
    .then(r => { console.log(JSON.stringify(r, null, 2)); process.exit(0); })
    .catch(e => { console.error('selftest 실패: ' + e.message); process.exit(1); });
}
}
