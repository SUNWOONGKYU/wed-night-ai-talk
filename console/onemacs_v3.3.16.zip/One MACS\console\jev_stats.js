/**
 * jev_stats.js — Jev 를 실제로 얼마나 부르는지 도구별·자리별로 센다 (PO 2026-09-24: "아무도 안 쓰는 걸 몰랐던 게 문제")
 *   node jev_stats.js [일수=7]
 *   기록: ~/.onemacs/jev_mcp.log — MCP(AI 가 직접 부름)는 "call <도구> {...}", 코드 자리는 "call <도구> [hook:<자리>]"
 */
const fs = require('fs'), path = require('path'), os = require('os');
const DAYS = Number(process.argv[2]) || 7;
const LOG = path.join(os.homedir(), '.onemacs', 'jev_mcp.log');
let text = ''; try { text = fs.readFileSync(LOG, 'utf8'); } catch (_) { console.log('기록 없음: ' + LOG + ' (Jev 를 한 번도 부르지 않았거나 이 PC 에 없음)'); process.exit(0); }
const since = Date.now() - DAYS * 86400000;
const TOOLS = ['jev_choose_worker', 'jev_should_continue', 'jev_evaluate_result', 'jev_risk_score', 'jev_evaluate'];
const byTool = {}, bySrc = {}, byDay = {}, err = {};
for (const ln of text.split('\n')) {
  const m = ln.match(/^\[([^\]]+)\] (call|err) (\S+)(?: \[hook:([^\]]+)\])?/); if (!m) continue;
  const t = Date.parse(m[1]); if (!(t >= since)) continue;
  const tool = m[3], src = m[4] ? 'hook:' + m[4].split(':')[0] : 'AI(MCP)';
  if (m[2] === 'err') { err[tool] = (err[tool] || 0) + 1; continue; }
  byTool[tool] = (byTool[tool] || 0) + 1;
  bySrc[src] = (bySrc[src] || 0) + 1;
  const d = m[1].slice(0, 10); byDay[d] = byDay[d] || {}; byDay[d][tool] = (byDay[d][tool] || 0) + 1;
}
console.log('Jev 호출 — 최근 ' + DAYS + '일 (' + os.hostname() + ')');
for (const t of TOOLS) console.log('  ' + t.padEnd(22) + String(byTool[t] || 0).padStart(5) + (err[t] ? '   실패 ' + err[t] : '') + (!byTool[t] ? '   ⚠️ 한 번도 안 불림' : ''));
console.log('자리별: ' + (Object.entries(bySrc).map(([k, v]) => k + ' ' + v).join(' · ') || '없음'));
console.log('날짜별:');
for (const d of Object.keys(byDay).sort()) console.log('  ' + d + '  ' + TOOLS.map(t => t.replace('jev_', '') + ' ' + (byDay[d][t] || 0)).join(' · '));
