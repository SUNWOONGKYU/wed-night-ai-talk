/**
 * 권한 모드 (2026-09-21, 안전 모드 기본)
 *  perm_mode: "safe"(기본) | "full"  — console_config.json 의 값. start_all 이 CONSOLE_PERM_MODE 환경변수로 자식(프로젝트 서버·브릿지)에 전달한다.
 *   safe : 브릿지 4개가 권한 우회 플래그를 빼고 작업 폴더 한정 + 위험 명령 차단 훅(hooks/dangerous_cmd_block.js) + 감사 로그
 *   full : 자동 승인 모드(무인). 핸드폰 ⚙ 설정에서 PIN 번호 확인 후 바꾼다(PC 의 node perm.js full 도 가능).
 *  getPermMode() / isSafe() / setPermMode(mode)  — setPermMode 는 콘솔 본체 폴더의 console_config.json 을 고치고 감사 로그에 남긴다(재기동 후 반영).
 */
const fs = require('fs');
const path = require('path');

const HOME = process.env.CONSOLE_HOME || __dirname;
const CFG = path.join(HOME, 'console_config.json');

function readCfg() { try { return JSON.parse(fs.readFileSync(CFG, 'utf8').replace(/^﻿/, '')); } catch (_) { return {}; } }

function getPermMode() {
  const env = String(process.env.CONSOLE_PERM_MODE || '').toLowerCase();
  if (env === 'safe' || env === 'full') return env;
  const c = readCfg();
  return String(c.perm_mode || '').toLowerCase() === 'full' ? 'full' : 'safe';
}
function isSafe() { return getPermMode() === 'safe'; }

function setPermMode(mode, who) {
  mode = String(mode || '').toLowerCase() === 'full' ? 'full' : 'safe';
  const c = readCfg(); c.perm_mode = mode;
  fs.writeFileSync(CFG, JSON.stringify(c, null, 2), 'utf8');
  process.env.CONSOLE_PERM_MODE = mode;
  try { require('./audit').audit('perm_mode', { mode, by: who || 'cli' }); } catch (_) {}
  return mode;
}

module.exports = { getPermMode, isSafe, setPermMode, CFG };

if (require.main === module) {
  const arg = process.argv[2];
  if (arg === 'safe' || arg === 'full') { console.log('권한 모드 → ' + setPermMode(arg, 'cli') + ' (콘솔을 다시 켜면 적용됩니다)'); }
  else console.log('현재 권한 모드: ' + getPermMode() + '   (바꾸기: node perm.js safe|full)');
}
