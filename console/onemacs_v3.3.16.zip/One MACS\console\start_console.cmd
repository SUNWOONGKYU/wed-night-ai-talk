@echo off
rem
chcp 65001 >nul
cd /d "%~dp0"
set CLAUDECODE=
set CLAUDE_PID=
set CLAUDE_EFFORT=
rem child-server env must not leak into a restarted console (PC2 2026-09-24: came back on PORT 7897)
set PORT=
set PROJECT_NAME=
set PROJECT_ROLE=
set PROJECT_HOME=
set CONSOLE_HOME=
if not exist logs mkdir logs
rem
rem
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath cmd.exe -ArgumentList '/c','node start_all.js >> logs\console.log 2>&1' -WorkingDirectory (Get-Location).Path -WindowStyle Hidden"
if errorlevel 1 start "" /b cmd /c "node start_all.js >> logs\console.log 2>&1"
