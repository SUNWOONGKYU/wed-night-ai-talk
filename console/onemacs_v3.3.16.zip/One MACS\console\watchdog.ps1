﻿# One MACS 콘솔 워치독 (2026-09-22) — 예약 작업 OneMACS-Watchdog 이 5분마다 watchdog.cmd 로 실행.
#  라우터 포트(console_config.json 의 port, 기본 7890)가 안 열려 있으면 start_console.cmd 로 다시 띄운다.
#  살아 있으면 아무것도 하지 않는다 (재시작 강제 없음). 14:28 무로그 사망 재발 대비.
$home_ = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfg = $null
try { $cfg = Get-Content (Join-Path $home_ 'console_config.json') -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
$port = 7890
if ($cfg -and $cfg.port) { $port = [int]$cfg.port }
$up = Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue
if ($up) {
  # (2026-09-24) 포트를 잡은 것이 이 홈의 콘솔인지 본다. 옛 사본(C:\trader-bot\_mobile_remote 등)이 대신 떠 있으면
  #  /api/version 이 없어 404 를 낸다 → 이 홈의 restart_console.cmd 로 되찾는다(stop_console 이 포트 주인을 끈다).
  #  12:51 실측: 옛 사본이 7890 을 잡고 임시 터널을 허브에 올려 폰이 옛 콘솔을 봤다.
  $code = 0
  try { $r = Invoke-WebRequest -Uri ('http://127.0.0.1:' + $port + '/api/version') -UseBasicParsing -TimeoutSec 5; $code = [int]$r.StatusCode } catch { if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode } }
  if ($code -ne 404) { exit 0 }
  $logDir = Join-Path $home_ 'logs'
  if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
  Add-Content -Path (Join-Path $logDir 'console.log') -Value ('[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] watchdog: 포트 ' + $port + ' 를 다른 콘솔(옛 사본)이 잡고 있음 -> restart_console.cmd') -Encoding UTF8
  Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('"' + (Join-Path $home_ 'restart_console.cmd') + '"') -WindowStyle Hidden -WorkingDirectory $home_
  exit 0
}
# 기동 중(start_all.js 가 떠 있는데 포트만 아직 안 열림)이면 건드리지 않는다
$starting = Get-CimInstance Win32_Process -Filter "Name='node.exe'" | Where-Object { $_.CommandLine -match 'start_all\.js' }
if ($starting) { exit 0 }
$logDir = Join-Path $home_ 'logs'
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }
$line = '[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] watchdog: 포트 ' + $port + ' 닫힘 -> start_console.cmd 재기동'
Add-Content -Path (Join-Path $logDir 'console.log') -Value $line -Encoding UTF8
Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('"' + (Join-Path $home_ 'start_console.cmd') + '"') -WindowStyle Hidden -WorkingDirectory $home_
exit 0
