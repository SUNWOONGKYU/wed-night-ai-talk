﻿# One MACS 콘솔 설치·업데이트 (배포판 v3, 2026-09-22)
#
#  이 zip 을 푼 폴더에서:
#    powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -PcLabel "PC 1" -Pin 483920 [-Port 7890]
#        [-HubMode onemacs|self|none] [-PairCode XXXXXXXX] [-HubUrl https://...] [-Root C:\OneMACS] [-NoStart]
#    powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Update        ← 새 버전 zip 으로 코드만 갱신(설정·세션·로그 보존)
#
#  만드는 것:  <Root>\console\  콘솔 실행 홈(코드·설정·로그)   <Root>\general\uploads\  One MACS 채널 작업 폴더   <Root>\CLAUDE.md
#  하는 일:    코드 복사 → console_config.json 작성(첫 설치만) → CLAUDE.md → 워치독 예약 작업 → 기동 → 포트 확인  (외부 npm 의존성 없음)
#  안 하는 것: AI CLI 로그인(사용자가 직접), 허브 계정 만들기(One MACS 사용설명서.html 참조)
param(
  [string]$Root = 'C:\OneMACS',
  [string]$PcLabel = '',
  [string]$Pin = '',
  [int]$Port = 7890,
  [ValidateSet('onemacs', 'self', 'none')][string]$HubMode = 'onemacs',
  [string]$PairCode = '',
  [string]$HubUrl = '',
  [switch]$Update,
  [switch]$NoStart
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Con = Join-Path $Root 'console'
$Gen = Join-Path $Root 'general'
function Say($m) { Write-Host ('[One MACS 설치 ' + (Get-Date -Format 'HH:mm:ss') + '] ' + $m) }

# 0. 준비물 확인
if (-not (Test-Path (Join-Path $Here 'console\start_all.js'))) { throw "이 스크립트는 배포판 zip 을 푼 폴더(console\ 가 있는 곳)에서 실행해야 합니다: $Here" }
$manifest = Get-Content (Join-Path $Here 'console\manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
try { $nodeVer = (& node --version) } catch { throw 'Node.js 가 없습니다. https://nodejs.org 에서 LTS 를 설치한 뒤 다시 실행하세요.' }
$nodeMajor = 0; if ($nodeVer -match '^v(\d+)\.') { $nodeMajor = [int]$Matches[1] }
if ($nodeMajor -lt 18) { throw ("Node.js " + $nodeVer + " 는 너무 오래됐습니다. 18 이상(LTS 권장)을 설치하세요: https://nodejs.org") }
Say ("배포판 v" + $manifest.version + " · Node " + $nodeVer)
$hasClaude = $false; try { $null = & claude --version 2>$null; $hasClaude = $true } catch {}
if (-not $hasClaude) { Say "⚠️ Claude Code CLI(claude)가 PATH 에 없습니다 — 설치·로그인 후 콘솔이 동작합니다 (npm i -g @anthropic-ai/claude-code)" }

# 1. 폴더
$firstInstall = -not (Test-Path (Join-Path $Con 'console_config.json'))
if ($Update -and $firstInstall) { throw "-Update 인데 기존 설치가 없습니다: $Con (처음이면 -Update 없이 실행)" }
New-Item -ItemType Directory -Force -Path $Con, (Join-Path $Gen 'uploads'), (Join-Path $Con 'logs') | Out-Null
# 1-b. 버전별 보관 자리 (PO 2026-09-24: 「One MACS 폴더 안에 버전별로 기록을 남겨야지. 처음부터 만들어지도록」)
#  <Root>\updates\v<버전>\ 에 이번에 쓴 배포판을 한 벌 남긴다 → 몇 판 전으로든 되돌릴 수 있다.
#  단 console\ 안에서 풀어 실행하면 자기가 자기를 덮으므로 거부한다
$Upd = Join-Path $Root 'updates'
New-Item -ItemType Directory -Force -Path $Upd | Out-Null
$hereFull = [IO.Path]::GetFullPath($Here).TrimEnd('\'); $conFull = [IO.Path]::GetFullPath($Con).TrimEnd('\')
if ($hereFull -eq $conFull -or $hereFull.StartsWith($conFull + '\', [StringComparison]::OrdinalIgnoreCase)) { throw ("배포판 zip 을 " + $Con + " 안에 풀었습니다. 그 폴더는 덮어쓰기 대상이라 여기서는 설치할 수 없습니다. " + $Upd + "\v<버전>\ 에 풀고 다시 실행하세요.") }

# 2. 실행 중이면 잠깐 세운다 (업데이트) — 이 홈(<Root>\console)에서 뜬 콘솔만 (console.pid 기준). 다른 폴더의 콘솔은 절대 건드리지 않는다
if (-not $firstInstall) {
  $stopper = Join-Path $Con 'stop_console.ps1'
  if (Test-Path $stopper) { $r = & powershell -NoProfile -ExecutionPolicy Bypass -File $stopper -Home_ $Con -PidOnly; Say ("콘솔 정지: " + ($r -join ' ')) }
  else {
    $pidFile = Join-Path $Con 'console.pid'
    if (Test-Path $pidFile) { $p = [int](Get-Content $pidFile -Raw).Trim(); $ids = @($p); $q = @($p); while ($q.Count) { $x = $q[0]; $q = @($q | Select-Object -Skip 1); $kids = @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$x" | ForEach-Object { $_.ProcessId }); $ids += $kids; $q += $kids }; [array]::Reverse($ids); foreach ($i in $ids) { Stop-Process -Id $i -Force -ErrorAction SilentlyContinue }; Say ("콘솔 정지 (PID " + $p + ")") }
    else { Say "⚠️ 실행 중인 콘솔을 특정할 수 없어(console.pid 없음) 정지하지 않습니다 — 업데이트 뒤 restart_console.cmd 를 한 번 실행하세요" }
  }
  Start-Sleep -Seconds 2
}

# 3. 코드 복사 (manifest 에 적힌 파일만 — 설정·상태·로그는 절대 덮지 않는다). zip 이 불완전하면 시작 전에 실패
$missing = @($manifest.files | Where-Object { -not (Test-Path -LiteralPath (Join-Path (Join-Path $Here 'console') $_)) })
if ($missing.Count) { throw ("배포판 zip 이 불완전합니다 (" + $missing.Count + " 파일 없음): " + ($missing[0..([Math]::Min(4, $missing.Count - 1))] -join ', ') + " — zip 을 다시 받으세요") }
$prev = Join-Path $Con '_prev'
if (-not $firstInstall) { if (Test-Path $prev) { Remove-Item -Recurse -Force $prev }; New-Item -ItemType Directory -Force $prev | Out-Null
  foreach ($f in $manifest.files) { $cur = Join-Path $Con $f; if (Test-Path -LiteralPath $cur) { $d2 = Join-Path $prev $f; $dd2 = Split-Path -Parent $d2; if (-not (Test-Path $dd2)) { New-Item -ItemType Directory -Force -Path $dd2 | Out-Null }; Copy-Item -LiteralPath $cur -Destination $d2 -Force } }
  if (Test-Path (Join-Path $Con 'VERSION')) { Copy-Item (Join-Path $Con 'VERSION') (Join-Path $prev 'VERSION') -Force } }
$n = 0
try {
  foreach ($f in $manifest.files) {
    $src = Join-Path (Join-Path $Here 'console') $f; $dst = Join-Path $Con $f
    $dd = Split-Path -Parent $dst; if (-not (Test-Path $dd)) { New-Item -ItemType Directory -Force -Path $dd | Out-Null }
    Copy-Item -LiteralPath $src -Destination $dst -Force; $n++
  }
  Set-Content -Path (Join-Path $Con 'VERSION') -Value $manifest.version -Encoding ASCII -NoNewline
} catch {
  if (-not $firstInstall -and (Test-Path $prev)) { Say ("⚠️ 복사 실패(" + $_.Exception.Message + ") → 이전 버전으로 되돌립니다"); Get-ChildItem $prev -Recurse -File | ForEach-Object { $rel = $_.FullName.Substring($prev.Length + 1); Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $Con $rel) -Force }; Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('"' + (Join-Path $Con 'start_console.cmd') + '"') -WindowStyle Hidden -WorkingDirectory $Con }
  throw
}
Say ("코드 " + $n + " 파일 복사 → " + $Con + " (v" + $manifest.version + ")" + $(if (-not $firstInstall) { "  (바로 전 버전은 console\_prev\ 에도 보관)" } else { "" }))
# 1-b 이어서: 이번 배포판을 updates\v<버전>\ 에 보관 (이미 그 자리에서 실행 중이면 그대로 둔다)
$keep = Join-Path $Upd ('v' + $manifest.version)
#  zip 맨 위는 「One MACS\」·「주식 매매 자동화 시스템\」·설명서 세 장이다(2026-09-24). 이 스크립트는 One MACS\ 안에 있으므로
#  그 위 폴더(푼 자리 전체)를 통째로 보관한다 — 되돌릴 때 봇·설명서까지 그 판 그대로
$distRoot = $Here; $par = Split-Path -Parent $Here
if ($par -and (Test-Path -LiteralPath (Join-Path $par 'One MACS 사용설명서.html'))) { $distRoot = $par }
$distFull = [IO.Path]::GetFullPath($distRoot).TrimEnd('\')
if ($distFull -ne ([IO.Path]::GetFullPath($keep).TrimEnd('\'))) {
  try {
    if (Test-Path $keep) { Remove-Item -Recurse -Force $keep }
    New-Item -ItemType Directory -Force -Path $keep | Out-Null
    # 푼 자리가 다운로드 폴더 같은 곳일 수도 있다 → 배포판에 든 것만 골라 보관한다(그 폴더의 다른 파일까지 끌고 오지 않게)
    if ($distRoot -eq $par) {
      foreach ($nm in @('One MACS', '주식 매매 자동화 시스템', 'One MACS 사용설명서.html', 'One MACS 업데이트하는 법.html', '주식 매매 자동화 시스템 설명서.html')) {
        $it = Join-Path $par $nm; if (Test-Path -LiteralPath $it) { Copy-Item -LiteralPath $it -Destination $keep -Recurse -Force }
      }
    } else { Get-ChildItem -LiteralPath $distRoot -Force | Copy-Item -Destination $keep -Recurse -Force }
    Say ("이번 배포판을 " + $keep + " 에 보관 (되돌릴 때 그 폴더의 One MACS 폴더에서 install.ps1 -Update)")
  } catch { Say ("⚠️ 배포판 보관 실패: " + $_.Exception.Message + " — 설치는 계속합니다") }
} else { Say ("배포판 위치: " + $keep + " (버전별 보관 자리)") }
# 핸드폰 앱 파일 — 배포판에 같이 들어 있으면 콘솔 홈으로 옮긴다.
# 그러면 핸드폰으로 콘솔에 들어온 사람이 설정에서 [앱 받기] 로 내 PC 에서 바로 받는다(마켓 없이도 된다).
$appSrc = Join-Path $Here 'app'
if (Test-Path $appSrc) {
  $appDst = Join-Path $Con 'app'
  if (-not (Test-Path $appDst)) { New-Item -ItemType Directory -Force -Path $appDst | Out-Null }
  $apks = @(Get-ChildItem $appSrc -Filter *.apk -File -ErrorAction SilentlyContinue)
  foreach ($a in $apks) { Copy-Item -LiteralPath $a.FullName -Destination (Join-Path $appDst $a.Name) -Force }
  if ($apks.Count -gt 0) { Say ("핸드폰 앱 " + $apks.Count + "개 → " + $appDst + " (핸드폰 설정에서 [앱 받기])") }
}
# 외부 npm 의존성 없음 (package.json 에 dependencies 가 생기면 그때만 설치)
$pkg = Get-Content (Join-Path $Con 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($pkg.dependencies -and -not (Test-Path (Join-Path $Con 'node_modules'))) {
  Say "npm install (처음 한 번)"; Push-Location $Con; try { & npm install --no-audit --no-fund --loglevel=error 2>&1 | Select-Object -Last 2 } finally { Pop-Location }
}

# 4. 설정 (첫 설치만) — 이후 변경은 폰 ⚙ 설정 시트 또는 console_config.json 직접 편집
if ($firstInstall) {
  if (-not $PcLabel) { $PcLabel = $env:COMPUTERNAME }
  # PIN 번호: 6자리 숫자, 약한 값(반복·연속·흔한 번호) 거부 — 안 주거나 약하면 무작위로 만든다
  $weak = @('000000','111111','222222','333333','444444','555555','666666','777777','888888','999999','123456','654321','112233','121212','123123','000111','101010')
  $isWeak = { param($v) ($weak -contains $v) -or ($v -match '^(\d)\1{5}$') -or ($v -match '^(012345|123456|234567|345678|456789|567890|987654|876543|765432|654321|543210)$') }
  if ($Pin -and ($Pin -notmatch '^\d{6}$' -or (& $isWeak $Pin))) { Say ("⚠️ PIN '" + $Pin + "' 은 6자리가 아니거나 너무 쉬워서 쓰지 않습니다"); $Pin = '' }
  if (-not $Pin) { do { $Pin = [string](Get-Random -Minimum 100000 -Maximum 999999) } while (& $isWeak $Pin); Say ("PIN 을 새로 만들었습니다: " + $Pin + "  (폰 접속 때 입력, 나중에 폰 ⚙ 설정에서 변경)") }
  # 연결 코드: 대문자·숫자 8자리, I O 0 1 제외 — 형식이 틀리면 여기서 거부 (콘솔은 말없이 바꾸지 않는다)
  if ($PairCode) { $PairCode = $PairCode.Trim().ToUpper(); if ($PairCode -notmatch '^[A-HJ-NP-Z2-9]{8}$') { throw ("연결 코드 '" + $PairCode + "' 형식이 아닙니다: 대문자·숫자 8자리, I O 0 1 은 쓰지 않습니다 (예: KDP89XGA). 받은 코드를 다시 확인하세요") } }
  if ($HubMode -eq 'onemacs' -and -not $HubUrl) { $HubUrl = 'https://console-hub.consolesystem.workers.dev' }
  if ($HubMode -eq 'self' -and -not $HubUrl) { throw '-HubMode self 에는 -HubUrl (내 워커 주소) 이 필요합니다. One MACS 사용설명서.html 참조' }
  $cfg = [ordered]@{
    pin = $Pin; port = $Port; pc_label = $PcLabel
    primary = 'One MACS'
    projects = @([ordered]@{ name = 'One MACS'; dir = $Root; home = $true })
    projects_root = (Join-Path $Root '프로젝트')
    perm_mode = 'safe'; mirror_window = $true; show_quota = $false; theme = 'dark'   # 배포판 기본: 안전 모드(위험 명령은 확인), 한도 표시 끔 (PO 2026-09-21)
    tunnel_protocol = 'http2'
    legacy_hub = $false
    heartbeat_sec = 300
  }
  if ($HubMode -eq 'none') { $cfg.pair_hub_url = ''; $cfg.pair_code = '' } else { $cfg.pair_hub_url = $HubUrl.TrimEnd('/'); if ($PairCode) { $cfg.pair_code = $PairCode } }
  $json = $cfg | ConvertTo-Json -Depth 6
  [IO.File]::WriteAllText((Join-Path $Con 'console_config.json'), $json, (New-Object System.Text.UTF8Encoding($false)))
  Say ("설정 작성: PC 라벨 " + $PcLabel + " · 포트 " + $Port + " · 허브 " + $HubMode + $(if ($PairCode) { " · 코드 " + $PairCode } else { " (코드는 첫 기동 때 자동 생성)" }))
  New-Item -ItemType Directory -Force -Path $cfg.projects_root | Out-Null
} else { Say "기존 설정 유지 (console_config.json)" }

# 5. 규칙 파일 — Claude Code 지시문은 한 장(CLAUDE_CODE_지시문.md)이다(PO 2026-09-24). 그 3부의 표시 사이 내용을 꺼내 쓴다
function Get-RuleSection($name) {
  $f = Join-Path $Here 'CLAUDE_CODE_지시문.md'
  if (-not (Test-Path -LiteralPath $f)) { return '' }
  $t = [IO.File]::ReadAllText($f, [Text.Encoding]::UTF8)
  $m = [regex]::Match($t, '(?s)<!-- BEGIN:' + $name + ' -->\r?\n(.*?)\r?\n<!-- END:' + $name + ' -->')
  if ($m.Success) { return $m.Groups[1].Value } else { return '' }
}
# 5-a. One MACS 채널 규칙 (C:\OneMACS\CLAUDE.md — 처음 한 번만. 사용자가 고친 것은 덮지 않는다)
$homeMd = Get-RuleSection 'HOME_CLAUDE_MD'
if (-not (Test-Path (Join-Path $Root 'CLAUDE.md')) -and $homeMd) { [IO.File]::WriteAllText((Join-Path $Root 'CLAUDE.md'), $homeMd + "`n", (New-Object System.Text.UTF8Encoding($false))); Say "CLAUDE.md 작성" }

# 5-b. 사용자 공통 Claude 규칙(%USERPROFILE%\.claude\CLAUDE.md) — Jev 자문은 One MACS 채널만이 아니라 이 PC 의 모든 프로젝트·모드에서 (PO 2026-09-22)
$globalMd = Join-Path $env:USERPROFILE '.claude\CLAUDE.md'
$jevSec = Get-RuleSection 'JEV_RULES'
if ($jevSec) {
  $sec = $jevSec
  New-Item -ItemType Directory -Force (Split-Path -Parent $globalMd) | Out-Null
  $cur = if (Test-Path $globalMd) { [IO.File]::ReadAllText($globalMd, [Text.Encoding]::UTF8) } else { '' }
  if ($cur -notmatch 'Jev 자문') { [IO.File]::WriteAllText($globalMd, ($cur.TrimEnd() + "`n`n" + $sec).TrimStart(), (New-Object System.Text.UTF8Encoding($false))); Say "사용자 공통 CLAUDE.md 에 Jev 자문 규칙 추가 (모든 프로젝트·모드 적용)" }
}

# 6. 워치독 + 기동
if ($NoStart) { Say "-NoStart: 기동 생략"; exit 0 }
& cmd /c ('"' + (Join-Path $Con 'install_watchdog.cmd') + '"') | Out-Null
$wd = $null; try { $wd = Get-ScheduledTask -TaskName 'OneMACS-Watchdog' -ErrorAction Stop } catch {}
if ($wd) { Say "워치독 예약 작업 등록 (5분마다 생존 확인·자동 재기동)" } else { Say "⚠️ 워치독 예약 작업 등록 실패 — 콘솔이 죽어도 자동 재기동이 안 됩니다. 나중에 관리자 PowerShell 에서 console\install_watchdog.cmd 를 실행하세요" }
Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', ('"' + (Join-Path $Con 'start_console.cmd') + '"') -WindowStyle Hidden -WorkingDirectory $Con
$ok = $false
for ($i = 0; $i -lt 45 -and -not $ok; $i++) { Start-Sleep -Seconds 2; $ok = [bool](Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue) }
if (-not $ok) { Say ("⚠️ 90초 안에 포트 " + $Port + " 이 안 열렸습니다 — " + (Join-Path $Con 'start_all.log') + " 를 확인하세요"); exit 1 }
$cfgNow = Get-Content (Join-Path $Con 'console_config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
Say ("✅ 콘솔 기동 (포트 " + $Port + "). PIN " + $cfgNow.pin)
$log = Join-Path $Con 'start_all.log'; $url = $null
for ($i = 0; $i -lt 40 -and -not $url; $i++) { Start-Sleep -Seconds 3; if (Test-Path $log) { $m = Select-String -Path $log -Pattern '터널 URL 발급 성공: (https://\S+)' | Select-Object -Last 1; if ($m) { $url = $m.Matches[0].Groups[1].Value } } }
if ($url) { Say ("🌐 이 PC 의 콘솔 주소: " + $url + "   (재시작 때마다 바뀜 — 허브가 최신 주소를 알려준다)") } else { Say "⚠️ 터널 주소가 2분 안에 안 잡혔습니다 — 인터넷 연결과 start_all.log 확인" }
$code = $null; try { $code = (Get-Content (Join-Path $Con 'console_config.json') -Raw -Encoding UTF8 | ConvertFrom-Json).pair_code } catch {}
if ($cfgNow.pair_hub_url -and $code) { Say ("📱 폰에서 열 허브: " + $cfgNow.pair_hub_url + "/?code=" + $code + "   (앱에는 코드 " + $code + " 입력)") }
Say "끝. 폰(앱 또는 브라우저)에서 허브 → 이 PC → PIN 번호 입력 → 프로젝트 'One MACS' 에 인사를 보내 답이 오면 설치 완료."
