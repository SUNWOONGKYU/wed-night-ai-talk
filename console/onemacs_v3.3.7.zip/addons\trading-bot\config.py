# -*- coding: utf-8 -*-
"""Trader Bot 설정"""
import os
from datetime import time
from dotenv import load_dotenv

load_dotenv()

# === CPC / Supabase / Agent SDK 설정은 2026-06-13 _ARCHIVE_CPC_20260613/ 로 분리됨 ===
# (CPC 서버 미사용. 관련 코드·키 일체 아카이브)

# === KIS API ===
KIS_APP_KEY = os.getenv('KIS_APP_KEY', '')
KIS_APP_SECRET = os.getenv('KIS_APP_SECRET', '')
KIS_ACCOUNT = os.getenv('KIS_ACCOUNT', '')          # 8자리
KIS_ACCOUNT_PROD = os.getenv('KIS_ACCOUNT_PROD', '01')  # 01=주식, 03=선물옵션
KIS_ACCOUNT_PASSWORD = os.getenv('KIS_ACCOUNT_PASSWORD', '')
KIS_HTS_ID = os.getenv('KIS_HTS_ID', '')
KIS_PERSONAL_SEC_KEY = os.getenv('KIS_PERSONAL_SEC_KEY', '')  # 모의투자 개인비밀키

# 모의투자 전용 앱키 (실전과 별도 등록 — 없으면 실전 키 fallback)
KIS_PAPER_APP_KEY = os.getenv('KIS_PAPER_APP_KEY', '')
KIS_PAPER_APP_SECRET = os.getenv('KIS_PAPER_APP_SECRET', '')

# KIS 도메인
KIS_API_URL = 'https://openapi.koreainvestment.com:9443'    # 실전
KIS_WS_URL = 'ws://ops.koreainvestment.com:21000'           # 실전 WebSocket
KIS_PAPER_URL = 'https://openapivts.koreainvestment.com:29443'  # 모의
KIS_PAPER_WS_URL = 'ws://ops.koreainvestment.com:31000'     # 모의 WebSocket

# 모의투자 모드 (True=모의, False=실전)
KIS_PAPER_MODE = os.getenv('KIS_PAPER_MODE', 'true').lower() == 'true'

# === 텔레그램 봇 ===
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')

# === AI (선택) ===
# 텔레그램에서 버튼 대신 말로 지시할 때만 쓴다("오늘은 사지 마" 같은 문장).
# 없어도 봇은 그대로 돈다 — 버튼과 직접 명령(정지/재개/min_score 70)은 열쇠가 필요 없다.
# 2026-09-24: 이 줄이 없어서 손님이 아무 말이나 치면 파이썬 ImportError 문구가
# 그대로 텔레그램으로 나갔다.
ANTHROPIC_API_KEY = os.getenv('ANTHROPIC_API_KEY', '')

# === OpenRouter AI ===
OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY', '')
AI_MODEL = 'anthropic/claude-sonnet-4-20250514'

# === 안전 장치 ===
MAX_DAILY_TRADES = 30
MAX_DAILY_LOSS = 50_000  # KRW — 2026-09-21 실전 첫날(잔고 35만) 기준. 계좌 커지면 상향

# === 거래 승인 모드 (2026-06-08) ===
APPROVAL_REQUIRED = True   # True = 주문 전 사용자 승인 필수, False = 자동 실행
EXIT_APPROVAL_REQUIRED = True     # 청산(매도)도 텔레그램 승인 (2026-09-20 PO: 매수·매도 모두 승인)
EXIT_APPROVAL_TIMEOUT = 120       # 청산 승인 대기(초)
EXIT_STOPLOSS_AUTO_ON_TIMEOUT = True  # 손절 요청에 응답이 없으면 안전을 위해 자동 청산 (익절·트레일링은 응답 없으면 보류 후 재요청)
EXIT_REASK_SEC = 600              # 거절/보류 후 같은 포지션 청산 재요청 간격(초)
DAY_START_APPROVAL_REQUIRED = True  # 장 시작 전 '오늘 매매 시작' 텔레그램 승인 (2026-09-20 PO). 승인 전엔 신규 진입 없음, 청산 감시만
DAY_START_APPROVAL_TIMEOUT = 600    # 1회 대기(초). 응답 없으면 10분마다 다시 묻고 그동안 진입 없음
STRATEGY_LIVE_ENABLED = False  # strategies/*.json 의 live:true 전략으로 주문 허용 (2026-09-20 신설, 모의투자 검증 후 켤 것)

# === Sentry (매매 자동화 봇) ===
SENTRY_SCAN_INTERVAL = 60        # 스캔 간격 (초) = 1분
SENTRY_MIN_SCORE = 65            # 주문 최소 점수 (strategies.json 검증 기준)
SENTRY_FUTURES_MIN_SCORE = 65    # 선물 최소 점수
SENTRY_MAX_POSITIONS = 2         # 동시 보유 최대 포지션 (2026-09-21 잔고 35만 기준, 원래 5)
SENTRY_STOP_LOSS_PCT = 3.0       # 손절 %
SENTRY_TAKE_PROFIT_PCT = 5.0     # 익절 %
SENTRY_TRAILING_PCT = 3.0        # 트레일링 스탑 % (5%+ 수익 후 고점 대비 -3% 청산)
SENTRY_FORCE_CLOSE_TIME = time(15, 44)  # 강제 청산 시각 (내일 홀드용 — 15:44로 연장)
SENTRY_MARKET_OPEN = time(8, 45)        # 장 시작 (주식선물 8:45, 현물 9:00)
SENTRY_MARKET_CLOSE = time(15, 45)      # 장 마감 (주식선물 15:45 — PO 2026-09-21)
SENTRY_DEFAULT_QTY_FUTURES = 1   # 선물 기본 수량
SENTRY_DEFAULT_QTY_STOCK = 1     # 주식선물 기본 수량 (2026-09-21 잔고 35만 기준 1계약, 원래 2)
MAX_QTY_PER_STOCK = 3            # 한 종목에 쌓을 수 있는 최대 계약수 (PO 2026-09-23: 한 번에 1계약씩, 종목당 3계약까지)
MAX_NEW_STOCKS_PER_DAY = 2       # 하루에 새로 살 수 있는 종목 수 (PO 2026-09-23)
MINUTE_SCAN_ENABLED = False      # 290종목 분봉 2단계 스캔(5대장2졸병). PO 2026-09-23: 엣지 없음 →
                                 # 290종목은 아침 일봉으로 후보를 고르는 데만 쓴다

# === 시장 레짐 필터 (2026-06-12 교훈: 급등장 CALL 추격매수 엣지 부재) ===
# 강한 상승장에서는 6대장 CALL 조건이 고점 추격매수만 양산 → 승률·평균수익 0 수렴.
# KOSPI 프록시(KODEX200 069500)의 당일 등락률(%)로 진입을 게이트한다. PUT은 제한 안 함.
# ── 2026-06-19 레짐 게이트 재설계 (단순 원칙: 상승장에서만 롱 매수) ──
# 하락장이면 떨어지는 칼날 안 잡는다 → CALL 매수 금지. 상승/횡보장에서만 눌림목 매수.
REGIME_FILTER_ENABLED = True     # 레짐 게이트 활성화
REGIME_PROXY_TICKER = '069500'   # KOSPI 프록시 (KODEX200)
REGIME_BUY_FLOOR_PCT = -0.3      # KODEX200 당일 등락 이 % 미만이면 매수 금지(하락장)
REGIME_CACHE_SEC = 60            # 지수 조회 캐시 (초)

# === 상위 타임프레임(월/주/일봉) 추세 선별 (2026-06-18) ===
# 종목 선정 1단계: 월/주/일봉 상승 추세 종목만 CALL 매수 후보로 통과.
# 분봉 6대장(analysis.py)은 2단계 진입 타이밍만 담당. htf_filter.py 참조.
HTF_FILTER_ENABLED = True        # 상위 타임프레임 선별 활성화

# === PUT(숏) 비활성 (2026-06-18 연구결론) ===
# 신호 12,077건 분석: PUT 평균 10분 수익 -2.5%(횡보장 -2.9%), 순손실원. 숏 전면 금지.
# 6대장은 역추세 지표라 추세를 거슬러 숏치면 크게 깨짐. 롱(CALL)만 운용.
PUT_ENABLED = True               # PO 결정(2026-09-21): PUT(숏)도 승인 요청 대상 — 매수/매도 모두 사람이 텔레그램에서 결정. 자동 진입은 없음

# === 장기 모멘텀 전략 (2026-06-22 백테스트 검증 — momentum_strategy.py) ===
# 8년(2018~2026, 약세장 포함) 백테스트: 60일모멘텀+60일보유 = CAGR+19.2%/MDD-38%, 시장(+15%/-46%) 우위.
# 레짐게이트(시장 60일선 위에서만 진입)가 약세장 낙폭 방어 입증. 분봉 스캘핑과 별개로 하루 1회 스윙 진입.
# 청산은 시간기반(MOMENTUM_HOLD_DAYS 영업일 보유) — 분봉 손절/익절과 별도 트랙.
MOMENTUM_ENABLED = True           # True=장기 모멘텀 스윙 진입 활성화 (2026-06-22 연동·활성화, 진입은 텔레그램 승인 필수)
MOMENTUM_MIN_PCT = 0.10           # 60일 수익률 최소(10%)
MOMENTUM_TOP_N = 12               # 하루 진입 후보 상위 N (전체 유니버스라 넉넉히)
MOMENTUM_HOLD_DAYS = 60           # 보유 영업일 (시간기반 청산)
MOMENTUM_SCAN_HOUR = 9            # 일 1회 스캔 시각(시)

# ─── 과매도 반등 일봉 트랙 (2026-09-21 정식 검증 → 확장 게이트 사전 등록, 전진검증) ───
# 정본: wiki/연구/project_oversold_rebound_validation_20260921.md §11. 진입은 텔레그램 승인 필수.
OVERSOLD_ENABLED = True           # True=하락장 게이트 통과 시 과매도·저변동 종목 시가 매수 후보를 승인 요청
OVERSOLD_SCAN_HOUR = 8            # (하위호환) 일봉 트랙 스캔은 개장 08:45 첫 스캔 = 시가 근처 진입 (DAILY_STRATEGY_SCAN_TIME 참조)
OVERSOLD_TOP_N = 3                # 하루 후보 상위 N (저변동 순)
OVERSOLD_HOLD_DAYS = 20           # 보유 영업일 → 시가 청산(시간 청산). 손절 없음(파국 -15%만)
OVERSOLD_DEV60_MAX = -0.15        # 60일선 괴리 ≤ -15%
OVERSOLD_LOWVOL_PCT = 0.30        # 20일 변동성 횡단면 하위 30%

# ─── 일봉 전략 엔진 (2026-09-21 — daily_strategy_engine.py: strategies/*.json 중 timeframe "1d") ───
# 과매도 반등 트랙을 JSON 전략 규격으로 일반화. enabled && live 인 1d 전략(현재 3대장4졸병)을 09시 첫 스캔에 평가해
# 후보를 텔레그램 승인 요청 → 승인 시 주식선물 1계약 매수 → 청산_일봉트랙 규칙(시간 청산)으로 정리.
# OVERSOLD_ENABLED 는 하위호환 별칭(둘 중 하나라도 True 면 실행). 하드코딩판 oversold_strategy.get_candidates 는 더 이상 봇이 호출하지 않는다.
DAILY_STRATEGY_ENABLED = True     # True=일봉 전략(enabled+live) 후보를 승인 요청
DAILY_STRATEGY_SCAN_HOUR = OVERSOLD_SCAN_HOUR
DAILY_STRATEGY_SCAN_TIME = time(8, 45)   # 일봉 트랙 스캔 시각 = 주식선물 개장 (PO 2026-09-21: 8시 45분부터)
DAILY_STRATEGY_MAX_NEW_PER_DAY = 1       # R5-7: 같은 날 일봉 트랙 신규 진입 최대 건수(2026-09-22 심사 반영, 전진검증 첫 달 1건)

# ── 종합 신호 (PO 2026-09-22: "두 개를 종합해서 신호를 내야지") ──
# 일봉 전략(3대장4졸병)이 '종목'을 고르고, 분봉 타이밍 신호가 '언제'를 정해 하나의 승인 요청으로 낸다.
# 후보 밖 종목의 분봉 5대장2졸병 신호는 기록만(승인 요청 없음). 타이밍 창 안에 신호가 없으면 그날 포기(시가 추격 없음).
COMBINED_SIGNAL_ENABLED = True
TIMING_WINDOW_START = time(8, 45)    # 타이밍 감시 시작 = 주식선물 개장 (PO 2026-09-22 '08:45부터'). 오늘 분봉은 KIS 통합(KRX+NXT) 08:00 프리마켓부터 받아 개장 즉시 판정
TIMING_WINDOW_END = time(12, 0)
TIMING_RULES = ['3m_golden_5_20', 'open_breakout', 'boss_soldier_1m', 'vwap_volume']   # A 3분봉 5/20 골든크로스 · B 장초반 강세 · C 1분봉 5대장2졸병 · D VWAP+거래량 (PO 2026-09-22: 타입별로 따로 판정, 복합 금지)
TIMING_STAGE1_ENABLED = True         # 1단계 빠른 선별(당일 방향 일치·추격 금지)을 통과한 후보만 2단계 타입 판정
TIMING_B_MIN_PCT = 1.0               # B타입 전일 종가 대비 최소 등락(%)
TIMING_D_VOL_SURGE = 1.5             # D타입 거래량 급증 배수
TIMING_CROSS_LOOKBACK_BARS = 2       # 골든크로스가 최근 N개(완성) 3분봉 안에서 일어났으면 인정 (스캔 주기 60초 대비 여유)
DAILY_STRATEGY_HOLD_DAYS = OVERSOLD_HOLD_DAYS   # 운영 전략 청산_일봉트랙.보유_영업일 이 덮어씀
ENTRY_MAX_PRICE = 500000          # 종목당 가격 상한(원) — 1계약 명목(주가×10)이 자본을 넘지 않게. 운영 전략 자본.종목당_가격상한_원 이 덮어씀

# === 장전 NXT 돌파매수 (2026-06-24 신설 — breakout_strategy.py) ===
# 6대장(눌림목 시스템)이 갭상승·거래량돌파를 구조적으로 못 잡는 문제 보완.
# 장전(NXT 프리마켓)으로 추세 리더 워치리스트 고정 → 09:00~ 1분 단위 실시간 감시 →
# (전일고가 돌파 + 등락률 + 거래량 급증 + MA20 위) 충족 시 매수(텔레그램 승인 필수).
BREAKOUT_ENABLED = False           # 2026-09-22 PO: 후보 종목 밖 단독 승인 요청 금지 — 장초반 강세는 종합 신호 B타입으로 흡수(후보에만 적용)
BREAKOUT_STAGE_HOUR = 8            # 장전 워치리스트 고정 시각(시) — NXT 프리마켓 08:00~08:50
BREAKOUT_MIN_PCT = 2.0            # 당일 최소 등락률(%)
BREAKOUT_VOL_SURGE = 1.5         # 거래량 페이스 급증 배수(정상 대비)
BREAKOUT_RET60_MIN = 10.0        # 60일 추세 최소(%) — 리더만
BREAKOUT_MAX_PRICE = 150000       # 가격 상한 — 증거금(주가×10×~15%)이 잔고 35만을 넘지 않게 (원래 500000)
BREAKOUT_TOP_N = 12               # 워치리스트 종목 수(전체 유니버스라 넉넉히 — 저가 리더도 포함)

# === 스캔 유니버스 (2026-06-24) ===
# True=주식선물 가능 전체 종목(futures_map, ~250개)을 모멘텀·돌파 스캔 유니버스로.
# False=config_data/watchlist.json(소수 대형주)만. 사용자 요구: "몇 개 고르지 말고 선물 되는 전체 스캔".
SCAN_FUTURES_UNIVERSE = True

# === 사전검증 리더 자동매수 (2026-06-24 — 승인 병목 해소) ===
# 장전 워치리스트/모멘텀 '추세 리더'에 한해 승인 생략하고 자동 체결(소액 한도).
# 6대장 잡신호는 해당 없음(여전히 승인 필요). 청산은 손절/익절/트레일링 자동.
AUTO_BUY_VETTED = False           # 2026-09-21 실전 첫날: 자동매수 끔 — 모든 매수 텔레그램 승인 (원래 True)
AUTO_BUY_MAX_CONTRACTS = 1       # 자동매수 1회 최대 계약수
AUTO_BUY_DAILY_MAX = 2           # 하루 자동매수 최대 건수(폭주 방지)

# === 추격 방지 타이밍 가드 (2026-06-24) ===
# ★ 전역 규칙: 당일 +N% 이상 오른 종목은 어떤 트랙(모멘텀·돌파·6대장)도 매수하지 않는다(꼭지 추격 금지).
ENTRY_MAX_DAY_CHG_PCT = 5.0      # 당일 등락률 >= 이 값이면 신규 매수 전면 차단
# 돌파: 돌파 기준선(전일고가) 바로 위에서만 진입 — 이미 멀리 달아난 종목 추격 금지.
BREAKOUT_ENTRY_BUFFER = 0.02     # 기준선 +2% 이내에서만 진입(이 밴드 벗어나면 추격으로 보고 보류)

# === 장초반 조기진입 (2026-06-24) — 러너를 +5% 추격 전에 일찍 잡기 ===
# 사전검증 리더가 09:00~09:00+WINDOW에 (전일종가·시가 위 + 상승중 + 등락 < 5% 가드)면 조기 자동매수.
OPENING_ENTRY_ENABLED = True     # True=장초반 조기진입 활성
OPENING_WINDOW_MIN = 30          # 09:00부터 이 분(分)까지만 조기진입 허용
OPENING_MIN_CHG_PCT = 0.5        # 최소 상승 확인(전일종가 대비) — 이 이상 올라야 '강세'로 인정

# === 경로 ===
KNOWLEDGE_DIR = os.path.join(os.path.dirname(__file__), 'config_data')
DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')
LOG_DIR = os.path.join(DATA_DIR, 'logs')

# ═══════════════════════════════════════════════════════════════
# 운영 전략 파일(config_data/operating_strategy.json)이 위 기본값을 덮어쓴다 — PO 3대 구성요소 분리(2026-09-21)
#   ① 신호 전략 strategies/*.json  ② 운영 전략 operating_strategy.json  ③ 매매 자동화 봇 trader.py
# 파일이 없거나 항목이 빠지면 위 기본값 그대로. 값이 있으면 이 파일이 정본이다.
# ═══════════════════════════════════════════════════════════════
def _load_operating_strategy():
    import json as _json
    p = os.path.join(KNOWLEDGE_DIR, 'operating_strategy.json')
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding='utf-8') as f:
            return _json.load(f)
    except Exception:
        return None

_OPS = _load_operating_strategy()
if _OPS:
    _cap = _OPS.get('자본', {}); _apv = _OPS.get('승인', {}); _ex1 = _OPS.get('청산_분봉트랙', {}); _ex2 = _OPS.get('청산_일봉트랙', {}); _gate = _OPS.get('시장_게이트', {})
    def _pick(d, k, cur):
        v = d.get(k); return cur if v is None else v
    MAX_DAILY_LOSS = int(_pick(_cap, '일일_허용손실_원', MAX_DAILY_LOSS))
    # PO 2026-09-22 결정 6: 일일 허용손실 = 투자 자본금 × %(기본 10%). % 가 있으면 원 단위 값보다 우선
    _dl_pct = _cap.get('일일_허용손실_자본대비_pct')
    if _dl_pct and _cap.get('총투자금_원'):
        MAX_DAILY_LOSS = int(float(_cap['총투자금_원']) * float(_dl_pct) / 100.0)
    EXIT_STOPLOSS_AUTO = bool(_pick(_apv, '손절_자동청산', True))   # PO 결정 7: 손절은 승인 없이 자동
    DAILY_STRATEGY_TRAIL_ARM_PCT = _ex2.get('트레일링_발동_pct')    # 고점이 이만큼 오르면 트레일링 작동 (PO 2026-09-22)
    DAILY_STRATEGY_TRAIL_DROP_PCT = _ex2.get('트레일링_되밀림_pct')  # 고점 대비 이만큼 되밀리면 청산
    DAILY_STRATEGY_STOP_LOSS_PCT = _ex2.get('손절_pct')   # None = 손절 없음(파국손절만). 일봉 트랙(momentum) 포지션에만 적용
    DAILY_STRATEGY_CATASTROPHIC_PCT = float(_pick(_ex2, '파국손절_pct', 15.0))
    SENTRY_DEFAULT_QTY_STOCK = int(_pick(_cap, '기본_계약수', SENTRY_DEFAULT_QTY_STOCK))
    MAX_QTY_PER_STOCK = int(_pick(_cap, '종목별_최대_계약수', MAX_QTY_PER_STOCK))
    MAX_NEW_STOCKS_PER_DAY = int(_pick(_cap, '하루_신규진입_최대종목수', MAX_NEW_STOCKS_PER_DAY))
    SENTRY_MAX_POSITIONS = int(_pick(_cap, '동시_최대_포지션', SENTRY_MAX_POSITIONS))
    DAILY_STRATEGY_MAX_NEW_PER_DAY = int(_pick(_cap, '하루_신규진입_최대건수_일봉트랙', DAILY_STRATEGY_MAX_NEW_PER_DAY))
    _cmb = _OPS.get('종합_신호', {})
    COMBINED_SIGNAL_ENABLED = bool(_pick(_cmb, '사용', COMBINED_SIGNAL_ENABLED))
    _tr = _cmb.get('타이밍_규칙')
    if isinstance(_tr, list) and _tr:
        TIMING_RULES = [str(x) for x in _tr]
    for _k, _n in (('타이밍_창_시작', 'TIMING_WINDOW_START'), ('타이밍_창_종료', 'TIMING_WINDOW_END')):
        _v = _cmb.get(_k)
        if _v:
            try:
                _h, _m = [int(x) for x in str(_v).split(':')]; globals()[_n] = time(_h, _m)
            except Exception:
                pass
    APPROVAL_REQUIRED = bool(_pick(_apv, '매수_승인_필수', APPROVAL_REQUIRED))
    EXIT_APPROVAL_REQUIRED = bool(_pick(_apv, '청산_승인_필수', EXIT_APPROVAL_REQUIRED))
    EXIT_APPROVAL_TIMEOUT = int(_pick(_apv, '청산_승인_대기_초', EXIT_APPROVAL_TIMEOUT))
    EXIT_REASK_SEC = int(_pick(_apv, '청산_재요청_간격_초', EXIT_REASK_SEC))
    DAY_START_APPROVAL_REQUIRED = bool(_pick(_apv, '당일_매매시작_승인', DAY_START_APPROVAL_REQUIRED))
    DAY_START_APPROVAL_TIMEOUT = int(_pick(_apv, '당일_매매시작_대기_초', DAY_START_APPROVAL_TIMEOUT))
    AUTO_BUY_VETTED = bool(_pick(_apv, '사전검증_자동매수', AUTO_BUY_VETTED))
    PUT_ENABLED = bool(_pick(_apv, '매도(PUT)_신호도_승인요청', PUT_ENABLED))
    SENTRY_STOP_LOSS_PCT = float(_pick(_ex1, '손절_pct', SENTRY_STOP_LOSS_PCT))
    SENTRY_TAKE_PROFIT_PCT = float(_pick(_ex1, '익절_pct', SENTRY_TAKE_PROFIT_PCT))
    SENTRY_TRAILING_PCT = float(_pick(_ex1, '트레일링_pct', SENTRY_TRAILING_PCT))
    OVERSOLD_HOLD_DAYS = int(_pick(_ex2, '보유_영업일', OVERSOLD_HOLD_DAYS))
    DAILY_STRATEGY_HOLD_DAYS = OVERSOLD_HOLD_DAYS
    ENTRY_MAX_PRICE = int(_pick(_cap, '종목당_가격상한_원', ENTRY_MAX_PRICE))
    REGIME_FILTER_ENABLED = bool(_pick(_gate, '분봉트랙_하락장_매수금지', REGIME_FILTER_ENABLED))
    REGIME_BUY_FLOOR_PCT = float(_pick(_gate, '분봉트랙_KODEX200_당일등락_하한_pct', REGIME_BUY_FLOOR_PCT))
    HTF_FILTER_ENABLED = bool(_pick(_gate, '분봉트랙_상위추세_선별(HTF)', HTF_FILTER_ENABLED))
    _fc = _ex1.get('강제청산_시각')
    if _fc:
        try:
            _h, _m = [int(x) for x in str(_fc).split(':')]; SENTRY_FORCE_CLOSE_TIME = time(_h, _m)
        except Exception:
            pass
