# -*- coding: utf-8 -*-
"""
KIS (한국투자증권) API 연동
Trading_Stock/KIS_API 기반 — REST + WebSocket
"""
import os
import json
import time
import logging
import requests
from datetime import datetime
from config import (
    KIS_APP_KEY, KIS_APP_SECRET, KIS_ACCOUNT, KIS_ACCOUNT_PROD,
    KIS_HTS_ID, KIS_PERSONAL_SEC_KEY, KIS_PAPER_APP_KEY, KIS_PAPER_APP_SECRET,
    KIS_API_URL, KIS_WS_URL, KIS_PAPER_URL, KIS_PAPER_WS_URL, KIS_PAPER_MODE,
)

log = logging.getLogger(__name__)

# === Token 관리 (파일 캐시 — 프로세스 간 공유) ===

_TOKEN_CACHE_FILE = os.path.join(os.path.dirname(__file__), '.kis_token_cache.json')
_token = None
_token_expires = None

# 시세 조회 전용 토큰 (항상 실전 서버 — 모의투자 서버 타임아웃 회피)
_market_token = None
_market_token_expires = None
_MARKET_TOKEN_CACHE = os.path.join(os.path.dirname(__file__), '.kis_market_token_cache.json')


def _base_url():
    return KIS_PAPER_URL if KIS_PAPER_MODE else KIS_API_URL


def _ws_url():
    return KIS_PAPER_WS_URL if KIS_PAPER_MODE else KIS_WS_URL


def _base_headers():
    return {
        'Content-Type': 'application/json',
        'Accept': 'text/plain',
        'charset': 'UTF-8',
    }


def _load_token_cache():
    """파일에서 토큰 캐시 로드"""
    global _token, _token_expires
    try:
        if os.path.exists(_TOKEN_CACHE_FILE):
            with open(_TOKEN_CACHE_FILE, 'r') as f:
                cache = json.load(f)
            env = 'paper' if KIS_PAPER_MODE else 'real'
            if cache.get('env') == env and cache.get('token'):
                expires = datetime.strptime(cache['expires'], '%Y-%m-%d %H:%M:%S')
                if datetime.now() < expires:
                    _token = cache['token']
                    _token_expires = expires
                    return True
    except Exception:
        pass
    return False


def _save_token_cache(token, expires):
    """토큰을 파일에 저장"""
    try:
        env = 'paper' if KIS_PAPER_MODE else 'real'
        cache = {
            'env': env,
            'token': token,
            'expires': expires.strftime('%Y-%m-%d %H:%M:%S'),
        }
        with open(_TOKEN_CACHE_FILE, 'w') as f:
            json.dump(cache, f)
    except Exception as e:
        log.warning(f'[KIS] Token cache save failed: {e}')


def get_access_token():
    """OAuth2 접근 토큰 발급 (메모리 + 파일 캐시)"""
    global _token, _token_expires

    # 1. 메모리 캐시
    if _token and _token_expires and datetime.now() < _token_expires:
        return _token

    # 2. 파일 캐시 (프로세스 재시작 후에도 유효)
    if _load_token_cache():
        log.info(f'[KIS] Token loaded from cache, expires: {_token_expires}')
        return _token

    # 3. 신규 발급
    # 모의투자 전용 앱키가 있으면 모의 서버 + 모의 키 사용, 없으면 실전 키 fallback
    if KIS_PAPER_MODE and KIS_PAPER_APP_KEY:
        url = f'{KIS_PAPER_URL}/oauth2/tokenP'
        body = {
            'grant_type': 'client_credentials',
            'appkey': KIS_PAPER_APP_KEY,
            'appsecret': KIS_PAPER_APP_SECRET,
        }
    else:
        url = f'{_base_url()}/oauth2/tokenP'
        body = {
            'grant_type': 'client_credentials',
            'appkey': KIS_APP_KEY,
            'appsecret': KIS_APP_SECRET,
        }
    try:
        r = requests.post(url, json=body, headers=_base_headers(), timeout=10)
        r.raise_for_status()
        data = r.json()
        _token = data['access_token']
        _token_expires = datetime.strptime(data['access_token_token_expired'], '%Y-%m-%d %H:%M:%S')
        _save_token_cache(_token, _token_expires)
        log.info(f'[KIS] Token acquired, expires: {_token_expires}')
        return _token
    except Exception as e:
        log.error(f'[KIS] Token failed: {e}')
        return None


def _auth_headers(tr_id):
    """인증 포함 헤더 생성"""
    token = get_access_token()
    if not token:
        raise RuntimeError('KIS token not available')
    h = _base_headers()
    h['authorization'] = f'Bearer {token}'
    if KIS_PAPER_MODE and KIS_PAPER_APP_KEY:
        h['appkey'] = KIS_PAPER_APP_KEY
        h['appsecret'] = KIS_PAPER_APP_SECRET
    else:
        h['appkey'] = KIS_APP_KEY
        h['appsecret'] = KIS_APP_SECRET
    if KIS_PAPER_MODE and KIS_PERSONAL_SEC_KEY:
        h['personalseckey'] = KIS_PERSONAL_SEC_KEY
    h['tr_id'] = tr_id
    h['custtype'] = 'P'
    return h


# === REST API 호출 ===

def _get(api_path, tr_id, params):
    url = f'{_base_url()}{api_path}'
    headers = _auth_headers(tr_id)
    try:
        r = requests.get(url, headers=headers, params=params, timeout=15)
        r.raise_for_status()
        data = r.json()
        if data.get('rt_cd') == '0':
            return data
        log.warning(f'[KIS] {tr_id} error: {data.get("msg1", "")}')
        return None
    except Exception as e:
        log.error(f'[KIS] GET {api_path} failed: {e}')
        return None


def _post(api_path, tr_id, body):
    url = f'{_base_url()}{api_path}'
    headers = _auth_headers(tr_id)
    try:
        r = requests.post(url, headers=headers, json=body, timeout=15)
        r.raise_for_status()
        data = r.json()
        if data.get('rt_cd') == '0':
            return data
        log.warning(f'[KIS] {tr_id} error: msg1={data.get("msg1","")} / msg_cd={data.get("msg_cd","")} / rt_cd={data.get("rt_cd","")} / full={str(data)[:300]}')
        return None
    except Exception as e:
        log.error(f'[KIS] POST {api_path} failed: {e}')
        return None


# === 시세 조회 ===

def get_stock_price(ticker, market='UN'):
    """주식 현재가 조회.
    market: 'UN'=통합(KRX+NXT, 기본 — 양 거래소 합산 시세), 'J'=KRX 단독, 'NX'=넥스트레이드 단독(장전 08:00~08:50 포함).
    2026-06-24: 기본값을 'J'→'UN'으로 변경(대체거래소 NXT 유동성 반영)."""
    tr_id = 'FHKST01010100'
    mkt = market if market in ('J', 'NX', 'UN') else 'UN'
    data = _get('/uapi/domestic-stock/v1/quotations/inquire-price', tr_id,
                {'FID_COND_MRKT_DIV_CODE': mkt, 'FID_INPUT_ISCD': ticker})
    out = (data or {}).get('output', {}) if data else {}
    # 안전장치: 통합/NXT 조회가 비거나 가격 0이면 KRX(J)로 폴백 (특정 종목·시간대 무응답 방지)
    if (not data or int(out.get('stck_prpr', 0) or 0) <= 0) and mkt != 'J':
        data = _get('/uapi/domestic-stock/v1/quotations/inquire-price', tr_id,
                    {'FID_COND_MRKT_DIV_CODE': 'J', 'FID_INPUT_ISCD': ticker})
        out = (data or {}).get('output', {}) if data else {}
    if not data:
        return None
    return {
        'ticker': ticker,
        'price': int(out.get('stck_prpr', 0)),
        'change': int(out.get('prdy_vrss', 0)),
        'change_pct': float(out.get('prdy_ctrt', 0)),
        'volume': int(out.get('acml_vol', 0)),
        'high': int(out.get('stck_hgpr', 0)),
        'low': int(out.get('stck_lwpr', 0)),
        'open': int(out.get('stck_oprc', 0)),
        'prev_close': int(out.get('stck_prpr', 0)) - int(out.get('prdy_vrss', 0)),  # 전일 종가 = 현재가 − 전일대비
    }


def get_futures_price(code='A01609'):
    """지수선물 현재가 조회 (코스피200 선물).
    2026-06-22 수정: tr_id FHKIF03010100(없는 서비스 코드) → FHKIF03020200(분봉 차트).
    코드 포맷: A01+연1자리+월2자리 (예 A01609=2026-09). 기본값은 현 근월물."""
    from datetime import datetime, timezone, timedelta
    kst = datetime.now(timezone.utc) + timedelta(hours=9)
    params = {
        'FID_COND_MRKT_DIV_CODE': 'F',
        'FID_INPUT_ISCD': code,
        'FID_HOUR_CLS_CODE': '60',
        'FID_PW_DATA_INCU_YN': 'N',
        'FID_FAKE_TICK_INCU_YN': 'N',
        'FID_INPUT_DATE_1': kst.strftime('%Y%m%d'),
        'FID_INPUT_HOUR_1': kst.strftime('%H%M%S'),
    }
    data = _get('/uapi/domestic-futureoption/v1/quotations/inquire-time-fuopchartprice',
                'FHKIF03020200', params)
    if not data:
        return None
    out1 = data.get('output1', {}) or {}
    rows = data.get('output2', []) or []
    price = float(out1.get('futs_prpr', 0) or 0)
    change = float(out1.get('futs_prdy_vrss', 0) or 0)
    if price == 0 and rows:  # 장 외 등 실시간 0이면 최신 봉에서
        price = float(rows[0].get('futs_prpr', 0) or 0)
    return {
        'code': code,
        'price': price,
        'change': change,
        'volume': int(out1.get('acml_vol', 0) or 0),
    }


def get_stock_daily_ohlcv(ticker, period='D', count=100):
    """주식 일봉 OHLCV (기술적 분석용)"""
    tr_id = 'FHKST01010400'
    today = datetime.now().strftime('%Y%m%d')
    params = {
        'FID_COND_MRKT_DIV_CODE': 'J',
        'FID_INPUT_ISCD': ticker,
        'FID_INPUT_DATE_1': '',
        'FID_INPUT_DATE_2': today,
        'FID_PERIOD_DIV_CODE': period,
        'FID_ORG_ADJ_PRC': '0',
    }
    data = _get('/uapi/domestic-stock/v1/quotations/inquire-daily-price', tr_id, params)
    if not data:
        return None
    rows = data.get('output', [])[:count]
    import pandas as pd
    df = pd.DataFrame(rows)
    if df.empty:
        return None
    df = df.rename(columns={
        'stck_bsop_date': 'date',
        'stck_oprc': 'open', 'stck_hgpr': 'high',
        'stck_lwpr': 'low', 'stck_clpr': 'close',
        'acml_vol': 'volume',
    })
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df = df.sort_values('date').reset_index(drop=True)
    return df


# === 주문 ===

def place_order(ticker, side, qty, price=0):
    """
    주식 주문 (현금)
    side: 'buy' or 'sell'
    price: 0이면 시장가
    """
    if KIS_PAPER_MODE:
        tr_id = 'VTTC0012U' if side == 'buy' else 'VTTC0011U'
    else:
        tr_id = 'TTTC0012U' if side == 'buy' else 'TTTC0011U'

    ord_dvsn = '00' if price > 0 else '01'  # 00=지정가, 01=시장가
    body = {
        'CANO': KIS_ACCOUNT,
        'ACNT_PRDT_CD': KIS_ACCOUNT_PROD,
        'PDNO': ticker,
        'ORD_DVSN': ord_dvsn,
        'ORD_QTY': str(qty),
        'ORD_UNPR': str(price),
    }
    data = _post('/uapi/domestic-stock/v1/trading/order-cash', tr_id, body)
    if data:
        out = data.get('output', {})
        log.info(f'[KIS] Order OK: {side} {ticker} x{qty} (주문번호: {out.get("ODNO", "")})')
        return out
    return None


def get_balance():
    """계좌 잔고 조회"""
    tr_id = 'TTTC8434R'
    if KIS_PAPER_MODE:
        tr_id = 'VTTC8434R'

    params = {
        'CANO': KIS_ACCOUNT,
        'ACNT_PRDT_CD': KIS_ACCOUNT_PROD,
        'AFHR_FLPR_YN': 'N',
        'OFL_YN': '',
        'INQR_DVSN': '02',
        'UNPR_DVSN': '01',
        'FUND_STTL_ICLD_YN': 'N',
        'FNCG_AMT_AUTO_RDPT_YN': 'N',
        'PRCS_DVSN': '01',
        'CTX_AREA_FK100': '',
        'CTX_AREA_NK100': '',
    }
    data = _get('/uapi/domestic-stock/v1/trading/inquire-balance', tr_id, params)
    if not data:
        return None

    positions = []
    for item in data.get('output1', []):
        if int(item.get('hldg_qty', 0)) > 0:
            positions.append({
                'ticker': item.get('pdno', ''),
                'name': item.get('prdt_name', ''),
                'qty': int(item.get('hldg_qty', 0)),
                'avg_price': float(item.get('pchs_avg_pric', 0)),
                'current': int(item.get('prpr', 0)),
                'pnl': int(item.get('evlu_pfls_amt', 0)),
                'pnl_pct': float(item.get('evlu_pfls_rt', 0)),
            })

    summary = data.get('output2', [{}])[0] if data.get('output2') else {}
    return {
        'positions': positions,
        'total_eval': int(summary.get('tot_evlu_amt', 0)),
        'total_pnl': int(summary.get('evlu_pfls_smtl_amt', 0)),
        'cash': int(summary.get('dnca_tot_amt', 0)),
    }


def _decode_kis_name(raw):
    """KIS 잔고의 종목명이 이스케이프 문자열(\\uXXXX)로 오는 경우를 한글로 되돌리고 월물 꼬리를 뗀다.
    (2026-09-23 PO: 보유 포지션에 한글 종목명이 안 보임)"""
    import re as _re
    s = str(raw or "")
    try:
        if (chr(92) + "u") in s:            # 드물게 이스케이프로 오는 경우만 되돌린다 (이미 한글이면 그대로)
            s = s.encode("ascii", "ignore").decode("unicode_escape")
    except Exception:
        pass
    s = _re.sub(r"\s*[FC]\s*\d{6}.*$", "", s)   # "대한항공   F 202610 (  10)" → "대한항공"
    return s.strip()


def get_futures_balance():
    """선물옵션 계좌(03) 잔고 조회"""
    params = {
        'CANO': KIS_ACCOUNT,
        'ACNT_PRDT_CD': '03',
        'MGNA_DVSN': '01',   # 개시증거금
        'EXCC_STAT_CD': '1', # 정산
        'CTX_AREA_FK200': '',
        'CTX_AREA_NK200': '',
    }
    data = _get('/uapi/domestic-futureoption/v1/trading/inquire-balance', 'CTFO6118R', params)
    if not data:
        return None

    positions = []
    for item in data.get('output1', []):
        qty = int(item.get('cblc_qty', 0))
        if qty == 0:
            continue
        raw_name = item.get('prdt_name', '') or ''
        name = _decode_kis_name(raw_name)
        side = _decode_kis_name(item.get('sll_buy_dvsn_name', ''))
        positions.append({
            'name': name,
            'code': item.get('shtn_pdno', ''),
            'side': side,
            'qty': qty,
            'avg_price': float(item.get('ccld_avg_unpr1', 0)),
            'current': float(item.get('excc_unpr', 0)) or float(item.get('idx_clpr', 0)),
            'pnl': int(item.get('evlu_pfls_amt', 0)),
            'buy_amt': int(item.get('pchs_amt', 0)),
            'eval_amt': int(item.get('evlu_amt', 0)),
        })

    s = data.get('output2', {})
    if isinstance(s, list):
        s = s[0] if s else {}
    return {
        'positions': positions,
        'cash': int(s.get('dnca_cash', 0)),
        'margin': int(s.get('mgna_tota', 0)),
        'ord_psbl_cash': int(s.get('ord_psbl_cash', 0)),
        'trade_pnl': int(s.get('trad_pfls_amt_smtl', 0)),
        'eval_pnl': int(s.get('evlu_pfls_amt_smtl', 0)),
        'total_eval': int(s.get('evlu_amt_smtl', 0)),
        'buy_total': int(s.get('pchs_amt_smtl', 0)),
    }


def get_futures_orderable(fcode, side='buy', price=0):
    """선물옵션 주문가능수량 조회 (TTTO5105R 실전 / VTTO5105R 모의). 계좌의 실제 주문가능 계약수를 KIS 가 계산해 준다
    (증거금률·기존 포지션·평가손익 반영). 2026-09-22 교훈: 추정 15% 증거금으로는 통과했지만 KIS 가 '주문가능금액총액 초과' 로 거부.
    반환 {'qty': 주문가능수량, 'raw': ...} / 실패 시 None."""
    params = {
        'CANO': KIS_ACCOUNT,
        'ACNT_PRDT_CD': '03',
        'PDNO': fcode,
        'SLL_BUY_DVSN_CD': '02' if side == 'buy' else '01',
        'UNIT_PRICE': str(int(price or 0)),
        'ORD_DVSN_CD': '01' if price else '02',
    }
    tr = 'VTTO5105R' if KIS_PAPER_MODE else 'TTTO5105R'
    data = _get('/uapi/domestic-futureoption/v1/trading/inquire-psbl-order', tr, params)
    if not data:
        return None
    o = data.get('output', {}) or {}
    if isinstance(o, list):
        o = o[0] if o else {}
    try:
        qty = int(float(o.get('max_ord_psbl_qty') or o.get('ord_psbl_qty') or o.get('psbl_qty') or 0))
    except Exception:
        qty = 0
    return {'qty': qty, 'raw': o}


# === 선물옵션 주문 (KIS API) ===

def _krx_tick(price):
    """KRX 호가단위 (2023 개편 기준)."""
    if price < 2000:    return 1
    if price < 5000:    return 5
    if price < 20000:   return 10
    if price < 50000:   return 50
    if price < 200000:  return 100
    if price < 500000:  return 500
    return 1000


def place_futures_order(code, side, qty, price=0, night=False, stock_futures=False):
    """
    선물옵션 주문 — 지수선물/옵션 + 주식선물 통합
    code        : 단축상품번호
                  지수선물  6자리  예: 101W09
                  지수옵션  9자리  예: 201S03370
                  주식선물  종목별  예: KQ6M3 (기초자산코드+월물)
    side        : 'buy' or 'sell'
    price       : 0이면 시장가
    night       : 야간선물 여부 (실전만 지원, 지수선물/지수옵션 한정)
    stock_futures: True이면 주식선물 (FUOP_ITEM_DVSN_CD 구분)
    """
    if KIS_PAPER_MODE:
        tr_id = 'VTTO1101U'         # 모의 (주간만)
    elif night:
        tr_id = 'STTN1101U'         # 실전 야간 (지수선물/옵션)
    else:
        tr_id = 'TTTO1101U'         # 실전 주간

    market_order = (price == 0)
    if stock_futures and market_order:
        # 주식선물은 시장가(02)·최유리(04) 모두 불가(APBK0838/APBK2122) → 오직 지정가만 가능.
        # 현물 현재가 기준 마켓터블 지정가 산출(매수 +버퍼/매도 -버퍼). 체결은 실제 호가에 발생, 버퍼는 상/하한.
        import math
        from futures_map import get_stock_code
        scode = get_stock_code(code)
        sp = get_stock_price(scode) if scode else None
        cur = (sp or {}).get('price', 0)
        if not cur or cur <= 0:
            log.error(f'[KIS] 주식선물 {code} 현물({scode}) 현재가 조회 실패 — 주문 중단')
            return None
        tick = _krx_tick(cur)
        buf = 0.02
        if side == 'buy':
            price = int(math.ceil(cur * (1 + buf) / tick) * tick)
        else:
            price = int(math.floor(cur * (1 - buf) / tick) * tick)
        nmpr_type_cd = '01'
        ord_dvsn_cd  = '01'
        log.info(f'[KIS] 주식선물 {code} {side} 마켓터블 지정가 {price:,}원 (현물 {cur:,}, 버퍼 {buf:.0%})')
    elif market_order:
        nmpr_type_cd = '02'   # 지수선물/옵션 시장가
        ord_dvsn_cd  = '02'
    else:
        nmpr_type_cd = '01'   # 지정가
        ord_dvsn_cd  = '01'

    # 주식선물: FUOP_ITEM_DVSN_CD로 서버 측 구분
    fuop_item_dvsn_cd = '1' if stock_futures else ''

    body = {
        'ORD_PRCS_DVSN_CD': '02',                          # 주문전송
        'CANO': KIS_ACCOUNT,
        'ACNT_PRDT_CD': '03',                               # 선물옵션 계좌
        'SLL_BUY_DVSN_CD': '02' if side == 'buy' else '01',
        'SHTN_PDNO': code,
        'ORD_QTY': str(qty),
        'UNIT_PRICE': str(price),
        'NMPR_TYPE_CD': nmpr_type_cd,
        'KRX_NMPR_CNDT_CD': '0',                            # 없음(기본)
        'ORD_DVSN_CD': ord_dvsn_cd,
        'CTAC_TLNO': '',
        'FUOP_ITEM_DVSN_CD': fuop_item_dvsn_cd,
    }
    data = _post('/uapi/domestic-futureoption/v1/trading/order', tr_id, body)
    if data:
        kind = '주식선물' if stock_futures else '지수선물/옵션'
        log.info(f'[KIS] {kind} Order OK: {side} {code} x{qty}')
        return data.get('output', {})
    return None


# === 시세 전용 실전 서버 (모의투자 타임아웃 회피) ===

def _get_market_token():
    """시세 조회 전용 토큰 — 항상 실전 서버에서 발급 (PAPER_MODE 무관)"""
    global _market_token, _market_token_expires

    if _market_token and _market_token_expires and datetime.now() < _market_token_expires:
        return _market_token

    try:
        if os.path.exists(_MARKET_TOKEN_CACHE):
            with open(_MARKET_TOKEN_CACHE, 'r') as f:
                cache = json.load(f)
            if cache.get('token'):
                expires = datetime.strptime(cache['expires'], '%Y-%m-%d %H:%M:%S')
                if datetime.now() < expires:
                    _market_token = cache['token']
                    _market_token_expires = expires
                    return _market_token
    except Exception:
        pass

    url = f'{KIS_API_URL}/oauth2/tokenP'
    body = {'grant_type': 'client_credentials', 'appkey': KIS_APP_KEY, 'appsecret': KIS_APP_SECRET}
    try:
        r = requests.post(url, json=body, headers=_base_headers(), timeout=10)
        r.raise_for_status()
        data = r.json()
        _market_token = data['access_token']
        _market_token_expires = datetime.strptime(data['access_token_token_expired'], '%Y-%m-%d %H:%M:%S')
        try:
            with open(_MARKET_TOKEN_CACHE, 'w') as f:
                json.dump({'token': _market_token, 'expires': _market_token_expires.strftime('%Y-%m-%d %H:%M:%S')}, f)
        except Exception:
            pass
        log.info(f'[KIS] Market token acquired (실전서버), expires: {_market_token_expires}')
        return _market_token
    except Exception as e:
        log.error(f'[KIS] Market token failed: {e}')
        return None


def _get_market(api_path, tr_id, params):
    """시세 조회 전용 — 항상 실전 서버 사용, timeout=8초 (모의투자 서버 타임아웃 회피)"""
    token = _get_market_token()
    if not token:
        return None
    h = _base_headers()
    h['authorization'] = f'Bearer {token}'
    h['appkey'] = KIS_APP_KEY
    h['appsecret'] = KIS_APP_SECRET
    h['tr_id'] = tr_id
    h['custtype'] = 'P'
    url = f'{KIS_API_URL}{api_path}'
    try:
        r = requests.get(url, headers=h, params=params, timeout=8)
        r.raise_for_status()
        data = r.json()
        if data.get('rt_cd') == '0':
            return data
        log.warning(f'[KIS] market {tr_id}: {data.get("msg1", "")}')
        return None
    except Exception as e:
        log.error(f'[KIS] market GET {api_path}: {e}')
        return None


# === WebSocket (실시간 데이터) ===

def get_ws_approval_key():
    """WebSocket 접속키 발급"""
    url = f'{_base_url()}/oauth2/Approval'
    body = {
        'grant_type': 'client_credentials',
        'appkey': KIS_APP_KEY,
        'secretkey': KIS_APP_SECRET,
    }
    try:
        r = requests.post(url, json=body, headers=_base_headers(), timeout=10)
        r.raise_for_status()
        return r.json().get('approval_key')
    except Exception as e:
        log.error(f'[KIS] WS approval failed: {e}')
        return None
