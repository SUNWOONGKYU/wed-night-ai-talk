# -*- coding: utf-8 -*-
"""
262개 종목 5대장2졸병 2단계 스캐너
  1단계: 네이버 1분봉 (close+volume) → 262개 빠른 필터링
  2단계: 30점 이상만 KIS 1분봉 (OHLCV) → 정확한 신호
CALL/PUT 양방향 모두 체크
키움 REST API 복구 시 전환 예정
"""
import sys
import os
import re
import time
import logging
import requests
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    import yfinance as yf
    _YFINANCE_OK = True
except ImportError:
    _YFINANCE_OK = False

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

log = logging.getLogger(__name__)

from analysis import IndicatorEngine
try:
    import strategy_engine   # strategies/*.json 다중 전략 (없어도 스캐너는 동작)
except Exception as _e:
    strategy_engine = None
    log.warning(f'strategy_engine 로드 실패: {_e}')


def _eval_strategies(engine, df):
    """활성 전략 전부 평가 → 축약 결과 list. 실패 시 []"""
    if strategy_engine is None:
        return []
    try:
        return strategy_engine.compact(strategy_engine.evaluate_all(df.copy(), engine))
    except Exception as e:
        log.debug(f'전략 평가 실패: {e}')
        return []
# 옛 262 고정 목록 — futures_code_map.json 이 없을 때만 쓰는 폴백.
# 맵은 매일 08:40 자동 갱신되므로 평소에는 쓰이지 않는다. 배포판에서는 이 파일을 빼서
# 아래 임포트가 실패하고, 그때는 빈 목록으로 두고 맵만 쓴다 (2026-09-23).
try:
    from Trading_Stock.STOCK_CODES_262 import STOCK_CODES as _STOCK_CODES_262
except ImportError:
    _STOCK_CODES_262 = {}

def _load_universe_codes():
    """스캔 유니버스 = 지금 주식선물이 상장된 전 종목(futures_code_map.json, 매일 08:40 자동 갱신 — 현재 290).
    2026-09-21 PO: 손으로 고른 262 목록은 21종이 폐지·51종이 누락돼 있었음. 맵이 없으면 옛 262 로 폴백."""
    try:
        import json as _json
        _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'futures_code_map.json')
        with open(_p, encoding='utf-8') as _f:
            _m = _json.load(_f)
        _codes = _m.get('stock_to_futures', {})
        _names = _m.get('names', {})
        if len(_codes) >= 100:
            return {c: _names.get(c, _STOCK_CODES_262.get(c, c)) for c in _codes}
    except Exception:
        pass
    if not _STOCK_CODES_262:
        log.error('[Scanner] futures_code_map.json 을 읽지 못했고 폴백 목록도 없습니다. '
                  'python build_futures_map.py 를 먼저 실행하세요.')
    return dict(_STOCK_CODES_262)

STOCK_CODES = _load_universe_codes()
from kis import get_access_token, _get_market as _kis_get_raw, _get_market_token


# ── 설정 ──
MIN_SCORE = 65          # 6대장 전부(60) + 졸병 최소 1개(5) = 65점
STAGE1_MIN_SCORE = 50  # 1단계 필터 (5대장 이상)
CRASH_MIN_SCORE = 50   # 폭락장 특별 모드: K200 -3% 이하 + 소나K < 20 골든크로스
CRASH_K200_THRESHOLD = -3.0  # 폭락장 판정 기준 (%)

# 점수: 6대장 각 10점(최대60) + 2졸병 각 5점(최대10) = 최대 70점
SCORE_BOSS = 10
SCORE_SOLDIER = 5
API_DELAY = 0.1         # KIS 초당 ~10건
MIN_BARS = 3   # 최소 3봉부터 분석 시작
NAVER_DELAY = 0.03      # 네이버 빠름
STAGE1_WORKERS = 14     # 1단계 네이버 병렬 스캔 동시 워커 (검증된 안전치 15 이하)

# ── 종목명 캐시 ──
# 네이버 시세콜(get_stock_info_naver)을 매 스캔 종목마다 부르면 IP 스로틀(~3.6 req/s)에
# 묶여 1단계가 200초+ 걸린다. 종목명은 거의 안 바뀌므로 1회성 캐시(build_name_cache.py)로
# 박아두고, 스캔 중엔 분봉 1콜만 쓴다. 가격은 분봉 마지막 close, 등락률은 통과 신호만 KIS로.
import json as _json
_NAME_CACHE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'stock_names.json')
try:
    with open(_NAME_CACHE_PATH, 'r', encoding='utf-8') as _f:
        NAME_CACHE = _json.load(_f)
except Exception:
    NAME_CACHE = {}


def _kis_price_rate(code):
    """KIS 현재가조회(FHKST01010100) → (현재가, 등락률). 최종 통과 신호 표시용으로만 호출."""
    try:
        data = _get_retry(
            '/uapi/domestic-stock/v1/quotations/inquire-price',
            'FHKST01010100',
            {'FID_COND_MRKT_DIV_CODE': 'J', 'FID_INPUT_ISCD': code},
        )
        if data:
            out = data.get('output', {})
            return int(out.get('stck_prpr', 0) or 0), float(out.get('prdy_ctrt', 0) or 0)
    except Exception:
        pass
    return 0, 0.0


def _rate_from_bars(bars):
    """분봉 리스트에서 전일 종가 대비 등락률(%) 계산 — API 추가 호출 없음.
    bars: ts(YYYYMMDDHHMM) 오름차순 정렬 가정. 전일 마지막 봉 close 기준."""
    try:
        if not bars:
            return 0.0
        today = bars[-1]['ts'][:8]
        cur = bars[-1]['close']
        prev_close = None
        for b in reversed(bars):
            if b['ts'][:8] != today:
                prev_close = b['close']
                break
        if not prev_close:
            return 0.0
        return round((cur - prev_close) / prev_close * 100, 2)
    except Exception:
        return 0.0

# 코스피200 선물 설정
# KIS 실제 코드 (fo_idx_code_mts.mst.zip 마스터 파일 기준)
# A01 = KOSPI200 선물, 형식: A01{YY}{MM} — 예) 2026년 6월물 = A01606, 9월물 = A01609
# 분기물: 3월/6월/9월/12월 (매 분기 2번째 목요일 만기)

def _get_futures_code():
    """현재 날짜 기준 최선월 KOSPI200 선물 코드 자동 선택 (만기 5일 전 롤오버)
    분기물: 3월/6월/9월/12월, 매 분기 2번째 목요일 만기
    """
    from datetime import datetime, timezone, timedelta, date
    import calendar

    today = (datetime.now(timezone.utc) + timedelta(hours=9)).date()

    def second_thursday(y, m):
        cal = calendar.monthcalendar(y, m)
        thursdays = [w[3] for w in cal if w[3] > 0]
        return date(y, m, thursdays[1])

    # 향후 2년치 분기월 후보 생성
    candidates = []
    for y in [today.year, today.year + 1]:
        for m in [3, 6, 9, 12]:
            expiry = second_thursday(y, m)
            candidates.append((expiry, y, m))

    # 만기 5일 이상 남은 가장 가까운 분기물 선택
    for expiry, y, m in sorted(candidates):
        if (expiry - today).days > 5:
            # KIS 지수선물 코드는 연도 '1자리' (2026→6): A01609. (기존 2자리 A012609는 KIS 미인식 → 빈 응답 버그)
            yy = str(y)[-1:]
            mm = f'{m:02d}'
            return f'A01{yy}{mm}'

    return 'A01609'  # 최후 fallback (2026-09)

KOSPI200_FUTURES_CODE = _get_futures_code()
KOSPI200_FUTURES_NEXT = None  # 롤오버 시 자동 계산


def _get_retry(path, tr_id, params, retries=1, timeout_sec=5):
    """KIS GET with retry (futures 전용 - 빠른 실패)"""
    # 선물 조회는 실패할 가능성이 높으므로 빠르게 포기
    for attempt in range(retries + 1):
        try:
            result = _kis_get_raw(path, tr_id, params)
            if result is not None:
                return result
        except Exception:
            pass
        if attempt < retries:
            time.sleep(0.5)  # 짧은 대기
    return None


# ═══════════════════════════════════════════
#  코스피200 선물 (KIS API)
# ═══════════════════════════════════════════

def get_futures_info_kis(code=KOSPI200_FUTURES_CODE):
    """선물 현재가 + 등락률 (KIS) - FHKIF03020200 분봉에서 현재가 추출"""
    kst = _kst_now()
    today = kst.strftime('%Y%m%d')
    try:
        params = {
            'FID_COND_MRKT_DIV_CODE': 'F',
            'FID_INPUT_ISCD': code,
            'FID_HOUR_CLS_CODE': '60',
            'FID_PW_DATA_INCU_YN': 'N',
            'FID_FAKE_TICK_INCU_YN': 'N',
            'FID_INPUT_DATE_1': today,
            'FID_INPUT_HOUR_1': '154559',
        }
        data = _get_retry(
            '/uapi/domestic-futureoption/v1/quotations/inquire-time-fuopchartprice',
            'FHKIF03020200', params
        )
        if not data:
            return 'KOSPI200선물', 0, 0.0
        out1 = data.get('output1', {})
        rows = data.get('output2', [])
        # output1에서 현재가 시도
        price = float(out1.get('futs_prpr', 0) or 0)
        change_pct = float(out1.get('futs_prdy_ctrt', 0) or 0)
        # output1 없으면 bars 마지막 봉에서 추출
        if price == 0 and rows:
            valid = [r for r in rows if float(r.get('futs_prpr', 0) or 0) > 0]
            if valid:
                last = valid[0]  # 최신 봉 (역순 정렬)
                price = float(last.get('futs_prpr', 0))
                first = valid[-1]
                open_price = float(first.get('futs_oprc', 0) or price)
                if open_price > 0:
                    change_pct = round((price - open_price) / open_price * 100, 2)
        return 'KOSPI200선물', price, change_pct
    except:
        return 'KOSPI200선물', 0, 0.0


def get_minute_bars_futures_kis(code=KOSPI200_FUTURES_CODE, pages=3):
    """KIS 선물옵션 분봉조회 (FHKIF03020200) - 1분봉 OHLCV (주간+야간)"""
    all_bars = []
    seen_ts = set()
    kst = _kst_now()
    today = kst.strftime('%Y%m%d')
    h_now = kst.hour

    # 현재 세션 판단
    # 야간: 18:00-23:59 → next_hour=현재시각
    # 야간: 00:00-05:00 → next_hour=현재시각
    # 주간: 09:00-15:45 → next_hour=현재시각
    # 장 마감 후(15:45-18:00): 주간 마지막 봉 조회
    if h_now >= 18:
        next_hour = kst.strftime('%H%M') + '59'
        night_session = True
    elif h_now < 6:
        next_hour = kst.strftime('%H%M') + '59'
        night_session = True
    else:
        next_hour = kst.strftime('%H%M') + '59' if h_now < 16 else '154559'
        night_session = False

    for _ in range(pages):
        params = {
            'FID_COND_MRKT_DIV_CODE': 'F',
            'FID_INPUT_ISCD': code,
            'FID_HOUR_CLS_CODE': '60',
            'FID_PW_DATA_INCU_YN': 'N',
            'FID_FAKE_TICK_INCU_YN': 'N',
            'FID_INPUT_DATE_1': today,
            'FID_INPUT_HOUR_1': next_hour,
        }
        data = _get_retry(
            '/uapi/domestic-futureoption/v1/quotations/inquire-time-fuopchartprice',
            'FHKIF03020200', params
        )
        if not data:
            break

        rows = data.get('output2', [])
        if not rows:
            break

        for row in rows:
            try:
                hhmm = row.get('futs_cntg_hour', row.get('stck_cntg_hour', ''))[:4]
                if not hhmm:
                    continue
                # 주간: 0900-1545, 야간: 1800-2359 or 0000-0500
                is_day = '0900' <= hhmm <= '1545'
                is_night = hhmm >= '1800' or hhmm <= '0500'
                if not (is_day or is_night):
                    continue
                dt = row.get('stck_bsop_date', row.get('futs_bsop_date', today))
                ts = dt + row.get('futs_cntg_hour', row.get('stck_cntg_hour', ''))
                if ts in seen_ts:
                    continue
                seen_ts.add(ts)

                o = float(row.get('futs_oprc', row.get('stck_oprc', 0)))
                h = float(row.get('futs_hgpr', row.get('stck_hgpr', 0)))
                l = float(row.get('futs_lwpr', row.get('stck_lwpr', 0)))
                c = float(row.get('futs_prpr', row.get('stck_prpr', 0)))
                v = int(row.get('cntg_vol', row.get('acml_vol', 0)))
                if c > 0 and o > 0:
                    all_bars.append({
                        'ts': ts, 'open': o, 'high': h, 'low': l,
                        'close': c, 'volume': v,
                    })
            except:
                continue

        last_hour = rows[-1].get('futs_cntg_hour', rows[-1].get('stck_cntg_hour', ''))
        if not last_hour:
            break
        # 야간 세션이면 1800 이하까지, 주간이면 0900 이하까지 페이징
        if night_session and last_hour <= '180000':
            break
        elif not night_session and last_hour <= '090000':
            break
        next_hour = last_hour

        time.sleep(API_DELAY)

    all_bars.sort(key=lambda x: x['ts'])
    for b in all_bars:
        del b['ts']
    return all_bars


def _kst_now():
    return datetime.now(timezone.utc) + timedelta(hours=9)


# ═══════════════════════════════════════════
#  1단계: 네이버 1분봉 (close+volume)
# ═══════════════════════════════════════════

def get_minute_bars_naver(code):
    """
    네이버 siseJson 1분봉 (close + volume만 존재)
    O=H=L=C=close 로 DataFrame 구성 — 3거래일치 조회 (50봉 이상 보장)
    """
    try:
        kst = _kst_now()
        today = kst.strftime('%Y%m%d')
        start = (kst - timedelta(days=5)).strftime('%Y%m%d')  # 주말 포함 5일 전
        url = (f'https://api.finance.naver.com/siseJson.naver?symbol={code}'
               f'&requestType=1&startTime={start}&endTime={today}&timeframe=minute')
        r = requests.get(url, timeout=2, headers={'User-Agent': 'Mozilla/5.0'}, allow_redirects=False)
        if r.status_code != 200:
            return []

        bars = []
        for line in r.text.split('\n'):
            line = line.strip()
            if not line or '"202' not in line:
                continue
            line = line.strip().rstrip(',')
            # ["202602261530", null, null, null, 218000, 29904892, null]
            line = line.replace('[', '').replace(']', '').replace('"', '')
            parts = [p.strip() for p in line.split(',')]
            if len(parts) < 6:
                continue

            ts = parts[0]
            close_str = parts[4]
            vol_str = parts[5]

            if close_str == 'null' or not close_str:
                continue

            try:
                c = int(close_str)
                v = int(vol_str) if vol_str != 'null' else 0
                if c > 0:
                    # 장중 봉만 (0901~1530)
                    hhmm = ts[8:12] if len(ts) >= 12 else ''
                    if hhmm and '0901' <= hhmm <= '1530':
                        bars.append({
                            'ts': ts,
                            'open': c, 'high': c, 'low': c,
                            'close': c, 'volume': v,
                        })
            except:
                continue

        # 시간순 정렬 (네이버는 역순 반환)
        bars.sort(key=lambda x: x['ts'])

        # 날짜별로 그룹핑 후 누적 거래량 → 봉별 거래량 변환
        from collections import defaultdict
        day_groups = defaultdict(list)
        for b in bars:
            day_groups[b['ts'][:8]].append(b)

        result = []
        for date in sorted(day_groups.keys()):
            day = day_groups[date]
            # 역순으로 delta 변환 (당일 내에서만)
            for i in range(len(day) - 1, 0, -1):
                diff = day[i]['volume'] - day[i-1]['volume']
                day[i]['volume'] = max(diff, 0)
            result.extend(day)

        return result   # 'ts' 유지 — 등락률 계산(_rate_from_bars)에 필요, 지표는 컬럼 명시 선택이라 무해
    except:
        return []


# ═══════════════════════════════════════════
#  2단계: KIS 1분봉 (진짜 OHLCV)
# ═══════════════════════════════════════════

ADX_MIN_BARS = 60   # 당일 봉이 이 미만이면 전일치로 워밍업 (장초반 ADX(14) 계산 불가 방지)


def _fetch_kis_day_bars(code, date):
    """특정 과거 일자의 분봉 (FHKST03010230 일별분봉, 1콜 ~120봉). 장초반 ADX 워밍업용."""
    params = {
        'FID_COND_MRKT_DIV_CODE': 'J',
        'FID_INPUT_ISCD': code,
        'FID_INPUT_HOUR_1': '153000',
        'FID_INPUT_DATE_1': date,
        'FID_PW_DATA_INCU_YN': 'N',
        'FID_FAKE_TICK_INCU_YN': 'N',
    }
    data = _get_retry(
        '/uapi/domestic-stock/v1/quotations/inquire-time-dailychartprice',
        'FHKST03010230', params, timeout_sec=8
    )
    if not data or str(data.get('rt_cd')) != '0':
        return []
    out = []
    for row in data.get('output2', []):
        try:
            hhmm = row.get('stck_cntg_hour', '')[:4]
            if hhmm < '0901' or hhmm > '1530':
                continue
            o = int(row.get('stck_oprc', 0)); h = int(row.get('stck_hgpr', 0))
            l = int(row.get('stck_lwpr', 0)); c = int(row.get('stck_prpr', 0))
            v = int(row.get('cntg_vol', 0))
            if c > 0 and o > 0:
                out.append({
                    'ts': row.get('stck_bsop_date', '') + row.get('stck_cntg_hour', ''),
                    'open': o, 'high': h, 'low': l, 'close': c, 'volume': v,
                })
        except Exception:
            continue
    return out


def get_minute_bars_union(code, pages=20):
    """KIS 통합(UN = KRX + 넥스트레이드) 오늘 1분봉 — 08:00 프리마켓부터 (PO 2026-09-22: "제2거래소는 8시부터 거래되는데 왜 9시까지 기다리나").
    오늘 봉을 최신 시각부터 거슬러 받아 08:00 에 닿으면 멈춘다. 실패·비어 있으면 [] (호출부가 네이버로 폴백).
    반환 [{'ts': 'YYYYMMDDHHMM', 'open','high','low','close','volume'}] 시간순."""
    out = []
    seen = set()
    kst = _kst_now()
    today = kst.strftime('%Y%m%d')
    hhmm_now = kst.strftime('%H%M')
    next_hour = (hhmm_now if hhmm_now < '1530' else '1530') + '59'   # 정규장 마감 뒤에는 15:30 부터 거슬러(애프터마켓 페이지 낭비 방지)
    for _ in range(pages):
        params = {
            'FID_ETC_CLS_CODE': '',
            'FID_COND_MRKT_DIV_CODE': 'UN',
            'FID_INPUT_ISCD': code,
            'FID_INPUT_HOUR_1': next_hour,
            'FID_PW_DATA_INCU_YN': 'Y',
        }
        data = _get_retry('/uapi/domestic-stock/v1/quotations/inquire-time-itemchartprice', 'FHKST03010200', params)
        rows = (data or {}).get('output2') or []
        if not rows:
            break
        oldest = None
        for row in rows:
            try:
                d8 = row.get('stck_bsop_date', '')
                hhmm = row.get('stck_cntg_hour', '')[:4]
                if not hhmm:
                    continue
                oldest = hhmm if oldest is None or hhmm < oldest else oldest   # 페이지 이동 기준(필터 전)
                if d8 != today:
                    continue
                if hhmm < '0800' or hhmm > '1530':
                    continue   # 08:00 프리마켓 ~ 15:30 정규장만 (애프터마켓 15:30~20:00 제외)
                ts = d8 + hhmm
                if ts in seen:
                    continue
                seen.add(ts)
                c = int(row.get('stck_prpr', 0) or 0)
                if c <= 0:
                    continue
                out.append({'ts': ts, 'open': int(row.get('stck_oprc', 0) or c), 'high': int(row.get('stck_hgpr', 0) or c),
                            'low': int(row.get('stck_lwpr', 0) or c), 'close': c, 'volume': int(row.get('cntg_vol', 0) or 0)})
            except Exception:
                continue
        if not oldest or oldest <= '0800':
            break
        # 다음 페이지: 가장 오래된 봉 1분 전
        h, m = int(oldest[:2]), int(oldest[2:])
        m -= 1
        if m < 0:
            h -= 1; m = 59
        next_hour = f'{h:02d}{m:02d}59'
    out.sort(key=lambda x: x['ts'])
    return out


def get_minute_bars_kis(code, pages=3):
    """KIS 주식분봉 OHLCV. 당일분봉(FHKST03010200) + 부족 시 전일치(FHKST03010230) 워밍업."""
    all_bars = []
    seen_ts = set()
    kst = _kst_now()
    if kst.hour < 15 or (kst.hour == 15 and kst.minute <= 30):
        next_hour = kst.strftime('%H%M') + '59'
    else:
        next_hour = '153059'

    for _ in range(pages):
        params = {
            'FID_ETC_CLS_CODE': '',
            'FID_COND_MRKT_DIV_CODE': 'J',
            'FID_INPUT_ISCD': code,
            'FID_INPUT_HOUR_1': next_hour,
            'FID_PW_DATA_INCU_YN': 'N',
        }
        data = _get_retry(
            '/uapi/domestic-stock/v1/quotations/inquire-time-itemchartprice',
            'FHKST03010200', params
        )
        if not data:
            break

        rows = data.get('output2', [])
        if not rows:
            break

        for row in rows:
            try:
                hhmm = row.get('stck_cntg_hour', '')[:4]
                if hhmm < '0901' or hhmm > '1530':
                    continue
                ts = row.get('stck_bsop_date', '') + row.get('stck_cntg_hour', '')
                if ts in seen_ts:
                    continue
                seen_ts.add(ts)

                o = int(row.get('stck_oprc', 0))
                h = int(row.get('stck_hgpr', 0))
                l = int(row.get('stck_lwpr', 0))
                c = int(row.get('stck_prpr', 0))
                v = int(row.get('cntg_vol', 0))
                if c > 0 and o > 0:
                    all_bars.append({
                        'ts': ts, 'open': o, 'high': h, 'low': l,
                        'close': c, 'volume': v,
                    })
            except:
                continue

        last_hour = rows[-1].get('stck_cntg_hour', '')
        if not last_hour or last_hour <= '090000':
            break
        next_hour = last_hour

        time.sleep(API_DELAY)

    # 장초반엔 당일 봉이 부족해 ADX(14) 등이 계산 안 됨 → 전일 트레이딩데이 분봉으로 워밍업
    if len(all_bars) < ADX_MIN_BARS:
        for back in range(1, 6):
            d = (kst - timedelta(days=back)).strftime('%Y%m%d')
            prev = _fetch_kis_day_bars(code, d)
            if prev:
                for b in prev:
                    if b['ts'] not in seen_ts:
                        seen_ts.add(b['ts'])
                        all_bars.append(b)
                break

    all_bars.sort(key=lambda x: x['ts'])
    for b in all_bars:
        del b['ts']
    return all_bars


def get_stock_info_naver(code):
    """종목명 + 현재가 + 등락률"""
    try:
        r = requests.get(
            f'https://m.stock.naver.com/api/stock/{code}/basic',
            timeout=1.5, headers={'User-Agent': 'Mozilla/5.0'}, allow_redirects=False
        )
        if r.status_code == 200:
            d = r.json()
            return (
                d.get('stockName', code),
                int(d.get('closePrice', '0').replace(',', '')),
                float(d.get('fluctuationsRatio', '0')),
            )
    except Exception:
        pass
    return code, 0, 0.0


def get_naver_prices_parallel(codes, max_workers=15):
    """262개 종목의 현재가 + 등락률을 병렬로 빠르게 조회 (약 20-30초)"""
    prices = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(get_stock_info_naver, code): code for code in codes}
        for i, future in enumerate(as_completed(futures)):
            code = futures[future]
            try:
                name, price, rate = future.result()
                prices[code] = {'name': name, 'price': price, 'rate': rate}
                if (i + 1) % 50 == 0:
                    print(f"  [가격 로드] {i+1}/{len(codes)}개 완료")
            except Exception:
                prices[code] = {'name': code, 'price': 0, 'rate': 0.0}
    return prices


def get_naver_bars_parallel(codes, max_workers=10):
    """262개 종목의 1분봉을 병렬로 빠르게 조회"""
    bars_dict = {}
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(get_minute_bars_naver, code): code for code in codes}
        for i, future in enumerate(as_completed(futures)):
            code = futures[future]
            try:
                bars = future.result()
                bars_dict[code] = bars
                if (i + 1) % 50 == 0:
                    print(f"  [1분봉 로드] {i+1}/{len(codes)}개 완료")
            except Exception:
                bars_dict[code] = []
    return bars_dict


# ═══════════════════════════════════════════
#  점수 계산
# ═══════════════════════════════════════════

def score_signal(signal_result):
    """5대장 각 10점 + 2졸병 각 5점 = 최대 60점"""
    if signal_result is None:
        return 0, 0, 0
    bosses = signal_result['bosses']
    soldiers = signal_result['soldiers']
    bc = sum(1 for v in bosses.values() if v)
    sc = sum(1 for v in soldiers.values() if v)
    return bc * SCORE_BOSS + sc * SCORE_SOLDIER, bc, sc


def validate_signal(engine, df, min_wr=50, lookback=50):
    """
    승률 검증: 해당 종목의 1분봉 데이터로 미니 백테스트
    CALL/PUT 각각 승률 50%+ 인 방향만 유효 신호로 인정
    """
    if len(df) < lookback + 20:
        return {'call': False, 'put': False}

    call_wins, call_total = 0, 0
    put_wins, put_total = 0, 0

    for end in range(lookback, len(df) - 5):
        window = df.iloc[end-lookback:end+1].reset_index(drop=True)
        ohlcv = window[['open', 'high', 'low', 'close', 'volume']].copy()

        call = engine.check_call_signal(ohlcv.copy())
        put = engine.check_put_signal(ohlcv.copy())

        close_now = window.iloc[-1]['close']
        close_5m = df.iloc[end + 5]['close']

        if call:
            bc = sum(1 for v in call['bosses'].values() if v)
            sc = sum(1 for v in call['soldiers'].values() if v)
            if bc * SCORE_BOSS + sc * SCORE_SOLDIER >= MIN_SCORE:
                call_total += 1
                if close_5m > close_now:
                    call_wins += 1

        if put:
            bc = sum(1 for v in put['bosses'].values() if v)
            sc = sum(1 for v in put['soldiers'].values() if v)
            if bc * SCORE_BOSS + sc * SCORE_SOLDIER >= MIN_SCORE:
                put_total += 1
                if close_5m < close_now:
                    put_wins += 1

    call_wr = (call_wins / call_total * 100) if call_total >= 10 else 0
    put_wr = (put_wins / put_total * 100) if put_total >= 10 else 0

    return {
        'call': call_wr >= min_wr,
        'put': put_wr >= min_wr,
        'call_wr': call_wr,
        'put_wr': put_wr,
        'call_n': call_total,
        'put_n': put_total,
    }


def analyze_both(engine, df, direction=None):
    """CALL/PUT 양방향 체크.

    direction 을 주면 그쪽만 계산한다 — 타이밍 C 는 한쪽 점수만 쓰는데 매 스캔마다
    양쪽을 다 돌리고 하나를 버리고 있었다 (2026-09-24 채점자 지적).
    """
    want = str(direction).upper() if direction else None
    out = {}
    if want != 'PUT':
        call = engine.check_call_signal(df.copy())
        cs, cb, css = score_signal(call)
        out['call'] = {'score': cs, 'boss': cb, 'soldier': css, 'signal': call}
    if want != 'CALL':
        put = engine.check_put_signal(df.copy())
        ps, pb, pss = score_signal(put)
        out['put'] = {'score': ps, 'boss': pb, 'soldier': pss, 'signal': put}
    return out


# ═══════════════════════════════════════════
#  KOSPI200 지수 데이터
# ═══════════════════════════════════════════

_KODEX200_CODE = '069500'   # KODEX 200 ETF — KOSPI200 완벽 추적
_KODEX200_SCALE = 100.0     # KOSPI200 ≈ KODEX200가격 / 100


def _get_kospi200_spot_kis():
    """KIS FHPST02400000 → KOSPI200 현물지수 + 베이시스 = 선물 추정가
    Returns (spot_price, futures_price, rate) or (0, 0, 0.0)
    """
    from datetime import date, timedelta
    try:
        from kis import get_access_token, KIS_API_URL, KIS_APP_KEY, KIS_APP_SECRET
        import requests as _req
        tok = get_access_token()
        h = {
            'Content-Type': 'application/json',
            'authorization': 'Bearer ' + tok,
            'appkey': KIS_APP_KEY,
            'appsecret': KIS_APP_SECRET,
            'tr_id': 'FHPST02400000',
        }
        p = {'fid_cond_mrkt_div_code': 'U', 'fid_input_iscd': '2001'}
        r = _req.get(KIS_API_URL + '/uapi/domestic-stock/v1/quotations/inquire-index-price',
                     headers=h, params=p, timeout=3)
        d = r.json()
        if d.get('rt_cd') == '0':
            o = d.get('output', {})
            spot = float(o.get('stck_prpr', '0').replace(',', ''))
            rate = float(o.get('prdy_ctrt', '0').replace(',', ''))
            if spot > 0:
                # 베이시스 = spot × rf × T/365
                today = date.today()
                def _second_thu(y, m):
                    dd = date(y, m, 1)
                    first = dd + timedelta(days=(3 - dd.weekday()) % 7)
                    return first + timedelta(weeks=1)
                exps = [_second_thu(today.year, mo) for mo in [3, 6, 9, 12] if _second_thu(today.year, mo) >= today]
                if not exps:
                    exps = [_second_thu(today.year + 1, 3)]
                exp = min(exps)
                T = max((exp - today).days, 1)
                fut = round(spot + spot * 0.035 * T / 365, 2)
                return spot, fut, round(rate, 2)
    except Exception:
        pass
    return 0, 0, 0.0


def get_kospi200_kodex():
    """KODEX200 ETF(069500)로 KOSPI200 실시간 조회
    - Naver: 현재가 실시간 (지연 없음)
    - KIS: 1분봉 OHLCV 실시간
    - KOSPI200 지수 = ETF 가격 / 100 변환
    Returns (name, price, rate, bars, last_ts) or (None, 0, 0.0, [], '')
    """
    kst = _kst_now()
    h, m = kst.hour, kst.minute
    # 장 시간(09:00~15:30) 체크
    in_market = (9 <= h <= 14) or (h == 15 and m <= 30)
    if not in_market:
        return None, 0, 0.0, [], ''

    # ① 현재가 (Naver 실시간)
    name_etf, price_etf, rate = get_stock_info_naver(_KODEX200_CODE)
    if not price_etf:
        return None, 0, 0.0, [], ''

    price = round(price_etf / _KODEX200_SCALE, 2)  # KOSPI200 환산

    # ② 1분봉 bars (KIS 실시간) — 가격 /100 스케일 변환
    bars_etf = get_minute_bars_kis(_KODEX200_CODE, pages=3)
    bars = []
    for b in bars_etf:
        bars.append({
            'open':   round(b['open']   / _KODEX200_SCALE, 2),
            'high':   round(b['high']   / _KODEX200_SCALE, 2),
            'low':    round(b['low']    / _KODEX200_SCALE, 2),
            'close':  round(b['close']  / _KODEX200_SCALE, 2),
            'volume': b['volume'],
        })

    if not bars:
        return None, 0, 0.0, [], ''

    last_ts = kst.strftime('%m/%d %H:%M') + '(실시간)'
    return 'KOSPI200', price, rate, bars, last_ts


def get_kospi200_yfinance():
    """yfinance ^KS200 1분봉 OHLCV — (name, price, rate, bars, last_ts) 반환"""
    if not _YFINANCE_OK:
        return None, 0, 0.0, [], ''
    try:
        ticker = yf.Ticker('^KS200')
        hist = ticker.history(period='1d', interval='1m')
        if hist.empty:
            hist = ticker.history(period='2d', interval='1m')
        if hist.empty:
            return None, 0, 0.0, [], ''

        bars = []
        for _, row in hist.iterrows():
            bars.append({
                'open':   float(row['Open']),
                'high':   float(row['High']),
                'low':    float(row['Low']),
                'close':  float(row['Close']),
                'volume': max(int(row['Volume']), 1),
            })

        if not bars:
            return None, 0, 0.0, [], ''

        price = bars[-1]['close']
        prev_close = bars[0]['close'] if len(bars) > 1 else price
        rate = round((price - prev_close) / prev_close * 100, 2) if prev_close else 0.0

        # 마지막 봉 타임스탬프 (KST)
        last_ts = hist.index[-1]
        try:
            import pytz
            kst = pytz.timezone('Asia/Seoul')
            last_ts = last_ts.astimezone(kst).strftime('%m/%d %H:%M')
        except Exception:
            last_ts = str(last_ts)[:16]

        return 'KOSPI200', price, rate, bars, last_ts
    except Exception as e:
        print(f"    [KOSPI200 yfinance] 오류: {e}")
        return None, 0, 0.0, [], ''


# ═══════════════════════════════════════════
#  메인 스캔
# ═══════════════════════════════════════════

def scan_futures(engine):
    """코스피200 선물 5대장2졸병 분석
    1순위: KIS 선물 분봉 API (실시간, A01606 코드 사용)
    2순위: KODEX200 ETF (실시간, 선물 API 실패 시)
    3순위: yfinance ^KS200 (15~20분 지연, 장외용)
    """
    name, price, rate, bars, last_ts = 'KOSPI200', 0, 0.0, [], ''
    source = '-'

    # ── 1순위: KIS 선물 실시간 (A01606) ──
    try:
        code = KOSPI200_FUTURES_CODE
        n, p, r = get_futures_info_kis(code)
        if p > 0:
            b = get_minute_bars_futures_kis(code, pages=3)
            if b:
                name, price, rate, bars = n, p, r, b
                kst = _kst_now()
                last_ts = kst.strftime('%m/%d %H:%M') + '(실시간)'
                source = 'KIS선물'
    except Exception as e:
        print(f"    [KOSPI200] KIS 선물 오류: {e}")

    # ── 2순위: KODEX200 ETF bars + FHPST02400000 현물지수 가격 ──
    if not bars or price == 0:
        try:
            n, p, r, b, ts = get_kospi200_kodex()
            if b and p > 0:
                name, price, rate, bars, last_ts = n, p, r, b, ts
                source = 'KODEX200'
                # 표시 가격만 FHPST02400000+베이시스로 교체 (bars는 KODEX200 유지)
                _, fut_price, fut_rate = _get_kospi200_spot_kis()
                if fut_price > 0:
                    price = fut_price
                    rate  = fut_rate
                    source = 'KPI200+KODEX봉'
        except Exception as e:
            print(f"    [KOSPI200] KODEX200 오류: {e}")

    # ── 3순위: yfinance ^KS200 (15~20분 지연) ──
    if not bars or price == 0:
        n, p, r, b, ts = get_kospi200_yfinance()
        if b and p > 0:
            name, price, rate, bars, last_ts = n, p, r, b, ts
            source = 'yfinance'

    if not bars or price == 0:
        print(f"    [KOSPI200] 데이터 없음 - 선물 신호 스킵")
        return None

    if len(bars) < MIN_BARS:
        print(f"    [KOSPI200] 데이터 부족 ({len(bars)}봉)")
        return None

    df = pd.DataFrame(bars)
    both = analyze_both(engine, df)
    call = both['call']
    put = both['put']

    rs = f"+{rate:.2f}%" if rate > 0 else f"{rate:.2f}%"
    ts_str = f" [{last_ts}]" if last_ts else ""
    print(f"    [KOSPI200({source}){ts_str}] {price:.2f}pt {rs}  ({len(bars)}봉)")
    print(f"    CALL {call['score']}점 [5대장:{call['boss']}/5 2졸병:{call['soldier']}/2]")
    print(f"    PUT  {put['score']}점 [5대장:{put['boss']}/5 2졸병:{put['soldier']}/2]")

    return {
        'code': '^KS200', 'name': name or 'KOSPI200',
        'price': price, 'rate': rate,
        'last_ts': last_ts,
        'call_score': call['score'], 'put_score': put['score'],
        'call_boss': call['boss'], 'call_soldier': call['soldier'],
        'put_boss': put['boss'], 'put_soldier': put['soldier'],
        'call_signal': call['signal'], 'put_signal': put['signal'],
        'bars': len(bars),
        'call_wr': 0, 'call_n': 0, 'put_wr': 0, 'put_n': 0,
        'source': source,
    }


def _scan_one_stage2(args):
    """2단계: KIS 정밀 분석 단일 종목 (병렬 처리용)"""
    engine, s1, crash_mode = args if len(args) == 3 else (*args, False)
    code = s1['code']
    try:
        name = NAME_CACHE.get(code, code)
        bars = get_minute_bars_kis(code, pages=3)   # KIS 분봉 (네이버 시세콜 생략)
        if len(bars) < MIN_BARS:
            return []
        # 현재가 = KIS 분봉 마지막 봉 close
        price = bars[-1]['close']
        # 2단계에서도 가격 필터 재확인 (1단계 이후 가격 급등 방어)
        if not price or price >= 500000:
            return []

        df = pd.DataFrame(bars)
        both = analyze_both(engine, df)
        call = both['call']
        put = both['put']

        # 폭락장 특별 모드: 소나K < 20 골든크로스면 낮은 기준 적용
        def _effective_min(sig):
            if crash_mode and sig.get('signal'):
                sonar_k = sig['signal'].get('values', {}).get('sonar_k', 100)
                if sonar_k < 20:
                    return CRASH_MIN_SCORE
            return MIN_SCORE

        strat = _eval_strategies(engine, df)
        strat_hit = [x for x in strat if x['passed'] and x['id'] != (strategy_engine.SAMPLE_ID if strategy_engine else '')]

        # 점수 높은 방향 하나만 반환 (CALL/PUT 동시 신호 방지)
        call_ok = call['score'] >= _effective_min(call)
        put_ok = put['score'] >= _effective_min(put)
        if not call_ok and not put_ok:
            if not strat_hit:
                return []
            # 샘플은 미달이지만 사용자 전략이 통과 → 신호 목록에 올리되 실매매 점수(score)는 샘플 기준 그대로
            chosen = call if call['score'] >= put['score'] else put
            sig_type = 'CALL' if call['score'] >= put['score'] else 'PUT'
            sig = chosen['signal'] or {}
            kp, rate = _kis_price_rate(code)
            if kp > 0:
                price = kp
            return [{
                'code': code, 'name': name, 'price': price, 'rate': rate,
                'type': sig_type, 'score': chosen['score'],
                'boss': chosen['boss'], 'soldier': chosen['soldier'],
                'bosses': sig.get('bosses', {}), 'soldiers': sig.get('soldiers', {}), 'values': sig.get('values', {}),
                'bars': len(bars), 'wr': 0, 'wr_n': 0,
                'strategies': strat, 'strategy_only': True,
            }]
        if call_ok and put_ok:
            # 둘 다 통과 시 더 높은 점수 우선
            chosen = call if call['score'] >= put['score'] else put
            sig_type = 'CALL' if call['score'] >= put['score'] else 'PUT'
        elif call_ok:
            chosen = call
            sig_type = 'CALL'
        else:
            chosen = put
            sig_type = 'PUT'
        sig = chosen['signal'] or {}
        # 최종 통과 신호만 KIS 현재가조회로 정확한 가격·등락률 보강 (호출 소수)
        kp, rate = _kis_price_rate(code)
        if kp > 0:
            price = kp
        return [{
            'code': code, 'name': name, 'price': price, 'rate': rate,
            'type': sig_type, 'score': chosen['score'],
            'boss': chosen['boss'], 'soldier': chosen['soldier'],
            'bosses': sig.get('bosses', {}),
            'soldiers': sig.get('soldiers', {}),
            'values': sig.get('values', {}),
            'bars': len(bars), 'wr': 0, 'wr_n': 0,
            'strategies': strat,
        }]
    except Exception:
        return []


def scan_all(on_stage1=None, on_stage2=None, on_futures=None, k200_rate=0.0):
    """
    순차 스캔: 262개 종목을 하나씩 돌면서
      0) 코스피200 선물 (KIS 1분봉, 최우선)
      1) 각 종목: 네이버 가격+1분봉 조회 → 분석 → UI 즉시 업데이트
      2) 1단계 통과 즉시 stage2 패널에 표시(분석중) + KIS 분석은 백그라운드 스레드
    """
    import threading
    engine = IndicatorEngine()
    codes = list(STOCK_CODES.keys())
    total = len(codes)
    t_start = time.time()

    print(f"\n{'='*70}")
    print(f"  코스피200선물 + {total}개 종목 순차 스캐너")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}")

    # ─── 0단계: 코스피200 지수 (최우선) ───
    try:
        futures_result = scan_futures(engine)
        if futures_result and on_futures:
            on_futures(futures_result)
    except Exception as e:
        log.warning(f"[스캔] 코스피200 스캔 실패: {e}")
        futures_result = None

    # ─── KIS 토큰 사전 확인 ───
    token = _get_market_token()
    if not token:
        print(f"  [ERROR] KIS 실전서버 토큰 실패. 2단계 불가.")

    # ─── 폭락장 모드 감지 ───
    crash_mode = k200_rate <= CRASH_K200_THRESHOLD
    if crash_mode:
        print(f"  [폭락장] K200 {k200_rate:.2f}% -> 최소점수 {CRASH_MIN_SCORE}점 (소나K<20 골든크로스)")

    # ─── 공유 상태 (병렬 스캔용 락) ───
    stage1_results = []
    stage1_lock = threading.Lock()
    stage2_dedup = {}          # key: code → item
    stage2_lock = threading.Lock()
    cnt = {'pass': 0, 'filtered': 0, 'errors': 0}
    cnt_lock = threading.Lock()

    def _notify_s2():
        with stage2_lock:
            result = sorted(stage2_dedup.values(), key=lambda x: x['score'], reverse=True)
        if on_stage2:
            on_stage2(result[:])

    def _run_kis(item):
        """백그라운드 KIS 2단계 분석 — 완료 시 pending 교체 또는 제거"""
        code = item['code']
        pre_key = f'pre_{code}'
        try:
            s2_items = _scan_one_stage2((IndicatorEngine(), item, crash_mode))
            with stage2_lock:
                stage2_dedup.pop(pre_key, None)   # pending 항목 제거
                if s2_items:
                    best = s2_items[0]
                    c = best['code']
                    if c not in stage2_dedup or best['score'] > stage2_dedup[c].get('score', 0):
                        stage2_dedup[c] = best
                    print(f"    → KIS확인: {best['name']} {best['type']} {best['score']}점")
                else:
                    print(f"    → KIS탈락: {item['name']}")
        except Exception as e:
            with stage2_lock:
                stage2_dedup.pop(pre_key, None)
        _notify_s2()

    # ─── KIS 백그라운드 풀 (최대 5개 동시) ───
    kis_pool = ThreadPoolExecutor(max_workers=5)

    print(f"\n  [{total}개 병렬 스캔 시작 / {STAGE1_WORKERS}워커]")

    def _scan_one_stage1(code):
        """종목 1개 1단계 스캔 (병렬 워커). 네이버 가격+1분봉 순차 조회 → 분석."""
        engine_local = IndicatorEngine()
        name = NAME_CACHE.get(code, code)
        rate = 0.0   # 1단계 표시용 — 최종 신호는 2단계(KIS)에서 정확값으로 덮어씀
        bars = []
        try:
            bars = get_minute_bars_naver(code)   # 네이버 콜 1회 (시세콜 생략, 가격은 분봉에서)
        except Exception:
            bars = []

        # 데이터 부족 (분봉 우선 확인)
        if len(bars) < MIN_BARS:
            with cnt_lock:
                cnt['errors'] += 1
            rec = {
                'code': code, 'name': name, 'price': 0, 'rate': rate,
                'call_score': 0, 'put_score': 0,
                'bars': len(bars), 'passed': False,
            }
            with stage1_lock:
                stage1_results.append(rec)
                snap = stage1_results[:]
            if on_stage1:
                on_stage1(snap)
            return

        # 현재가 = 분봉 마지막 봉 close (네이버 시세콜 생략)
        price = bars[-1]['close']
        rate = _rate_from_bars(bars)   # 전일 종가 대비 등락률 (추가 호출 없이 분봉에서 계산)

        # 가격 필터 (50만원 이상 제외)
        if not price or price >= 500000:
            with cnt_lock:
                cnt['filtered'] += 1
            rec = {
                'code': code, 'name': name, 'price': price, 'rate': rate,
                'call_score': 0, 'put_score': 0,
                'bars': len(bars), 'passed': False, 'filtered': True,
            }
            with stage1_lock:
                stage1_results.append(rec)
                snap = stage1_results[:]
            if on_stage1:
                on_stage1(snap)
            return

        # 1단계 분석
        try:
            df = pd.DataFrame(bars)
            both = analyze_both(engine_local, df)
            call_score = both['call']['score']
            put_score = both['put']['score']
            strat = _eval_strategies(engine_local, df)
            # 1단계 통과: 샘플(6대장) 점수 기준 또는 사용자 전략 중 하나라도 통과
            passed = call_score >= STAGE1_MIN_SCORE or put_score >= STAGE1_MIN_SCORE or any(x['passed'] for x in strat)
        except Exception:
            with cnt_lock:
                cnt['errors'] += 1
            rec = {
                'code': code, 'name': name, 'price': price, 'rate': rate,
                'call_score': 0, 'put_score': 0,
                'bars': len(bars), 'passed': False,
            }
            with stage1_lock:
                stage1_results.append(rec)
                snap = stage1_results[:]
            if on_stage1:
                on_stage1(snap)
            return

        item = {
            'code': code, 'name': name, 'price': price, 'rate': rate,
            'call_score': call_score, 'put_score': put_score,
            'bars': len(bars), 'passed': passed,
            'strategies': strat,
        }
        with stage1_lock:
            stage1_results.append(item)
            snap = stage1_results[:]

        direction = 'CALL' if call_score >= put_score else 'PUT'
        top = max(call_score, put_score)
        print(f"  {name}({code})  {direction} {top}점"
              + (" [통과]" if passed else ""))

        if on_stage1:
            on_stage1(snap)

        # 1단계 통과 → stage2 패널에 즉시 표시(pending) + KIS 백그라운드 제출
        if passed:
            pre_key = f'pre_{code}'
            pending = {
                'code': code, 'name': name, 'price': price, 'rate': rate,
                'type': direction, 'score': top,
                'boss': both[direction.lower()]['boss'],
                'soldier': both[direction.lower()]['soldier'],
                'wr': 0, 'wr_n': 0, 'bars': len(bars),
                'pending': True,
                'strategies': strat,
            }
            with stage2_lock:
                stage2_dedup[pre_key] = pending
            with cnt_lock:
                cnt['pass'] += 1
            _notify_s2()
            print(f"    → stage2 즉시표시 / KIS분석 백그라운드 제출")
            if token:
                kis_pool.submit(_run_kis, item)

    # ─── 1단계 병렬 스캔 (네이버 동시 조회, STAGE1_WORKERS 워커) ───
    with ThreadPoolExecutor(max_workers=STAGE1_WORKERS) as scan_pool:
        list(scan_pool.map(_scan_one_stage1, codes))

    stage1_elapsed = time.time() - t_start
    print(f"\n  [1단계 병렬 완료] {stage1_elapsed:.0f}초 / 통과 {cnt['pass']}개 → KIS 2단계 대기...")

    # ─── KIS 분석 전부 완료 대기 ───
    kis_pool.shutdown(wait=True)

    # pending 항목 최종 제거 (KIS 탈락이라 남은 것)
    with stage2_lock:
        for k in list(stage2_dedup.keys()):
            if k.startswith('pre_'):
                del stage2_dedup[k]
        final = sorted(stage2_dedup.values(), key=lambda x: x['score'], reverse=True)

    if on_stage2:
        on_stage2(final[:])

    total_elapsed = time.time() - t_start
    print(f"\n  [스캔 완료] {total_elapsed:.0f}초 / "
          f"1단계통과: {cnt['pass']}개 / 필터제외: {cnt['filtered']}개 / 데이터부족: {cnt['errors']}개")
    _print_results(final, total_elapsed, total, cnt['errors'], cnt['pass'], futures_result, cnt['filtered'])
    return {'stage1': stage1_results, 'stage2': final, 'futures': futures_result}


def _print_results(results, total_elapsed, total_stocks, s1_errors, s1_pass, futures=None, s1_filtered=0):
    """결과 출력"""
    results.sort(key=lambda x: x['score'], reverse=True)

    # 5대장x10 + 2졸병x5 = 최대 60점
    t60 = [r for r in results if r['score'] == 60]       # 올킬
    t50 = [r for r in results if 45 <= r['score'] < 60]  # 강력
    t30 = [r for r in results if 30 <= r['score'] < 45]  # 관심

    print(f"\n{'='*70}")
    print(f"  최종 결과 ({datetime.now().strftime('%Y-%m-%d %H:%M')})")
    print(f"  점수: 5대장x10(최대50) + 2졸병x5(최대10) = 최대60점")
    print(f"  0단계: 코스피200선물 -> 1단계: 네이버필터 -> 2단계: KIS정밀")
    print(f"{'='*70}")

    # ── 코스피200 선물 결과 (최상단) ──
    if futures:
        f = futures
        rs = f"+{f['rate']:.2f}%" if f['rate'] > 0 else f"{f['rate']:.2f}%"
        ps = f"{f['price']:.2f}pt" if f['price'] > 0 else "가격미상"
        print(f"\n  [코스피200 선물] {ps} {rs} ({f['bars']}봉)")
        print(f"  {'-'*60}")
        print(f"    CALL {f['call_score']}점 [5대장:{f['call_boss']}/5 2졸병:{f['call_soldier']}/2]"
              f"  승률{f.get('call_wr',0):.0f}%({f.get('call_n',0)}건)")
        print(f"    PUT  {f['put_score']}점 [5대장:{f['put_boss']}/5 2졸병:{f['put_soldier']}/2]"
              f"  승률{f.get('put_wr',0):.0f}%({f.get('put_n',0)}건)")
        if f.get('call_signal') and f['call_signal'].get('values'):
            v = f['call_signal']['values']
            print(f"    CALL: SONAR K={v.get('sonar_k',0):.1f}/D={v.get('sonar_d',0):.1f}  "
                  f"RSI={v.get('rsi',0):.1f}  ADX={v.get('adx',0):.1f}  "
                  f"STOCH={v.get('stoch_k',0):.1f}  VOL={v.get('vol_ratio',0):.2f}  "
                  f"WILLR={v.get('willr',0):.1f}")
        if f.get('put_signal') and f['put_signal'].get('values'):
            v = f['put_signal']['values']
            print(f"    PUT:  SONAR K={v.get('sonar_k',0):.1f}/D={v.get('sonar_d',0):.1f}  "
                  f"RSI={v.get('rsi',0):.1f}  ADX={v.get('adx',0):.1f}  "
                  f"STOCH={v.get('stoch_k',0):.1f}  VOL={v.get('vol_ratio',0):.2f}  "
                  f"WILLR={v.get('willr',0):.1f}")
    else:
        print(f"\n  [코스피200 선물] 데이터 없음 (장외 또는 토큰 실패)")

    def prt(r, ind="  "):
        rs = f"+{r['rate']:.1f}%" if r['rate'] > 0 else f"{r['rate']:.1f}%"
        ps = f"{r['price']:,}원" if r['price'] > 0 else "가격미상"
        v = r.get('values', {})
        wr_str = f" 승률{r.get('wr',0):.0f}%({r.get('wr_n',0)}건)" if r.get('wr') else ""
        print(f"{ind}{r['name']}({r['code']})  {ps} {rs}  "
              f"{r['type']} {r['score']}점 "
              f"[5대장:{r['boss']}/5 2졸병:{r['soldier']}/2] ({r['bars']}봉){wr_str}")
        if v:
            print(f"{ind}  SONAR K={v.get('sonar_k',0):.1f}/D={v.get('sonar_d',0):.1f}  "
                  f"RSI={v.get('rsi',0):.1f}  ADX={v.get('adx',0):.1f}  "
                  f"STOCH={v.get('stoch_k',0):.1f}  VOL={v.get('vol_ratio',0):.2f}  "
                  f"WILLR={v.get('willr',0):.1f}")

    if t60:
        print(f"\n  [올킬] 60점 - 5대장5/5+졸병2/2 ({len(t60)}개)")
        print(f"  {'-'*60}")
        for r in t60: prt(r)
    else:
        print(f"\n  [올킬] 60점 종목 없음")

    if t50:
        print(f"\n  [강력] 45~55점 ({len(t50)}개)")
        print(f"  {'-'*60}")
        for r in t50: prt(r)

    if t30:
        print(f"\n  [관심] 30~40점 ({len(t30)}개)")
        print(f"  {'-'*60}")
        for r in t30: prt(r)

    print(f"\n{'='*70}")
    print(f"  분포: 60점={len(t60)} / 45~55점={len(t50)} / "
          f"30~40점={len(t30)}")
    print(f"  전체: {total_stocks}개 / 필터제외: {s1_filtered}개 / 1단계통과: {s1_pass}개 / "
          f"최종: {len(results)}개 / 데이터부족: {s1_errors}개")
    print(f"  소요시간: {total_elapsed:.1f}초")
    print(f"{'='*70}\n")


if __name__ == '__main__':
    scan_all()
