"""3분봉 타이밍 신호 (종합 신호의 '언제' 층 — PO 2026-09-22).

일봉 전략이 고른 후보 종목에 대해, 1분봉(네이버 siseJson, close·volume)을 3분봉으로 묶어
5이평/20이평 골든크로스(CALL) 또는 데드크로스(PUT)를 판정한다.
근거: wiki/연구/project_regime_3boss4soldier_20260921.md §15 — 3분봉 5/20 골든크로스 시점 진입이
시가 진입 대비 +0.7%p(504건, 09:00~12:00). 졸병(MACD·거래량·VWAP 등)은 학습/검증 부호 불일치로 채택 없음.
"""
from __future__ import annotations
from datetime import datetime


def resample_3m(bars, day: str = None, strict=True):
    """1분봉 리스트([{'ts':'YYYYMMDDHHMM','close':..,'volume':..}]) → 완성된 3분봉 종가 리스트 [(YYYYMMDDHHMM 버킷, close)].
    여러 날의 봉을 이어 붙인다(차트 앱의 3분봉과 같음 — 어제 봉으로 20이평을 만들어 09:03부터 판정 가능, PO 2026-09-22 "08:45부터").
    마지막(진행 중인) 3분 구간은 버린다. strict=True 면 1분봉 3개가 모두 있는 버킷만 완성봉으로 인정(결측 오판 방지)."""
    rows = [(str(b['ts']), float(b['close'])) for b in bars if b.get('ts') and b.get('close')]
    if not rows:
        return []
    rows.sort()
    buckets = {}; counts = {}; order = []
    for ts, c in rows:
        d8 = ts[:8]; m = int(ts[8:10]) * 60 + int(ts[10:12])
        b = ((m - 1) // 3) * 3 + 1
        key = (d8, b)
        if key not in buckets:
            order.append(key)
        buckets[key] = c
        counts[key] = counts.get(key, 0) + 1
    last_d8, last_ts = rows[-1][0][:8], rows[-1][0]
    last_min = int(last_ts[8:10]) * 60 + int(last_ts[10:12])
    out = []
    for key in order:
        d8, b = key
        complete = (d8 < last_d8) or (last_min >= b + 2)
        if complete and (not strict or counts[key] == 3):
            out.append((f'{d8}{b // 60:02d}{b % 60:02d}', buckets[key]))
    return out


def is_fresh(bars, day: str, now_hhmm: str, max_lag_min=4):
    """마지막 1분봉이 now 기준 max_lag_min 분 안이면 True (지연·오래된 데이터로 과거 교차를 현재 신호로 오인하는 것 방지)."""
    ts = [str(b.get('ts', '')) for b in bars if str(b.get('ts', '')).startswith(day)]
    if not ts:
        return False
    last = max(ts)
    lm = int(last[8:10]) * 60 + int(last[10:12])
    nm = int(now_hhmm[:2]) * 60 + int(now_hhmm[2:4])
    return 0 <= nm - lm <= max_lag_min


def _sma(vals, n):
    out = []
    for i in range(len(vals)):
        if i + 1 < n:
            out.append(None)
        else:
            out.append(sum(vals[i + 1 - n:i + 1]) / n)
    return out


def golden_cross_5_20(bars, day: str, direction='CALL', lookback=2, now_hhmm=None):
    """최근 `lookback`개 완성 3분봉 안에서 5/20 골든크로스(CALL) 또는 데드크로스(PUT)가 났고
    지금도 그 상태가 유지되면 (True, info). 아니면 (False, info). now_hhmm 을 주면 데이터 신선도(4분)도 검사."""
    info = {}
    if now_hhmm and not is_fresh(bars, day, now_hhmm):
        info['reason'] = '1분봉 지연/결측(신선도 실패)'
        return False, info
    c3 = resample_3m(bars, day)
    closes = [c for _, c in c3]
    info['bars3m'] = len(closes)
    if len(closes) < 21:
        info['reason'] = f'3분봉 부족({len(closes)}<21)'
        return False, info
    ma5, ma20 = _sma(closes, 5), _sma(closes, 20)
    up = direction == 'CALL'
    def above(i):
        return ma5[i] > ma20[i] if up else ma5[i] < ma20[i]
    n = len(closes)
    if not above(n - 1):
        info['reason'] = '5이평이 20이평 ' + ('아래' if up else '위')
        info.update(ma5=round(ma5[-1], 1), ma20=round(ma20[-1], 1), t=c3[-1][0][-4:])
        return False, info
    # 최근 lookback개 봉 중 하나에서 교차(직전 봉은 반대 상태)
    for k in range(1, lookback + 1):
        i = n - k
        if i - 1 < 20:
            break
        if not c3[i][0].startswith(day):
            break   # 어제 봉에서 난 교차는 오늘 신호가 아니다
        if above(i) and not above(i - 1):
            info.update(cross_at=c3[i][0][-4:], ma5=round(ma5[-1], 1), ma20=round(ma20[-1], 1), t=c3[-1][0][-4:],
                        rule='3m_golden_5_20' if up else '3m_dead_5_20')
            return True, info
    info['reason'] = f'교차 없음(최근 {lookback}봉, 이미 {"위" if up else "아래"})'
    info.update(ma5=round(ma5[-1], 1), ma20=round(ma20[-1], 1), t=c3[-1][0][-4:])
    return False, info



# ── 타이밍 타입 (PO 2026-09-22: "A타입·B타입·C타입·D타입으로 나눠라 — 복합으로 묶으면 아무것도 안 나온다") ──
# 1단계(네이버 1분봉 빠른 선별) → 2단계(정밀조사 = 타입별 판정). 후보 종목(일봉 선정)에만 적용한다.
TIMING_TYPES = {
    'A': {'id': '3m_golden_5_20', 'label': 'A타입 3분봉 5/20 골든크로스', 'evidence': '시가 진입 대비 +0.7%p(504건, 09~12시)'},
    'B': {'id': 'open_breakout', 'label': 'B타입 장초반 강세(시가·전일종가 위 +1%↑)', 'evidence': '6월 돌파 트랙 기준(미검증)'},
    'C': {'id': 'boss_soldier_1m', 'label': 'C타입 1분봉 5대장2졸병 65점', 'evidence': '후보 분봉으로 직접 계산(종목 선별력 0, 타이밍용)'},
    'D': {'id': 'vwap_volume', 'label': 'D타입 VWAP 위 + 거래량 급증(최근 5봉 ≥ 20봉 평균 1.5배)', 'evidence': '후보 졸병(학습/검증 부호 불일치)'},
}


def stage1_screen(bars, day: str, direction='CALL', quote=None):
    """1단계 빠른 선별(네이버 1분봉·현재가): 후보가 오늘 '살아 있는' 종목인가.
    조건: 오늘 봉 20개 이상 · 당일 방향이 규칙 방향과 같음(CALL: 현재가 ≥ 시가, PUT: ≤) · 시가 대비 추격 금지(±3% 이내).
    반환 (통과, 사유)"""
    q = quote or {}
    today = [b for b in bars if str(b.get('ts', '')).startswith(day)]
    if len(today) < 3:
        return False, f'분봉이 아직 {len(today)}개뿐 — 시세가 더 쌓이면 다시 봅니다'
    op = float(q.get('open') or 0); px = float(q.get('price') or today[-1]['close'])
    if not op:
        return False, '시가 없음'
    chg = px / op - 1
    if direction == 'CALL' and chg < 0:
        return False, f'시가 아래({chg*100:+.1f}%)'
    if direction == 'PUT' and chg > 0:
        return False, f'시가 위({chg*100:+.1f}%)'
    if abs(chg) > 0.03:
        return False, f'시가 대비 {chg*100:+.1f}% 추격 금지'
    return True, f'시가 대비 {chg*100:+.1f}%'


def type_B_open_breakout(quote, direction='CALL', min_pct=1.0):
    """B타입: 장초반 강세/약세 — CALL 은 현재가가 시가와 전일 종가 둘 다 위이고 전일 종가 대비 +min_pct 이상. PUT 은 반대."""
    q = quote or {}
    op = float(q.get('open') or 0); px = float(q.get('price') or 0); pc = float(q.get('prev_close') or 0)
    if not (op and px and pc):
        return False, {'reason': '시가/전일종가 없음'}
    chg = (px / pc - 1) * 100
    if direction == 'CALL':
        ok = px > op and px > pc and chg >= min_pct
    else:
        ok = px < op and px < pc and chg <= -min_pct
    return ok, {'rule': 'open_breakout', 'open': op, 'prev_close': pc, 'chg_pct': round(chg, 2)}


_ENGINE = None

# C타입은 고저폭을 쓰는 지표(ADX·DI·스토캐스틱·%R)에 기댄다. 합성봉(고가=저가)만으로는
# 엉터리 값이 나오므로, 최근 이만큼 안에 진짜 봉이 이만큼은 있어야 판정한다.
MIN_REAL_WINDOW = 30
MIN_REAL_BARS = 20


def type_C_boss_soldier_1m(bars, direction='CALL', min_score=65):
    """C타입 — 후보의 1분봉으로 5대장2졸병 점수를 직접 낸다.

    2026-09-24: 전에는 trader 가 290종목 스캐너 결과(s2)에서 이 종목을 찾아 썼다.
    그런데 9/23 에 290종목 분봉 스캔을 끄면서 s2 가 늘 비어, C 는 언제나
    '스캐너 신호 없음' 이 되어 죽어 있었다. A·D 가 이미 받아 둔 같은 분봉으로
    여기서 직접 계산한다 — 290종목 스캔 없이 돈다.
    """
    global _ENGINE
    n = len(bars or [])
    if n < 60:
        return False, {'rule': 'boss_soldier_1m', 'reason': f'분봉이 {n}개뿐(60 미만)'}

    # 어제까지의 분봉은 네이버에서 오는데 고가=저가=종가인 합성봉이다(실측 100%).
    # ADX·DI·스토캐스틱·%R 은 고저폭에 기대는데, 폭이 0이면 NaN 이 아니라
    # DI+ 80 · 스토캐 93 같은 '그럴듯한 엉터리 값'이 나온다(2026-09-24 실험으로 확인).
    # 그 값으로 65점이 뜨면 사람은 정상 신호로 믿고 승인한다. 오늘 실봉이 충분히
    # 쌓이기 전에는 판정하지 않는다.
    tail = bars[-MIN_REAL_WINDOW:]
    real = sum(1 for b in tail
               if (b.get('high') or 0) > (b.get('low') or 0))
    if real < MIN_REAL_BARS:
        return False, {'rule': 'boss_soldier_1m',
                       'reason': f'고저폭 있는 분봉이 {real}개뿐 — 시세가 더 쌓이면 봅니다'}
    try:
        import pandas as pd
        from analysis import IndicatorEngine
        from scanner_262_52 import analyze_both
    except Exception as e:
        return False, {'rule': 'boss_soldier_1m', 'reason': f'지표 계산기를 못 불러옴({type(e).__name__})'}
    try:
        if _ENGINE is None:
            _ENGINE = IndicatorEngine()
        both = analyze_both(_ENGINE, pd.DataFrame(bars), direction=direction)
    except Exception as e:
        return False, {'rule': 'boss_soldier_1m', 'reason': str(e)[:60]}
    r = (both or {}).get('put' if str(direction).upper() == 'PUT' else 'call') or {}
    sc = int(r.get('score') or 0)
    return sc >= int(min_score), {'rule': 'boss_soldier_1m', 'score': sc,
                                  'boss': r.get('boss'), 'soldier': r.get('soldier')}


def type_D_vwap_volume(bars, day: str, direction='CALL', surge=1.5):
    """D타입: 당일 VWAP(거래량 가중 평균가) 위(PUT 은 아래) + 최근 5개 1분봉 거래량 평균이 그 전 20봉(어제 봉 포함) 평균의 surge 배 이상."""
    allb = [b for b in bars if b.get('ts') and b.get('close')]
    today = [b for b in allb if str(b['ts']).startswith(day)]
    if len(today) < 3 or len(allb) < 26:
        return False, {'reason': f'봉 부족(오늘 {len(today)}, 전체 {len(allb)})'}
    vols_t = [float(b.get('volume') or 0) for b in today]
    pv = sum(float(b['close']) * v for b, v in zip(today, vols_t)); tv = sum(vols_t)
    if tv <= 0:
        return False, {'reason': '거래량 0'}
    vwap = pv / tv; px = float(today[-1]['close'])
    vols = [float(b.get('volume') or 0) for b in allb]
    nr = min(5, len(today)); recent = sum(vols[-nr:]) / nr; base = sum(vols[-(20 + nr):-nr]) / 20.0
    ratio = (recent / base) if base > 0 else 0.0
    above = px > vwap if direction == 'CALL' else px < vwap
    ok = above and ratio >= surge
    return ok, {'rule': 'vwap_volume', 'vwap': round(vwap, 1), 'price': px, 'vol_ratio': round(ratio, 2)}



if __name__ == '__main__':
    # 자가 점검: 합성 데이터로 골든크로스 감지
    day = '20260922'
    bars = []
    price = 100.0
    for m in range(9 * 60 + 1, 11 * 60 + 1):
        # 09:01~10:20 완만 하락, 이후 급반등 → 어느 시점에 5>20 교차
        price += -0.05 if m < 10 * 60 + 20 else 0.4
        bars.append({'ts': f'{day}{m // 60:02d}{m % 60:02d}', 'close': price, 'volume': 1})
    hits = []
    for cut in range(60, len(bars)):
        ok, info = golden_cross_5_20(bars[:cut], day)
        if ok:
            hits.append((bars[cut - 1]['ts'][8:], info['cross_at']))
    print('감지 시점(1분봉 ts, 교차 3분봉):', hits[:3], '… 총', len(hits))
    assert hits, '골든크로스 미감지'
    print('A타입 OK')

    # ── C타입: 합성봉(고가=저가=종가)으로 점수를 내면 안 된다 ──
    # 2026-09-24: 합성봉만으로도 DI+ 80 · 스토캐 93 같은 그럴듯한 값이 나온다.
    # 그 점수로 65점이 뜨면 사람은 정상 신호로 믿고 승인한다.
    def _bars(n_flat, n_real, px=70000):
        out = []
        for i in range(n_flat):
            out.append({'ts': f'2026092300{i:04d}', 'open': px, 'high': px,
                        'low': px, 'close': px, 'volume': 1000})
        for i in range(n_real):
            out.append({'ts': f'2026092400{i:04d}', 'open': px, 'high': px + 40,
                        'low': px - 40, 'close': px, 'volume': 1500})
        return out

    ok, info = type_C_boss_soldier_1m(_bars(300, 0), direction='CALL')
    assert not ok and '고저폭' in str(info.get('reason', '')), f'합성봉만으로 판정했다: {info}'
    ok, info = type_C_boss_soldier_1m(_bars(300, MIN_REAL_BARS - 1), direction='CALL')
    assert not ok, f'실봉이 모자란데 판정했다: {info}'
    ok, info = type_C_boss_soldier_1m(_bars(300, MIN_REAL_BARS), direction='CALL')
    assert 'score' in info, f'실봉이 찼는데 점수를 못 냈다: {info}'
    ok, info = type_C_boss_soldier_1m(_bars(30, 0), direction='CALL')
    assert not ok and '개뿐' in str(info.get('reason', '')), f'분봉이 적은데 판정했다: {info}'
    print('C타입 OK — 합성봉 거부 · 실봉 부족 거부 · 분봉 부족 거부')
