/**
 * bridge.js — 내 PC 끼리 파일·글을 주고받는다 (PO 2026-09-23 지시, 안 2: 「기본은 직접 전송, 원하면 공유 폴더도」)
 *
 *  두 길을 **겹쳐서** 쓴다. 설정은 한 칸(`bridge_dir`)뿐이다.
 *   ① 직접 전송  — 받는 PC 가 켜져 있으면 허브에서 주소를 찾아 바로 넣는다. 설치할 것이 없고 내 PC 밖으로 안 나간다.
 *   ② 공유 폴더  — `bridge_dir` 이 정해져 있으면 거기에도 남긴다. 상대가 꺼져 있어도 되고, 기록이 남고, 큰 파일이 되고,
 *                  PC 가 셋 이상이면 한 번에 끝나고, 폰에서 클라우드 앱으로 바로 볼 수 있다.
 *  둘 중 하나만 돼도 보낸 것으로 친다. 둘 다 안 되면 그 사실을 그대로 알린다.
 *
 *  PC 가 한 대뿐이면 이 기능은 쓸 일이 없다 — `usable()` 이 false 를 돌려주고 화면에서도 숨긴다.
 *
 *  파일 이름 규칙(사람이 읽는 것이 먼저다):  YYYY-MM-DD_HHMM_<보낸PC>→<받는PC>_<제목>.md
 *  받은 것은 각 PC 의 `general\inbox\` 에 들어간다. 무엇을 이미 가져왔는지는 **내 PC 안**(bridge_seen.json)에만 적는다
 *  — 공유 폴더의 파일을 고치면 다른 PC 와 충돌하기 때문이다.
 *
 *  CLI:
 *    node bridge.js 자리찾기                      공유 폴더 후보를 찾아 보여 준다(원드라이브·구글드라이브·드롭박스)
 *    node bridge.js 보내기 --pc <PC> --제목 "..." [--글 "..."] [--파일 <경로>]
 *    node bridge.js 받은것                        내 inbox 목록
 *    node bridge.js 가져오기                      공유 폴더에서 나에게 온 것을 inbox 로 내린다
 */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');

const HOME = process.env.CONSOLE_HOME || __dirname;
const BASE_DIR = path.resolve(HOME, '..');                 // C:\OneMACS
const INBOX = path.join(BASE_DIR, 'general', 'inbox');
const SEEN_FILE = path.join(HOME, 'bridge_seen.json');
const CFG_FILE = path.join(HOME, 'console_config.json');

function cfg() { try { return JSON.parse(fs.readFileSync(CFG_FILE, 'utf8').replace(/^\uFEFF/, '')); } catch (_) { return {}; } }
function ensureDir(d) { fs.mkdirSync(d, { recursive: true }); }

/** 이 PC 이름 — 허브 장부와 같은 값을 쓴다(hostname). 라벨은 사람이 읽는 이름이라 따로 둔다. */
function myPc() { return os.hostname(); }
function myLabel() { return cfg().pc_label || myPc(); }

// ── 공유 폴더 ────────────────────────────────────────────────────────────────
/** 설정된 공유 폴더. 없으면 ''(= 직접 전송만 쓴다) */
function sharedDir() {
  const d = String(cfg().bridge_dir || '').trim();
  if (!d) return '';
  try { return fs.statSync(d).isDirectory() ? d : ''; } catch (_) { return ''; }
}

/**
 * 이 PC 에서 쓸 만한 공유 폴더 후보를 찾는다.
 * **사용자가 이미 쓰는 것**을 찾아 제안할 뿐, 새로 만들라고 하지 않는다. 없으면 빈 목록을 준다.
 */
function findSharedCandidates() {
  const home = os.homedir();
  const out = [];
  const add = (dir, name) => {
    try { if (fs.statSync(dir).isDirectory()) out.push({ dir, name }); } catch (_) {}
  };
  // 윈도우 11 은 원드라이브가 거의 항상 있다 — 마찰이 가장 적은 후보라 먼저 본다
  for (const v of [process.env.OneDriveCommercial, process.env.OneDriveConsumer, process.env.OneDrive]) if (v) add(v, 'OneDrive');
  add(path.join(home, 'OneDrive'), 'OneDrive');
  // 구글 드라이브(내 드라이브) — 드라이브 문자는 PC 마다 다르다
  for (const letter of 'GHIJKLDEF') {
    add(letter + ':\\내 드라이브', '구글 드라이브');
    add(letter + ':\\My Drive', '구글 드라이브');
  }
  add(path.join(home, 'Google Drive'), '구글 드라이브');
  add(path.join(home, 'Dropbox'), 'Dropbox');
  add(path.join(home, 'Nextcloud'), 'Nextcloud');
  // 같은 이름이 여러 번 잡히면 하나만
  const seen = new Set();
  return out.filter(c => { const k = c.dir.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; })
    .map(c => Object.assign({}, c, { suggest: path.join(c.dir, 'OneMACS', 'bridge') }));
}

// ── 이름 짓기 ────────────────────────────────────────────────────────────────
function stamp(d) {
  const p = (n) => String(n).padStart(2, '0');
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '_' + p(d.getHours()) + p(d.getMinutes());
}
/** 파일 이름에 못 쓰는 글자만 바꾼다 — 한글은 그대로 둔다(사람이 읽어야 한다) */
function safeTitle(s) {
  return String(s || '쪽지').replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60) || '쪽지';
}
function fileNameFor(toPc, title, ext) {
  return stamp(new Date()) + '_' + myPc() + '→' + (toPc || '모두') + '_' + safeTitle(title) + (ext || '.md');
}

// ── 보내기 ───────────────────────────────────────────────────────────────────
/**
 * @param {{to:string, title:string, body?:string, file?:string, post?:function}} o
 *   to    받는 PC 이름(hostname). '' 이면 모두에게(공유 폴더에만 남는다)
 *   post  직접 전송에 쓸 함수 — (pc, payload) => Promise<{ok:boolean, error?:string}>.
 *         라우터가 넣어 준다. 없으면 공유 폴더만 쓴다(단독 CLI 실행 등).
 */
async function send(o) {
  const to = String(o.to || '').trim();
  const title = safeTitle(o.title);
  let body = String(o.body || '');
  const attach = o.file && fs.existsSync(o.file) ? o.file : '';
  const result = { shared: '', direct: '', errors: [] };

  if (attach && !body) body = '(첨부 파일 ' + path.basename(attach) + ')';

  // 두 길로 **같은 이름**을 쓴다. 그래야 받는 쪽이 같은 것을 두 번 받지 않는다 —
  // 직접 전송으로 이미 받은함에 들어갔으면, 공유 폴더에서 내려받을 때 그 이름이 있으므로 건너뛴다.
  const name = fileNameFor(to, title);

  // ① 공유 폴더 — 남겨야 할 것은 여기 남는다
  const sd = sharedDir();
  if (sd) {
    try {
      ensureDir(sd);
      const head = ['# ' + title, '', '- 보낸 PC: ' + myLabel() + ' (' + myPc() + ')',
        '- 받는 PC: ' + (to || '모두'), '- 보낸 때: ' + new Date().toLocaleString('ko-KR'), '', '---', ''].join('\n');
      fs.writeFileSync(path.join(sd, name), head + body + '\n', 'utf8');
      if (attach) {
        const adir = path.join(sd, 'files');
        ensureDir(adir);
        const an = stamp(new Date()) + '_' + path.basename(attach);
        fs.copyFileSync(attach, path.join(adir, an));
        fs.appendFileSync(path.join(sd, name), '\n첨부: `files/' + an + '`\n', 'utf8');
      }
      result.shared = path.join(sd, name);
    } catch (e) { result.errors.push('공유 폴더: ' + e.message); }
  }

  // ② 직접 전송 — 급한 것은 이쪽이 빠르다. 받는 PC 가 켜져 있어야 한다
  if (to && typeof o.post === 'function') {
    try {
      const r = await o.post(to, { from: myPc(), fromLabel: myLabel(), title, body, name, at: new Date().toISOString() });
      if (r && r.ok) result.direct = to;
      else result.errors.push('직접 전송: ' + ((r && r.error) || '받는 PC 가 꺼져 있거나 응답하지 않습니다'));
    } catch (e) { result.errors.push('직접 전송: ' + e.message); }
  }

  result.ok = !!(result.shared || result.direct);
  return result;
}

// ── 받기 ─────────────────────────────────────────────────────────────────────
/** 다른 PC 가 직접 보낸 것을 내 inbox 에 떨어뜨린다 */
function receive(msg) {
  ensureDir(INBOX);
  const title = safeTitle(msg && msg.title);
  const from = String((msg && msg.from) || '알수없음');
  // 보낸 쪽이 정한 이름을 그대로 쓴다 — 공유 폴더에 남은 같은 글과 이름이 같아야 두 번 받지 않는다.
  // 이름이 안 왔으면(옛 버전) 여기서 짓는다.
  const given = String((msg && msg.name) || '').replace(/[\\/]/g, '');
  const name = /\.md$/i.test(given) ? given : (stamp(new Date()) + '_' + from + '→' + myPc() + '_' + title + '.md');
  const head = ['# ' + title, '', '- 보낸 PC: ' + ((msg && msg.fromLabel) || from) + ' (' + from + ')',
    '- 받은 때: ' + new Date().toLocaleString('ko-KR'), '', '---', ''].join('\n');
  const p = path.join(INBOX, name);
  fs.writeFileSync(p, head + String((msg && msg.body) || '') + '\n', 'utf8');
  return p;
}

function loadSeen() { try { return JSON.parse(fs.readFileSync(SEEN_FILE, 'utf8')); } catch (_) { return { files: [] }; } }
function saveSeen(s) { try { fs.writeFileSync(SEEN_FILE, JSON.stringify(s, null, 2), 'utf8'); } catch (_) {} }

/**
 * 공유 폴더에서 **나에게 온 것**을 inbox 로 내린다. 이미 가져온 것은 건너뛴다.
 * 공유 폴더의 파일은 고치지 않는다 — 다른 PC 와 충돌하기 때문이다. 무엇을 가져왔는지는 내 PC 에만 적는다.
 */
function pull() {
  const sd = sharedDir();
  if (!sd) return { got: [], skipped: 0 };
  const seen = loadSeen();
  const set = new Set(seen.files || []);
  const got = [];
  let names = [];
  try { names = fs.readdirSync(sd).filter(n => n.toLowerCase().endsWith('.md')); } catch (_) { return { got: [], skipped: 0 }; }
  for (const n of names) {
    if (set.has(n)) continue;
    // 「…_<보낸PC>→<받는PC>_제목.md」 에서 받는 쪽이 나인 것만. '모두' 도 가져간다
    const m = /_([^_→]+)→([^_]+)_/.exec(n);
    const to = m && m[2];
    const from = m && m[1];
    if (from === myPc()) { set.add(n); continue; }          // 내가 보낸 것은 다시 받지 않는다
    if (to && to !== myPc() && to !== '모두') continue;      // 남에게 온 것은 건드리지 않는다(표시도 남기지 않는다)
    // 직접 전송으로 이미 받았으면 건너뛴다 — 두 길로 보내도 **한 번만** 받는다(이름이 같다)
    if (fs.existsSync(path.join(INBOX, n))) { set.add(n); continue; }
    try {
      ensureDir(INBOX);
      fs.copyFileSync(path.join(sd, n), path.join(INBOX, n));
      got.push(n);
      set.add(n);
    } catch (_) {}
  }
  seen.files = [...set].slice(-2000);
  saveSeen(seen);
  return { got, skipped: names.length - got.length };
}

/** 받은 것 목록 (새것부터) */
function inbox(limit) {
  try {
    return fs.readdirSync(INBOX)
      .filter(n => n.toLowerCase().endsWith('.md'))
      .map(n => ({ name: n, at: fs.statSync(path.join(INBOX, n)).mtime }))
      .sort((a, b) => b.at - a.at)
      .slice(0, limit || 30);
  } catch (_) { return []; }
}

/** PC 가 둘 이상일 때만 쓸모가 있다 — 한 대뿐이면 화면에서도 숨긴다 */
function usable(pcCount) { return (pcCount || 0) >= 2 || !!sharedDir(); }

module.exports = { send, receive, pull, inbox, sharedDir, findSharedCandidates, usable, myPc, myLabel, INBOX };

// ── 단독 실행 ────────────────────────────────────────────────────────────────
if (require.main === module) {
  const a = process.argv.slice(2);
  const val = (k) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : ''; };
  const cmd = a[0] || '받은것';

  if (cmd === '자리찾기') {
    const now = sharedDir();
    console.log('지금 공유 폴더: ' + (now || '(정해지지 않음 — 직접 전송만 씁니다)'));
    const cands = findSharedCandidates();
    if (!cands.length) { console.log('이 PC 에서 클라우드 동기 폴더를 찾지 못했습니다. 직접 전송만으로도 씁니다.'); process.exit(0); }
    console.log('\n쓸 만한 곳:');
    for (const c of cands) console.log('  · ' + c.name + '  →  ' + c.suggest);
    console.log('\n고르려면 폰 ⚙ 설정에서 「PC 사이 공유 폴더」에 위 경로 하나를 넣으십시오.');
  } else if (cmd === '보내기') {
    // 콘솔을 거쳐 보낸다 — 그래야 **직접 전송까지** 된다(상대 PC 주소를 찾는 것은 콘솔이 한다).
    // 여기서 혼자 보내면 공유 폴더에만 남는다. 콘솔이 꺼져 있으면 그 사실을 말하고 공유 폴더로만 보낸다.
    const body = { to: val('--pc'), title: val('--제목') || val('--title'), body: val('--글') || val('--body'), file: val('--파일') || val('--file') };
    const c = cfg();
    const post = () => new Promise((resolve) => {
      const data = Buffer.from(JSON.stringify(body), 'utf8');
      const r = require('http').request({
        host: '127.0.0.1', port: c.port || 7890, path: '/api/bridge-send?pin=' + encodeURIComponent(c.pin || ''), method: 'POST',
        timeout: 30000, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': data.length, 'X-Console-Project': encodeURIComponent('OneMACS') },
      }, (res) => { const b = []; res.on('data', d => b.push(d)); res.on('end', () => { try { resolve({ s: res.statusCode, j: JSON.parse(Buffer.concat(b).toString('utf8')) }); } catch (_) { resolve(null); } }); });
      r.on('timeout', () => { r.destroy(); resolve(null); });
      r.on('error', () => resolve(null));
      r.write(data); r.end();
    });
    post().then(async (res) => {
      let r = res && res.j;
      if (!r) {
        console.log('(콘솔이 응답하지 않습니다 — 공유 폴더로만 보냅니다. 직접 전송은 콘솔이 켜져 있어야 합니다)');
        r = await send(body);
      }
      if (r.shared) console.log('공유 폴더에 남김: ' + r.shared);
      if (r.direct) console.log('직접 전송: ' + r.direct);
      else if (body.to) console.log('직접 전송: 안 됨 (상대 PC 가 꺼져 있거나 옛 버전일 수 있습니다) — 공유 폴더로 갑니다');
      for (const e of (r.errors || [])) console.log('  · ' + e);
      if (!r.ok) { console.error('보내지 못했습니다.'); process.exit(1); }
    });
  } else if (cmd === '가져오기') {
    const r = pull();
    console.log(r.got.length ? ('가져온 것 ' + r.got.length + '건:\n  ' + r.got.join('\n  ')) : '새로 온 것이 없습니다.');
  } else {
    const list = inbox(20);
    if (!list.length) { console.log('받은 것이 없습니다. (' + INBOX + ')'); }
    else for (const f of list) console.log('  ' + f.at.toLocaleString('ko-KR') + '  ' + f.name);
  }
}
