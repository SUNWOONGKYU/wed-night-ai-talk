// 설치 점검: Node / 4개 AI CLI 설치·버전(검증표 대조) / cloudflared.  `node check_setup.js --health` 는 각 AI 에 1줄 지시까지 보내 답이 오는지 본다.
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { detectVersions } = require('./cli_versions');

function run(cmd) { try { return execSync(cmd, { stdio: ['ignore', 'pipe', 'pipe'], timeout: 20000 }).toString().trim(); } catch (e) { return null; } }
const INSTALL = {
  claude: '없음 → npm install -g @anthropic-ai/claude-code 후 claude 실행해 로그인',
  codex: '없음(선택) → npm install -g @openai/codex 후 codex login',
  agy: '없음(선택) → Antigravity 설치 후 agy 실행해 로그인',
  grok: '없음(선택) → npm install -g @xai-official/grok 후 grok login'
};
const ROLE = { claude: '메인', codex: '서브', agy: '서브', grok: '서브' };

(async () => {
  const rows = [];
  const nodeV = run('node --version');
  rows.push(['Node.js', nodeV ? 'OK ' + nodeV : '없음 → https://nodejs.org']);
  const s = await detectVersions();
  for (const k of ['claude', 'codex', 'agy', 'grok']) {
    const v = s.versions[k] || {};
    let msg;
    if (!v.installed) msg = INSTALL[k];
    else if (v.status === 'verified') msg = 'OK ' + v.installed + ' (확인된 버전)';
    else if (v.status === 'older_ok') msg = 'OK ' + v.installed + ' (동작 범위, 확인 버전 ' + v.verified + ')';
    else if (v.status === 'newer_unverified') msg = '주의 ' + v.installed + ' — ' + v.message;
    else if (v.status === 'too_old') msg = '주의 ' + v.installed + ' — ' + v.message;
    else msg = 'OK ' + v.installed;
    rows.push([v.label + ' (' + ROLE[k] + ')', msg]);
  }
  rows.push(['cloudflared.exe', fs.existsSync(path.join(__dirname, 'cloudflared.exe')) ? 'OK' : '없음 → 배포판 폴더에 포함돼 있어야 함']);
  console.log('\n=== 설치 점검 (검증표 ' + (s.verified_at || '-') + ' 기준) ===');
  for (const [k, v] of rows) console.log(k.padEnd(24) + v);
  if (s.unverified.length) console.log('\n※ 확인되지 않은 버전이 있습니다. 문제가 생기면 PC 의 Claude Code 에 "OneMACS 진단해줘" 라고 시키세요.');
  console.log('\n메인(Claude Code)과 Node, cloudflared 세 개만 OK면 시작할 수 있습니다. 서브 워커는 있는 것만 탭에서 동작합니다.');

  if (process.argv.includes('--health')) {
    console.log('\n=== 응답 점검 (각 AI 에 "답으로 OK만 출력" 을 보냅니다, 최대 3분) ===');
    const { runHealthcheck } = require('./healthcheck');
    const h = await runHealthcheck();
    for (const k of Object.keys(h.results)) { const r = h.results[k]; console.log((r.label + ' ').padEnd(24) + (r.ok ? 'OK (' + (r.format || '-') + ', ' + r.ms + 'ms)' : '실패 — ' + (r.message || r.cause))); }
  }
  process.exit(0);
})();
