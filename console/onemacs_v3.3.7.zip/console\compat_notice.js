/**
 * 원격 호환 공지 (2026-09-21) — 콘솔이 하루 1회 WAAT 의 compat.json 을 읽어 폰 상태줄에 안내한다.
 *  URL : https://www.waat.community/market/onemacs/compat.json   (없거나 실패하면 조용히 무시)
 *  스키마:
 *    { "updated": "2026-09-21",
 *      "notices": [
 *        { "ai": "codex",           // claude | codex | agy | grok | * (전체)
 *          "min_unsupported": "0.160.0",   // 이 버전 이상은 아직 미지원 (설치 버전 >= 이 값이면 안내). 비우면 무조건 안내
 *          "message": "Codex 0.160 이후 버전은 확인 중입니다. 문제가 생기면 Claude Code에게 맡기세요.",
 *          "until": "2026-10-31"    // (선택) 이 날짜 지나면 안내 안 함
 *        } ] }
 *      "console_latest": { "version": "3.1.0", "zip_url": "https://…/OneMACS_v3.1.0.zip", "summary": "프로젝트 관리 시트", "date": "2026-10-01" }   // (선택, W8 2026-09-22) 배포판 새 버전 안내
 *  캐시: compat_remote.json(콘솔 본체 폴더) — 24시간.
 */
const fs = require('fs');
const path = require('path');
const https = require('https');
const { cmpVer } = require('./cli_versions');

const URL_ = process.env.ONEMACS_COMPAT_URL || 'https://www.waat.community/market/onemacs/compat.json';
const STATE_DIR = process.env.CONSOLE_HOME || __dirname;
const CACHE_FILE = path.join(STATE_DIR, 'compat_remote.json');
const TTL_MS = 24 * 60 * 60 * 1000;

function readCache() { try { return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8')); } catch (_) { return null; } }

function fetchRemote() {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    try {
      const req = https.get(URL_, { headers: { 'User-Agent': 'onemacs-console', 'Cache-Control': 'no-cache' }, timeout: 8000 }, (res) => {
        let b = ''; res.on('data', d => { b += d; if (b.length > 200000) req.destroy(); });
        res.on('end', () => { if (res.statusCode !== 200) return finish(null); try { const j = JSON.parse(b); finish(j && Array.isArray(j.notices) ? j : null); } catch (_) { finish(null); } });
      });
      req.on('timeout', () => { req.destroy(); finish(null); });
      req.on('error', () => finish(null));
    } catch (_) { finish(null); }
  });
}

/** 하루 1회만 원격을 읽고 캐시. 실패면 이전 캐시 유지 */
async function refresh(force) {
  const c = readCache();
  if (!force && c && c.fetchedAt && Date.now() - new Date(c.fetchedAt).getTime() < TTL_MS) return c;
  const j = await fetchRemote();
  const next = j ? { fetchedAt: new Date().toISOString(), ok: true, data: j } : Object.assign(c || { data: null }, { fetchedAt: new Date().toISOString(), ok: false });
  try { fs.writeFileSync(CACHE_FILE, JSON.stringify(next, null, 2), 'utf8'); } catch (_) {}
  return next;
}

/** 설치 버전(cli_versions.readVersions().versions)과 대조해 지금 보여줄 공지만 고른다 */
function applicable(versions) {
  const c = readCache();
  const list = c && c.data && Array.isArray(c.data.notices) ? c.data.notices : [];
  const today = new Date().toISOString().slice(0, 10);
  const out = [];
  for (const n of list) {
    if (!n || !n.message) continue;
    if (n.until && String(n.until) < today) continue;
    const ai = String(n.ai || '*').toLowerCase();
    if (ai !== '*') {
      const v = versions && versions[ai] && versions[ai].installed;
      if (!v) continue;                                        // 설치 안 된 AI 공지는 무의미
      if (n.min_unsupported && cmpVer(v, n.min_unsupported) < 0) continue; // 아직 그 버전 아님
    }
    out.push({ ai, kind: 'remote', message: String(n.message).slice(0, 200) });
  }
  // W8 (2026-09-22, PO): 배포판 사용자가 새 버전이 나온 줄 모른다 → compat.json 의 console_latest { version, zip_url, summary, date } 가
  //   설치 버전(VERSION 파일)보다 높으면 상태줄 한 줄. Claude Code 에 "OneMACS 업데이트해줘" 라고 하면 docs\OneMACS_업데이트.md 절차(zip → install.ps1 -Update)
  const latest = latestConsole();
  if (latest) out.push({ ai: '*', kind: 'update', message: 'OneMACS 콘솔 새 버전 ' + latest.version + (latest.summary ? ' — ' + latest.summary : '') + ' · PC 의 Claude Code 에 "OneMACS 업데이트해줘"', version: latest.version, zip_url: latest.zip_url || '' });
  return out;
}

/** compat.json 의 console_latest 가 설치본보다 새 버전이면 그 항목, 아니면 null */
function latestConsole() {
  const c = readCache();
  const l = c && c.data && c.data.console_latest;
  if (!l || !l.version) return null;
  // 운영본(파인더월드 3대, legacy_hub 없음)은 정본 동기화로 갱신되고 버전 체계도 다르므로 배포판(legacy_hub:false)에서만 안내
  try { const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'console_config.json'), 'utf8').replace(/^﻿/, '')); if (cfg.legacy_hub !== false) return null; } catch (_) { return null; }
  let local = '';
  try { local = fs.readFileSync(path.join(__dirname, 'VERSION'), 'utf8').trim(); } catch (_) { return null; }
  return cmpVer(String(l.version), local) > 0 ? { version: String(l.version), zip_url: l.zip_url || '', summary: l.summary || '', date: l.date || '' } : null;
}

function schedule(log) {
  const run = () => refresh(false).then(c => { if (c && c.ok && c.data) (log || console.log)('호환 공지 확인: ' + (c.data.notices || []).length + '건'); }).catch(() => {});
  const t = setTimeout(run, 30000); const iv = setInterval(run, TTL_MS);
  if (t.unref) t.unref(); if (iv.unref) iv.unref();
}

module.exports = { refresh, applicable, latestConsole, schedule, URL: URL_, CACHE_FILE };

if (require.main === module) {
  refresh(true).then((c) => { console.log(JSON.stringify(c, null, 2)); process.exit(0); });
}
