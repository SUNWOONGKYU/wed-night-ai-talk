/**
 * daemon_ask.js — 메인 Claude(1번 프로젝트)가 다른 프로젝트의 Claude 데몬에게 지시하고 답을 받는 CLI
 *
 *   node daemon_ask.js "<프로젝트명>" "<지시>"            → 지시 보내고 끝날 때까지 기다려 마지막 답을 출력
 *   node daemon_ask.js "<프로젝트명>" --file <지시문.txt>  → **긴 지시는 반드시 이것으로.** 명령줄로 넘기면
 *                                                            PowerShell 이 큰따옴표에서 인자를 끊어 거기까지만 도착한다
 *   node daemon_ask.js "<프로젝트명>" "<지시>" --nowait   → 접수만 하고 바로 종료
 *   node daemon_ask.js --list                              → 프로젝트 목록·상태
 *   node daemon_ask.js "<프로젝트명>" --status             → 그 프로젝트의 최근 대화 5줄
 *   --pc <hostname|라벨>  를 앞에 붙이면 **다른 PC** 의 채널에 보낸다 (2026-09-22 PO: "허브에 등록된 PC 끼리 서로 지시")
 *       예) node daemon_ask.js --pc MY-LAPTOP "보고서_에이전트" "패키지 상태를 한 줄로"
 *       경로: 허브 장부(페어링 허브 /devices?code=, 같은 코드를 쓰는 내 PC 들)에서 그 PC 의 최신 터널 주소를 찾아 https 로 같은 API 를 부른다. PIN 은 같은 값 또는 CONSOLE_PIN.
 *
 * 통로: 라우터(7890) /api/send-mobile-input · /api/live-transcript + 헤더 X-Console-Project (폰 콘솔과 같은 길)
 * 환경: CONSOLE_URL(기본 http://127.0.0.1:7890), CONSOLE_PIN(기본 console_config.json 의 pin)
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

let cfg = {}; try { cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'console_config.json'), 'utf8').replace(/^﻿/, '')); } catch (_) {}
let BASE = process.env.CONSOLE_URL || ('http://127.0.0.1:' + (cfg.port || 7890));
// 허브 장부 조회는 hub_lookup.js 한 곳에서만 한다 — bridge.js 도 같은 것을 쓴다.
// 여기에 따로 두었더니 기본 허브 주소 규칙이 start_all.js 와 어긋나, 페어링 허브를 놔두고
// 옛 장부만 보고 있었다(2026-09-23 실측). 두 벌로 두지 않는다.
const findPcUrl = require('./hub_lookup.js').findPcUrl;

const PIN = process.env.CONSOLE_PIN || cfg.pin || '';
const WAIT_MAX_MS = Number(process.env.DAEMON_WAIT_MS || 30 * 60 * 1000);

function call(method, pathname, project, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(pathname, BASE); u.searchParams.set('pin', PIN);
    const data = body ? Buffer.from(JSON.stringify(body), 'utf8') : null;
    const headers = { 'Accept': 'application/json' };
    if (project) headers['X-Console-Project'] = encodeURIComponent(project);
    if (data) { headers['Content-Type'] = 'application/json; charset=utf-8'; headers['Content-Length'] = data.length; }
    const mod = u.protocol === 'https:' ? https : http;
    const r = mod.request({ host: u.hostname, port: u.port || undefined, path: u.pathname + u.search, method, headers, timeout: 20000 }, (res) => {
      const bufs = []; res.on('data', d => bufs.push(d)); res.on('end', () => { const t = Buffer.concat(bufs).toString('utf8'); try { resolve({ status: res.statusCode, body: JSON.parse(t) }); } catch (_) { resolve({ status: res.statusCode, body: t }); } });
    });
    r.on('timeout', () => { r.destroy(new Error('timeout')); }); r.on('error', reject);
    if (data) r.write(data); r.end();
  });
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  const argv = process.argv.slice(2);
  const pcIdx = argv.indexOf('--pc');
  if (pcIdx >= 0) {
    const pc = argv[pcIdx + 1]; argv.splice(pcIdx, 2);
    try { BASE = await findPcUrl(pc); } catch (e) { console.error('오류: ' + e.message); process.exit(2); }
    console.error('[--pc ' + pc + '] ' + BASE);
  }
  if (!argv.length || argv[0] === '--list') {
    // 2026-09-22 OneMACS 관제: 채널마다 작업 중/대기/끊김 을 한 줄로 — 메인 워커(OneMACS 창)가 이 PC 데몬들을 살필 때 쓴다
    const r = await call('GET', '/api/projects');
    const list = (r.body && r.body.projects) || [];
    for (const p of list) {
      let st = null; try { const t = await call('GET', '/api/live-transcript?limit=1', p.name); st = t.body || null; } catch (_) {}
      const last = st && st.messages && st.messages.length ? st.messages[st.messages.length - 1] : null;
      const when = last && last.time ? new Date(last.time) : null;
      const ago = when && !isNaN(when) ? Math.round((Date.now() - when.getTime()) / 60000) + '분 전' : '';
      const state = !p.alive ? '죽음' : (st && st.isWorking ? '작업 중' + (st.queued ? ' +대기 ' + st.queued : '') : '대기');
      const stall = st && st.isWorking && when && !isNaN(when) && Date.now() - when.getTime() > 30 * 60000 ? '  ⚠️ 30분 넘게 진행 중 — 끊겼을 수 있음' : '';
      console.log((p.current ? '* ' : '  ') + p.name + (p.home ? ' [홈]' : '') + (p.primary ? ' [PC창]' : ' [데몬]') + '  ' + state + (ago ? ' (' + ago + ')' : '') + (st && st.lastAction ? '  ' + st.lastAction : '') + (p.failed ? '  ⚠️ ' + (p.failReason || '기동 실패') : '') + stall + '\n      ' + p.dir + (last ? '\n      마지막: [' + last.role + '] ' + String(last.text || last.summary || '').replace(/\s+/g, ' ').slice(0, 90) : ''));
    }
    return;
  }
  const project = argv[0];
  if (argv[1] === '--status') {
    const r = await call('GET', '/api/live-transcript?limit=5', project);
    const st = r.body || {};
    console.log('worker=' + st.worker + ' mode=' + st.mode + ' session=' + st.conversationId + ' working=' + st.isWorking + ' queued=' + st.queued);
    for (const m of (st.messages || []).slice(-5)) console.log('[' + m.role + '] ' + String(m.text || m.summary || '').slice(0, 300).replace(/s+/g, ' '));
    return;
  }
  // --worker codex|agy|grok : 그 프로젝트의 Claude 가 아니라 해당 AI 탭에 직접 지시 (폰 탭과 같은 /api/<w>-send · /api/<w>-status) — PO 2026-09-22 질문(카탈로그 14번)
  const wIdx = argv.indexOf('--worker');
  const worker = wIdx >= 0 ? String(argv[wIdx + 1] || '').toLowerCase() : '';
  if (wIdx >= 0) argv.splice(wIdx, 2);
  if (worker && !['codex', 'agy', 'grok'].includes(worker)) { console.error('--worker 는 codex | agy | grok'); process.exit(2); }
  // 긴 지시는 **파일로 넘긴다.** 명령줄 인자로 넘기면 PowerShell 이 큰따옴표에서 인자를 끊어 버려
  // 거기까지만 도착한다 (2026-09-23 실측: 첫 큰따옴표 735자 지점에서 잘려 PC1 M7 이 결함 보고 뒷부분을 못 받음).
  //   node daemon_ask.js --pc <PC> "<프로젝트명>" --file <지시문.txt>
  const fIdx = argv.findIndex(a => a === '--file' || a === '--text-file');
  let text = argv[1];
  if (fIdx >= 0) {
    const fp = argv[fIdx + 1];
    argv.splice(fIdx, 2);
    try { text = fs.readFileSync(fp, 'utf8').replace(/^﻿/, ''); }
    catch (e) { console.error('지시문 파일을 읽지 못했습니다: ' + fp + ' — ' + e.message); process.exit(2); }
    if (!text.trim()) { console.error('지시문 파일이 비어 있습니다: ' + fp); process.exit(2); }
  }
  if (!text) { console.error('사용법: node daemon_ask.js [--pc <PC>] "<프로젝트명>" ("<지시>" | --file <지시문.txt>) [--worker codex|agy|grok] [--nowait]\n        긴 지시(수백 자 이상)는 --file 을 쓰십시오 — 명령줄로 넘기면 따옴표에서 잘립니다.'); process.exit(2); }
  if (worker) {
    const st0 = await call('GET', '/api/' + worker + '-status', project); const n0 = ((st0.body && st0.body.messages) || []).length;
    const sent = await call('POST', '/api/' + worker + '-send', project, { text });
    if (sent.status !== 200) { console.error('전송 실패', sent.status, JSON.stringify(sent.body)); process.exit(1); }
    if (argv.includes('--nowait')) { console.log('접수됨 (' + worker + ')'); return; }
    const t0 = Date.now(); let seen = false;
    while (Date.now() - t0 < WAIT_MAX_MS) {
      await sleep(2000);
      const r = await call('GET', '/api/' + worker + '-status', project).catch(() => null); const st = r && r.body; if (!st) continue;
      if (st.isWorking) seen = true;
      const msgs = st.messages || [];
      if (!st.isWorking && (seen || msgs.length > n0 + 1)) { const ai = msgs.filter(m => m.role === 'ai').slice(-1)[0]; if (ai) { process.stdout.write(String(ai.text || ai.summary || '') + '\n'); return; } if (Date.now() - t0 > 15000) { console.log('(답변 없음)'); return; } }
    }
    console.error('대기 시간 초과'); process.exit(3);
  }
  const before = await call('GET', '/api/live-transcript?limit=1', project);
  const baseCount = (before.body && before.body.count) || 0;
  const sent = await call('POST', '/api/send-mobile-input', project, { text });
  if (sent.status !== 200) { console.error('전송 실패', sent.status, JSON.stringify(sent.body)); process.exit(1); }
  if (argv.includes('--nowait')) { console.log('접수됨 (queued=' + ((sent.body || {}).queued || 0) + ')'); return; }
  const t0 = Date.now(); let seenWorking = false;
  while (Date.now() - t0 < WAIT_MAX_MS) {
    await sleep(2000);
    const r = await call('GET', '/api/live-transcript', project).catch(() => null);
    const st = r && r.body; if (!st) continue;
    if (st.isWorking) seenWorking = true;
    if (!st.isWorking && (seenWorking || (st.count || 0) > baseCount + 1)) {
      const msgs = st.messages || [];
      // 이번 지시 이후의 마지막 AI 텍스트
      let idx = msgs.map(m => m.role === 'user' && m.text === text).lastIndexOf(true);
      const after = idx >= 0 ? msgs.slice(idx + 1) : msgs.slice(-3);
      const ai = after.filter(m => m.role === 'ai').slice(-1)[0];
      if (ai) { process.stdout.write(ai.text + '\n'); return; }
      if (Date.now() - t0 > 15000) { console.log('(답변 텍스트 없음 — 상태: ' + (st.lastAction || '') + ')'); return; }
    }
  }
  console.error('대기 시간 초과'); process.exit(3);
})().catch(e => { console.error('오류:', e.message); process.exit(1); });
