#!/usr/bin/env node
/**
 * 위험 명령 차단 훅 (2026-09-21, 안전 모드) — Claude Code PreToolUse(Bash) 훅 규격
 *  stdin : {"tool_name":"Bash","tool_input":{"command":"..."}}
 *  stdout: {"decision":"block","reason":"..."} 이면 차단, 빈 출력이면 허용. exit 0.
 *  (trader-bot 저장소 .claude/hooks/dangerous-cmd-approval.py 의 패턴을 일반화. 승인 경로(CPC) 없이 차단만 한다 — 안전 모드의 뜻.)
 *  같은 판정 함수(isDangerous)를 grok --deny 규칙 생성·감사 로그·다른 브릿지가 재사용한다.
 *  모든 판정은 logs/audit_YYYYMMDD.log 에 hook_block / hook_allow 로 남는다.
 */
const path = require('path');

// [설명, 정규식] — 대소문자 무시. 허용 예외(SAFE)는 아래.
const RULES = [
  ['파일·폴더 삭제', /(^|[\s;&|(])(rm\s+(-[a-z]*r[a-z]*f|-[a-z]*f[a-z]*r|-rf|-fr)\b|rm\s+-r\b|rmdir\s+\/s|rd\s+\/s|del\s+\/[sq]|Remove-Item\b[^\n]*-Recurse|shred\b)/i],
  ['디스크·파티션 조작', /\b(format\s+[a-z]:|diskpart\b|mkfs\.|fdisk\b|bcdedit\b|wipefs\b)/i],
  ['레지스트리 변경', /\b(reg\s+(add|delete|import|restore)|regedit\s+\/s|Set-ItemProperty\s+[^\n]*HK(LM|CU)|New-ItemProperty\s+[^\n]*HK(LM|CU)|Remove-ItemProperty\s+[^\n]*HK(LM|CU))\b/i],
  ['자격증명·비밀 파일 접근', /(\.credentials(\.json)?|\.env(\.[a-z]+)?\b|\.netrc|id_rsa|id_ed25519|\.pem\b|keystore|\.jks\b|\.p12\b|\.pfx\b|console_config\.json|\.claude[\\\/]\.credentials)/i],
  ['git 강제 푸시·이력 파괴', /\bgit\s+(push\s+[^\n]*(--force|-f\b)|reset\s+--hard|branch\s+-D|clean\s+-[a-z]*f|filter-branch|push\s+[^\n]*--delete)/i],
  ['작업 스케줄러 삭제·변경', /\b(schtasks\s+\/(delete|change)|Unregister-ScheduledTask|Disable-ScheduledTask)\b/i],
  ['시스템 종료·계정·방화벽', /\b(shutdown\s+\/[srp]|net\s+user\b|netsh\s+(advfirewall|firewall)|icacls\s+[^\n]*\/grant\s+everyone|takeown\b)\b/i],
  ['프로세스 일괄 종료', /\b(taskkill\s+\/f\s+\/im\s+(explorer|winlogon|csrss|lsass)|Stop-Process\s+[^\n]*-Name\s+(explorer|winlogon))/i],
  ['DB 파괴 쿼리', /\b(DROP\s+(TABLE|DATABASE)|TRUNCATE\s+TABLE|DELETE\s+FROM\s+\w+\s*;?\s*$)/i],
  ['원격 스크립트 즉시 실행', /(curl|wget|iwr|Invoke-WebRequest)[^\n|]*\|\s*(sh|bash|powershell|iex)\b|\biex\s*\(\s*(iwr|Invoke-WebRequest)/i]
];
const SAFE = [
  /Remove-Item\s+"?\$env:TEMP/i, /Remove-Item\s+"?C:\\+Windows\\+Temp/i, /rm\s+-rf?\s+(\.\/)?node_modules\b/i, /rm\s+-rf?\s+(\.\/)?dist\b/i, /git\s+push\s+origin\s+\S+\s*$/i
];

function isDangerous(cmd) {
  const c = String(cmd || '');
  if (!c.trim()) return null;
  if (SAFE.some(re => re.test(c))) return null;
  for (const [why, re] of RULES) if (re.test(c)) return why;
  return null;
}

module.exports = { isDangerous, RULES };

if (require.main === module) {
  let raw = '';
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', d => raw += d);
  process.stdin.on('end', () => {
    let input = {}; try { input = JSON.parse(raw || '{}'); } catch (_) {}
    const ti = input.tool_input || {};
    const cmd = ti.command || ti.cmd || (typeof ti === 'string' ? ti : '');
    const why = isDangerous(cmd);
    let audit = null; try { audit = require(path.join(__dirname, '..', 'audit.js')).audit; } catch (_) {}
    if (why) {
      if (audit) audit('hook_block', { tool: input.tool_name || 'Bash', why, command: cmd });
      process.stdout.write(JSON.stringify({ decision: 'block', reason: '[OneMACS 안전 모드] 이 명령은 실행하지 않습니다 — ' + why + '. 꼭 필요하면 핸드폰 ⚙ 설정에서 권한 모드를 자동 승인 모드로 바꾸세요(PIN 입력).' }));
    } else if (audit) audit('hook_allow', { tool: input.tool_name || 'Bash', command: cmd });
    process.exit(0);
  });
}
