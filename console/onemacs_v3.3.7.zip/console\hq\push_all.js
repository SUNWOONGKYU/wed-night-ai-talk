/**
 * push_all.js — 정본에 게시한 판을 **모든 PC 에 바로 퍼뜨린다** (HQ 전용, publish.js 가 끝에서 자동으로 부른다)
 *   PO 2026-09-24: 「수정이 일어나면 빨리빨리 정본을 수정해 놓고 PC1·PC2 에 전달해야지. 시킬 때 하지 말고 시스템화해」
 *
 *   node hq/push_all.js <버전>        예) node hq/push_all.js 1.9.39
 *
 * 허브 장부에서 내 PC 들(같은 페어링 코드)의 주소를 읽어 각 PC 에 POST /api/console-restart?want=<버전> 을 보낸다.
 * 각 PC 는 **자기 구글 드라이브에 그 판이 도착할 때까지 기다렸다가**(최대 15분) 자기 권한으로 재시작하고 새 판을 받는다.
 * 옛 판(원격 재시작 API 가 없는 PC)은 404 로 답한다 — 그 PC 만 사람이 한 번 재시작하면 이후는 자동이다.
 */
'use strict';
const path = require('path');
const https = require('https');
const http = require('http');
const HOME = process.env.CONSOLE_HOME || 'C:\\OneMACS\\console';
process.env.CONSOLE_HOME = HOME;
const hub = require(path.join(HOME, 'hub_lookup.js'));
const PIN = (() => { try { return String(require(path.join(HOME, 'console_config.json')).pin || ''); } catch (_) { return ''; } })();

function post(u) {
  return new Promise((resolve) => {
    const mod = u.startsWith('https') ? https : http;
    const r = mod.request(u, { method: 'POST', timeout: 20000, headers: { 'User-Agent': 'OneMACS-HQ/1.0', 'Content-Length': 0 } }, (res) => {
      const b = []; res.on('data', d => b.push(d)); res.on('end', () => resolve({ code: res.statusCode, body: Buffer.concat(b).toString('utf8').slice(0, 200) }));
    });
    r.on('timeout', () => r.destroy(new Error('timeout')));
    r.on('error', (e) => resolve({ code: 0, body: e.message }));
    r.end();
  });
}

(async () => {
  const want = String(process.argv[2] || '').trim();
  if (!/^\d+\.\d+\.\d+$/.test(want)) { console.error('사용법: node hq/push_all.js <버전>'); process.exit(2); }
  let pcs = [];
  try { pcs = await hub.listPcs(); } catch (e) { console.error('허브 장부를 읽지 못함: ' + e.message); process.exit(3); }
  // 한 PC 에 프로젝트가 여럿이라 주소가 겹친다 — 호스트별로 한 번만
  const byHost = new Map();
  for (const p of pcs) { const h = p.hostname || p.host || ''; const u = String(p.url || '').replace(/\/+$/, ''); if (h && u && !byHost.has(h)) byHost.set(h, { url: u, label: p.display || p.label || h }); }
  if (!byHost.size) { console.log('퍼뜨릴 PC 가 장부에 없습니다'); return; }
  for (const [h, v] of byHost) {
    const r = await post(v.url + '/api/console-restart?want=' + encodeURIComponent(want) + '&pin=' + encodeURIComponent(PIN));
    let msg;
    if (r.code === 202) msg = '접수 — 드라이브에 v' + want + ' 가 오면 재시작';
    else if (r.code === 200) msg = '이미 v' + want;
    else if (r.code === 404) msg = '옛 판(원격 재시작 없음) — 그 PC 에서 한 번만 직접 재시작 필요';
    else msg = '실패 ' + r.code + ' ' + r.body;
    console.log('  ' + (v.label + ' (' + h + ')').padEnd(30) + msg);
  }
})();
