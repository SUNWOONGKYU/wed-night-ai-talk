<!-- OneMACS 배포판 v3 · 2026-09-22 · W8 -->
# OneMACS 콘솔 업데이트 — Claude Code 지시문

사용자가 "OneMACS 업데이트해줘"라고 하면 이 절차대로 한다. 설정(PIN·프로젝트·허브)·대화 세션·로그는 그대로 남고 코드만 바뀐다.

## 절차
1. 현재 버전 확인: `type C:\OneMACS\console\VERSION`
2. 새 버전 확인: 폰 상태줄의 "OneMACS 콘솔 새 버전 x.y.z" 또는 `C:\OneMACS\console\compat_remote.json` 의 `data.console_latest` (`version`, `zip_url`, `summary`). 없으면 판매 페이지에서 최신 zip 을 받는다.
3. zip 받기: `zip_url` 을 `%TEMP%\onemacs_update\` 에 내려받아 푼다 (PowerShell: `Invoke-WebRequest -Uri <zip_url> -OutFile ...` → `Expand-Archive`). 풀린 폴더 안에 `console\`·`install.ps1` 이 있어야 한다.
4. 업데이트 실행 (푼 폴더에서):
   ```
   powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -Update
   ```
   → 실행 중 콘솔을 잠깐 세우고 코드를 덮은 뒤 다시 기동한다 (1~2분 끊김).
5. 확인: `type C:\OneMACS\console\VERSION` 이 새 버전, `C:\OneMACS\console\start_all.log` 에 `터널 URL 발급 성공`, 폰에서 OneMACS 채널에 "안녕" → 답.
6. 사용자에게 보고: 이전 버전 → 새 버전, 바뀐 점(`summary`), 이상 유무.

## 안 되면
- 포트가 안 열리면 `C:\OneMACS\console\restart_console.cmd` 한 번 더. 그래도 안 되면 `start_all.log` 마지막 30줄을 사용자에게 보여 준다.
- 되돌리기: 이전 zip 으로 같은 명령(`install.ps1 -Update`)을 실행하면 그 버전으로 돌아간다.
