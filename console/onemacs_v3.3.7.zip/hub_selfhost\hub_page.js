// 허브 페이지 (워커 GET / 가 서빙) — 페어링 코드 입력 → 이 코드의 PC 목록(탭) → 콘솔 iframe. PIN 은 폰 저장소에만 둔다.
export const HUB_PAGE = `<!DOCTYPE html>
<html lang="ko"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, interactive-widget=resizes-content">
<title>One MACS · OneMACS</title>
<style>
  :root { --bg:#0b0e17; --surface:#131826; --border:#28334e; --accent:#2563eb; --accent-light:#60a5fa; --win:#10b981; --warn:#f59e0b; --text:#f1f5f9; --dim:#8a99b5; }
  * { box-sizing:border-box; margin:0; padding:0; -webkit-tap-highlight-color:transparent; }
  html, body { background:var(--bg); color:var(--text); font-family:-apple-system,BlinkMacSystemFont,'Pretendard',sans-serif; height:100%; height:100dvh; overflow:hidden; }
  /* hub-banner-css:start — 자동 생성: node _console_hub_worker/build_hub_page.js (원본 _deploy_console_hub/index.html) — 직접 고치지 말 것 */
  /* 맨 위 배너 줄(PO 확정): 좌 ⓘ 사용법 · 가운데 문구 · 우 ⚙ 콘솔 설정(열린 콘솔 iframe 의 설정 시트를 postMessage 로 연다) */
  .brandbar { height:44px; display:flex; align-items:center; justify-content:space-between; gap:8px; padding:0 8px; background:var(--bg); border-bottom:1px solid var(--border); flex-shrink:0; }
  .brandbar .side { flex:0 0 44px; width:44px; height:44px; border:0; border-radius:10px; background:rgba(255,255,255,0.06); color:var(--dim); font-size:18px; font-weight:800; cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }
  .brandbar .side:active { background:var(--accent); color:#fff; }
  .brandbar span.phrase { flex:1 1 auto; min-width:0; text-align:center; font-size:clamp(14px,3.9vw,15.5px); font-weight:600; letter-spacing:.02em; text-transform:none; white-space:nowrap; overflow:visible; line-height:1; background:linear-gradient(90deg,#a855f7,#60a5fa 60%,#38bdf8); -webkit-background-clip:text; background-clip:text; color:transparent; }
  /* 문구 크기(정본): clamp(14px, 3.9vw, 15.5px)·600·자간 .02em 고정 — JS 자간 조정 없음 */
  /* hub-banner-css:end */
  .bar { height:50px; background:var(--surface); border-bottom:1.5px solid var(--border); display:flex; align-items:center; padding:0 8px; gap:6px; overflow-x:auto; }
  .tab { flex:1 0 auto; min-width:0; display:flex; align-items:center; justify-content:center; gap:6px; background:rgba(255,255,255,0.04); border:1.5px solid var(--border); border-radius:10px; padding:6px 6px; color:var(--dim); font-size:12.5px; font-weight:700; cursor:pointer; white-space:nowrap; text-align:center; }
  .tab.active { background:rgba(37,99,235,0.22); border-color:var(--accent-light); color:#fff; }
  .tab small { display:block; font-size:9px; font-weight:600; opacity:.7; margin-top:1px; line-height:1.1; }
  .tab .gear { flex:0 0 auto; }
  .dot { width:7px; height:7px; border-radius:50%; background:var(--dim); flex-shrink:0; }
  .dot.online { background:var(--win); box-shadow:0 0 6px var(--win); }
  .view { width:100%; height:calc(100% - 50px); position:relative; }
  iframe { width:100%; height:100%; border:none; display:none; background:var(--bg); }
  iframe.active { display:block; }
  .pane { display:none; position:absolute; inset:0; align-items:center; justify-content:center; flex-direction:column; gap:14px; padding:24px; text-align:center; color:var(--dim); font-size:14px; }
  .pane.active { display:flex; }
  .card { width:100%; max-width:360px; background:var(--surface); border:1px solid var(--border); border-radius:16px; padding:22px 18px; }
  .card h2 { color:#fff; font-size:18px; margin-bottom:6px; }
  .card p { font-size:12.5px; line-height:1.5; margin-bottom:14px; }
  .card input { width:100%; background:#0b0e17; border:1.5px solid var(--border); border-radius:12px; padding:13px; color:#fff; font-size:22px; font-weight:800; text-align:center; letter-spacing:6px; text-transform:uppercase; outline:none; margin-bottom:10px; }
  .card button { width:100%; background:var(--accent); color:#fff; border:none; border-radius:12px; padding:13px; font-size:15px; font-weight:800; cursor:pointer; }
  .card .err { color:#f87171; font-size:12px; min-height:16px; margin-top:8px; }
  .spinner { width:26px; height:26px; border-radius:50%; border:3px solid var(--border); border-top-color:var(--accent-light); animation:spin .9s linear infinite; }
  @keyframes spin { to { transform:rotate(360deg); } }
</style></head>
<body>
  <script>
  (function(){var vv=window.visualViewport;if(!vv)return;var r=document.documentElement,b=document.body;function fit(){try{var h=Math.round(vv.height),off=Math.round(vv.offsetTop||0),kb=Math.max(0,window.innerHeight-h-off);if(kb>80){b.style.height=h+'px';r.style.height=h+'px';b.style.transform=off?'translateY('+off+'px)':'';}else{b.style.height='';r.style.height='';b.style.transform='';}}catch(_){}}vv.addEventListener('resize',fit);vv.addEventListener('scroll',fit);window.addEventListener('orientationchange',function(){setTimeout(fit,250);});})();
  </script>
<!-- hub-banner:start — 자동 생성(build_hub_page.js), 직접 고치지 말 것 -->
<div class="brandbar" role="toolbar" aria-label="OneMACS">
  <button class="side" type="button" id="guideBtn" aria-label="사용법 보기" title="사용법" onclick="window.open('https://www.waat.community/market/onemacs/guide','_blank')"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><line x1="12" y1="11" x2="12" y2="16.5"/><circle cx="12" cy="8" r="0.6" fill="currentColor"/></svg></button>
  <span class="phrase">One-stop Multi AI Console System</span>
  <button class="side" type="button" id="settingsBtn" aria-label="콘솔 설정" title="콘솔 설정" onclick="openConsoleSettings()">⚙</button>
</div>
<!-- hub-banner:end -->
<div class="bar" id="bar"></div>
<div class="view" id="view">
  <div class="pane active" id="paneCode"><div class="card">
    <h2>One MACS · OneMACS <small style="font-weight:400;opacity:.7;display:block;font-size:12px">One-stop Multi AI Console System · 원스톱 멀티 AI 콘솔 시스템</small></h2>
    <p>PC 콘솔을 켤 때 검은 창에 나온 <b>페어링 코드 8자리</b>를 넣으세요.<br>같은 코드를 쓰는 PC·프로젝트가 모두 나타납니다.</p>
    <input id="code" maxlength="8" placeholder="ABCD2345" autocomplete="off" inputmode="latin" onkeydown="if(event.key==='Enter')go()">
    <button onclick="go()">연결</button>
    <div class="err" id="err"></div>
  </div></div>
  <div class="pane" id="paneWait"><div class="spinner"></div><div id="waitMsg">PC 찾는 중…</div></div>
</div>
<script>
  const CODE_RE = /^[A-HJ-NP-Z2-9]{8}$/;
  let code = '', devices = {}, active = null, frames = {}, timer = null;
  const $ = (id) => document.getElementById(id);
  function pinFor(url) { try { return localStorage.getItem('pin:' + new URL(url).host) || ''; } catch (_) { return ''; } }
  function askPin(url) { const p = prompt('이 PC 콘솔의 PIN (설치 때 Claude Code가 알려준 6자리)'); if (p) { try { localStorage.setItem('pin:' + new URL(url).host, p.trim()); } catch (_) {} } return (p || '').trim(); }
  function go() {
    const c = ($('code').value || '').trim().toUpperCase();
    if (!CODE_RE.test(c)) { $('err').innerText = '8자리 영숫자(I O 0 1 제외)'; return; }
    code = c; try { localStorage.setItem('pair_code', code); } catch (_) {}
    history.replaceState(null, '', '?code=' + code);
    $('paneCode').classList.remove('active'); $('paneWait').classList.add('active');
    poll(); timer = setInterval(poll, 15000);
  }
  async function poll() {
    try {
      const r = await fetch('/devices?code=' + code + '&t=' + Date.now(), { cache: 'no-store' }); const d = await r.json();
      devices = d.devices || {}; render();
    } catch (_) {}
  }
  function label(d, i) { return { n: i, label: d.display || (d.label && String(d.label).trim()) || 'PC', host: d.host_pretty || d.hostname || '' }; }
  function render() {
    const bar = $('bar'), view = $('view');
    const list = Object.entries(devices).sort((a, b) => (a[1].hostname + a[1].project).localeCompare(b[1].hostname + b[1].project)).map(([k, d], i) => ({ key: k, d, ...label(d, i) }));
    if (!list.length) { $('waitMsg').innerText = '코드 ' + code + ' 로 켜진 PC 가 없습니다. PC의 OneMACS 실행 창이 켜져 있는지 확인해 주세요. PC를 방금 켰다면 1분 뒤 다시 확인됩니다. (15초마다 다시 확인)'; $('paneWait').classList.add('active'); bar.innerHTML = '<button class="tab" onclick="reset()">코드 바꾸기</button>'; return; }
    $('paneWait').classList.remove('active');
    if (!active || !devices[active]) active = list[0].key;
    bar.innerHTML = '';
    for (const it of list) {
      const b = document.createElement('button'); b.className = 'tab' + (it.key === active ? ' active' : ''); b.onclick = () => { active = it.key; render(); };
      b.innerHTML = '<span class="dot online"></span><span>' + it.label + '<small>' + it.host + '</small></span>';
      bar.appendChild(b);
      if (!frames[it.key]) { const f = document.createElement('iframe'); f.allow = 'camera; microphone; clipboard-read; clipboard-write'; view.appendChild(f); frames[it.key] = f; }
      const base = it.d.url.replace(/\\/+$/, '');
      let pin = pinFor(base); if (!pin && it.key === active) pin = askPin(base);
      const want = base + '/?pin=' + encodeURIComponent(pin) + '&embed=1'; // embed=1: 콘솔은 자기 맨 윗줄을 그리지 않는다(허브가 가짐)
      if (pin && frames[it.key].dataset.src !== want) { frames[it.key].dataset.src = want; frames[it.key].src = want; }
      frames[it.key].classList.toggle('active', it.key === active);
    }
    const g = document.createElement('button'); g.className = 'tab gear'; g.innerText = '코드 바꾸기'; g.title = '코드 바꾸기'; g.setAttribute('aria-label', '페어링 코드 바꾸기'); g.onclick = reset; bar.appendChild(g);
  }
// 문구 자간(PO): 글자 크기는 clamp 그대로 두고, 폭을 넘치면 자간만 .06em → .04em → .02em → 0 순으로 줄여 한 줄 유지
  let settingsAck = false, settingsTimer = null;
  window.addEventListener('message', function (e) { const d = e && e.data; if (d && typeof d === 'object' && d.type === 'onemacs:settings-opened') { settingsAck = true; hideHubNotice(); } });
  function showHubNotice(text) {
    let n = document.getElementById('hub-notice');
    if (!n) { n = document.createElement('div'); n.id = 'hub-notice'; n.setAttribute('role', 'status'); n.style.cssText = 'position:fixed;left:12px;right:12px;top:52px;z-index:50;background:#1f2a44;color:#f1f5f9;font-size:13px;line-height:1.5;padding:10px 14px;border-radius:10px;box-shadow:0 6px 18px rgba(0,0,0,.35)'; document.body.appendChild(n); }
    n.textContent = text; n.style.display = 'block';
    clearTimeout(n._t); n._t = setTimeout(hideHubNotice, 6000);
  }
  function hideHubNotice() { const n = document.getElementById('hub-notice'); if (n) n.style.display = 'none'; }
  function openConsoleSettings() {
    const f = active && frames[active];
    if (!f || !f.contentWindow) { showHubNotice('먼저 PC를 연결하세요.'); return; }
    settingsAck = false;
    try { f.contentWindow.postMessage({ type: 'onemacs:open-settings' }, '*'); } catch (_) {}
    clearTimeout(settingsTimer);
    settingsTimer = setTimeout(function () { if (!settingsAck) showHubNotice('이 PC의 OneMACS가 아직 새 버전이 아닙니다 — PC에서 OneMACS를 업데이트한 뒤 다시 켜 주세요.'); }, 500);
  }
  function reset() { clearInterval(timer); active = null; for (const k of Object.keys(frames)) { frames[k].remove(); delete frames[k]; } $('bar').innerHTML = ''; $('paneCode').classList.add('active'); $('paneWait').classList.remove('active'); }
  (function init() {
    const q = new URLSearchParams(location.search).get('code'); let saved = ''; try { saved = localStorage.getItem('pair_code') || ''; } catch (_) {}
    const c = (q || saved || '').toUpperCase(); if (CODE_RE.test(c)) { $('code').value = c; go(); }
  })();
</script>
</body></html>`;
