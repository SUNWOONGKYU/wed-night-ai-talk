/**
 * 원스톱 멀티 에이전트 모바일 콘솔 올인원 통합 실행기 (All-in-One Runner)
 * - server.js (포트 7890) 직접 구동
 * - cloudflared.exe 터널 연결
 * - Gist 및 허브 자동 등록
 * - 모든 stdout/stderr를 start_all.log에 실시간 기록
 */

const fs = require('fs');
try { require('./no_stop_button_guard.js').enforce(__dirname); } catch (e) { if (e && e.code !== 'MODULE_NOT_FOUND') throw e; } // PO 2026-09-20: 정지 버튼 재발 방지 게이트
const path = require('path');
const os = require('os');
const https = require('https');
const { spawn, exec } = require('child_process');

const LOG_FILE = path.join(__dirname, 'start_all.log');

function log(msg) {
  const line = `[${new Date().toLocaleTimeString('ko-KR')}] ${msg}\n`;
  console.log(line.trim());
  try {
    fs.appendFileSync(LOG_FILE, line, 'utf8');
  } catch (_) {}
}

fs.writeFileSync(LOG_FILE, `=== [All-in-One Console Runner] Starting at ${new Date().toISOString()} ===\n`, 'utf8');

const _cfgFile = path.join(__dirname, 'console_config.json');
let _cfg = {};
try { _cfg = JSON.parse(fs.readFileSync(_cfgFile, 'utf8').replace(/^\uFEFF/, '')); } catch (_) {}
const PORT = Number(process.env.PORT || _cfg.port || 7890);
if (_cfg.pin) process.env.PIN = String(_cfg.pin);
process.env.CONSOLE_WORKERS = JSON.stringify(_cfg.workers || {}); // 설치 마법사가 정한 AI 구성(켜기/끄기·모델) → server.js/브릿지
process.env.PORT = String(PORT);
process.env.CONSOLE_HOME = process.env.CONSOLE_HOME || __dirname; // 상태 파일(cli_versions/health_state/last_failure)은 콘솔 본체 폴더 한 곳에 (2026-09-21)
// 보안(2026-09-21): 권한 모드·미러링·한도 표시를 자식(프로젝트 서버·브릿지)에 환경변수로 전달. 운영본은 config 에 명시(perm_mode full / mirror_window true / show_quota true)
process.env.CONSOLE_PERM_MODE = String(_cfg.perm_mode || 'safe').toLowerCase() === 'full' ? 'full' : 'safe';
process.env.CONSOLE_MIRROR = _cfg.mirror_window === false ? '0' : '1'; // 기본 켬 (PO 2026-09-22)
process.env.CONSOLE_SHOW_QUOTA = _cfg.show_quota === true ? '1' : '0';
// 약한 PIN 번호(1234·0000·111111·123456 등) 이면 무작위 6자리로 바꿔 저장 (운영본은 자릿수는 그대로 둔다)
{
  const weak = /^(1234|0000|1111|123456|654321|000000|111111|222222|333333|444444|555555|666666|777777|888888|999999|121212|112233)$/;
  const cur = String(_cfg.pin || '');
  if (!cur || weak.test(cur) || /^(\d)\1+$/.test(cur)) {
    const np = String(Math.floor(100000 + Math.random() * 900000));
    try { const raw = JSON.parse(fs.readFileSync(_cfgFile, 'utf8').replace(/^﻿/, '')); raw.pin = np; fs.writeFileSync(_cfgFile, JSON.stringify(raw, null, 2), 'utf8'); } catch (_) {}
    _cfg.pin = np; process.env.PIN = np;
    log('🔐 PIN 번호가 약해서 새로 만들었습니다: ' + np + ' (console_config.json 에 저장됨)');
  }
}
// 2026-09-22 14:28 장애: 콘솔 트리(라우터+자식 5개)가 로그 한 줄 없이 통째로 사라짐 — 원인 불명. 다음엔 증거가 남도록
//   예외·종료 사유를 start_all.log 에 반드시 남긴다. (라우터는 이 프로세스 안에서 require 되므로 여기 핸들러가 라우터까지 덮는다)
process.on('uncaughtException', (e) => { log('❌ uncaughtException: ' + (e && e.stack || e)); });
process.on('unhandledRejection', (e) => { log('❌ unhandledRejection: ' + (e && e.stack || e)); });
process.on('exit', (code) => { log('⏹ 콘솔 프로세스 종료 (code ' + code + ')'); });
for (const sig of ['SIGTERM', 'SIGHUP', 'SIGBREAK']) { try { process.on(sig, () => { log('⏹ 시그널 수신: ' + sig); process.exit(0); }); } catch (_) {} }
// 살아있음 표시: 워치독(watchdog.cmd)이 이 파일의 갱신 시각으로 생존을 판정한다 (포트 검사 보조)
const HEARTBEAT_FILE = path.join(__dirname, 'heartbeat.txt');
// 내 PID 파일 — stop_console.cmd·install.ps1 이 "이 홈에서 뜬 콘솔"만 정확히 세우기 위해 (보조 W4 결함 #1: 경로 무관하게 start_all 전부를 죽여 운영 콘솔이 다운됨)
try { fs.writeFileSync(path.join(__dirname, 'console.pid'), String(process.pid), 'utf8'); } catch (_) {}
setInterval(() => { try { fs.writeFileSync(HEARTBEAT_FILE, new Date().toISOString(), 'utf8'); } catch (_) {} }, 60 * 1000).unref();

const CLOUDFLARED_PATH = path.join(__dirname, 'cloudflared.exe');
// 2026-09-22 15:1x 장애: 이 망에서 QUIC(UDP 7844) 이 "failed to dial to edge with quic: timeout" 으로 계속 실패 → 터널 주소는 나오는데 530 만 돌아와 3분마다 재기동 반복(14:19~15:14).
//   http2(TCP) 로 강제하면 즉시 200. 기본 http2, 필요하면 console_config.json tunnel_protocol 로 바꿈 (quic|http2|auto)
const TUNNEL_PROTOCOL = (_cfg.tunnel_protocol && /^(quic|http2|auto)$/.test(String(_cfg.tunnel_protocol))) ? String(_cfg.tunnel_protocol) : 'http2';

// ── 고정 주소 (PO 2026-09-23: 「고정 주소로 바꿔. 우리 것부터 먼저」) ─────────────────────────────
//  임시 터널(trycloudflare)은 켤 때마다 주소가 바뀌고, 클라우드플레어가 「테스트·개발 전용, 가동 보장 없음,
//  동시 요청 200개」로 못 박아 둔 방식이다. 고정 주소는 클라우드플레어 계정에 만든 터널에 붙고 주소가 안 바뀐다.
//  config 에 fixed_url + tunnel_token 이 둘 다 있을 때만 고정 모드로 간다. 없으면 지금처럼 임시 터널.
//  **고정 모드가 90초 안에 서지 않으면 임시 터널로 물러선다** — 전환하다 PC 에 못 들어가는 일이 없게.
//  토큰은 명령줄이 아니라 환경변수(TUNNEL_TOKEN)로 넘긴다 — 프로세스 목록·로그에 드러나지 않게.
const FIXED_URL = String(_cfg.fixed_url || '').trim().replace(/\/+$/, '');
const TUNNEL_TOKEN = String(_cfg.tunnel_token || '').trim();
let fixedMode = !!(FIXED_URL && TUNNEL_TOKEN && /^https:\/\//.test(FIXED_URL));
function tunnelSpawnArgs() {
  return fixedMode
    ? { args: ['tunnel', '--no-autoupdate', '--protocol', TUNNEL_PROTOCOL, 'run'], env: Object.assign({}, process.env, { TUNNEL_TOKEN }) }
    : { args: ['tunnel', '--url', `http://127.0.0.1:${PORT}`, '--protocol', TUNNEL_PROTOCOL], env: process.env };
}
const GIST_ID = '';
// 2026-09-22 배포판 v3 준비: Gist/Vercel 장부(registerDeviceToHub·selfHealHub·hub_deploy)는 파인더월드 운영본 전용(legacy) —
//   배포판 console_config.json 은 legacy_hub:false 로 게시되어 페어링 허브(pair_hub_url + pair_code)만 쓴다. 없으면(운영본) 켜짐.
const LEGACY_HUB = _cfg.legacy_hub === true; // 배포판: 명시적으로 켠 경우에만 (Codex 리뷰 2026-09-22)
const HEARTBEAT_SEC = Math.max(30, Number(_cfg.heartbeat_sec) || 60); // 배포판은 300(원가 1/5), 운영본은 60
const GH_TOKEN = process.env.GH_TOKEN || process.env.GITHUB_TOKEN || _cfg.gh_token || ''; // 배포판: 운영 장부(Gist) 는 쓰지 않는다 (legacy_hub:false)
const PERMANENT_HUB_URL = '';
const PIN_CODE = String(_cfg.pin || '');

// 1. server.js 직통 로드 및 실행 (config 에 projects 목록이 있으면 프로젝트 라우터가 포트를 맡고 프로젝트별 server.js 를 자식으로 띄운다)
// 2026-09-22 One MACS: 배포판: 정본 동기화 모듈 없음(install.ps1 -Update 로 갱신)
if (fs.existsSync(path.join(__dirname, 'sync_from_master.js'))) { try { require('./sync_from_master.js').sync(log); } catch (e) { log('⚠️ 정본 동기화 건너뜀: ' + e.message); } } // 배포판에는 없음(install.ps1 -Update)
// (PO 2026-09-24) Jev MCP 는 모든 PC 에 — 기동 때마다 사용자 범위 등록이 있는지 보고, 없거나 경로가 다르면 이 콘솔의 jev_mcp 로 등록한다.
//  열쇠(~/.onemacs/jev.env)는 옮기지 않는다 — 없으면 한 줄만 남긴다(PO 가 넣는다)
(function ensureJevMcp() {
  try {
    const srv = path.join(__dirname, 'jev_mcp', 'server.js'); if (!fs.existsSync(srv)) return;
    const want = srv.replace(/\\/g, '/');
    let reg = null; try { reg = (JSON.parse(fs.readFileSync(path.join(os.homedir(), '.claude.json'), 'utf8')).mcpServers || {}).jev || null; } catch (_) {}
    const have = reg && Array.isArray(reg.args) ? reg.args.join(' ').replace(/\\/g, '/') : '';
    if (!have.includes(want)) {
      const cp = require('child_process');
      if (reg) try { cp.execSync('claude mcp remove --scope user jev', { stdio: 'ignore', timeout: 30000 }); } catch (_) {}
      cp.execSync('claude mcp add --scope user jev -- node "' + want + '"', { stdio: 'ignore', timeout: 30000 });
      log('Jev MCP 등록: ' + want);
    }
    if (!fs.existsSync(path.join(os.homedir(), '.onemacs', 'jev.env')) && !process.env.AI_GATEWAY_API_KEY) log('⚠️ Jev 열쇠 없음 — ~/.onemacs/jev.env 에 AI_GATEWAY_API_KEY 를 넣어야 Jev 가 답합니다');
  } catch (e) { log('⚠️ Jev MCP 등록 건너뜀: ' + e.message); }
})();
const MULTI = Array.isArray(_cfg.projects) && _cfg.projects.length > 0;

// 포트가 비기를 기다린다 — 앞 콘솔이 아직 포트를 놓지 않았는데 바로 띄우면 EADDRINUSE 로
// **조용히 죽는다.** 그러면 재시작이 실패한 줄도 모른 채 폰에서 「연결 안 됨」만 보게 된다.
// (PC1 요청 2026-09-23 · PC2 05:50 실측 사고 · PC3 에서도 같은 증상)
//  **동기로** 기다린다 — 뒤에 오는 기동 순서(터널·허브 등록·헬스체크)를 그대로 지키려면 여기서 멈춰야 한다.
function portListening(port) {
  try {
    const out = require('child_process').execSync('netstat -ano -p tcp', { encoding: 'utf8', windowsHide: true, timeout: 8000 });
    return new RegExp('[:.]' + port + '\\s+\\S+\\s+LISTENING', 'i').test(out);
  } catch (_) { return false; }   // 확인할 수 없으면 막지 않는다
}
function sleepSync(ms) { try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch (_) {} }
{
  const WAIT_MS = 30000, STEP = 1000;
  const t0 = Date.now();
  let said = false;
  while (portListening(PORT)) {
    if (Date.now() - t0 > WAIT_MS) {
      log('❌ 포트 ' + PORT + ' 이 ' + Math.round(WAIT_MS / 1000) + '초가 지나도 비지 않습니다 — 콘솔을 띄우지 않습니다.');
      log('   앞 콘솔이 아직 돌고 있거나 다른 프로그램이 이 포트를 쓰고 있습니다.');
      log('   stop_console.cmd 로 멈춘 뒤 다시 하거나, 작업 관리자에서 node.exe 를 확인하십시오.');
      process.exit(1);
    }
    if (!said) { log('포트 ' + PORT + ' 이 아직 쓰이고 있습니다 — 비기를 기다립니다(최대 ' + Math.round(WAIT_MS / 1000) + '초)'); said = true; }
    sleepSync(STEP);
  }
  if (said) log('포트 ' + PORT + ' 비었습니다 (' + Math.round((Date.now() - t0) / 1000) + '초 기다림) — 기동합니다');
}

log('Step 1: ' + (MULTI ? 'project_router.js (프로젝트 ' + _cfg.projects.length + '개)' : 'server.js') + ' 로드 시작...');
try {
  require(MULTI ? './project_router.js' : './server.js');
  log('Step 1 완료: 포트 ' + PORT + '에서 대기 중입니다!');
} catch (err) {
  log('❌ FATAL: server.js 로드 실패!\n' + err.stack);
  process.exit(1);
}

// Step 1-b (2026-09-21, 기동을 막지 않는 비동기): CLI 버전 실측·검증표(cli_compat.json) 대조 → 미확인 버전은 로그 + /api/status 로 폰 상태줄에 안내.
//  이어서 20초 뒤 헬스체크(각 AI 에 "답으로 OK만 출력") 1회 + 6시간마다, 원격 호환 공지(compat_notice.js)는 하루 1회.
setTimeout(() => {
  try {
    require('./cli_versions.js').detectVersions().then((s) => {
      for (const k of Object.keys(s.versions)) { const v = s.versions[k]; log('CLI ' + v.label + ': ' + (v.installed || '없음') + (v.status === 'verified' ? ' (확인됨)' : (v.message ? ' — ' + v.message : ' (' + v.status + ')'))); }
      if (s.unverified.length) log('⚠️ 확인되지 않은 CLI 버전: ' + s.unverified.map(k => s.versions[k].label + ' ' + s.versions[k].installed).join(', ') + ' → 문제가 생기면 Claude Code 에 "One MACS 진단해줘"');
    }).catch(e => log('CLI 버전 확인 실패: ' + e.message));
  } catch (e) { log('cli_versions 모듈 오류: ' + e.message); }
  try { require('./healthcheck.js').schedule(log, 20000); } catch (e) { log('healthcheck 모듈 오류: ' + e.message); }
  try { require('./compat_notice.js').schedule(log); } catch (e) { log('compat_notice 모듈 오류: ' + e.message); }
}, 3000);

// Gist 등록 함수
// 2026-09-22 홈 이전 후유증: 각 PC 가 자기 로컬 devices.json 을 허브와 되섞기 때문에, 옛 홈 키(예: <PC>__<옛프로젝트>)를
//   한 PC 가 지워도 다른 PC 가 되살린다. 규칙을 "hostname 마다 last_seen 최신 1개만" 으로 두면 어느 PC 가 쓰든 수렴한다.
function collapseByHost(devices, selfHost, selfKey) {
  const best = {};
  for (const [key, d] of Object.entries(devices || {})) {
    if (!d) continue;
    const h = d.hostname || key.split('__')[0];
    const score = (h === selfHost && key === selfKey) ? Infinity : (d.last_seen || 0);
    if (!best[h] || score > best[h].score) best[h] = { key, score };
  }
  const keep = new Set(Object.values(best).map(x => x.key));
  const dropped = Object.keys(devices || {}).filter(k => !keep.has(k));
  for (const k of dropped) delete devices[k];
  return dropped;
}
function registerDeviceToHub(publicUrl, quiet) {
  if (!quiet) log(`Hub 등록 시작: ${publicUrl}`);
  const gistRawUrl = `https://gist.githubusercontent.com/__legacy__/${GIST_ID}/raw/devices.json?nocache=${Date.now()}`;
  
  const updateLocalAndGist = (existingDevices) => {
    try {
      const hostname = os.hostname();
      const parentDir = path.basename(path.resolve(__dirname, '..'));
      const projectName = (parentDir && parentDir !== '.' && parentDir !== '/') ? parentDir : '원스톱 콘솔';
      const timeStr = new Date().toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul' });
      const now = Date.now();

      // 기존 로컬 파일이 있으면 먼저 복원하여 누락 방지
      let devices = {};
      const devicesFile = path.join(__dirname, 'devices.json');
      if (fs.existsSync(devicesFile)) {
        try {
          const localParsed = JSON.parse(fs.readFileSync(devicesFile, 'utf8'));
          if (localParsed && localParsed.active_devices) {
            devices = Object.assign(devices, localParsed.active_devices);
          }
        } catch (_) {}
      }

      // 원격 Gist에 존재하는 기기 정보도 병합
      if (existingDevices && existingDevices.active_devices) {
        devices = Object.assign(devices, existingDevices.active_devices);
      }

      for (const [key, d] of Object.entries(devices)) {
        if (now - (d.last_seen || 0) > 24 * 3600 * 1000) {
          delete devices[key];
        }
      }

      // 현재 PC 등록 (상대방 PC 정보 절대 보존)
      const devKey = hostname + '__' + projectName;
      if (devices[hostname] && devices[hostname].project === projectName) delete devices[hostname]; // 옛 키 정리
      // 2026-09-22 홈 이전: 한 PC 에는 콘솔이 하나뿐이므로 같은 hostname 의 다른 키(옛 홈 등록, 예: <PC>__<옛프로젝트>)는 지운다 — 허브에 PC 가 둘로 보이던 문제
      { const dropped = collapseByHost(devices, hostname, devKey); if (dropped.length && !quiet) log('🩹 허브 장부 정리: ' + dropped.join(', ')); }
      devices[devKey] = {
        hostname: hostname,
        project: projectName,
        url: publicUrl,
        last_seen: now,
        time: timeStr
      };

      fs.writeFileSync(devicesFile, JSON.stringify({ active_devices: devices }, null, 2), 'utf8');

      // 개별 기기 전용 파일 생성 (충돌 방지 격리)
      const dedicatedUrlFile = path.join(__dirname, `url_${hostname}.txt`);
      fs.writeFileSync(dedicatedUrlFile, publicUrl, 'utf8');

      const urlFile = path.join(__dirname, 'last_tunnel_url.txt');
      fs.writeFileSync(urlFile, publicUrl, 'utf8');

      // GitHub Gist 갱신: devices.json + PC 전용 파일(url_${hostname}.txt) 패치
      const filesToPatch = {
        [`url_${hostname}.txt`]: { content: publicUrl },
        'devices.json': { content: JSON.stringify({ active_devices: devices }, null, 2) },
        'last_tunnel_url.txt': { content: publicUrl }
      };

      const token = GH_TOKEN;
      const payload = JSON.stringify({ description: 'Mobile Remote Console Multi-Device Hub', files: filesToPatch });
      const patchReq = https.request({
        hostname: 'api.github.com',
        path: `/gists/${GIST_ID}`,
        method: 'PATCH',
        headers: {
          'User-Agent': 'Node-Gist-Client',
          'Authorization': `token ${token}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload)
        }
      }, (patchRes) => {
        if (patchRes.statusCode === 200) {
          if (!quiet) log(`✅ GitHub Gist 허브 갱신 완료! (기기: ${hostname})`);
          if (false) {
            // 허브(Vercel)에 장부를 같이 배포 → 폰이 GitHub 캐시·한도와 무관하게 새 주소를 즉시 읽음
            try {
              require('./hub_deploy.js').deployHub(devices, (m) => log(m)).catch(e => log('⚠️ 허브 배포 실패: ' + e.message));
            } catch (e) { log('⚠️ 허브 배포 모듈 오류: ' + e.message); }
          }
        } else {
          log(`⚠️ GitHub Gist 갱신 응답 코드: ${patchRes.statusCode}`);
        }
      });
      patchReq.on('error', (err) => {
        log(`⚠️ Node HTTPS Gist 요청 실패: ${err.message}`);
        // fallback to gh cli
        const safeDevicesJson = JSON.stringify({ active_devices: devices });
        const cmd = `gh api -X PATCH /gists/${GIST_ID} -f "files[url_${hostname}.txt][content]=${publicUrl}" -f "files[devices.json][content]=${safeDevicesJson.replace(/"/g, '\\"')}" -f "files[last_tunnel_url.txt][content]=${publicUrl}"`;
        exec(cmd, () => {});
      });
      patchReq.write(payload);
      patchReq.end();

      // 허브(Vercel) 배포는 Gist 결과와 무관하게 기동 시 1회 (Gist가 403이어도 폰은 새 주소를 봐야 함)
      if (!quiet) {
        try {
          require('./hub_deploy.js').deployHub(devices, (m) => log(m)).catch(e => log('⚠️ 허브 배포 실패: ' + e.message));
        } catch (e) { log('⚠️ 허브 배포 모듈 오류: ' + e.message); }
      }
    } catch (e) {
      log('❌ Hub 갱신 내부 오류: ' + e.message);
    }
  };

  const fetchRaw = () => {
    https.get(gistRawUrl, (res) => {
      let raw = '';
      res.on('data', chunk => raw += chunk);
      res.on('end', () => {
        try { updateLocalAndGist(JSON.parse(raw)); } catch (_) { updateLocalAndGist(null); }
      });
    }).on('error', () => updateLocalAndGist(null));
  };

  // GitHub API는 CDN 캐시가 없어 다른 PC가 방금 쓴 장부도 즉시 보인다 (raw URL은 수 분간 낡은 사본을 줄 수 있음)
  const token = GH_TOKEN;
  https.get({
    hostname: 'api.github.com',
    path: `/gists/${GIST_ID}`,
    headers: { 'User-Agent': 'Node-Gist-Client', 'Authorization': `token ${token}`, 'Cache-Control': 'no-cache' }
  }, (res) => {
    let raw = '';
    res.on('data', chunk => raw += chunk);
    res.on('end', () => {
      try {
        const g = JSON.parse(raw);
        const content = g && g.files && g.files['devices.json'] && g.files['devices.json'].content;
        if (!content) return fetchRaw();
        updateLocalAndGist(JSON.parse(content));
      } catch (_) { fetchRaw(); }
    });
  }).on('error', fetchRaw);
}

// 허브 자가치유: Vercel 에 올라간 devices.json 에서 내 항목이 현재 주소와 다르면(다른 PC 가 낡은 장부로 덮어씀) 병합해 재배포
// ---------- 페어링 허브(콘솔 시스템 공용 허브: Cloudflare Worker) ----------
// config: pair_hub_url (기본 https://console-hub.consolesystem.workers.dev), pair_code (없으면 8자리 자동 생성해 저장)
// pair_hub_url 이 빈 문자열('')이면 허브 등록 안 함(배포판 -HubMode none). 없으면(undefined) 기본 One MACS 허브
const PAIR_HUB_URL = String(_cfg.pair_hub_url || '').replace(/\/+$/, ''); // 배포판: 설정에 적힌 허브만 (install.ps1 -HubMode 가 적는다)
function ensurePairCode() {
  const re = /^[A-HJ-NP-Z2-9]{8}$/;
  if (_cfg.pair_code && re.test(String(_cfg.pair_code).toUpperCase())) return String(_cfg.pair_code).toUpperCase();
  // 사용자가 적어 둔 코드가 형식에 안 맞으면 말없이 바꾸지 않는다(보조 W4 결함 #2, 2026-09-22) — 그대로 두고 허브 등록만 건너뛰며 크게 알린다
  if (_cfg.pair_code) { log('❌ 연결 코드 "' + _cfg.pair_code + '" 는 형식이 아닙니다 (대문자·숫자 8자리, I O 0 1 제외). 허브 등록을 건너뜁니다 — console_config.json 의 pair_code 를 고치고 재시작하세요'); return null; }
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = require('crypto').randomBytes(8);
  let code = ''; for (let i = 0; i < 8; i++) code += alphabet[bytes[i] % alphabet.length];
  try {
    const raw = JSON.parse(fs.readFileSync(_cfgFile, 'utf8').replace(/^﻿/, ''));
    raw.pair_code = code; fs.writeFileSync(_cfgFile, JSON.stringify(raw, null, 2), 'utf8');
  } catch (e) { log('⚠️ pair_code 저장 실패: ' + e.message); }
  _cfg.pair_code = code;
  log('🔑 연결 코드 생성: ' + code + ' (앱/허브에서 이 코드로 이 PC를 찾는다)');
  return code;
}
const PAIR_CODE = (_cfg.pair_hub_url !== false) ? ensurePairCode() : null;
// 허브 HTML 단일 소스(2026-09-22): 기동 때 hub_console.html 을 정본(_deploy_console_hub/index.html)과 맞춘다 — 다르면 덮어쓰고 경고
if (LEGACY_HUB) try { const _hs = require('./hub_deploy.js').syncHubHtml(log); if (_hs.ok && !_hs.synced) log('허브 HTML 정본 일치 확인'); } catch (e) { log('⚠️ 허브 HTML 동기화 확인 실패: ' + e.message); }
function registerPairHub(publicUrl) {
  if (!PAIR_CODE || !PAIR_HUB_URL) return;
  const projName = 'OneMACS'; // 2026-09-22: 콘솔 홈이 프로젝트에서 독립 — 기기 등록명은 프로젝트가 아니라 콘솔 자체
  const body = JSON.stringify({ code: PAIR_CODE, hostname: os.hostname(), project: projName, label: String(_cfg.pc_label || ''), url: publicUrl });
  const u = new URL(PAIR_HUB_URL + '/register');
  const req = https.request({ hostname: u.hostname, path: u.pathname, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }, timeout: 8000 }, (res) => {
    let b = ''; res.on('data', d => b += d); res.on('end', () => { if (res.statusCode !== 200) log('⚠️ 페어링 허브 등록 실패 ' + res.statusCode + ' ' + b.slice(0, 120)); });
  });
  req.on('timeout', () => req.destroy()); req.on('error', (e) => log('⚠️ 페어링 허브 연결 실패: ' + e.message)); req.end(body);
}

let healing = false;
function selfHealHub(publicUrl) {
  if (healing) return;
  healing = true;
  const done = () => { healing = false; };
  https.get(PERMANENT_HUB_URL + '/devices.json?t=' + Date.now(), { headers: { 'Cache-Control': 'no-cache' } }, (res) => {
    let raw = ''; res.on('data', c => raw += c);
    res.on('end', () => {
      try {
        const hub = JSON.parse(raw); const devices = (hub && hub.active_devices) || {};
        const hostname = os.hostname();
        const parentDir = path.basename(path.resolve(__dirname, '..'));
        const devKey = hostname + '__' + parentDir;
        const mine = devices[devKey];
        // 같은 PC 의 옛 홈 키(예: <PC>__<옛프로젝트>)가 허브 사본(vercel devices.json)에 남아 있으면 여기서도 지운다 — 등록 경로와 같은 규칙 (2026-09-22)
        const stale = collapseByHost(devices, hostname, devKey);
        if (mine && mine.url === publicUrl && !stale.length) return done();
        if (stale.length) log('🩹 허브에 이 PC 의 옛 등록 ' + stale.join(', ') + ' → 제거');
        devices[devKey] = { hostname, project: parentDir, url: publicUrl, last_seen: Date.now(), time: new Date().toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul' }) };
        try { fs.writeFileSync(path.join(__dirname, 'devices.json'), JSON.stringify({ active_devices: devices }, null, 2), 'utf8'); } catch (_) {}
        log('🩹 허브에 내 주소가 낡아 있음(' + (mine ? mine.url : '없음') + ') → 재배포');
        require('./hub_deploy.js').deployHub(devices, (m) => log(m)).catch(e => log('⚠️ 허브 자가치유 실패: ' + e.message)).finally(done);
      } catch (e) { done(); }
    });
  }).on('error', done);
}

// 2. cloudflared 터널 구동 (2초 후)
setTimeout(() => {
  log('Step 2: Cloudflare 터널 구동 시작...');

  if (!fs.existsSync(CLOUDFLARED_PATH)) {
    log('❌ cloudflared.exe를 찾을 수 없습니다: ' + CLOUDFLARED_PATH);
    return;
  }

  const spawnTunnel = () => { const t = tunnelSpawnArgs(); return spawn(CLOUDFLARED_PATH, t.args, { windowsHide: true, env: t.env }); };
  if (fixedMode) log('고정 주소 모드: ' + FIXED_URL);
  let cf = spawnTunnel();

  let urlFound = false;

  // 2026-09-21 21:25 장애: cloudflared 의 "Requesting new quick Tunnel on https://api.trycloudflare.com..." 줄이
  // 먼저 매칭돼 api. 주소가 허브에 등록됨(청크 순서 레이스) → api. 제외 + 실제 /api/devices 응답 확인 후에만 채택
  const verifyTunnel = (u) => new Promise((resolve) => {
    try {
      const req = https.get(u + '/api/devices', { timeout: 8000 }, (res) => { res.resume(); resolve(res.statusCode < 500); });  // 우리 서버 응답(200/401/423 등)이면 터널이 이 PC 를 가리키는 것. 502/530 은 미연결
      req.on('error', () => resolve(false)); req.on('timeout', () => { req.destroy(); resolve(false); });
    } catch (_) { resolve(false); }
  });
  let verifying = false;
  const handleOutput = (data) => {
    const text = data.toString();
    const match = text.match(/https:\/\/(?!api\.)[a-z0-9-]+\.trycloudflare\.com/i);
    if (match && !urlFound && !verifying) {
      verifying = true;
      const cand = match[0];
      (async () => {
        // 퀵 터널은 발급 직후 수십 초~1분 넘게 530/DNS 미전파일 수 있고 cloudflared 는 URL 을 한 번만 찍는다(22:46 장애).
        // → 최대 3분(5초 간격) 재확인, 그래도 안 되면 버리지 않고 채택(fail-open) + 경고. 하트비트가 이후 재확인·자가치유.
        let ok = false;
        for (let i = 0; i < 36 && !ok; i++) { ok = await verifyTunnel(cand); if (!ok) await new Promise(r => setTimeout(r, 5000)); }
        verifying = false;
        if (urlFound) return;
        urlFound = true;
        if (!ok) log('⚠️ 터널 주소 확인이 안 됐지만 등록합니다(발급 직후 전파 지연 가능): ' + cand);
        onTunnelUrl(cand);
      })();
    }
  };
  let currentUrl = null;
  let heartbeatStarted = false;
  const onTunnelUrl = (publicUrl) => {
    currentUrl = publicUrl;
    log(`🎉 터널 URL 발급 성공: ${publicUrl}`);
    if (LEGACY_HUB) { try { require('./sync_urls.js').syncUrls(publicUrl); } catch (_) {} } // 접속링크 txt/html 은 운영본(우리 허브·PIN 번호) 전용
    if (LEGACY_HUB) registerDeviceToHub(publicUrl);
    registerPairHub(publicUrl);
    if (PAIR_CODE && PAIR_HUB_URL) log('📱 페어링 허브: ' + PAIR_HUB_URL + '/?code=' + PAIR_CODE); else if (!PAIR_HUB_URL) log('허브 없음 모드 — 폰에서는 위 터널 주소를 직접 입력');
    if (heartbeatStarted) return;  // cloudflared 재기동으로 URL 이 바뀌어도 인터벌은 한 벌만(currentUrl 참조)
    heartbeatStarted = true;
    // 하트비트 60초: 허브(Vercel) devices.json 을 직접 읽어 내 주소가 낡았으면 즉시 재배포(자가치유).
    // Gist 갱신은 10분마다만 (PC 3대 × 60초 PATCH 가 GitHub 시간당 쓰기 한도 → 403 을 냈음)
    let hb = 0;
    setInterval(() => { if (!currentUrl) return; hb++; if (LEGACY_HUB) selfHealHub(currentUrl); registerPairHub(currentUrl); if (LEGACY_HUB && hb % 10 === 0) registerDeviceToHub(currentUrl, true); }, HEARTBEAT_SEC * 1000);
    // 터널 재확인(60초): 연속 3회(3분) 우리 서버 응답이 없으면 cloudflared 를 다시 띄운다 — 새 URL 이 찍히면 handleOutput 이 재검증·재등록
    let tunnelFails = 0;
    setInterval(async () => {
      if (!currentUrl) return;
      const alive = await verifyTunnel(currentUrl);
      if (alive) { tunnelFails = 0; return; }
      tunnelFails++;
      log('⚠️ 터널 응답 없음 ' + tunnelFails + '/3: ' + currentUrl);
      if (tunnelFails >= 3) { tunnelFails = 0; log('🔄 터널 재기동(cloudflared)'); try { urlFound = false; currentUrl = null; cf.kill(); } catch (_) {} }
    }, 60 * 1000);
  };

  let shuttingDown = false;
  const attach = () => {
    cf.stdout.on('data', handleOutput);
    cf.stderr.on('data', handleOutput);
    cf.on('close', code => {
      log(`⚠️ cloudflared 프로세스 종료 (코드: ${code})`);
      if (shuttingDown) return;
      // 고정 모드에서 주소가 서기도 전에 연달아 죽으면(토큰이 틀림 등) 90초를 기다리지 않고 바로 물러선다
      if (fixedMode && !urlFound) {
        fixedCrashes++;
        if (fixedCrashes >= 3) {
          log('↩️ 고정 주소 터널이 연달아 ' + fixedCrashes + '번 바로 끝났습니다 — 토큰을 확인하십시오. 임시 터널로 물러섭니다');
          fixedMode = false;
        }
      }
      // 자가치유: 3초 뒤 다시 띄운다(새 URL 이 찍히면 handleOutput 이 재검증·재등록). urlFound 는 재기동 지시 쪽에서 false 로 되돌림
      setTimeout(() => {
        try {
          urlFound = false; verifying = false;
          cf = spawnTunnel();
          attach();
          log('🔄 cloudflared 재기동' + (fixedMode ? ' (고정 주소)' : ''));
          if (fixedMode) startFixedVerify();
        } catch (e) { log('❌ cloudflared 재기동 실패: ' + e.message); }
      }, 3000);
    });
  };

  // 고정 모드: cloudflared 는 주소를 찍지 않는다(주소는 이미 정해져 있다). 그 주소로 우리 서버가 답하는지 확인하고
  // 답하면 채택한다. 90초 안에 답이 없으면 **임시 터널로 물러선다** — 토큰이 틀렸거나 도메인·DNS 가
  // 아직 준비되지 않은 경우다. 이 경우에도 PC 에는 계속 들어갈 수 있어야 한다.
  let fixedFailRuns = 0;
  var fixedCrashes = 0;   // var — close 처리(위)가 먼저 읽을 수 있게 끌어올린다
  function startFixedVerify() {
    (async () => {
      for (let i = 0; i < 18; i++) {
        if (!fixedMode) return;
        if (await verifyTunnel(FIXED_URL)) {
          fixedFailRuns = 0; fixedCrashes = 0;
          if (!urlFound) { urlFound = true; onTunnelUrl(FIXED_URL); }
          return;
        }
        await new Promise(r => setTimeout(r, 5000));
      }
      fixedFailRuns++;
      log('⚠️ 고정 주소가 90초 안에 답하지 않습니다: ' + FIXED_URL + ' (' + fixedFailRuns + '회)');
      if (fixedFailRuns >= 2 || !urlFound) {
        log('↩️ 임시 터널로 물러섭니다 — 고정 주소 설정(토큰·도메인·DNS)을 확인하십시오. 폰은 허브로 계속 들어올 수 있습니다');
        fixedMode = false;
      }
      try { urlFound = false; currentUrl = null; cf.kill(); } catch (_) {}   // close 처리가 지금 모드로 다시 띄운다
    })();
  }
  attach();
  if (fixedMode) startFixedVerify();

  process.on('SIGINT', () => {
    shuttingDown = true;
    try { cf.kill(); } catch (_) {}
    process.exit();
  });
}, 2000);
