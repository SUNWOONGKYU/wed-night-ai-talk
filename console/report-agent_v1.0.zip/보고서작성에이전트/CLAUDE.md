# 보고서 작성 에이전트 — 프로젝트 헌법

> 기업·공공기관 실무자용 기획·검토 보고서 집필 보조 도구.
> 데스크톱형 + 로컬 웹 GUI · 구독 CLI(claude→codex, **LLM API 키 0**) · 규모 L.
> 에신 V4.4 로 제조(2026-09-20). 원자재: SUNNY 학위논문 작성 에이전트(경로 A).
> 설계 `_개발자료/_design/plan.md` · 부품 `_개발자료/_design/bom.md` · 재사용 원장 `SOURCE_REUSE_LOG.md`.
>
> 이 파일은 «다음에 고치는 사람»이 망가뜨리지 않게 하는 문서다 — 설명이 아니라 **금지·함정·명령**을 적는다.

## 이 프로젝트에서 절대 어기지 말 것

1. **근거는 LLM 이 만들지 않는다.** 후보는 `vault/`(사용자 자료)와 실제 조회 결과뿐(`engine.ensure_sources`). 후보 밖 참조는 `[미검증]`.
2. **「URL 이 살아있다」는 검증이 아니다.** HTTP 200 만으로 `live` 를 주지 않는다 — `source.content_match` 가 **그 페이지 본문에 인용 내용이 실존하는지** 대조한다. 실패는 `unverified`.
3. **`[미검증]` 이 1건이라도 남으면 DOCX export 차단**(`source.export_gate`). 경고가 아니라 차단이다.
4. **장애(`blocked`)와 미확인(`unverified`)을 구분한다.** 5xx·네트워크 = 재시도. 404·본문 불일치·주소 오류(`badurl`) = 미확인. ⚠️ 이 구분을 흐리면 미확인 출처가 「검증대기」로 남아 **영원히 export 가 안 풀린다**(조립 중 실측 — 한글 URL 이 UnicodeEncodeError → ValueError 로 장애 오분류된 사고).
5. **수치는 코드가 계산한다**(`calc.py` → `canon.figures`). LLM 에 계산을 맡기지 않고, 정본 수치표에 없는 숫자는 본문에서 `[확인 필요]` 로 표시된다(`calc.crosscheck`). **표 파일(csv/xlsx)** 은 `tables.profile_table()` 이 행 수·합계·평균·범주별·연도별 집계를 결정론으로 산출하고, `engine.approve_outline()` 이 목차 승인 트랜잭션 안에서 그 결과를 `calc.register` 로 `canon.figures` 에 등재한다(D-006) — 이 호출이 빠지면 등재 함수가 정의만 되고 안 불려서 표의 수치가 보고서에 영영 못 들어간다.
6. **4절 대안 비교 점수를 LLM 이 매기지 않는다.** 가중치는 사용자가 정하고(`calc.validate_criteria` — 합 100 강제), 가중합은 `calc.weighted_score` 가 계산한다. 초고 프롬프트는 4절에 `[[비교표]]` 자리표시만 남기게 한다.
7. **비율 차이는 %가 아니라 %p 다.** `calc.diff_pp` 를 쓴다. 기준값 0 일 때 증감률(`pct_change`)은 숫자를 내지 않고 「정의 불가」로 돌려준다 — "전년 0건 → 5건 = 500% 증가"를 막는다.
8. **식별자는 LLM 전송 전 가명화**(`guard.pseudonymize`). 주민번호·사업자번호·사번·계좌·연락처·이메일·주소 + `names`(인명·거래처명·부서명). 새 입력 경로를 추가하면 **`engine._names_from_fields` 에 등록한다** — 빠뜨리면 실명이 샌다. 이름 목록은 `state.pseudonym_names` 에 저장돼 재시작 후에도 복원된다. 전송 직전 `guard.scan_leak` 히트 = **호출 중단**(경고 아님).
9. **법적·제도적 판정 문구 생성 금지** — "법적으로 문제없음"·"규정 위반 아님"·"감사 지적 없음"·"승인 가능"은 `guard.filter_output` 이 고지문으로 바꾼다. 판정은 법무·감사·결재권자 몫.
10. **AI 활용 고지는 기본 포함** — `settings.ai_disclosure=False` 로만 해제. 붙임.
11. **목차 미승인 상태에서 절 생성 금지** — `state.outline.approved` 가 false 면 `engine.write_section` 이 `Blocked`.
12. **API 키 0** — `llm._sub_env()` 가 ANTHROPIC/OPENAI/GOOGLE 키를 env 에서 지운다. 공공 통계 API 키(KOSIS·ECOS)는 LLM 키가 아니며 `config/keys.json` 에 둔다. **Antigravity(AGY) 를 폴백 체인에 넣지 않는다**(PO 지시).
13. **저장은 로컬 전용** — `127.0.0.1` 바인딩. 외부 전송 경로를 만들지 않는다. 화면은 마지막 하나만(`terminate_previous`).
14. **매 절 정본 수치표 재주입**(`outline.canon_block`) — 컨텍스트 붕괴 대응. 통짜 생성 금지.
15. **자기검증 금지** — 절별 채점(`score_section`)·2차 검증(`consistency_check`)은 **제품 품질 루프**일 뿐 출하 판정이 아니다. 출하 판정은 제조 미참여 V1·V2.
16. **`시작.bat` 에 한글·한글 경로 금지** — cp949 콘솔. 한국어 안내는 `ui.py` 가 낸다. cmd 블록 안 echo 문구에 괄호 금지(블록 조기 종료).
17. **DOCX 는 "완성본"이 아니다** — TOC 는 Word 가 열 때 채운다. `output/후처리_목록.md` 를 반드시 동봉한다. 과잉 약속 금지.
18. **새 보고서 시작(intake)은 확인 + 백업 없이 기존 것을 지우지 않는다** — 진행 중인 절이 있는데 `force` 없이 `intake` 하면 `Blocked`, `force=True` 면 `store.backup_state("before_intake")` 가 먼저 돈다.
19. **LLM 3자리는 화면 칩(설치 확인)과 실행 배선(실제 호출)을 구분한다.**

    | 화면 용어 | 하는 일 | 코드 함수 | providers |
    |---|---|---|---|
    | **1차 검증** | 절별 채점(90점 게이트) | `engine.score_section()` | `["claude"]` 단독(검증 전용 모델 자리 `llm.claude_model_verify`) |
    | **2차 검증** | 절간 정합성 + 출처 + 1차 점수 재판정 + 종합 | `engine.consistency_check()` → `outline.consistency_pass()` | `["codex","claude"]`(Codex 우선 — 다른 회사 AI 로 독립성 확보) |

    ★ **원자재는 이 이름이 역할과 반대였다**(`verify_1st`↔`verify_2nd`). 혼란의 원인이라 **승계하지 않고 이름과 역할을 일치시켰다.** 되돌리지 마라. 두 검증 모두 「작성에 참여하지 않은 별도 호출(초고 맥락 없음)」이라 자기검증이 아니며, `run_all()` 이 실제로 부른다 — 「정의됨 ≠ 호출됨」을 시험이 자동 대조한다.

20. **공식 체크리스트 5항은 코드가 판정한다 — 채점자(rubric)가 중복 지적하지 않는다.**
    `guard.check_vague`(#8 애매표현) · `outline.check_title_match`(#10) · `docx_build.measure_table_ratio`(#11) ·
    `outline.check_plan_fields`(#13) · `outline.check_issue_coverage`(#14 논점 커버리지).
    근거: 국가공무원인재개발원 「정책기획 실습」(2018) p.083~084. 중복 지적은 재생성 루프를 헛돌게 한다.
21. **기업 양식은 "표준"이 아니다.** 공공기관 절 구성만 공식 근거(같은 교재 p.076~077)가 있다. `enterprise` 프로필은 실무 관례이며, 문서 어디에도 "표준"이라고 적지 않는다.

## 구조

```
보고서 작성 에이전트/
├─ 시작.bat · README.md · CLAUDE.md · 사용자 매뉴얼(설치 및 사용법).html · 이번에 바뀐 것.md · 확인이 필요한 사항 목록.md
├─ SOURCE_REUSE_LOG.md · THIRD_PARTY_NOTICES.md
├─ app/                                본체 (사용자는 열 일 없음)
│  ├─ ui.py · ui/index.html            로컬 웹 GUI (헤더+3단, 액션봇 실행형+confirm, /api/setup·/api/org_profile)
│  ├─ engine.py                        State Machine: 접수→목차→[승인]→절별 루프(초고→score_section→수정)
│  │                                   →consistency_check→출처 검증→요약→export
│  ├─ llm.py                           구독 CLI 폴백 체인(claude→codex) · probe(설치≠작동) · call_json(정확히 1개 JSON)
│  ├─ guard.py                         가명화·출력 필터·페르소나 검사·애매표현 검출(#8)·AI 고지
│  ├─ source.py                        출처 2단 등급 검증 게이트(원부 API·URL 실접속+본문 대조) · export 게이트 · 검증표
│  ├─ calc.py                          결정론 수치(증감률·%p·구성비·CAGR·가중합·회수기간) · 본문 수치 대조
│  ├─ tables.py                        표 파일(csv/xlsx) 결정론 집계(행수·합계·평균·범주·연도 추이) · LLM 호출 0
│  ├─ outline.py                       목차·정본 수치표·절간 정합성 · 공식 체크리스트 #10·#13·#14
│  ├─ docx_build.py                    DOCX 조립(개조식 3단 들여쓰기·조직 프로필 표지·TOC 필드·각주)·열림 검증
│  ├─ store.py                         state.json·history.json·logs 원자 쓰기·잠금·단계 스냅샷
│  ├─ uicontract.py                    백엔드(/api/status·state·probe) 키 ↔ 화면 렌더러 계약
│  ├─ setup_helper.py                  설치 도우미 명령표(claude/codex 설치·로그인)
│  ├─ run.py                           터미널 진입점(병행)
│  ├─ skills/                          SSOT: persona·structure·source·rubric·web_allowlist
│  ├─ config/                          org_profile.json(기업/공공 2종) · keys.json(선택 — 공공 통계 API)
│  ├─ vault/ · uploads/ · output/ · logs/ · state_backups/
│  └─ state.json
└─ _개발자료/                          실무자 눈에 안 띄게 분리
   ├─ _design/  plan.md · bom.md · report-agent_architecture.svg · phase3_*.md · phase5_design_verify.md · 기획안_구현_대조표.md
   ├─ _qc/  v1_report.md · v1_gui_대조표.md · v2_report.md · 출하_보고서.md · 화면_구성_고정표.md · smoke_ui.py
   ├─ tests/  test_gates.py …
   └─ tools/  출하_정리.py · verify_windows_adapter.ps1
```

## 손대기 전에 읽을 것
`_개발자료/_design/plan.md`(7대 구성요소·실패 모드) → `app/skills/*.md`(규칙 SSOT) → `app/uicontract.py`(화면 계약)

## 검증 명령
```
set PYTHONUTF8=1                                   # cmd.exe 전용 — PowerShell 은 $env:PYTHONUTF8=1
python -m compileall -q app                          # 윈도우 cmd·PowerShell 은 app/*.py 와일드카드를 펼치지 않는다
python app/run.py probe --live                     # CLI 작동 확인(설치 ≠ 작동)
python -m pytest _개발자료/tests -q -p no:cacheprovider
powershell -ExecutionPolicy Bypass -File _개발자료/tools/verify_windows_adapter.ps1 -ProjectDir . -HumanFacing
```
게이트 단위 확인:
```
python -c "import sys;sys.path.insert(0,'app');import source as S;print(S.verify_one({'kind':'live','url':'https://kosis.kr/index/index.do','claim':'존재하지 않는 수치 987654'})['status'])"
# → unverified  (페이지는 열리지만 본문에 없으므로)
```
그리고 **`시작.bat` 을 눌러 화면을 실제로 띄워 눈으로 확인한다.** "파일이 생겼다"는 확인이 아니다.

## 이 프로젝트에서 실제로 반복된 함정
1. **`store.load_config()` 는 확장자까지 받는다** — `load_config("org_profile")` 로 부르면 조용히 `{}` 가 돌아와 **조직 프로필이 통째로 안 읽힌다**(공공을 골라도 기업 양식이 나옴). 반드시 `load_config("org_profile.json")`.
2. **한글이 든 URL** — `urllib` 이 `UnicodeEncodeError`(=`ValueError` 하위)를 던져 네트워크 장애로 오분류된다. `source.normalize_url()`(IRI→URI + IDNA)로 먼저 정규화하고, 인코딩 실패는 `badurl` 로 따로 잡아 **`unverified`** 로 보낸다. 헌법 4조와 짝.
3. **문서-코드 표기 불일치가 감점의 대부분을 차지한다**(원자재 실측: V1 총점 79→71). 코드를 바꾸지 않는 한 문서·UI·검증표 표현을 **코드 동작에 맞춰** 정정한다 — 반대로 고치지 않는다.
4. **동시 작업 잠금 예외가 상위 `except Exception` 에 먼저 잡히면 409 가 안 뜬다** — `Busy` 를 라우트 디스패처에서 `except Busy: raise` 로 먼저 재전파하고, 바깥(`do_POST`)에서 409 `{"busy":true}` 로 응답해야 한다. except 순서를 바꾸면 재발한다.
5. **상태를 쓰는 함수는 절대 라이브 `state.json` 에 대고 실험하지 않는다** — 반드시 `monkeypatch.setattr(store, "STATE_PATH", tmp_path/...)`. 원자재에서 완성 상태 3장·인용 20건이 초기화로 날아간 사고가 있었다.
6. **pytest 컬렉션 크래시** — 시험 파일 최상단에 `sys.exit()` 을 두면 `python -m pytest` 가 INTERNALERROR 로 죽는다. 모듈 최상단에서 종료 코드를 부르지 않는다.
7. **작업 폴더에 발굴 원본 클론을 남기면 시크릿이 딸려 나간다** — `_scratch/` 는 출하 전 반드시 삭제. 재사용 원장에는 출처·sha 만 남긴다.
8. **뼈대 템플릿의 설치 도우미가 죽어 있을 수 있다** — `app/setup_helper.py` + `ui.py` 의 `/api/setup`·`/api/setup/run` + `index.html` 의 `loadSetup()`/`btn-setup-recheck` 리스너 4곳을 **세트로** 확인한다.
9. **`_PHASE_MARK` 는 프로세스 재시작마다 리셋된다** — `save_state()` 가 `None` 이면 파일에 남은 phase 로 채운 뒤 비교한다. 안 그러면 가짜 백업이 쌓인다.

## 주석 쓰는 법
확인한 것과 추정한 것을 갈라 적는다. 수치를 코드에 넣을 때는 출처(규칙·조문·실측)와 확인 날짜를 주석에 같이 적는다.

## 사용자에게 보내기 직전에는
```
python _개발자료/tools/출하_정리.py --지움      # 시제·시험 데이터 삭제. 순서는 「시험 → 정리 → 포장」
```
