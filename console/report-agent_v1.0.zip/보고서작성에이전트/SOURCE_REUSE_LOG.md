# SOURCE_REUSE_LOG — 재사용 증거 원장

> 보고서 작성 에이전트(report-agent) · 에신 V4.4 Phase 4 산출물 · 최초 기록 2026-09-20
> 무엇을 어디서 가져와 어디에 넣었는지, 원본 해시와 함께 남긴다. 이 기록이 없으면 취약 버전 교체·회귀 원인 추적·저작권 감사가 불가능하다.

## 1차 출처 — 지정 원자재 (경로 A)

| 항목 | 값 |
|---|---|
| 자산명 | SUNNY 학위논문 작성 에이전트 (thesis-agent) V1.0 |
| 경로 | **사내 자료(비공개)** — 내부 보관 위치는 배포본에 적지 않는다(2026-09-22 정리) |
| 소유권 | **PO 소유 내부 자산** — 본인이 에신 V3.23 공장으로 제조 |
| 소유 확인자 / 확인일 | **PO / 2026-09-20** (본 제조 건 원자재로 직접 지정) |
| 라이선스 판정 | ✅ 복사·재단 가능 (에신 「PO 소유 내부 자산」 경로) |
| 원본 버전 | V1.0 (2026-09-18, 실전 사용 1회 후 개편) |
| 해시 측정 시점 | 2026-09-20 |

### 부품별 원장 (13건)

| 원본 파일 | 행수 | SHA-256 (전체) | 적용 위치 | 분류 |
|---|--:|---|---|:-:|
| `app/store.py` | 217 | `07888da891d9938b3f12bfbb4cfd3a5b44463afc78688792b5ae94d1917f6299` | `app/store.py` | 🟢 (`default_state()`만 🟡) |
| `app/llm.py` | 257 | `29634acc836500fd96275c961b0e91af02e8401d32a81bb157fd96cf436457ce` | `app/llm.py` | 🟢 |
| `app/setup_helper.py` | 68 | `3d6bfc68fe2e048d2d565638a5946294abce4883f76bb68c5887398b37230704` | `app/setup_helper.py` | 🟢 |
| `app/guard.py` | 136 | `100184519e8542f97482e5f545831bad9454b65f738356bfccaac68deba9f740` | `app/guard.py` | 🟡 |
| `app/cite.py` | 365 | `cc3a2c8e0af50a3a69408ce44b749f14d6264c37be840b328e15426e0a7e0e08` | **`app/source.py`** | 🟡 + 🔴(어댑터 폐기) |
| `app/engine.py` | 635 | `6455d426460eb81cb9721fdcd9199e431bdfe8b8c4030c67ae2cf728327e7f41` | `app/engine.py` | 🟡 |
| `app/outline.py` | 120 | `1365f871f687c3c8b66c16163edcd15f579c9b97e243a703df9c14f521dd46de` | `app/outline.py` | 🟡 |
| `app/stats.py` | 163 | `d89abe49efe9f6beba4ca1d025e8990515de58edf354fca601e015150f656bc9` | **`app/calc.py`** | 🟡 + 🔴(학술 통계 폐기) |
| `app/docx_build.py` | 338 | `091bf948923631e0323a66d76039e68598cff04339ec177c7fbebed9fa30ab16` | `app/docx_build.py` | 🟡 |
| `app/ui.py` | 601 | `378e168f1e8b939bb09f204415db5512359d9a0754090c4bfc57b19dc852e11d` | `app/ui.py` | 🟡 |
| `app/ui/index.html` | 1,338 | `202063e63f2270d35d7f7ecff5043bdcd2ce50b1cef2f99c13d4e01c91b5106e` | `app/ui/index.html` | 🟡 |
| `app/uicontract.py` | 51 | `97e6e23967a91927f1ce038b742434e98f659177816f78428b38b98c85c27654` | `app/uicontract.py` | 🟡 |
| `app/run.py` | 64 | `9488cd65b6c8b7bfdc6e94169bbbf7cbd2a3230bfe80f5733a2e7bcf8e15d1e7` | `app/run.py` | 🟡 |

**복사 제외**: `app/__pycache__/`(12) · `app/state.json` · `app/.runtime/ui.lock` · `app/.deps_ok` · `app/config/school_profile.json` — 생성물·시제 데이터.

## 2차 출처 — 원자재가 업고 있는 상위 OSS (의무 승계)

⚠️ 원자재의 `cite.py`·`docx_build.py`는 외부 OSS 재단본이다. 우리가 이를 개조해 쓰는 순간 **고지 의무가 이 프로젝트로 그대로 따라온다.** 원자재 `SOURCE_REUSE_LOG.md`(2026-09-17 기록)에서 사슬을 이관한다.

| 상위 저장소 | 커밋 (전체) | 원본 파일 | SHA-256 (전체) | 이 프로젝트에서의 위치 |
|---|---|---|---|---|
| opendraft | `89128b30d9857cf9b871cbebc88ec07832260b9a` | `engine/utils/api_citations/multi_source.py` | `278859b9bc52d2c1aef3eff90faf4980c9b55ffc9be1a6770a7500e23d9428d8` | `app/source.py` (병렬 조회 골격) |
| opendraft | 동일 | `engine/utils/api_citations/base.py` | `3b7950e6a18be9868e6180f6a33dab2b1fa33a6ee2fd7c2198b8ee51a3075e78` | `app/source.py` |
| opendraft | 동일 | `engine/utils/api_citations/crossref.py` | `e2344290d3e41ab0b2a412d3721150bce578a7c598fd6e232de8c8de868e0399` | 🔴 폐기 예정(학술 전용 어댑터) |
| opendraft | 동일 | `engine/utils/api_citations/openalex.py` | `762089d7af82b2e3455f46fa980cc4ae2c45ff3163b60befa734cf3629b9173b` | 🔴 폐기 예정 |
| opendraft | 동일 | `engine/utils/api_citations/semantic_scholar.py` | `f0601d17e1e428954e8a367cc18b173a181eb11e85248218072f2abd758addca` | 🔴 폐기 예정 |
| docx-plus | `ee7d57ae9ee360e1b0c632fa0a9c67698607155d` | `docx_plus/publishing/toc.py` | `f4c14707897b00477a70ebdb2a0dc999158b7620f69575734aecfee406988c00` | `app/docx_build.py` — `add_toc()`·`_build_complex_field()` |
| thesis-writing-skills | `08d8f56fb00320a4fad5d165f75a61d0d2d5150f` | `skills/thesis-writing-en/scripts/validate_citation_order.py` | `2e950743d6b339d4932a08d0cd0760895d9b3871df3c70d692dca91c192e7ad4` | 🔴 **폐기 예정** — 학술 전용 검증기 |
| thesis-writing-skills | 동일 | `skills/thesis-writing-en/scripts/validate_thesis_docx.py` | `b3e3c600ff80eeb86e411a6e693c934a730437dad5cccf1ff6022018c6feb18f` | 🔴 **폐기 예정** |

### ⚠️ Phase 6 조립 시 반드시 확정할 것
1. **opendraft(MIT)** — `source.py`에 병렬 조회 골격이 남으므로 **고지 유지**.
2. **docx-plus(MIT)** — `add_toc()`를 쓰므로 **고지 유지**.
3. **thesis-writing-skills(Apache-2.0)** — 학술 검증기라 폐기 예정. **실제로 한 줄도 남지 않으면 고지 목록에서 제거**하고, 한 줄이라도 남으면 Apache-2.0 NOTICE 보존 의무를 이행한다. 조립 후 `grep`으로 확인한다.
4. **pandas·scipy** — `calc.py`가 학술 통계를 버리고도 이 둘을 계속 쓰는지 확인. 안 쓰면 `requirements.txt`에서 제거.

## 3차 — 공통부 (에신 V4.4 templates/)

| 부품 | 출처 | 비고 |
|---|---|---|
| `시작.bat` · `CLAUDE.md` · `출하_정리.py` · `test_gates.py` · `verify_windows_adapter.ps1` | `~/.claude/skills/에신-llm-dependent-agent-create/templates/` | PO 소유 제조 공장 자산 |

## 4차 — 문서 근거 (코드 아님, 규칙 SSOT의 출처)

| 자료 | 발행 | 사용처 | 보존 위치 |
|---|---|---|---|
| **「정책기획 실습」** — 국가공무원인재개발원 연구개발센터 | 2018-03-01, 160p | `app/skills/structure.md`(보고서 8절·공공 절번호 Ⅰ~Ⅴ) · `app/skills/rubric.md`(고도화 체크리스트 15항) | 원문 PDF + 근거 페이지 PNG 4장은 개발 사본에 보존(배포본에는 포함되지 않습니다) |

> 대조 결과와 정정 내역은 개발 사본에 보존되어 있으며, 배포본에는 포함되지 않습니다.
> **기업(민간)용 절 구성에는 이에 상응하는 공식 표준이 존재하지 않는다** — 실무 관례임을 `structure.md`에 명시한다.

## 변경 이력

| 일시 | 내용 |
|---|---|
| 2026-09-20 | 최초 작성 — 원자재 13부품 + 상위 OSS 8건 사슬 + 공통부 + 문서 근거 1건 |
