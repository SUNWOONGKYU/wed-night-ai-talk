# THIRD_PARTY_NOTICES

보고서 작성 에이전트(report-agent)는 아래 제3자 저작물을 포함하거나 의존합니다.
본 목록은 원자재인 SUNNY 학위논문 작성 에이전트의 고지를 **승계**한 것입니다 — 내부 자산을 거쳐 왔더라도 상위 라이선스 의무는 소멸하지 않습니다.

> ⚠️ **Phase 6 조립 후 재확인 필요.** 아래 ⚠️ 표시 항목은 코드가 실제로 남는지 `grep`으로 확인한 뒤, 남지 않으면 이 목록에서 제거합니다. 쓰지도 않는 라이선스를 고지하는 것도 부정확한 기록입니다.

## 포함된 코드 (재단·파생)

- **opendraft** — MIT License, Copyright (c) federicodeponte
  https://github.com/federicodeponte/opendraft
  (부품: `api_citations/multi_source.py`, `base.py` — 다중 소스 병렬 조회 골격 → `app/source.py` 재단본)
  ⚠️ `crossref.py`·`openalex.py`·`semantic_scholar.py` 파생분은 학술 DB 전용이라 폐기 예정 — 골격 부분만 남음

- **docx-plus** — MIT License, Copyright (c) thomas-villani
  https://github.com/thomas-villani/docx-plus
  (부품: `publishing/toc.py` → `app/docx_build.py`의 `add_toc()`·`_build_complex_field()` / `notes/registry.py` 로직 → `FootnoteRegistry`)

- ⚠️ **thesis-writing-skills** — Apache License 2.0, Copyright (c) 1-pluto1
  https://github.com/1-pluto1/thesis-writing-skills
  (부품: `validate_citation_order.py`, `validate_thesis_docx.py` 일부)
  **폐기 예정** — 학위논문 전용 검증기로 본 에이전트 범위 밖입니다. 조립 후 한 줄도 남지 않으면 이 항목을 삭제하고, 남으면 Apache-2.0 §4 NOTICE 보존 의무를 이행합니다.

## 런타임 의존 라이브러리

- **python-docx** — MIT License. https://github.com/python-openxml/python-docx
- **pypdf** — BSD-3-Clause. https://github.com/py-pdf/pypdf
- ⚠️ **pandas** — BSD-3-Clause. https://github.com/pandas-dev/pandas
  (원자재 `stats.py`의 학술 통계용. `calc.py` 재설계 후에도 표 로딩에 쓰는지 확인 필요)
- ⚠️ **scipy** — BSD-3-Clause. https://github.com/scipy/scipy
  (t검정·카이제곱 등 학술 통계 전용 — 폐기 가능성 높음)
- ⚠️ **matplotlib** — PSF-based License. (원자재 고지에 포함. 본 에이전트에서 도표를 생성하는지 Phase 6에서 확정)

## 문서 근거 (코드 아님)

- **「정책기획 실습」** — 국가공무원인재개발원 연구개발센터, 2018-03-01
  http://www.nhi.go.kr/upload/basicBook/04.pdf
  보고서 8절 구조(p.076~077)와 「보고서 고도화 작업」 체크리스트 15항(p.083~084)의 근거로 참조했습니다.
  코드에 포함된 저작물이 아니라 **규칙 수립의 참고 문헌**이며, 원문은 개발 사본에 보존되어 있습니다(배포본에는 포함되지 않습니다).

---
최종 갱신 2026-09-20 (Phase 4) · 다음 갱신 예정: Phase 6 조립 완료 후 ⚠️ 항목 확정
