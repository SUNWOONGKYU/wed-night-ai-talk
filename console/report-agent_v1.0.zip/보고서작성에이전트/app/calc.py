# -*- coding: utf-8 -*-
"""calc.py — 결정론 수치 산출 + 본문 수치 대조 (데이터 날조 금지의 코드 부분).

부품 출처(BOM 🟡): 원자재 thesis-agent `app/stats.py`
  sha256 d89abe49efe9f6beba4ca1d025e8990515de58edf354fca601e015150f656bc9 (2026-09-20)
  ← 그 위로는 공증에이전트 rules.py `_compare`·`check_calculated` 패턴 (PO 소유 내부 자산)
승계(🟢): `available` · `load_table` · `register` · **`crosscheck`** + `_NUM_RE`/`_SKIP_*` — 대조 엔진이 핵심 자산.
폐기(🔴): 학술 통계 검정 일체(`ttest_ind`·`chi_square`·`ols`·`correlation`·`_welch_df`·`describe`)와
  APA 표기(`apa_num`·`apa_p`·`apa_r`) — 기획·검토 보고서 범위 밖. **scipy 의존이 여기서 사라진다.**
자체 제작(🏭): 경영 지표 6종 — `pct_change` · `diff_pp` · `share` · `cagr` · `weighted_score` · `payback`
  + `summarize`(기술통계 간이판) + `validate_criteria`(가중치 합 100 검증).

원칙: **본문에 들어가는 모든 숫자는 `canon.figures[key]`에 있어야 한다. 없는 숫자 = `[확인 필요]`.**
      LLM 은 계산하지 않는다 — 이 모듈이 계산한 값을 옮겨 적을 뿐이다.
"""
from __future__ import annotations
import re
from pathlib import Path

try:
    import pandas as pd            # 표 파일(xlsx/csv) 적재 전용. scipy·numpy 는 더 이상 쓰지 않는다.
except ImportError:                # 준비 상태 패널이 알린다
    pd = None


def available() -> bool:
    """표 파일 적재 가능 여부. pandas 가 없어도 아래 지표 계산 함수는 전부 동작한다(순수 파이썬)."""
    return pd is not None


# ---------------------------------------------------------------- 표 적재 (🟢 승계)
def load_table(path: str):
    p = Path(path)
    if not available():
        raise RuntimeError("pandas 미설치 — 표 파일(xlsx/csv) 적재에만 필요합니다")
    if p.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(p)
    if p.suffix.lower() == ".csv":
        return pd.read_csv(p, encoding="utf-8-sig")
    raise ValueError("지원 형식: xlsx/xls/csv")


def summarize(df, cols: list[str]) -> dict:
    """🏭 기술통계 간이판 — {col: {n, sum, mean, min, max}}.

    원자재 `describe()`의 표준편차(sd)는 뺐다 — 기획·검토 보고서에서 sd 를 쓰는 일이 없고,
    쓰지 않는 값을 정본 수치표에 올려 두면 crosscheck 가 헐거워진다.
    """
    if not available():
        raise RuntimeError("pandas 미설치")
    out = {}
    for c in cols:
        s = pd.to_numeric(df[c], errors="coerce").dropna()
        if s.empty:
            out[c] = {"n": 0, "sum": None, "mean": None, "min": None, "max": None}
            continue
        out[c] = {"n": int(s.count()), "sum": round(float(s.sum()), 4),
                  "mean": round(float(s.mean()), 4), "min": float(s.min()), "max": float(s.max())}
    return out


# ---------------------------------------------------------------- 🏭 경영 지표 (순수 파이썬)
def _num(x, name: str) -> float:
    try:
        return float(x)
    except (TypeError, ValueError):
        raise ValueError("%s 는 숫자여야 합니다: %r" % (name, x))


def pct_change(new, old, digits: int = 1) -> dict:
    """증감률(%) = (new − old) / |old| × 100.

    old 가 0 이면 증감률을 정의할 수 없다 — **0 으로 채우거나 100%로 적지 않고** 계산 불가로 돌려준다.
    (보고서에서 "전년 0건 → 올해 5건"을 "500% 증가"로 적는 흔한 오류를 코드가 막는다.)
    """
    n, o = _num(new, "new"), _num(old, "old")
    if o == 0:
        return {"value": None, "formula": "(%s − %s) / |%s| × 100" % (n, o, o),
                "note": "기준값이 0 이라 증감률을 정의할 수 없음 — 절대 증감으로 서술할 것", "unit": "%"}
    v = (n - o) / abs(o) * 100
    return {"value": round(v, digits), "unit": "%",
            "formula": "(%g − %g) / |%g| × 100" % (n, o, o)}


def diff_pp(new, old, digits: int = 1) -> dict:
    """비율 간 차이(%p) = new − old.

    ⚠️ 비율끼리의 차이는 **%가 아니라 %p** 다. 18.7% 와 14.5% 의 차이는 4.2%p 이지 4.2% 가 아니다.
    보고서에서 가장 자주 틀리는 표기라 별도 함수로 둔다.
    """
    n, o = _num(new, "new"), _num(old, "old")
    return {"value": round(n - o, digits), "unit": "%p", "formula": "%g%% − %g%%" % (n, o)}


def share(part, total, digits: int = 1) -> dict:
    """구성비(%) = part / total × 100."""
    p, t = _num(part, "part"), _num(total, "total")
    if t == 0:
        return {"value": None, "unit": "%", "formula": "%g / %g × 100" % (p, t),
                "note": "분모가 0 — 구성비 계산 불가"}
    return {"value": round(p / t * 100, digits), "unit": "%", "formula": "%g / %g × 100" % (p, t)}


def cagr(begin, end, years, digits: int = 1) -> dict:
    """연평균 성장률 CAGR(%) = ((end / begin) ^ (1/years) − 1) × 100.

    begin ≤ 0 또는 years ≤ 0 이면 정의되지 않는다. 음수 구간에 CAGR 을 붙이지 않는다.
    """
    b, e, y = _num(begin, "begin"), _num(end, "end"), _num(years, "years")
    if b <= 0 or y <= 0:
        return {"value": None, "unit": "%", "formula": "((%g / %g)^(1/%g) − 1) × 100" % (e, b, y),
                "note": "시작값이 0 이하이거나 기간이 0 이하 — CAGR 정의 불가"}
    if e < 0:
        return {"value": None, "unit": "%", "formula": "((%g / %g)^(1/%g) − 1) × 100" % (e, b, y),
                "note": "종료값이 음수 — CAGR 정의 불가"}
    v = ((e / b) ** (1.0 / y) - 1) * 100
    return {"value": round(v, digits), "unit": "%",
            "formula": "((%g / %g)^(1/%g) − 1) × 100" % (e, b, y)}


def payback(initial_cost, annual_benefit, digits: int = 1) -> dict:
    """단순 회수기간(년) = 초기 투자비 / 연간 편익. 화폐의 시간가치를 반영하지 않는 '단순' 회수기간이다."""
    c, a = _num(initial_cost, "initial_cost"), _num(annual_benefit, "annual_benefit")
    if a <= 0:
        return {"value": None, "unit": "년", "formula": "%g / %g" % (c, a),
                "note": "연간 편익이 0 이하 — 회수 불가"}
    return {"value": round(c / a, digits), "unit": "년", "formula": "%g / %g (단순 회수기간, 할인 미적용)" % (c, a)}


def validate_criteria(criteria: list[dict]) -> list[str]:
    """4절 평가기준 검증. 반환: 오류 메시지 목록(빈 목록 = 통과).

    가중치는 **사용자가 정한다.** AI 가 임의로 부여하면 결론을 정해 놓고 근거를 맞춘 보고서가 된다.
    """
    errs = []
    if not criteria:
        return ["평가기준이 없습니다 — 4절 대안 비교에는 기준과 가중치가 필요합니다"]
    total = 0.0
    seen = set()
    for i, c in enumerate(criteria):
        name = str(c.get("name") or "").strip()
        if not name:
            errs.append("평가기준 #%d 의 이름이 비어 있습니다" % (i + 1))
        if name in seen:
            errs.append("평가기준 이름이 중복됩니다: %s" % name)
        seen.add(name)
        try:
            w = float(c.get("weight"))
        except (TypeError, ValueError):
            errs.append("평가기준 '%s' 의 가중치가 숫자가 아닙니다" % (name or i + 1))
            continue
        if w <= 0:
            errs.append("평가기준 '%s' 의 가중치는 0보다 커야 합니다" % name)
        total += w
    if errs:
        return errs
    if abs(total - 100.0) > 1e-6:
        errs.append("가중치 합이 100 이 아닙니다 (현재 %g)" % total)
    return errs


def weighted_score(criteria: list[dict], options: list[dict], raw: dict, scale: float = 5.0) -> dict:
    """🏭 4절 대안 비교 가중합. **LLM 이 점수를 매기지 않는다 — 이 함수가 계산한다.**

    criteria: [{"name": "비용절감", "weight": 40}, ...]   가중치 합 100
    options : [{"key": "opt1", "label": "1안 현행 유지"}, ...]   3개 이상
    raw     : {"opt1": {"비용절감": 3, ...}, ...}   각 기준에 대한 원점수(1~scale)
    scale   : 원점수 만점(기본 5)

    기여도 = weight × (원점수 / scale)  →  각 기준의 최대 기여도 = weight, 총점 만점 = 100.
    반환: {"rows": [...], "ranking": [...], "errors": [...]}  errors 가 있으면 값은 None 이다.
    """
    errs = validate_criteria(criteria)
    if len(options or []) < 3:
        errs.append("대안은 3개 이상이어야 합니다 (현재 %d개)" % len(options or []))
    if scale <= 0:
        errs.append("원점수 만점(scale)은 0보다 커야 합니다")
    if errs:
        return {"rows": [], "ranking": [], "errors": errs}

    rows, missing = [], []
    for opt in options:
        key = opt.get("key")
        label = opt.get("label") or key
        scores = (raw or {}).get(key) or {}
        cells, total = [], 0.0
        for c in criteria:
            name, w = c["name"], float(c["weight"])
            if name not in scores:
                missing.append("%s / %s" % (label, name))
                cells.append({"criterion": name, "weight": w, "raw": None, "contribution": None})
                continue
            r = _num(scores[name], "%s/%s 원점수" % (label, name))
            if not (0 <= r <= scale):
                errs.append("'%s'의 '%s' 원점수가 0~%g 범위를 벗어납니다: %g" % (label, name, scale, r))
                continue
            contrib = w * (r / scale)
            total += contrib
            cells.append({"criterion": name, "weight": w, "raw": r, "contribution": round(contrib, 2)})
        rows.append({"key": key, "label": label, "cells": cells,
                     "total": None if missing or errs else round(total, 2)})

    if missing:
        errs.append("원점수가 비어 있는 칸이 있습니다: " + ", ".join(missing[:8]) + (" 외" if len(missing) > 8 else ""))
    if errs:
        return {"rows": rows, "ranking": [], "errors": errs}

    ranking = sorted(rows, key=lambda r: -r["total"])
    top = ranking[0]["total"]
    tied = [r["label"] for r in ranking if abs(r["total"] - top) < 1e-9]
    return {"rows": rows,
            "ranking": [{"rank": i + 1, "label": r["label"], "total": r["total"]} for i, r in enumerate(ranking)],
            "tie": tied if len(tied) > 1 else [],
            "errors": []}


# ---------------------------------------------------------------- 정본 수치표 등록 + 본문 대조 (🟢 승계)
def register(canon: dict, key: str, value, source_id: str, formula: str = "",
             unit: str = "", basis_date: str = "", grade: str = "") -> None:
    """canon.figures[key] 등록. **본문은 여기 있는 값만 쓴다.**

    source_id : 출처 레코드 id (source.py) 또는 파일·시트 위치
    grade     : 출처 검증 등급(registry|live|internal|manual_review) — 본문 태그와 일치해야 한다
    """
    canon.setdefault("figures", {})[key] = {
        "value": value, "unit": unit, "basis_date": basis_date,
        "formula": formula, "source_id": source_id, "grade": grade,
    }


def register_result(canon: dict, key: str, result: dict, source_id: str, basis_date: str = "", grade: str = "") -> dict:
    """위 지표 함수의 반환값(dict)을 그대로 정본 수치표에 등록. 계산 불가(value=None)면 note 를 함께 보관한다."""
    canon.setdefault("figures", {})[key] = {
        "value": result.get("value"), "unit": result.get("unit", ""), "basis_date": basis_date,
        "formula": result.get("formula", ""), "source_id": source_id, "grade": grade,
        "note": result.get("note", ""),
    }
    return canon["figures"][key]


_NUM_RE = re.compile(r"(?<![0-9.])(?:-?\d{1,3}(?:,\d{3})+|-?\d+)(?:\.\d+)?(?:\s*%)?(?![0-9.])")   # 한글은 \w에 잡히므로 숫자·점만 경계로
# ★재단 — 뒤따르는 단위가 보고서 어휘로 바뀌었다(장/절/쪽/판 → 절/항/건/개소/부서/억/만 등)
# ★D-006 동반 수정(2026-09-23) — 「명·개·건·개소·개사·부서·과·팀」을 여기서 뺐다.
#   이 단위들은 보고서에서 순번이 아니라 **실질 수치**인 경우가 압도적이다(98건·7명·3개소).
#   종전에는 이 목록에 있으면 crosscheck 가 **무조건** 건너뛰어 「시공 120건」처럼 지어낸 값도 못 잡았다
#   (has_unit 로직이 이 단위들에 대해서는 죽은 코드였다 — _SKIP_AFTER 가 먼저 가로채므로 도달 자체가 안 됨).
#   이제 이 단위가 붙은 수치는 아래 has_unit 분기로 내려가 «정본에 있는지»로 판정한다.
#   년·월·일·분기·차·절·항·호·쪽·위·등·) 은 여전히 순번·문서 구조 표지이므로 남긴다.
_SKIP_AFTER = re.compile(r"^\s*(년|월|일|분기|차|절|항|호|쪽|위|등|\))")
_SKIP_BEFORE = re.compile(r"(제\s*|표\s*|그림\s*|붙임\s*|별첨\s*|\(|no\.\s*|vol\.\s*|\[\^?)$", re.I)

# D-010(V1 5차 반려, 2026-09-23) Medium — 표 칸 값 대조(주 방어선)가 1~2자리 건너뛰기를 꺼서
# 일정표의 하이픈 날짜(`2024-03-01`·`03-01 ~ 11-30`)가 03·01·11·30 으로 쪼개져 과잉 적발됐다.
# 날짜·시각으로 보이는 구간은 숫자 매칭 전에 가린다.
# D-010(V1 6차 반려, 2026-09-23) Medium — 그런데 연도 없는 모양(0 채움 MM-DD·HH:MM)을 **문서 전체**에
# 가리면, 점수 칸에 위조 원점수를 "03-05" 처럼 날짜 모양으로 적어 값 대조를 피해가는 위장 경로가 생긴다.
# → 연도가 붙은 모양(YYYY-MM-DD·YYYY-MM)은 모호하지 않으므로 표 칸 포함 어디서든 그대로 가리고,
#   연도 없는 모양은 **표의 그 열 머리가 날짜·시각 열일 때만** 가린다(열 신호 없으면 값으로 대조한다).
#   본문 문장은 원래 단위 없는 1~2자리를 순번으로 건너뛰므로 따로 가릴 필요가 없다.
_YMD_RE = re.compile(r"\b(?:19|20)\d{2}[-/](?:0[1-9]|1[0-2])[-/](?:0[1-9]|[12]\d|3[01])\b")   # 2024-03-01
_YM_RE = re.compile(r"\b(?:19|20)\d{2}[-/](?:0[1-9]|1[0-2])\b")                               # 2024-03
_TIME_RE = re.compile(r"\b(?:[01]\d|2[0-3]):[0-5]\d\b")                                        # 09:30
_MMDD_ANY_RE = re.compile(r"\b(?:0?[1-9]|1[0-2])-(?:0?[1-9]|[12]\d|3[01])\b")                  # MM-DD(월 1~12·일 1~31, 0 채움 무관)
# D-012(V2 지적 5, 2026-09-23) — 「기간·일정」은 «모호한» 날짜 열이다. 이 둘을 달력 전용 열과
# 같은 규칙(0 채움 무관 MM-DD 전부 가림)으로 다루면, 「기간」열의 `10-15`(=10~15건 같은 실측값)가
# 날짜로 오인돼 조용히 통과한다(V2 재현). → 달력 전용(일자·착수·준공…)과 기간·일정을 분리해
# 후자는 **연도 붙은 모양(전역) · 0 채움이 있는 MM-DD · MM-DD~MM-DD 범위**만 가린다.
_DATE_COL_KEYWORDS_CALENDAR = ("일자", "날짜", "착수", "준공", "시작", "종료", "마감",
                               "시점", "시각", "시간", "개시", "완료", "기한", "예정일", "일시")
_DATE_COL_KEYWORDS_AMBIGUOUS = ("기간", "일정")
_MMDD_RANGE_RE = re.compile(
    r"\b(?:0?[1-9]|1[0-2])-(?:0?[1-9]|[12]\d|3[01])\s*~\s*(?:0?[1-9]|1[0-2])-(?:0?[1-9]|[12]\d|3[01])\b")
_MMDD_LEADZERO_RE = re.compile(
    r"\b0[1-9]-(?:0?[1-9]|[12]\d|3[01])\b"        # 월이 0 채움(03-01, 03-15)
    r"|\b(?:0?[1-9]|1[0-2])-0[1-9]\b")            # 일이 0 채움(3-01, 12-01)
_PAREN_ANY_RE = re.compile(r"\([^)]*\)")


def _is_date_time_header(cell: str) -> "str | None":
    """열 머리가 날짜·시각 열 신호인가. 「기간(월)」처럼 측정 단위 괄호가 붙은 「기간」은 예외(날짜 아님).

    반환 'calendar'(달력 전용 — 연도 없는 M-D·HH:MM 무조건 가림) /
        'ambiguous'(기간·일정 — 0 채움 MM-DD 또는 MM-DD~MM-DD 범위만 가림) / None(날짜 열 아님)."""
    h = (cell or "").strip()
    if "기간" in h and _PAREN_ANY_RE.search(h):
        return None
    if any(k in h for k in _DATE_COL_KEYWORDS_CALENDAR):
        return "calendar"
    if any(k in h for k in _DATE_COL_KEYWORDS_AMBIGUOUS):
        return "ambiguous"
    return None


def _date_time_masked_spans(text: str) -> list[tuple[int, int]]:
    """날짜·시각으로 보이는 구간의 문자 위치를 모은다 — 이 구간의 숫자는 crosscheck 대상에서 뺀다."""
    spans = [(m.start(), m.end()) for m in _YMD_RE.finditer(text)]     # 연도 붙은 모양 — 어디서든 가린다
    spans += [(m.start(), m.end()) for m in _YM_RE.finditer(text)]

    lines = text.split("\n")
    offset = 0
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        if _TABLE_ROW_RE.match(line.strip()):
            block_lines, block_offsets = [], []
            cur = offset
            j = i
            while j < n and _TABLE_ROW_RE.match(lines[j].strip()):
                block_lines.append(lines[j]); block_offsets.append(cur)
                cur += len(lines[j]) + 1
                j += 1
            data_start = 1
            if len(block_lines) > 1:
                cells1 = [c.strip() for c in block_lines[1].strip().strip("|").split("|")]
                if cells1 and all(_SEP_CELL_RE.match(c) for c in cells1):
                    data_start = 2
            header_cells = [c.strip() for c in block_lines[0].strip().strip("|").split("|")] if block_lines else []
            date_cols = {}
            for ci, h in enumerate(header_cells):
                kind = _is_date_time_header(h)
                if kind:
                    date_cols[ci] = kind
            if date_cols:
                for k in range(data_start, len(block_lines)):
                    row_line = block_lines[k]
                    pipes = [p for p, ch in enumerate(row_line) if ch == "|"]
                    for ci, kind in date_cols.items():
                        if ci + 1 >= len(pipes):
                            continue
                        c_start, c_end = pipes[ci] + 1, pipes[ci + 1]
                        cell_text = row_line[c_start:c_end]
                        base = block_offsets[k] + c_start
                        if kind == "calendar":
                            for m in _MMDD_ANY_RE.finditer(cell_text):
                                spans.append((base + m.start(), base + m.end()))
                            for m in _TIME_RE.finditer(cell_text):
                                spans.append((base + m.start(), base + m.end()))
                        else:  # "ambiguous" — 기간·일정: 0 채움 MM-DD 또는 범위만 가린다
                            for m in _MMDD_RANGE_RE.finditer(cell_text):
                                spans.append((base + m.start(), base + m.end()))
                            for m in _MMDD_LEADZERO_RE.finditer(cell_text):
                                spans.append((base + m.start(), base + m.end()))
            offset = cur
            i = j
            continue
        offset += len(line) + 1
        i += 1
    return spans

# D-010(V1 4차, 2026-09-23) — 표 칸 값 대조 주 방어선.
# docx_build 의 모양(두 축 교차) 판정은 3라운드째 한쪽을 막으면 다른 쪽이 뚫렸다(괄호 위장·축 위치).
# 그래서 «나쁜 표를 알아보려」 하지 않고, **표 안의 모든 숫자가 canon.figures 에 있는지 값으로 증명**한다.
# 마크다운 표의 데이터 칸(머리행·구분선 행 제외, 첫 열 제외)에서는 자릿수·단위와 무관하게 전부 값으로 본다
# — 「단위 없는 1~2자리는 순번」 스킵을 이 칸에는 적용하지 않는다.
_TABLE_ROW_RE = re.compile(r"^\|(.+)\|$")
_SEP_CELL_RE = re.compile(r"^:?-{2,}:?$")
_CELL_NUM_RE = re.compile(r"^-?\d+(?:\.\d+)?%?$")
# D-010(V1 4차 재반려, 2026-09-23) High(가) — 첫 열은 «순번·라벨일 때만» 뺀다.
# `| 점수 | 대안 |` + `| 68 | 1안 |` 처럼 값이 첫 열에 오면 무조건 빼는 규칙이 그 값을 놓쳤다.
_FIRST_COL_SCORE_WORDS = ("점수", "순위", "평점", "득점", "등급", "총점", "배점", "가점", "감점",
                          "랭킹", "가중치", "가중합", "원점수", "환산", "평가점")


def _cell_looks_plain_numeric(s: str) -> bool:
    return bool(_CELL_NUM_RE.match((s or "").strip().replace(",", "")))


def _first_col_is_label_or_seq(first_cells: list[str]) -> bool:
    """첫 열이 (전부 비숫자 라벨) 이거나 (1부터 1씩 느는 순번) 이면 True — 이때만 첫 열을 뺀다."""
    if not first_cells:
        return True
    if all(not _cell_looks_plain_numeric(c) for c in first_cells):
        return True
    nums = []
    for c in first_cells:
        if not _cell_looks_plain_numeric(c):
            return False
        try:
            nums.append(int(float(c.strip().replace(",", "").rstrip("%"))))
        except ValueError:
            return False
    return nums == list(range(1, len(nums) + 1))


def _table_data_cell_spans(text: str) -> list[tuple[int, int]]:
    """마크다운 표의 «데이터 칸»(머리행·구분선 행 제외) 문자 구간을 모은다.
    첫 열은 기본적으로 제외하되, 머리행 첫 칸이 점수 낱말(점수·순위·평점 등)이거나 첫 열이
    순번·라벨이 아니면(=값이면) 첫 열도 데이터 칸에 포함한다.
    반환된 구간에 들어간 숫자는 crosscheck 에서 순번 스킵 없이 무조건 값으로 취급된다."""
    spans: list[tuple[int, int]] = []
    lines = text.split("\n")
    offset = 0
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        if _TABLE_ROW_RE.match(line.strip()):
            block_lines, block_offsets = [], []
            cur = offset
            j = i
            while j < n and _TABLE_ROW_RE.match(lines[j].strip()):
                block_lines.append(lines[j])
                block_offsets.append(cur)
                cur += len(lines[j]) + 1        # +1 = 줄바꿈 문자
                j += 1
            data_start = 1
            if len(block_lines) > 1:
                cells1 = [c.strip() for c in block_lines[1].strip().strip("|").split("|")]
                if cells1 and all(_SEP_CELL_RE.match(c) for c in cells1):
                    data_start = 2                # 구분선 행(|---|---|) 도 제외

            header_cells = [c.strip() for c in block_lines[0].strip().strip("|").split("|")] if block_lines else []
            header_first = header_cells[0] if header_cells else ""
            body_first_cells = []
            for k in range(data_start, len(block_lines)):
                cells = [c.strip() for c in block_lines[k].strip().strip("|").split("|")]
                body_first_cells.append(cells[0] if cells else "")
            exclude_first = True
            if any(w in header_first for w in _FIRST_COL_SCORE_WORDS):
                exclude_first = False                                     # 순위 1,2,3 도 LLM 이 매긴 판단이다
            elif not _first_col_is_label_or_seq(body_first_cells):
                exclude_first = False                                     # 첫 열이 값이다(순번·라벨이 아님)

            for k in range(data_start, len(block_lines)):
                row_line = block_lines[k]
                pipes = [p for p, ch in enumerate(row_line) if ch == "|"]
                if exclude_first:
                    if len(pipes) < 3:            # 열이 2개 이상이어야 "첫 열 제외"가 의미 있다
                        continue
                    start = pipes[1] + 1          # 두 번째 '|' 다음 = 둘째 칸(첫 데이터 칸) 시작
                else:
                    if len(pipes) < 2:
                        continue
                    start = pipes[0] + 1          # 첫 '|' 다음 = 첫 칸부터 전부 데이터
                end = pipes[-1]                   # 마지막 '|' = 표 끝
                spans.append((block_offsets[k] + start, block_offsets[k] + end))
            offset = cur
            i = j
            continue
        offset += len(line) + 1
        i += 1
    return spans


# ---------------------------------------------------------------- D-012(V2 지적 1·2, 2026-09-23) 단위 인식 대조
# V2(Codex) 재현: canon 에 「충전기 2023년 설치 건수 = 8 (unit 건)」만 등록해 두고
# 본문에 "동종업계 평균 가동률 8%" 라고 지어내면 값(8)만 맞아 조용히 통과했다 — 헌법 2조가 막으려는
# 「출처 없는 가동률 18%」 덫과 같은 종류다. 값이 같아도 **단위가 다르면 적발**해야 한다.
# 정본 unit 과 본문 unit 이 둘 다 있고 다르면 실패, 둘 중 하나라도 비어 있으면(정본 단위 미상 또는
# 본문에 단위 표기가 없음) 종전처럼 값만으로 매칭한다. %(구성비)와 %p(비율 차이)는 다른 단위다(헌법 7조).
_UNIT_TOKEN_RE = re.compile(
    r"^\s*(백만원|천원|만원|억원|조원|개소|개월|시간|%p|kW|㎡|건|명|개|곳|면|대|원|배|일)")

# D-012·V2R2 지적 1 재현: canon 단위가 「건」인데 본문이 "8퍼센트"·"8 퍼센트"라고 적으면
# 위 _UNIT_TOKEN_RE 에 한글 표기가 없어 단위를 못 읽고(""), 값만 같아서 조용히 통과했다.
# 「퍼센트」·「프로」(구어체) → %, 「퍼센트포인트」·「%포인트」·「포인트」(숫자 바로 뒤) → %p 로 정규화한다.
# 「프로」는 「프로젝트」·「프로그램」의 앞부분과 겹치므로 그 두 낱말일 때만 단위가 아니라고 본다.
_KOR_PP_RE = re.compile(r"^\s*(퍼센트\s*포인트|포인트)")
_KOR_PERCENT_RE = re.compile(r"^\s*(퍼센트|프로(?!젝트|그램))")
# 숫자 바로 뒤에 조사만 붙은 경우(「8건이」「8명의」)는 이미 위에서 단위 토큰이 먼저 매치되어 걸러진다.
# 여기서 가리는 것은 «단위도 조사도 아닌, 정체 모를 한글 단어»(예: 8킬로와트·8루멘) 다 —
# 그런 낱말이 붙어 있는데 정본 단위가 따로 있으면 값만으로 통과시키지 않고 불일치로 본다(과잉 방향이 안전).
_JOSA_RE = re.compile(r"^\s*(이|가|은|는|을|를|과|와|의|도|만|께|에게|에서|으로|로)(?![가-힣])")
_KOREAN_WORD_RE = re.compile(r"^\s*[가-힣]+")
_UNKNOWN_UNIT = "\x00?"          # "본문에 정체 모를 한글 단위어가 붙어 있음" 신호(공란=단위 표기 없음 과 구분)


def _detect_unit(text: str, m: "re.Match") -> str:
    """숫자 매치 바로 뒤의 단위를 읽는다. `_NUM_RE` 가 '%'를 이미 매치에 삼켰을 수 있어 %p 조합부터 본다.

    반환값 3가지: 알려진 단위 문자열 / ""(단위 표기 없음 — 조사만 있거나 그냥 끝남) /
    `_UNKNOWN_UNIT`(단위도 조사도 아닌 낯선 한글 낱말이 붙음 — 정본 단위가 있으면 불일치로 판정한다).
    """
    tail = m.group(0)
    after = text[m.end(): m.end() + 10]
    if tail.rstrip().endswith("%"):
        if after.lstrip(" ").startswith("p") or _KOR_PP_RE.match(after):
            return "%p"
        return "%"
    pp = _KOR_PP_RE.match(after)
    if pp:
        return "%p"
    pct = _KOR_PERCENT_RE.match(after)
    if pct:
        return "%"
    um = _UNIT_TOKEN_RE.match(after)
    if um:
        return um.group(1)
    if _JOSA_RE.match(after):
        return ""                # 조사만 붙음 — 단위 표기 없음
    if _KOREAN_WORD_RE.match(after):
        return _UNKNOWN_UNIT     # 정체 모를 한글 단어 — 단위 불일치 후보
    return ""


def _normalize_unit(u: str) -> str:
    """정본 figure 의 unit 표기 정규화 — 괄호 벗기고 공백 제거. '(백만원)' → '백만원'."""
    u = (u or "").strip()
    m = re.fullmatch(r"\(([^()]+)\)", u)
    if m:
        u = m.group(1).strip()
    return re.sub(r"\s+", "", u)


_HEADER_UNIT_RE = re.compile(r"\(([^()]+)\)\s*$")


def _table_cell_unit_spans(text: str) -> list[tuple[int, int, str]]:
    """마크다운 표 데이터 칸의 문자 구간 + 그 열 머리의 괄호 단위(있으면). 없으면 unit="".
    「계약금액(백만원)」처럼 열 머리에 단위가 있으면, 그 칸의 값은 그 단위로 본다."""
    spans: list[tuple[int, int, str]] = []
    lines = text.split("\n")
    offset = 0
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        if _TABLE_ROW_RE.match(line.strip()):
            block_lines, block_offsets = [], []
            cur = offset
            j = i
            while j < n and _TABLE_ROW_RE.match(lines[j].strip()):
                block_lines.append(lines[j]); block_offsets.append(cur)
                cur += len(lines[j]) + 1
                j += 1
            data_start = 1
            if len(block_lines) > 1:
                cells1 = [c.strip() for c in block_lines[1].strip().strip("|").split("|")]
                if cells1 and all(_SEP_CELL_RE.match(c) for c in cells1):
                    data_start = 2
            header_cells = [c.strip() for c in block_lines[0].strip().strip("|").split("|")] if block_lines else []
            col_units = []
            for h in header_cells:
                hm = _HEADER_UNIT_RE.search(h)
                col_units.append(_normalize_unit(hm.group(1)) if hm else "")
            for k in range(data_start, len(block_lines)):
                row_line = block_lines[k]
                pipes = [p for p, ch in enumerate(row_line) if ch == "|"]
                for ci in range(len(pipes) - 1):
                    c_start, c_end = pipes[ci] + 1, pipes[ci + 1]
                    unit = col_units[ci] if ci < len(col_units) else ""
                    spans.append((block_offsets[k] + c_start, block_offsets[k] + c_end, unit))
            offset = cur
            i = j
            continue
        offset += len(line) + 1
        i += 1
    return spans


def _body_unit(text: str, m: "re.Match", col_unit_spans: list) -> str:
    """이 숫자 매치의 «본문 단위» — 칸 안 인라인 단위(값 바로 뒤)를 우선하고, 없으면 그 열의 머리 단위."""
    u = _detect_unit(text, m)
    if u:
        return u
    for s, e, cu in col_unit_spans:
        if cu and s <= m.start() < e:
            return cu
    return ""


def _match_units(tok: str, known: dict) -> "list[str] | None":
    """토큰 값이 known(값문자열 → 단위 목록)에 있으면 그 단위 목록을, 없으면 None."""
    if tok in known:
        return known[tok]
    tok_norm = tok.lstrip("-").lstrip("0")
    matches: list[str] = []
    for k, units in known.items():
        if k.lstrip("-").lstrip("0") == tok_norm:
            matches.extend(units)
    return matches or None


# ---------------------------------------------------------------- D-012(V2 지적 2) 4절 엄격 모드
# V2 재현: 4절에 LLM 이 지어낸 점수표(`| 구분 | A | B |` / `| 1안 | 8 | 16 |`)를 우연히 정본 수치와
# 같은 값으로 채우면, 모양 판정(docx_build._is_score_table)이 못 잡을 때 값 대조도 조용히 통과했다.
# → 대안 표기(1안·제1안·대안1·A안·현행안…)가 있는 표에서는, 단위 없는 데이터 칸 숫자는
# 정본에 같은 값이 있어도 **무조건 적발**한다(단위가 있으면 위 단위 인식 대조를 그대로 따른다).
# ★ docx_build._ALT_LABEL_RE 와 판정 기준을 맞춘다 — 저 파일을 고치면 이 정규식도 같이 고친다.
_ALT_LABEL_RE = re.compile(
    r"^\(?\d+\)?\s*안$"        # 1안, (1)안
    r"|^제?\d+안$"             # 제1안, 1안
    r"|^대안\s*\d+$"           # 대안1, 대안 1
    r"|^[A-Za-z]\s*안$"        # A안
    r"|^대안\s*[A-Za-z]$"      # 대안A, 대안 A
    r"|^현행안$"               # 현행안
    r"|^현행\s*유지$"          # 현행 유지
)


def _table_alt_ranges(text: str) -> list[tuple[int, int]]:
    """본문 행 어느 칸이든 대안 표기가 있는 표 블록의 (시작, 끝) 문자 구간 목록."""
    spans: list[tuple[int, int]] = []
    lines = text.split("\n")
    offset = 0
    i, n = 0, len(lines)
    while i < n:
        line = lines[i]
        if _TABLE_ROW_RE.match(line.strip()):
            block_lines = []
            cur = offset
            j = i
            while j < n and _TABLE_ROW_RE.match(lines[j].strip()):
                block_lines.append(lines[j])
                cur += len(lines[j]) + 1
                j += 1
            data_start = 1
            if len(block_lines) > 1:
                cells1 = [c.strip() for c in block_lines[1].strip().strip("|").split("|")]
                if cells1 and all(_SEP_CELL_RE.match(c) for c in cells1):
                    data_start = 2
            has_alt = False
            for k in range(data_start, len(block_lines)):
                cells = [c.strip() for c in block_lines[k].strip().strip("|").split("|")]
                if any(_ALT_LABEL_RE.match(c) for c in cells):
                    has_alt = True
                    break
            if has_alt:
                spans.append((offset, cur))
            offset = cur
            i = j
            continue
        offset += len(line) + 1
        i += 1
    return spans


def crosscheck(text: str, canon: dict, strict_alt_tables: bool = False) -> list[dict]:
    """본문 숫자 중 canon.figures 값에 없는 것 목록. 연도·절항·표번호·쪽·건수 등은 제외.

    `[확인 필요]` 자리표시는 정상 표기이므로 여기서 잡지 않는다 — 잡아야 할 것은 **지어낸 수치**다.
    각 항목에 `start`/`end`(원문 문자 위치)를 함께 돌려준다 — 호출부(engine._postprocess)가
    표시를 **적발된 그 자리**에 뒤에서부터 꽂게 하기 위함(같은 숫자가 문서 앞쪽에 또 있어도 안 섞인다).

    strict_alt_tables : 4절(대안 비교)에서만 True 로 부른다. 대안 표기가 있는 표의 데이터 칸에서는
        단위 없는 숫자를 정본 값 일치와 무관하게 무조건 적발한다(D-012 V2 지적 2).
    """
    figs = canon.get("figures", {})
    # D-010(V1 4차 재반려) High(나) — outline.approve_outline() 이 등재하는 구조 수치
    # (「대안 수」·「평가기준 수」·「검토 논점 수」, source_id="목차 승인")는 본문 문장에서는
    # 정상 수치지만("대안 3개"), **표 데이터 칸**에서 지어낸 원점수와 우연히 같으면(예: 3)
    # 조용히 통과해 버린다. 표 칸 판정에서는 구조 수치를 known 후보에서 뺀다(본문은 그대로 인정).
    # D-012(V2 지적 1) — 값 집합(set)만으로는 단위를 비교할 수 없어 값문자열 → 단위 목록(dict)으로 바꾼다.
    known_all: dict = {}
    known_nonstruct: dict = {}
    for f in figs.values():
        is_struct = (f.get("source_id") == "목차 승인") or (f.get("kind") == "structural")
        v = f.get("value")
        vals = []
        if isinstance(v, (int, float)):
            vals = [v]
        elif isinstance(v, dict):
            vals = [vv for vv in v.values() if isinstance(vv, (int, float))]
        unit = _normalize_unit(f.get("unit") or "")
        for vv in vals:
            keys = {("%.4f" % vv).rstrip("0").rstrip("."), "%.2f" % vv, "%.1f" % vv, str(vv)}
            for k in keys:
                known_all.setdefault(k, []).append(unit)
                if not is_struct:
                    known_nonstruct.setdefault(k, []).append(unit)
    table_spans = _table_data_cell_spans(text)
    date_spans = _date_time_masked_spans(text)
    col_unit_spans = _table_cell_unit_spans(text)
    alt_ranges = _table_alt_ranges(text) if strict_alt_tables else []
    issues = []
    for m in _NUM_RE.finditer(text):
        ctx = text[max(0, m.start() - 12): m.end() + 12]
        if _SKIP_AFTER.match(text[m.end():m.end() + 6]) or _SKIP_BEFORE.search(text[max(0, m.start() - 6):m.start()]):
            continue
        if re.fullmatch(r"(19|20)\d{2}", m.group(0)):      # 연도
            continue
        if any(s <= m.start() < e for s, e in date_spans):  # 날짜·시각 구간(표 칸 안이라도 값 대조 제외)
            continue
        in_table_data = any(s <= m.start() < e for s, e in table_spans)
        known = known_nonstruct if in_table_data else known_all
        tok = m.group(0).replace(",", "").replace("%", "").strip()
        body_unit = _body_unit(text, m, col_unit_spans)
        # D-012(V2 지적 2) 4절 엄격 모드 — 대안 표기가 있는 표의 데이터 칸에서 단위 없는 숫자는
        # 정본에 같은 값이 있어도 무조건 적발한다(단위가 있으면 아래 일반 단위 대조로 내려간다).
        if in_table_data and not body_unit and any(s <= m.start() < e for s, e in alt_ranges):
            issues.append({"number": m.group(0), "context": ctx.replace("\n", " "),
                           "start": m.start(), "end": m.end()})
            continue
        matched_units = _match_units(tok, known)
        if matched_units is not None:
            # D-012(V2R2 지적 1) — 본문에 «정체 모를 한글 단위어»(퍼센트·프로·포인트 등 정규화 목록에
            # 없는 낱말)가 붙어 있으면, 값만 같다고 조용히 통과시키지 않는다. 정본에 단위가 있으면
            # 불일치로 본다(과잉 방향이 안전) — 정본 단위도 미상이면 종전처럼 값만으로 통과.
            if body_unit == _UNKNOWN_UNIT:
                if any(u for u in matched_units):
                    issues.append({"number": m.group(0), "context": ctx.replace("\n", " "),
                                   "start": m.start(), "end": m.end()})
                continue
            # D-012(V2 지적 1) 단위 인식 대조 — 둘 다 단위가 있고 다르면 값이 같아도 적발한다.
            if not body_unit or any(u in ("", body_unit) for u in matched_units):
                continue
            issues.append({"number": m.group(0), "context": ctx.replace("\n", " "),
                           "start": m.start(), "end": m.end()})
            continue
        # ★ V2(Codex) Critical 지적 2026-09-21 — 종전에는 **한두 자리 정수를 무조건 건너뛰었다.**
        #   원자재(학위논문)는 순번이 많아 그래도 됐지만, 보고서에서 한두 자리는 대개 **실질 수치**다
        #   (점유율 7%, 3개소, 12명). "점유율 99%"를 지어내도 [확인 필요]가 안 붙던 구멍이었다.
        #   → 자릿수가 아니라 **맥락**으로 가른다. 순번 표지(제·표·붙임…)는 위 _SKIP_* 가 이미 걸렀으므로
        #     여기서는 «단위가 붙은 수치»인지만 본다. 단위가 있으면 순번이 아니라 값이다.
        # ★ D-010(V1 4차) — 표의 «데이터 칸»(첫 열 제외)에서는 이 순번 스킵을 적용하지 않는다.
        #   crosscheck 가 단위 없는 한두 자리를 순번으로 보고 건너뛰어 원점수 4·3·5, 점수 68·75 가
        #   조용히 통과하던 구멍이었다 — 표 칸 안의 숫자는 자릿수·단위와 무관하게 전부 값이다.
        if not in_table_data and re.fullmatch(r"-?\d{1,2}", tok):
            # ⚠️ 매치 문자열이 이미 %를 삼켰을 수 있다(_NUM_RE 가 `\s*%` 를 포함) — 그것부터 본다.
            after = text[m.end():m.end() + 10]
            # ★D-006 — 곳·면·대·kW·㎡·백만원·천원·개 추가(표 파일 집계에서 흔한 단위). _SKIP_AFTER 축소의 짝.
            # ★D-012·V2R2 지적 1 — 「프로」·「포인트」도 한글 단위 표기로 인정한다(_KOR_PERCENT_RE/_KOR_PP_RE 재사용,
            #   「프로젝트」·「프로그램」은 그 안의 부정 전방탐색으로 이미 제외됨).
            has_unit = ("%" in m.group(0)) or bool(
                re.match(r"\s*(%|퍼센트|%p|건|명|개|개소|개사|부서|과|팀|곳|면|대|kW|㎡|백만원|천원|억|만|천|원|배|위|시간|일간)", after)
            ) or bool(_KOR_PERCENT_RE.match(after)) or bool(_KOR_PP_RE.match(after))
            if not has_unit:
                continue                          # 단위 없는 한두 자리 = 순번으로 본다(표 밖에서만)
        issues.append({"number": m.group(0), "context": ctx.replace("\n", " "),
                       "start": m.start(), "end": m.end()})
    return issues
