# -*- coding: utf-8 -*-
"""docx_build.py — Markdown 원고 → 조직 양식 DOCX 조립 + 열림 검증 + 후처리 목록.

부품 출처(BOM 🟡): 원자재 thesis-agent `app/docx_build.py`
  sha256 091bf948923631e0323a66d76039e68598cff04339ec177c7fbebed9fa30ab16 (2026-09-20)
  ← 그 위로는 **docx-plus** `publishing/toc.py`·`notes/registry.py` (MIT, Copyright (c) thomas-villani)
     커밋 ee7d57ae9ee360e1b0c632fa0a9c67698607155d — THIRD_PARTY_NOTICES.md 참조

승계(🟢): `_build_complex_field`·`add_toc`(진짜 Word TOC 필드 fldChar 5-run) · `mark_fields_dirty` ·
  `FootnoteRegistry`(각주 ID 순차 소정수 — 랜덤 큰 ID 는 Word 가 열기를 거부) · `_write_footnotes_part` ·
  `_table` · `validate`(zip 무결·document.xml 파싱·TOC 필드·각주 ID 순차)
폐기(🔴): 학술 양식 — `_apa_ref`(APA 참고문헌) · 국문/영문 초록 2종 · 학위논문 표지
자체 제작(🏭): **개조식 3단 들여쓰기 렌더러**(`□`/`○`/`-`) · 조직 프로필 표지(공공: 문서번호·결재란) ·
  **요약 글상자**(공공 보고요지) · **대안 비교표 자동 삽입**(`[[비교표]]`) · **출처 검증표** ·
  `measure_table_ratio`(공식 체크리스트 #11 표 비중)

한계(과잉 약속 금지): **TOC 본문은 Word 가 열 때 채운다**(updateFields=true 로 갱신 프롬프트).
  표 번호 자동 갱신 없음 → 후처리 목록에 기록. HWP 발송본은 한컴/LibreOffice 변환 필요(범위 밖).
"""
from __future__ import annotations
import re, zipfile, datetime
from pathlib import Path

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

try:
    from . import guard, source  # type: ignore
except ImportError:
    import guard, source  # type: ignore


# ---------------------------------------------------------------- 필드 (docx-plus 🟢)
def _build_complex_field(p_element, instruction: str, initial_text: str = ""):
    def sub(parent, tag, **attrs):
        el = OxmlElement(tag)
        for k, v in attrs.items():
            el.set(qn(k) if ":" in k and not k.startswith("xml:") else "{http://www.w3.org/XML/1998/namespace}space" if k == "xml:space" else k, v)
        parent.append(el)
        return el
    begin = sub(p_element, "w:r"); sub(begin, "w:fldChar", **{"w:fldCharType": "begin"})
    instr_run = sub(p_element, "w:r"); it = sub(instr_run, "w:instrText", **{"xml:space": "preserve"}); it.text = instruction
    sep = sub(p_element, "w:r"); sub(sep, "w:fldChar", **{"w:fldCharType": "separate"})
    tr = sub(p_element, "w:r"); tt = sub(tr, "w:t", **{"xml:space": "preserve"}); tt.text = initial_text
    end = sub(p_element, "w:r"); sub(end, "w:fldChar", **{"w:fldCharType": "end"})
    return begin


def add_toc(paragraph, levels=(1, 3)):
    return _build_complex_field(paragraph._p, ' TOC \\o "%d-%d" \\h \\z \\u ' % levels,
                                "목차는 Word에서 문서를 열 때 갱신됩니다(필드 업데이트 → 예).")


def mark_fields_dirty(doc):
    """settings.xml 에 <w:updateFields w:val="true"/> — Word 가 열 때 필드 갱신을 묻는다."""
    settings = doc.settings.element
    for el in settings.findall(qn("w:updateFields")):
        settings.remove(el)
    uf = OxmlElement("w:updateFields"); uf.set(qn("w:val"), "true")
    settings.append(uf)


# ---------------------------------------------------------------- 각주 (순차 ID — docx-plus registry 🟡)
class FootnoteRegistry:
    """각주 ID 는 1부터 순차 정수. python-docx 는 각주 API 가 없어 footnotes.xml 을 직접 만든다."""
    def __init__(self):
        self.notes: list[tuple[int, str]] = []

    def add(self, text: str) -> int:
        nid = len(self.notes) + 1
        self.notes.append((nid, text))
        return nid


def _footnote_ref_run(paragraph, nid: int):
    r = OxmlElement("w:r")
    rpr = OxmlElement("w:rPr"); va = OxmlElement("w:vertAlign"); va.set(qn("w:val"), "superscript"); rpr.append(va); r.append(rpr)
    ref = OxmlElement("w:footnoteReference"); ref.set(qn("w:id"), str(nid)); r.append(ref)
    paragraph._p.append(r)


def _write_footnotes_part(docx_path: Path, registry: FootnoteRegistry):
    """저장된 docx 에 footnotes.xml + rels + content type 추가(순차 ID). 각주 0건이면 건너뜀."""
    if not registry.notes:
        return
    ns = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
    body = ['<w:footnote w:type="separator" w:id="-1"><w:p><w:r><w:separator/></w:r></w:p></w:footnote>',
            '<w:footnote w:type="continuationSeparator" w:id="0"><w:p><w:r><w:continuationSeparator/></w:r></w:p></w:footnote>']
    for nid, text in registry.notes:
        body.append('<w:footnote w:id="%d"><w:p><w:pPr><w:pStyle w:val="FootnoteText"/></w:pPr><w:r><w:rPr><w:vertAlign w:val="superscript"/></w:rPr><w:footnoteRef/></w:r><w:r><w:t xml:space="preserve"> %s</w:t></w:r></w:p></w:footnote>' % (nid, _xml(text)))
    fx = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:footnotes %s>%s</w:footnotes>' % (ns, "".join(body))
    tmp = docx_path.with_suffix(".tmp.docx")
    with zipfile.ZipFile(docx_path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == "[Content_Types].xml":
                s = data.decode("utf-8")
                if "footnotes+xml" not in s:
                    s = s.replace("</Types>", '<Override PartName="/word/footnotes.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml"/></Types>')
                data = s.encode("utf-8")
            elif item.filename == "word/_rels/document.xml.rels":
                s = data.decode("utf-8")
                if "footnotes.xml" not in s:
                    s = s.replace("</Relationships>", '<Relationship Id="rIdFootnotes1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes" Target="footnotes.xml"/></Relationships>')
                data = s.encode("utf-8")
            zout.writestr(item, data)
        zout.writestr("word/footnotes.xml", fx)
    tmp.replace(docx_path)


def _xml(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


# ---------------------------------------------------------------- 패턴
_H_RE = re.compile(r"^(#{1,3})\s+(.*)$")
_TABLE_ROW = re.compile(r"^\|(.+)\|$")
_FN_RE = re.compile(r"\^\[([^\]]{2,400})\]|\[\^([^\]]{2,400})\]")
_TAG_RE = re.compile(r"\[(미검증|검증대기|확인 필요|내부자료)\]")

# D-010: [[비교표]] 관대 인식 — 백틱/강조/개조식 기호로 감싸도, 문장 속에 섞여도 자리표시로 본다.
_PLACEHOLDER_TOKEN = re.compile(r"`{1,3}\[\[비교표\]\]`{1,3}|\*\*\[\[비교표\]\]\*\*|__\[\[비교표\]\]__|\[\[비교표\]\]")
_BULLET_STRIP_RE = re.compile(r"^[□■○●\-·*]\s+")
# D-010(V1 2차 재작업, 2026-09-23): LLM 점수표 판별 — «두 축의 교차»로 판정한다.
# V1 72점 High 원인(소대장 2차 사양 결함, 내 구현은 맞았음): 한 축(행 or 낱말)만 보고 판정하면
# 「구분|투자비(억원)|기간(월)」× 「1안/2안/3안」같은 **비용·일정표**가 대안 라벨만으로 지워진다.
# 새 규칙: 점수표 = 한 축에 **대안 신호**, 다른 축에 **평가 신호**가 함께 있을 때만(교차 A/B).
# 측정 단위 괄호(억원·월·명·% 등)가 붙은 칸은 평가기준 이름과 겹쳐도 평가 신호에서 제외한다
# (`(점)` 은 예외 — 점수 표시로 본다). 「합계」「평가」 단독은 어떤 경우에도 평가 신호가 아니다.
_SCORE_STRONG_KEYWORDS = ("가중치", "가중합", "원점수", "환산")            # 그 자체로 평가표임이 분명한 낱말
_SCORE_WEAK_KEYWORDS = ("점수", "총점", "배점", "평점", "득점", "가점", "감점",
                        "등급", "순위", "비중", "랭킹", "평가점")           # "합계"·"평가" 단독은 제외
_ALT_LABEL_RE = re.compile(
    r"^\(?\d+\)?\s*안$"        # 1안, (1)안
    r"|^제?\d+안$"             # 제1안, 1안
    r"|^대안\s*\d+$"           # 대안1, 대안 1
    r"|^[A-Za-z]\s*안$"        # A안
    r"|^대안\s*[A-Za-z]$"      # 대안A, 대안 A
    r"|^현행안$"               # 현행안
    r"|^현행\s*유지$"          # 현행 유지
)
_NUMERIC_UNIT_RE = re.compile(r"(원|점|위|등|건|개|월|일|년|억원|만원)$")
_PAREN_RE = re.compile(r"\(([^)]*)\)")
# D-010(V1 3차 반려, 2026-09-23): 괄호 안이 이 **측정 단위 허용 목록**일 때만 측정 열로 본다.
# 그 밖(점·점수·pt·평점·5점 만점·등급 …)은 측정이 아니다 — 평가 신호를 죽이지 않는다.
_MEASUREMENT_UNITS = {"억원", "만원", "천원", "백만원", "원", "월", "개월", "일", "년",
                      "시간", "명", "%", "kW", "㎡", "면", "대", "건", "개", "곳"}
_PAREN_NUM_STRIP_RE = re.compile(r"[\d,.\~\-\s]")


def _looks_numeric(cell: str) -> bool:
    s = (cell or "").strip()
    s = re.sub(r"[,%]", "", s)
    s = _NUMERIC_UNIT_RE.sub("", s)
    return bool(re.fullmatch(r"-?\d+(\.\d+)?", s))


def _table_has_numeric_cell(rows: list[list[str]]) -> bool:
    return any(_looks_numeric(c) for row in rows[1:] for c in row)


def _comparison_names(comparison: dict | None):
    """comparison(calc.weighted_score 결과)에서 평가기준 이름·대안 이름(라벨+키)을 뽑는다. 없으면 빈 집합."""
    crit, alt = set(), set()
    if comparison and comparison.get("rows"):
        first = comparison["rows"][0]
        crit = {c.get("criterion") for c in (first.get("cells") or []) if c.get("criterion")}
        for r in comparison["rows"]:
            if r.get("label"):
                alt.add(r["label"])
            if r.get("key"):
                alt.add(r["key"])
    return crit, alt


def _norm_alt(s: str) -> str:
    """대안 이름 비교용 정규화 — 공백·괄호(문자 자체)를 지운다."""
    return re.sub(r"[()\s]", "", s or "")


def _has_measurement_paren(cell: str) -> bool:
    """칸의 괄호 안이 측정 단위 허용 목록(억원·월·명·% 등)과 일치할 때만 측정 열로 본다.
    「(점수)」「(5점 만점)」「(등급)」처럼 목록 밖이면 측정이 아니다 — 평가 신호를 죽이지 않는다."""
    for p in _PAREN_RE.findall(cell or ""):
        core = _PAREN_NUM_STRIP_RE.sub("", p.strip())
        if core in _MEASUREMENT_UNITS:
            return True
    return False


def _cell_is_alt(cell: str, alt_names: set) -> bool:
    """칸이 «대안 신호»인가 — comparison 의 대안 이름/키와 일치(공백·괄호 무시, 앞부분 일치 허용)
    또는 「1안·제1안·대안1·A안·대안 A·현행안·현행 유지」류 일반 표기."""
    cell = (cell or "").strip()
    if not cell:
        return False
    norm_cell = _norm_alt(cell)
    for name in alt_names:
        norm_name = _norm_alt(name)
        if norm_name and norm_cell and (norm_cell.startswith(norm_name) or norm_name.startswith(norm_cell)):
            return True
    return bool(_ALT_LABEL_RE.match(cell))


def _cell_is_eval(cell: str, crit_names: set) -> bool:
    """칸이 «평가 신호»인가 — 측정 단위 괄호가 있으면 제외하고, 평가기준 이름 또는 점수 낱말과 대조."""
    cell = (cell or "").strip()
    if not cell or _has_measurement_paren(cell):
        return False
    if any(name and name in cell for name in crit_names):
        return True
    if any(k in cell for k in _SCORE_STRONG_KEYWORDS):
        return True
    if any(k in cell for k in _SCORE_WEAK_KEYWORDS):
        return True
    return False


def _placeholder_kind(line: str):
    """줄에서 [[비교표]] 자리표시를 관대하게 인식한다.
    반환: ('whole', None) — 줄 전체가 자리표시뿐(기호·백틱·강조 벗기면 [[비교표]] 뿐)
          ('inline', 나머지줄) — 다른 글과 섞여 있음(자리표시만 제거한 나머지)
          (None, None) — 자리표시 없음
    """
    s = line.strip()
    if not _PLACEHOLDER_TOKEN.search(s):
        return None, None
    denuded = _BULLET_STRIP_RE.sub("", s).strip()
    denuded = denuded.strip("`").strip("*_").strip()
    if denuded == "[[비교표]]":
        return "whole", None
    remaining = _PLACEHOLDER_TOKEN.sub("", line).rstrip()
    lead_len = len(remaining) - len(remaining.lstrip(" \t"))
    lead, rest = remaining[:lead_len], remaining[lead_len:]
    rest = re.sub(r"[ \t]{2,}", " ", rest).rstrip()
    return "inline", lead + rest


def _row_first_nonnumeric_cell(row: list[str]) -> str:
    """행에서 처음 나오는 «숫자가 아닌» 칸 — 전치 표에서 순번 열 뒤에 오는 기준명 칸을 잡는다."""
    for c in row:
        if not _looks_numeric(c):
            return c
    return row[0] if row else ""


def _is_score_table(rows: list[list[str]], comparison: dict | None = None) -> bool:
    """표가 LLM 이 매긴 점수/평가표인지 **두 축의 교차**로 판정한다(헌법 6조).

    열 축 = 머리행 셀들(첫 칸 제외).
    1) 숫자 칸이 하나도 없으면 무조건 아니다(장단점 비교 등 보존).
    2) 교차 A: **본문 행 중 어느 칸이든** 대안 신호가 있는 행 ≥1 **그리고** 열 축에 평가 신호 ≥1
       → 점수표(대안 신호가 첫 열이 아니라 「순번|대안명|평점」처럼 다른 열에 있어도 잡는다).
    3) 교차 B(전치): 열 축에 대안 신호 ≥1 **그리고** 본문 행의 **첫 비숫자 칸**(순번 열을 건너뛴
       기준명 칸)에 평가 신호가 있는 행 ≥1 → 점수표(예: `순번|기준|1안|2안|3안`).
    4) 가중치표: 대안이 없어도 머리행에 「가중치·가중합·원점수」가 있으면 점수표(가중치도 사람만 정한다).
    5) 그 밖은 보존 — 대안 라벨이 있어도 다른 축이 측정 단위(억원·월 등)뿐이면 비용·일정표로 본다.
    """
    if not rows or len(rows) < 2:
        return False
    header = rows[0]
    if not _table_has_numeric_cell(rows):
        return False
    body = rows[1:]
    col_axis = header[1:] if len(header) > 1 else []
    crit_names, alt_names = _comparison_names(comparison)

    # D-010(V1 4차 재반려) High(가) — 평가 신호 검사에 머리행 **첫 칸도** 포함한다.
    # `점수|대안` 처럼 값이 첫 열에 오는 표는 `col_axis(=header[1:])` 만 보면 놓친다.
    row_alt = any(_cell_is_alt(c, alt_names) for row in body for c in row)
    col_eval = any(_cell_is_eval(c, crit_names) for c in header)
    if row_alt and col_eval:
        return True                                    # 교차 A

    col_alt = any(_cell_is_alt(c, alt_names) for c in col_axis)
    row_eval = any(_cell_is_eval(_row_first_nonnumeric_cell(row), crit_names) for row in body if row)
    if col_alt and row_eval:
        return True                                    # 교차 B(전치)

    if any(k in "".join(header) for k in ("가중치", "가중합", "원점수")):
        return True                                     # 가중치표(대안 없음)

    return False

# 🏭 개조식 3단 들여쓰기 — `□`(대) → `○`(중) → `-`(세부). 이 세 기호가 보고서 본문의 뼈대다.
_BULLET_LEVELS = [("□", 0), ("■", 0), ("○", 1), ("●", 1), ("-", 2), ("·", 2), ("*", 2)]
_INDENT_CM = {0: 0.0, 1: 0.6, 2: 1.2}


def _bullet_of(line: str):
    """줄 앞의 개조식 기호 → (level, 본문). 기호가 없으면 (None, 원문)."""
    s = line.lstrip()
    lead = len(line) - len(s)
    for mark, lvl in _BULLET_LEVELS:
        if s.startswith(mark + " ") or s == mark:
            body = s[len(mark):].strip()
            # 들여쓰기 공백이 깊으면 한 단계 더 내린다(LLM 이 `  - ` 로 쓰는 경우)
            if lvl == 2 and lead >= 4:
                return 2, body
            return lvl, body
    return None, line.rstrip()


# ---------------------------------------------------------------- 조립
def build(sections: list[dict], meta: dict, sources: list[dict], profile: dict, settings: dict, out_path: str) -> dict:
    """sections: [{'n','number','title','subhead','md'}]
    meta: {title, recipient, org_name, dept, author, doc_type, summary, key_points, comparison}
    반환 {'path','postprocess','footnotes','warnings','valid','table_ratio'}"""
    warnings = []
    profile = profile or {}
    tpl = profile.get("docx_template")
    doc = Document(tpl) if tpl and Path(tpl).exists() else Document()
    if tpl and not Path(tpl).exists():
        warnings.append("조직 양식 파일을 찾지 못해 기본 템플릿으로 생성: %s" % tpl)
    _apply_base_style(doc, profile)
    fn = FootnoteRegistry()
    public = (profile.get("active") == "public") or (profile.get("summary_mode") == "box")

    # ── 머리말 + 표지 블록
    _cover(doc, meta, profile, public)

    # ── 요약: 공공은 제목 직하 글상자(보고요지), 기업은 독립 절(Executive Summary)
    summary_title = profile.get("summary_title") or ("보고요지" if public else "Executive Summary")
    if meta.get("summary"):
        if public:
            _summary_box(doc, summary_title, meta.get("summary", ""), meta.get("key_points") or [])
        else:
            h = doc.add_paragraph(); h.style = doc.styles["Heading 1"]; h.add_run(summary_title)
            for para in str(meta.get("summary", "")).split("\n\n"):
                if para.strip():
                    doc.add_paragraph(para.strip())
            for kp in (meta.get("key_points") or []):
                _bullet_paragraph(doc, 1, str(kp), fn)
            doc.add_page_break()

    # ── 목차 (진짜 Word 필드)
    p = doc.add_paragraph(); p.style = doc.styles["Heading 1"]; p.add_run("목 차")
    add_toc(doc.add_paragraph(), (1, 3))
    doc.add_page_break()

    # ── 본문
    seen_merged = set()
    comparison_guarantee_used = False    # D-011(D-010 짝) — 4절에서 절 끝 보증 삽입이 실제로 일어났는지
    for sec in sections:
        number, title = sec.get("number", ""), sec.get("title", "")
        head = ("%s %s" % (number, title)).strip()
        if head in seen_merged:           # public 에서 2·3절, 4·5절이 같은 로마자 절로 합쳐질 때 제목 1회만
            head = None
        else:
            seen_merged.add(head)
        used_guarantee = _render_md(doc, sec.get("md", ""), fn, top_title=head, subhead=sec.get("subhead"),
                                    comparison=meta.get("comparison"), n=sec.get("n"))
        if used_guarantee:
            comparison_guarantee_used = True

    # ── 붙임 / <참고자료>
    doc.add_page_break()
    appendix = profile.get("appendix_title") or ("<참고자료>" if public else "붙임")
    h = doc.add_paragraph(); h.style = doc.styles["Heading 1"]; h.add_run(appendix)

    h2 = doc.add_paragraph(); h2.style = doc.styles["Heading 2"]; h2.add_run("1. 출처 검증표")
    _table(doc, source.verification_table(sources))
    _note(doc, "※ 등급 — [원부검증] 공공 통계 원부 조회·값 일치 / [출처확인] URL 실접속 + 본문 대조 / "
               "[내부자료] 사내 자료(자동검증 대상 아님) / 증빙은 사용자 검토 확인분.")

    disc = guard.ai_disclosure(profile, settings or {})
    if disc:
        h3 = doc.add_paragraph(); h3.style = doc.styles["Heading 2"]; h3.add_run("2. 생성형 AI 활용 고지")
        doc.add_paragraph(disc)

    _note(doc, guard.NOTICE)

    mark_fields_dirty(doc)
    out = Path(out_path); out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():                         # 덮어쓰기 금지
        k = 2
        while out.with_name("%s(%d)%s" % (out.stem, k, out.suffix)).exists():
            k += 1
        out = out.with_name("%s(%d)%s" % (out.stem, k, out.suffix))
    doc.save(str(out))
    _write_footnotes_part(out, fn)
    ok, why = validate(out)

    ratio = measure_table_ratio(sections)
    post = ["Word에서 열면 「필드를 업데이트하시겠습니까」 → 예 (목차 채움). 안 뜨면 목차 클릭 → F9",
            "표 번호는 자동 갱신되지 않음 — 본문 '표 N' 참조와 캡션 번호 대조",
            "붙임 「출처 검증표」에서 [미검증]·[검증대기] 항목이 0건인지 확인",
            "본문에 남은 [확인 필요] 표시를 확정 수치로 채우거나 문장을 정성 서술로 고칠 것"]
    if public:
        post.insert(0, "공공 양식 확인 — 문서번호·시행일자·협조부서·결재란을 기관 서식에 맞게 채울 것")
    if ratio["ratio"] > 0.5:
        w = "표 비중이 %.0f%% — 표가 보고서 전체를 차지하는 방식은 지양(공식 체크리스트 #11)" % (ratio["ratio"] * 100)
        warnings.append(w); post.append(w)
    if not ok:
        warnings.append("DOCX 열림 검증 실패: %s" % why)
    return {"path": str(out), "postprocess": post, "footnotes": len(fn.notes),
            "warnings": warnings, "valid": ok, "table_ratio": ratio,
            "comparison_guarantee_used": comparison_guarantee_used}


# ---------------------------------------------------------------- 🏭 표 비중 (체크리스트 #11)
def measure_table_ratio(sections: list[dict]) -> dict:
    """본문 줄 중 표(|…|) 줄의 비율. 「'표' 양식이 보고서 전체를 차지하는 방식 지양」의 코드 판정."""
    total = tbl = 0
    for sec in sections or []:
        for ln in str(sec.get("md", "")).splitlines():
            s = ln.strip()
            if not s or s.startswith("<!--"):
                continue
            total += 1
            if _TABLE_ROW.match(s):
                tbl += 1
    return {"table_lines": tbl, "body_lines": total, "ratio": (tbl / total) if total else 0.0}


# ---------------------------------------------------------------- 양식
def _apply_base_style(doc, profile):
    st = doc.styles["Normal"]
    body_font = profile.get("font_body", "맑은 고딕")
    st.font.name = body_font
    st.element.rPr.rFonts.set(qn("w:eastAsia"), body_font)
    st.font.size = Pt(float(profile.get("font_size", 11)))
    pf = st.paragraph_format
    pf.line_spacing = float(profile.get("line_spacing", 1.45))
    pf.space_after = Pt(2)
    for s in doc.sections:
        m = profile.get("margins_cm", {"top": 2.5, "bottom": 2.0, "left": 2.5, "right": 2.0})
        s.top_margin, s.bottom_margin, s.left_margin, s.right_margin = Cm(m["top"]), Cm(m["bottom"]), Cm(m["left"]), Cm(m["right"])
    for lvl in (1, 2, 3):
        hs = doc.styles["Heading %d" % lvl]
        title_font = profile.get("font_title", body_font)
        hs.font.name = title_font
        hs.element.rPr.rFonts.set(qn("w:eastAsia"), title_font)
        hs.font.size = Pt({1: 15, 2: 13, 3: 11.5}[lvl])
        hs.font.color.rgb = RGBColor(0, 0, 0)


def _cover(doc, meta, profile, public: bool):
    """표지 블록. 공공은 공식 규격(머리말 + 문서번호·시행일자·협조부서·결재란)."""
    hl = profile.get("header_line")
    if hl:
        today = datetime.date.today()
        wd = "월화수목금토일"[today.weekday()]
        line = (hl.replace("{보고일자}", today.strftime("%Y. %m. %d."))
                  .replace("{요일}", wd)
                  .replace("{담당부서}", meta.get("dept", "") or profile.get("dept", ""))
                  .replace("{성명}", meta.get("author", "") or profile.get("writer_name", ""))
                  .replace("{직급}", profile.get("writer_rank", ""))
                  .replace("{연락처}", profile.get("contact", "")))
        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        r = p.add_run(line); r.font.size = Pt(9)

    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(meta.get("title", "[제목]")); r.font.size = Pt(18); r.bold = True
    _hr(doc)

    fields = profile.get("cover_fields") or ["제목", "수신", "작성부서", "작성자", "작성일"]
    values = {
        "문서번호": meta.get("doc_no", ""), "시행일자": datetime.date.today().strftime("%Y. %m. %d."),
        "제목": meta.get("title", ""), "수신": meta.get("recipient", ""),
        "작성부서": meta.get("dept", ""), "작성자": meta.get("author", ""),
        "협조부서": meta.get("cooperation", ""), "작성일": datetime.date.today().strftime("%Y. %m. %d."),
    }
    if not public:
        # D-011 — 기업 표지에 기관명 + 작성자 "이름 직급"을 채운다. 공공 표지는 이미 규격이라 건드리지 않는다.
        values["기관명"] = meta.get("org_name") or profile.get("org_name") or ""
        author = meta.get("author") or profile.get("writer_name") or ""
        rank = profile.get("writer_rank") or ""
        values["작성자"] = (author + " " + rank).strip() if (author or rank) else ""
    rows = [[f, values.get(f, "")] for f in fields if f not in ("제목", "결재란")]
    if not public:
        rows = [[f, v] for f, v in rows if str(v).strip()]   # D-011 — 값이 비면 빈 칸 대신 줄을 생략(기업만)
    if rows:
        _table(doc, [["구분", "내용"]] + rows, header_shade=True)
    if "결재란" in fields:
        _table(doc, [["담당", "검토", "결재"], ["", "", ""]], header_shade=True)
        _note(doc, "※ 결재란은 기관 서식에 맞게 조정하십시오.")
    doc.add_page_break()


def _summary_box(doc, title: str, body: str, key_points: list):
    """🏭 공공 규격 요약 글상자 — 제목 직하, 위·아래 한 줄 테두리(공식 p.076)."""
    _hr(doc)
    p = doc.add_paragraph(); r = p.add_run(title); r.bold = True; r.font.size = Pt(11)
    for ln in str(body or "").splitlines():
        lvl, text = _bullet_of(ln)
        if not text.strip():
            continue
        _bullet_paragraph(doc, 1 if lvl is None else lvl, text, None)
    for kp in (key_points or []):
        _bullet_paragraph(doc, 1, str(kp), None)
    _hr(doc)
    doc.add_paragraph()


def _hr(doc):
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    bd = OxmlElement("w:pBdr")
    for edge in ("top", "bottom"):
        e = OxmlElement("w:" + edge)
        e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "6"); e.set(qn("w:space"), "1"); e.set(qn("w:color"), "444444")
        bd.append(e)
    pPr.append(bd)


def _note(doc, text: str):
    p = doc.add_paragraph()
    r = p.add_run(text); r.font.size = Pt(9); r.italic = True
    r.font.color.rgb = RGBColor(0x44, 0x44, 0x44)


# ---------------------------------------------------------------- 🏭 개조식 렌더러
def _render_md(doc, md: str, fn: FootnoteRegistry, top_title: str | None = None,
               subhead: str | None = None, comparison: dict | None = None, n: str | None = None):
    """Markdown → DOCX. **개조식 3단 들여쓰기를 DOCX 문단 속성으로 옮긴다** —
    `□`/`○`/`-` 기호와 마크다운 기호가 본문에 그대로 새어나가지 않게 한다.

    D-010: 4절(n=="4")은 대안 비교표가 반드시 코드 계산 표로 나가도록 보증한다 —
    [[비교표]] 자리표시(어떤 모양이든)를 관대하게 인식하고, LLM 이 초고에 직접 쓴
    점수표(가중치/점수 등 머리행)는 렌더하지 않고 코드 표로 대체하며, 절 끝까지
    한 번도 표가 안 들어갔으면 절 끝에 보증 삽입한다. 표는 절당 최대 1개."""
    lines = md.splitlines()
    i = 0
    first_h = True
    is_sec4 = (str(n) == "4")
    table_inserted = False
    if top_title:
        p = doc.add_paragraph(); p.style = doc.styles["Heading 1"]; p.add_run(top_title)
    if subhead:
        p = doc.add_paragraph(); p.style = doc.styles["Heading 2"]; p.add_run(subhead)

    while i < len(lines):
        ln = lines[i].rstrip()
        if ln.strip().startswith("<!--"):
            i += 1; continue

        kind, remaining = _placeholder_kind(ln)
        if kind:                                       # [[비교표]] 자리표시(관대 인식)
            if kind == "inline" and remaining and remaining.strip():
                lvl2, text2 = _bullet_of(remaining)
                if text2.strip():
                    _bullet_paragraph(doc, lvl2, text2, fn)
            if is_sec4 and not table_inserted:
                _comparison_table(doc, comparison)
                table_inserted = True
            # is_sec4 and table_inserted(이미 삽입됨) → 중복 표 없이 조용히 제거
            # 4절이 아니면 자리표시만 제거(표는 넣지 않음)
            i += 1; continue

        m = _H_RE.match(ln)
        if m:
            lvl = len(m.group(1)); text = m.group(2).strip()
            if first_h and top_title:                 # 절 제목은 이미 위에서 넣었다 — 중복 방지
                first_h = False
                i += 1; continue
            first_h = False
            p = doc.add_paragraph(); p.style = doc.styles["Heading %d" % min(max(lvl, 2), 3)]; p.add_run(text)
            i += 1; continue

        if _TABLE_ROW.match(ln):
            rows = []
            while i < len(lines) and _TABLE_ROW.match(lines[i].rstrip()):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            if rows and _is_score_table(rows, comparison):
                # D-010/헌법 6조: LLM 이 원고에 직접 쓴 점수표는 어느 절이든 렌더하지 않는다.
                if is_sec4:
                    if not table_inserted:
                        _comparison_table(doc, comparison, replace_note=True)
                        table_inserted = True
                    # 이미 코드 표가 들어갔으면 중복 없이 조용히 제거
                else:
                    _note(doc, "※ AI 가 작성한 평가 점수표를 뺐음 — 점수는 4절 코드 계산 표를 따른다")
                continue
            _table(doc, rows, header_shade=True); continue

        if ln.strip().startswith(("표 ", "그림 ", "<표 ", "<그림 ")):
            p = doc.add_paragraph(); r = p.add_run(ln.strip()); r.bold = True; r.font.size = Pt(10)
            i += 1; continue

        if not ln.strip():
            i += 1; continue

        lvl, text = _bullet_of(ln)
        _bullet_paragraph(doc, lvl, text, fn)
        i += 1

    if is_sec4 and not table_inserted:                 # D-010: 4절 보증 — 표가 한 번도 안 들어갔으면 절 끝에 삽입
        _comparison_table(doc, comparison)
        return True                                     # D-011 — 절 끝 보증이 실제로 쓰였음을 build() 에 알린다
    return False


def _bullet_paragraph(doc, level, text: str, fn: FootnoteRegistry | None):
    """개조식 한 항목. level None 이면 일반 문단(들여쓰기 없음)."""
    p = doc.add_paragraph()
    if level is None:
        p.paragraph_format.first_line_indent = Pt(11)
    else:
        mark = {0: "□", 1: "○", 2: "-"}[level]
        p.paragraph_format.left_indent = Cm(_INDENT_CM[level])
        p.paragraph_format.space_after = Pt(1 if level == 2 else 2)
        r = p.add_run(mark + " ")
        if level == 0:
            r.bold = True
    pos = 0
    if fn is not None:
        for m in _FN_RE.finditer(text):
            _add_runs(p, text[pos:m.start()], bold=(level == 0))
            nid = fn.add(m.group(1) or m.group(2))
            _footnote_ref_run(p, nid)
            pos = m.end()
    _add_runs(p, text[pos:], bold=(level == 0))


def _add_runs(p, text: str, bold: bool = False):
    """**굵게**·*기울임* 최소 처리 + 검증 태그 강조. 마크다운 기호는 본문에 남기지 않는다."""
    for part in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*|\[(?:미검증|검증대기|확인 필요|내부자료)\])", text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            r = p.add_run(part[2:-2]); r.bold = True
        elif part.startswith("*") and part.endswith("*") and len(part) > 2:
            r = p.add_run(part[1:-1]); r.italic = True
        elif _TAG_RE.fullmatch(part):
            r = p.add_run(part); r.bold = True
            if part in ("[미검증]", "[검증대기]", "[확인 필요]"):
                r.font.highlight_color = 7      # yellow — 사람이 반드시 보게
        else:
            r = p.add_run(part)
            if bold:
                r.bold = True


def _comparison_table(doc, comparison: dict | None, replace_note: bool = False):
    """🏭 4절 대안 비교표 — **코드가 계산한 가중합**을 표로 삽입한다. LLM 이 점수를 매기지 않는다.
    replace_note=True 면 원고에 있던 LLM 점수표를 대체했음을 표 아래에 밝힌다(조용한 삭제 금지)."""
    if not comparison or comparison.get("errors") or not comparison.get("rows"):
        reason = "; ".join((comparison or {}).get("errors") or ["평가 원점수가 아직 입력되지 않았습니다"])
        p = doc.add_paragraph()
        r = p.add_run("[확인 필요] 대안 비교표를 만들 수 없습니다 — %s" % reason)
        r.bold = True; r.font.highlight_color = 7
        return
    rows = comparison["rows"]
    crits = [c["criterion"] for c in rows[0]["cells"]]
    weights = {c["criterion"]: c["weight"] for c in rows[0]["cells"]}
    header = ["구분"] + ["%s (%g)" % (c, weights[c]) for c in crits] + ["가중합"]
    body = []
    for r in rows:
        cells = {c["criterion"]: c for c in r["cells"]}
        body.append([r["label"]] + ["%g" % cells[c]["contribution"] if cells[c]["contribution"] is not None else "—"
                                    for c in crits] + ["%g" % r["total"]])
    cap = doc.add_paragraph(); cr = cap.add_run("표. 대안별 가중합 비교 (가중치 × 원점수/만점, 만점 100)")
    cr.bold = True; cr.font.size = Pt(10)
    _table(doc, [header] + body, header_shade=True)
    rank = comparison.get("ranking") or []
    if rank:
        # D-007 취지(V1 반려) — 결재 문서에 내부 함수명을 찍지 않는다. "calc.weighted_score" 삭제.
        _note(doc, "※ 가중합 1위: %s (%g점). 점수는 사람이 정한 가중치와 원점수로 계산한 값 — AI 가 매긴 값이 아님.%s"
                   % (rank[0]["label"], rank[0]["total"],
                      " 동점 발생: " + ", ".join(comparison.get("tie") or []) if comparison.get("tie") else ""))
    if replace_note:
        _note(doc, "※ 원고에 AI 가 작성한 점수표가 있어 사람이 정한 가중치와 원점수로 계산한 표로 대체함")


def _table(doc, rows: list[list[str]], header_shade: bool = False):
    if not rows:
        return
    ncol = max(len(r) for r in rows)
    t = doc.add_table(rows=len(rows), cols=ncol)
    try:
        t.style = doc.styles["Table Grid"]
    except KeyError:
        pass
    for ri, row in enumerate(rows):
        for ci in range(ncol):
            cell = t.cell(ri, ci)
            cell.text = str(row[ci]) if ci < len(row) else ""
            if ri == 0 and header_shade:
                sh = OxmlElement("w:shd"); sh.set(qn("w:fill"), "EFEFEF")
                cell._tc.get_or_add_tcPr().append(sh)
            for par in cell.paragraphs:
                par.paragraph_format.space_after = Pt(0)
                for r in par.runs:
                    r.font.size = Pt(9)
                    if ri == 0:
                        r.bold = True
    doc.add_paragraph()


# ---------------------------------------------------------------- 검증
def validate(path: Path) -> tuple[bool, str]:
    """열림 검증: zip 무결 + document.xml 파싱 + Heading 스타일 존재 + TOC 필드 존재 + 각주 ID 순차."""
    try:
        with zipfile.ZipFile(path) as z:
            bad = z.testzip()
            if bad:
                return False, "zip 손상: %s" % bad
            xml = z.read("word/document.xml").decode("utf-8")
            if "w:instrText" not in xml or "TOC" not in xml:
                return False, "TOC 필드 없음"
            if 'w:val="Heading1"' not in xml and 'w:val="Heading 1"' not in xml and "Heading1" not in xml:
                return False, "제목 스타일 없음 — TOC 가 빈 채로 열림"
            if "word/footnotes.xml" in z.namelist():
                ids = [int(x) for x in re.findall(r'<w:footnote w:id="(\d+)"', z.read("word/footnotes.xml").decode("utf-8"))]
                if ids != list(range(1, len(ids) + 1)):
                    return False, "각주 ID 비순차: %s" % ids[:5]
        Document(str(path))   # python-docx 재로드
        return True, "ok"
    except Exception as e:
        return False, str(e)
