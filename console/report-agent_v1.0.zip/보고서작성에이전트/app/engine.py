# -*- coding: utf-8 -*-
"""engine.py — 최상위 집행자. State Machine(무판단 스케줄러) + 액션봇(LLM, 판단) 합작.

부품 출처(BOM 🟡): 원자재 thesis-agent `app/engine.py`
  sha256 6455d426460eb81cb9721fdcd9199e431bdfe8b8c4030c67ae2cf728327e7f41 (2026-09-20)

흐름: intake → propose_outline → [승인 게이트] → 절별 루프(정본 수치표 재주입 → 초고 →
     1차 검증(score_section) → 수정 → 재채점) → 2차 검증(consistency_check) → 출처 검증
     → 요약 → export 게이트 → DOCX + 후처리 목록 → done.
상한: 절당 호출 15회·30분(settings). 동일 점수 3회 연속 → 조기 종료. 절 완료마다 체크포인트(재개).
검증 게이트는 **코드가 강제**(guard·source·calc). LLM 은 판단·집필만 한다.

★ 원자재 대비 바로잡은 것 — 검증 함수 이름과 역할을 **일치**시켰다.
  원자재는 화면 「1차 검증」이 코드 `verify_2nd`, 「2차 검증」이 `verify_1st` 로 **반대**였고
  그 혼란을 헌법 16조에 적어 두고 살았다(2026-09-18). 승계하지 않는다.
    화면 「1차 검증」(절별 채점, 90점 게이트)                 = `score_section()`      providers=["claude"]
    화면 「2차 검증」(절간 정합성·출처·1차 점수 재판정·종합)   = `consistency_check()`  providers=["codex","claude"]
  두 함수 모두 `run_all()` 이 실제로 부른다 — 「정의됨 ≠ 호출됨」을 시험이 자동 대조한다.
"""
from __future__ import annotations
import re, time, json  # noqa: F401 (time: 표 파일 basis_date 산출에 사용)
from pathlib import Path

try:
    from . import store, llm, guard, source, calc, outline, docx_build, tables  # type: ignore
except ImportError:
    import store, llm, guard, source, calc, outline, docx_build, tables  # type: ignore

APP = Path(__file__).resolve().parent
OUT = APP / "output"
VAULT = APP / "vault"
RUBRIC_AXES = ("논리", "근거", "문체", "수치·출처", "완결")

# ui.py `/api/profile` 이 저장을 허용하는 키 · 좌측 「기준」 자동 펼침 조건
PROFILE_FIELDS = ("active", "org_name", "dept", "writer_name", "writer_rank", "contact")
PROFILE_REQUIRED = ("org_name", "writer_name")


class Blocked(Exception):
    """fail-closed 상태 — 다음 단계 진행 금지."""


# ---------------------------------------------------------------- 접수(intake)
def intake(topic: str, org_type: str = "enterprise", recipient: str = "", data_desc: str = "",
           files: list[str] | None = None, names: list[str] | None = None,
           sources: list[dict] | None = None, profile: dict | None = None, force: bool = False) -> dict:
    """필수 항목 검사(fail-closed) 후 state 초기화.

    ⚠️ 도메인 가드 3 — 진행 중인 보고서가 있으면 **확인 없이 덮어쓰지 않는다.**
       원자재에서 완성 상태 3장·인용 20건이 초기화로 날아간 사고(2026-09-17) 이후 추가된 장치를 그대로 승계.
    """
    missing = [k for k, v in (("주제", topic),) if not (v or "").strip()]
    if missing:
        raise Blocked("입력 필수 항목 부족: %s" % ", ".join(missing))
    if org_type not in ("enterprise", "public"):
        raise Blocked("조직 유형은 enterprise(기업) 또는 public(공공기관) 이어야 합니다: %r" % org_type)

    prev = store.load_state()
    if prev.get("sections") and not force:
        raise Blocked("이미 진행 중인 보고서(「%s」, %d개 절)가 있습니다. 새로 시작하면 현재 상태가 백업된 뒤 "
                      "초기화됩니다 — 확인 후 force=True 로 다시 호출하세요."
                      % ((prev.get("intake") or {}).get("topic", "")[:30], len(prev["sections"])))
    if prev.get("sections"):
        bp = store.backup_state("before_intake")
        store.log("시스템", "새 보고서 시작 전 이전 상태 백업 — %s" % bp.name)
    _reset_vault()  # 결함 F — 이전 보고서의 vault 잔재가 새 보고서의 후보·프롬프트에 섞이지 않게 백업 후 비운다

    cfg = store.load_config("org_profile.json", {}) or {}
    preset = dict(((cfg.get("presets") or {}).get(org_type)) or {})
    preset["active"] = org_type
    for k in ("org_name", "dept", "writer_name", "writer_rank", "contact"):
        if cfg.get(k):
            preset.setdefault(k, cfg[k])
    preset.update(profile or {})

    def _set(st):
        keep = dict(st.get("settings") or {})          # 사용자 설정(분량 모드·상한·고지)은 유지
        st.clear(); st.update(store.default_state())
        st["settings"].update(keep)
        st["intake"] = {"topic": topic, "org_type": org_type, "recipient": recipient,
                        "data_desc": data_desc, "files": files or [], "has_names": bool(names)}
        st["org_profile"] = preset
        st["phase"] = "outline"
        # 재시작 후에도 가명화가 유지되도록 저장(로컬 state.json, PC 밖으로 안 나감) — 원자재 V1 D3
        st["pseudonym_names"] = list(names or [])
        st["sources"] = []
        for rec in (sources or []):
            source.add_candidate(st["sources"], rec)
    st = store.update_state(_set)
    _NAMES.clear(); _NAMES.extend(names or [])
    store.log("시스템", "접수 완료 — %s·「%s」" % ("공공기관" if org_type == "public" else "기업", topic[:40]))
    return st


def _reset_vault() -> None:
    """결함 F — 새 보고서 시작(intake) 시 vault/ 를 백업 후 비운다.

    이전에는 vault/*.txt 가 지워지지 않아 `ensure_sources`·`_draft_prompt`·`_section_materials_block`
    가 **직전 보고서의 자료**를 계속 후보·프롬프트에 섞어 넣었다. 헌법 18조(확인·백업 없이 지우지 않는다)
    와 같은 원칙으로 — 조용히 지우지 않고 `state_backups/vault_{일시}/` 로 옮겨 둔다.
    """
    if not VAULT.exists():
        return
    files = list(VAULT.glob("*.txt"))
    if not files:
        return
    bdir = store.BACKUP_DIR / ("vault_%s" % time.strftime("%Y%m%d_%H%M%S"))
    bdir.mkdir(parents=True, exist_ok=True)
    moved = 0
    for f in files:
        try:
            f.replace(bdir / f.name); moved += 1
        except OSError:
            pass
    if moved:
        store.log("시스템", "이전 보고서 투입자료(vault) %d건 백업 후 비움 — %s" % (moved, bdir.name))


_NAMES: list[str] = []          # 프로세스 캐시 — 원본은 state["pseudonym_names"]


def _names_from_fields() -> list[str]:
    """★ 새 입력 경로를 추가하면 **반드시 여기 등록한다** — 빠뜨리면 실명이 샌다.

    현재 등록된 경로: intake(names) · state.pseudonym_names(재시작 복원).
    서버·프로세스가 재시작돼도 state.json 에서 복원한다(원자재 V1 D3).
    """
    if not _NAMES:
        saved = store.load_state().get("pseudonym_names") or []
        _NAMES.extend(saved)
    return list(_NAMES)


def add_names(more: list[str]) -> list[str]:
    """가명화 대상 추가(거래처명·부서명 등 고유명사 포함). state 에도 반영한다."""
    add = [str(x).strip() for x in (more or []) if str(x).strip()]
    if not add:
        return _names_from_fields()

    def _set(s):
        cur = list(s.get("pseudonym_names") or [])
        for x in add:
            if x not in cur:
                cur.append(x)
        s["pseudonym_names"] = cur
    store.update_state(_set)
    _NAMES.clear()
    return _names_from_fields()


# ---------------------------------------------------------------- 자료 요약 (RAG 볼트)
MAX_PDF_PAGES = 150
MAX_CHARS_PER_FILE = 40000
MAX_CHARS_TOTAL = 120000


_READABLE_EXTS = (".pdf", ".docx", ".txt", ".md", ".csv", ".xlsx", ".xls")


def _extract_text(p: Path) -> tuple[str, bool]:
    """파일 → (텍스트, 읽었는지). 표 파일은 구조 요약만(D-006 — 값은 LLM 에 안 준다).

    「여력 되면」 제보 확인(사실) — hwp·pptx 등 미지원 형식이 예전에는 "[표 형식 파일 …]" 이름표로
    들어가 표 파일인 것처럼 보였다. **읽지 못한 형식**이라고 정직하게 구분한다.
    """
    ext = p.suffix.lower()
    try:
        if ext == ".pdf":
            from pypdf import PdfReader
            pages = PdfReader(str(p)).pages
            n_all = len(pages)
            txt = "\n".join((pg.extract_text() or "") for pg in pages[:MAX_PDF_PAGES])
            if n_all > MAX_PDF_PAGES:
                txt += "\n[이 아래 %d쪽은 읽지 않았습니다 — 전체 %d쪽 중 앞 %d쪽만 반영]" % (
                    n_all - MAX_PDF_PAGES, n_all, MAX_PDF_PAGES)
            return txt, True
        if ext == ".docx":
            from docx import Document
            return "\n".join(par.text for par in Document(str(p)).paragraphs), True
        if ext in (".txt", ".md"):
            return p.read_text(encoding="utf-8", errors="replace"), True
        if ext in (".csv", ".xlsx", ".xls"):
            # ★D-006 — 값(합계·평균)은 여기 넣지 않는다(LLM 이 암산하게 만들지 않는다).
            # 목차 LLM 이 figures_needed 를 구체적으로 계획할 수 있게 **구조**만 덧붙인다.
            # 실제 값은 승인 시 tables.profile_table() 이 산출해 canon.figures 에 등재한다.
            schema = tables.schema_summary(str(p))
            return "[표 형식 파일 — 수치는 승인 시 코드가 산출해 정본 수치표에 등재됩니다] %s\n%s" % (p.name, schema), True
        # D-007 근원 대응 — 내부 파일명(calc.py)이 그대로 프롬프트에 들어가면 LLM 이 본문에 옮겨 적는다.
        return "[읽지 못한 형식 — 반영 안 됨] %s" % p.name, False
    except Exception as e:
        return "[읽기 실패 %s] %s" % (p.name, e), False


def _digest_files(files: list, write_vault: bool = True) -> str:
    """파일 목록 → 읽어서 합친 텍스트(한도 적용). 잘린 사실을 본문에 적어 사용자가 알 수 있게 한다."""
    parts = []
    used = 0
    for f in files:
        p = Path(f)
        if not p.exists():
            parts.append("[파일 없음] %s" % p.name); continue
        txt, _readable = _extract_text(p)
        if write_vault:
            VAULT.mkdir(parents=True, exist_ok=True)
            (VAULT / (p.stem + ".txt")).write_text(txt, encoding="utf-8")

        take = txt[:MAX_CHARS_PER_FILE]
        if len(txt) > MAX_CHARS_PER_FILE:
            take += "\n[이 파일은 %s자 중 앞 %s자만 반영했습니다]" % (format(len(txt), ","), format(MAX_CHARS_PER_FILE, ","))
        room = MAX_CHARS_TOTAL - used
        if room <= 0:
            parts.append("## %s\n[자료 합계 %s자 상한에 도달해 이 파일은 반영하지 못했습니다]" % (p.name, format(MAX_CHARS_TOTAL, ",")))
            continue
        if len(take) > room:
            take = take[:room] + "\n[자료 합계 %s자 상한에 걸려 여기서 끊었습니다]" % format(MAX_CHARS_TOTAL, ",")
        used += len(take)
        parts.append("## %s\n%s" % (p.name, take))
    return "\n\n".join(parts)


def digest_materials(st: dict) -> str:
    return _digest_files(st.get("intake", {}).get("files", [])) or "(투입 자료 없음 — 주제만으로 진행)"


MAX_CHARS_PER_SECTION_MATERIAL = 20000   # 절 전용 보충자료는 절 하나짜리 프롬프트라 전체 상한보다 좁게 둔다


def section_materials_status(files: list) -> list[dict]:
    """결함 E — /api/upload 가 화면에 「반영 안 됨」을 정직하게 보여주기 위한 상태 목록.
    반환: [{"file": 파일명, "readable": bool}]"""
    out = []
    for f in files:
        p = Path(f)
        if not p.exists():
            out.append({"file": p.name, "readable": False}); continue
        _txt, readable = _extract_text(p)
        out.append({"file": p.name, "readable": readable})
    return out


def _section_materials_block(st: dict, n: str) -> str:
    """결함 E — 절별 보충자료(`/api/upload?section=N` → state.sections[n].materials)를
    그 절의 초고·수정 프롬프트에 반영한다. 표 파일은 구조 요약만(D-006 원칙과 동일 — 값은 LLM 에 안 준다).
    읽지 못하는 형식은 프롬프트에도 「반영 안 됨」이라고 정직하게 적는다(화면에는 section_materials_status 가 알린다)."""
    mats = ((st.get("sections") or {}).get(n) or {}).get("materials") or []
    if not mats:
        return ""
    parts = []
    used = 0
    for f in mats:
        p = Path(f)
        if not p.exists():
            parts.append("[파일 없음] %s" % p.name); continue
        txt, readable = _extract_text(p)
        if not readable:
            parts.append(txt); continue
        take = txt[:MAX_CHARS_PER_SECTION_MATERIAL - used]
        if not take:
            parts.append("## %s\n[이 절 보충자료 합계 상한에 도달해 반영하지 못했습니다]" % p.name); continue
        if len(take) < len(txt):
            take += "\n[앞 %s자만 반영했습니다]" % format(len(take), ",")
        used += len(take)
        parts.append("## %s\n%s" % (p.name, take))
    if not parts:
        return ""
    return "# 이 절 전용 보충자료(사용자가 %s절에 따로 올림)\n" % n + "\n\n".join(parts)


# ---------------------------------------------------------------- 출처 후보
_URL_RE = re.compile(r"https?://[^\s<>\"')\]]+")


def ensure_sources(st: dict) -> dict:
    """후보 등록 — **LLM 이 만들지 않는다.** 사용자가 올린 자료(vault)와 자료 안에 실재하는 URL 만 후보가 된다.

    ① 투입 파일 → `[내부자료]` 후보(사용자 증빙으로 승격 필요)
    ② 자료 본문에 실제로 적힌 URL 중 허용 도메인인 것 → `live` 후보
    """
    files = st.get("intake", {}).get("files", []) or []
    found = []
    for f in files:
        p = Path(f)
        found.append({"kind": "internal", "doc": p.name, "title": p.stem, "org": "내부"})
    VAULT.mkdir(parents=True, exist_ok=True)
    for vp in sorted(VAULT.glob("*.txt"))[:20]:
        try:
            text = vp.read_text(encoding="utf-8", errors="replace")[:MAX_CHARS_PER_FILE]
        except OSError:
            continue
        for u in dict.fromkeys(_URL_RE.findall(text)):
            u = u.rstrip(".,);]")
            if source.is_allowed(u):
                found.append({"kind": "live", "url": u, "title": vp.stem, "org": ""})
    if not found:
        return st

    def _set(s):
        before = len(s.get("sources") or [])
        s.setdefault("sources", [])
        for rec in found:
            source.add_candidate(s["sources"], rec)
        s["_sources_added"] = len(s["sources"]) - before
    st = store.update_state(_set)
    if st.get("_sources_added"):
        store.log("시스템", "출처 후보 %d건 등록(투입 자료·자료 내 URL)" % st["_sources_added"])
    return st


# ---------------------------------------------------------------- 목차
def propose_outline() -> dict:
    st = store.load_state()
    if st["phase"] not in ("outline", "awaiting_approval"):
        raise Blocked("현재 단계(%s)에서는 목차 생성 불가" % st["phase"])
    st = ensure_sources(st)
    r = outline.propose(st, digest_materials(st), _names_from_fields())
    if not r["ok"]:
        store.log("시스템", "목차 생성 실패: " + llm.human_reason(r["error"]), error=r["error"])
        return r

    def _set(s):
        s["outline"] = {"sections": r["outline"], "approved": False, "approved_at": None}
        s["_pending_frame"] = r["frame"]
        s["phase"] = "awaiting_approval"
    store.update_state(_set)
    store.log("AI", "목차 초안 %d절 제안 (%s)" % (len(r["outline"]), _provider_ko(r["provider"])))
    return r


def _ingest_tables_on_approve(s: dict) -> None:
    """★D-006 — 목차 승인 트랜잭션 안에서 표 파일(csv/xlsx)을 집계해 canon.figures 에 등재한다.

    이전에는 `calc.register`/`register_result` 를 부르는 코드가 제품 어디에도 없어서(정의만 있음)
    표 파일의 수치가 보고서에 절대 들어가지 못했다. 이 함수가 그 «정의됨 ≠ 호출됨» 구멍을 메운다.

    표가 없어도 승인 자체는 성공한다(표 없는 보고서도 있다). 읽기 실패·상한 초과는 승인을 막지 않되
    **경고 로그로 사실이 사라지지 않게** 남긴다.
    """
    files = (s.get("intake") or {}).get("files") or []
    table_files = [f for f in files if Path(f).suffix.lower() in (".csv", ".xlsx", ".xls")]
    if not table_files:
        return
    canon = s.setdefault("canon", {})
    canon.setdefault("figures", {})
    total_before = len(canon["figures"])
    total_registered = 0
    for f in table_files:
        p = Path(f)
        rec = next((r for r in (s.get("sources") or []) if r.get("doc") == p.name), None)
        source_id = (rec or {}).get("id") or p.name
        grade = (rec or {}).get("status") or "internal"
        try:
            basis_date = time.strftime("%Y-%m-%d", time.localtime(p.stat().st_mtime)) if p.exists() else ""
        except OSError:
            basis_date = ""
        try:
            figures, notes = tables.profile_table(str(p), source_id, basis_date)
        except tables.TableReadError as e:
            store.log("시스템", "표 파일 집계 실패 — %s: %s" % (p.name, e))
            continue
        n = 0
        for fig in figures:
            if total_before + total_registered + n >= tables.MAX_FIGURES_TOTAL:
                store.log("시스템", "표 파일 정본 수치 전체 상한(%d건)에 도달 — %s 의 나머지는 등재하지 못함"
                          % (tables.MAX_FIGURES_TOTAL, p.name))
                break
            calc.register(canon, fig["key"], fig["value"], source_id, formula=fig.get("formula", ""),
                          unit=fig.get("unit", ""), basis_date=basis_date, grade=grade)
            n += 1
        total_registered += n
        for note in notes:
            store.log("시스템", "표 파일 집계 — %s" % note)
        store.log("시스템", "%s 에서 정본 수치 %d건 등재" % (p.name, n))
    if total_registered:
        store.log("시스템", "표 파일 %d개에서 정본 수치 %d건 등재(승인 시)" % (len(table_files), total_registered))


def approve_outline(edited: list[dict] | None = None, frame: dict | None = None) -> dict:
    """목차 승인 — **가중치 합 100·대안 3개 이상을 통과해야 승인된다**(fail-closed)."""
    st = store.load_state()
    if st["phase"] != "awaiting_approval":
        raise Blocked("승인 대기 상태가 아님")
    ol = edited or st["outline"]["sections"]
    fr = frame or st.get("_pending_frame") or {}
    # 검증은 `outline.approve` 가 **스스로** 한다(관문) — 여기서만 막으면 직접 호출로 우회된다.
    # (V2 재확인 지적 2026-09-21)
    def _set(s):
        outline.approve(s, ol, fr)
        _ingest_tables_on_approve(s)
        s.pop("_pending_frame", None)
    try:
        return store.update_state(_set)
    except outline.ApproveBlocked as e:
        raise Blocked(str(e))


# ---------------------------------------------------------------- 절별 루프
def _brief(st) -> bool:
    """약식 모드 — 시제·실습용. 분량 1/4, 상한 12회·20분. 품질 게이트(정본·출처·수치)는 그대로."""
    return (st.get("settings") or {}).get("length_mode") == "brief"


def _limits(st):
    se = st.get("settings", {})
    calls = int(se.get("max_calls_per_section", 15))
    mins = float(se.get("max_minutes_per_section", 30))
    ps = int(se.get("pass_score", 90))
    if _brief(st):
        calls, mins = min(calls, 12), min(mins, 20.0)
    return calls, mins, ps


def _section_spec(st: dict, n: str) -> dict:
    for s in st["outline"]["sections"]:
        if str(s["n"]) == n:
            return s
    raise Blocked("목차에 없는 절: %s" % n)


def _md_path(n: str) -> Path:
    d = OUT / "md"; d.mkdir(parents=True, exist_ok=True)
    return d / ("sec%s.md" % n)


def _bump(n: str, **fields):
    def _set(s):
        c = s["sections"].setdefault(n, {"status": "pending", "calls": 0, "critique": [], "versions": [], "minutes": 0.0})
        c["calls"] = c.get("calls", 0) + fields.pop("_call", 0)
        c.update(fields)
    return store.update_state(_set)


# ---------------------------------------------------------------- D-010 재수정 보존 (PC3 E2E 결함)
# 실제 사고: 집필·1차 검증 판본엔 `[[비교표]]` 가 있었는데, 2차 검증 재수정이 만든 최종 원고에서
# 자리표시가 0개가 됐다 — LLM 이 표를 직접 그리고 "가중치 미확정으로 산출 불가" 라고 적었다(거짓 —
# 가중치는 이미 사용자가 확정). 4절 원고를 고치는 **모든 경로**(_fix 채점 수정 루프·2차 검증 재수정·
# revise_section 부분 수정)에서, 고치기 전에 있던 `[[비교표]]` 가 결과에서 사라지면 되살린다.
def _restore_lost_comparison_placeholder(n: str, before_md: str, after_md: str) -> str:
    if str(n) != "4" or "[[비교표]]" not in (before_md or "") or "[[비교표]]" in (after_md or ""):
        return after_md
    before_lines = (before_md or "").splitlines()
    idx = next((i for i, ln in enumerate(before_lines) if "[[비교표]]" in ln), None)
    anchor = None
    if idx is not None:
        for j in range(idx - 1, -1, -1):
            cand = before_lines[j].strip()
            if cand:
                anchor = cand
                break
    after_lines = (after_md or "").splitlines()
    if anchor:
        for k, ln in enumerate(after_lines):
            if ln.strip() == anchor:
                after_lines.insert(k + 1, "[[비교표]]")
                store.log("시스템", "%s절 재수정 결과에서 [[비교표]] 자리표시 유실 — 원래 위치 근처에 되살림" % n)
                return "\n".join(after_lines)
    sep = "" if not after_md or after_md.endswith("\n") else "\n"
    store.log("시스템", "%s절 재수정 결과에서 [[비교표]] 자리표시 유실 — 위치를 못 찾아 절 끝에 되살림" % n)
    return (after_md or "") + sep + "\n[[비교표]]\n"


_N4_FIX_NOTE = ("# 4절 특별 주의 — `[[비교표]]` 줄은 반드시 그대로 둔다(지우거나 네가 표로 바꿔 쓰지 마라. "
                "가중합은 코드가 계산해 표로 삽입한다). 가중치·원점수의 확정 여부를 문장으로 쓰지 마라 — "
                "표가 보여준다. 확정 여부를 서술하지 말 것 — 사실과 다르면 결재 문서 신뢰가 깨진다.")


def write_section(n: str) -> dict:
    """한 절 완주: 초고 → 채점/수정 루프. 상한·조기종료·체크포인트. 반환 sections[n]."""
    st = store.load_state()
    if not st["outline"].get("approved"):
        raise Blocked("목차 미승인 — 절 생성 차단(도메인 가드 1)")
    if st.get("blocked"):
        raise Blocked("차단 상태: %s" % st["blocked"]["code"])
    spec = _section_spec(st, n)
    max_calls, max_min, pass_score = _limits(st)
    sec = st["sections"].get(n, {})
    if sec.get("status") == "done":
        return sec
    t0 = time.monotonic()
    _bump(n, status="drafting", started=store.now_iso())
    store.log("시스템", "%s절 착수 — %s" % (n, spec.get("title", "")))

    # 중단된 절(status=drafting + 원고 파일 있음)은 초고를 다시 만들지 않고 채점·수정 루프로 바로 들어간다.
    resume = bool(sec.get("status") == "drafting" and sec.get("versions") and _md_path(n).exists())
    if resume:
        md = _md_path(n).read_text(encoding="utf-8")
        md = re.sub(r"\n*<!-- guard: .*?-->\n*$", "", md, flags=re.S).replace(" [확인 필요]", "")
        store.log("시스템", "%s절 이어쓰기 — 기존 원고(%d자)로 재개(호출 %d회 소진)" % (n, len(md), sec.get("calls", 0)))
    else:
        r = llm.guarded_call(_draft_prompt(st, spec, n), purpose="draft sec%s" % n, timeout=600)
        _bump(n, _call=1)
        if not r["ok"]:
            _bump(n, status="stalled", note=llm.human_reason(r["error"]))
            store.log("시스템", "%s절 초고 실패: %s" % (n, llm.human_reason(r["error"])), error=r["error"])
            return store.load_state()["sections"][n]
        md = _postprocess(r["text"].strip(), st, n)
        _save_version(n, md, "draft")

    # 채점·수정 루프
    last_scores = []
    while True:
        st = store.load_state(); sec = st["sections"][n]
        elapsed_min = (time.monotonic() - t0) / 60
        if sec["calls"] >= max_calls or elapsed_min >= max_min:
            _bump(n, status="stalled", minutes=round(elapsed_min, 1),
                  note="상한 도달(호출 %d/%d · %.0f/%.0f분) — 미달 항목 보고" % (sec["calls"], max_calls, elapsed_min, max_min))
            store.log("시스템", "%s절 상한 도달 — 미달 보고" % n)
            break
        sc = score_section(st, spec, n, md)
        _bump(n, _call=1)
        if not sc["ok"]:
            _bump(n, status="stalled", note=llm.human_reason(sc["error"]))
            break
        total = sc["data"].get("total") or _total(sc["data"].get("scores", {}))
        last_scores.append(total)
        _append_critique(n, {"at": store.now_iso(), "total": total, "scores": sc["data"].get("scores"),
                             "fails": sc["data"].get("fails", []), "provider": sc["provider"]})
        if total >= pass_score and not sc["data"].get("canon_conflicts") and not sc["data"].get("unverified_sources"):
            md, final_total, open_issues = _pass_with_style_correction(st, spec, n, md, sc, total, pass_score)
            _bump(n, status="done", score=final_total, minutes=round((time.monotonic() - t0) / 60, 1),
                  open_issues=open_issues)
            store.log("AI", "%s절 완료 — %d점%s" % (n, final_total,
                      (" · 남은 지적 %d건" % len(open_issues)) if open_issues else ""))
            break
        if len(last_scores) >= 3 and last_scores[-1] == last_scores[-2] == last_scores[-3]:
            _bump(n, status="stalled", score=total, note="동일 점수 3회 연속 — 조기 종료")
            store.log("시스템", "%s절 동일 점수 3회 — 조기 종료" % n)
            break
        fx = _fix(st, spec, n, md, sc["data"])
        _bump(n, _call=1)
        if not fx["ok"]:
            _bump(n, status="stalled", note=llm.human_reason(fx["error"]))
            break
        md = _restore_lost_comparison_placeholder(n, md, _postprocess(fx["text"], st, n))
        _save_version(n, md, "rev%d" % len(last_scores))
    return store.load_state()["sections"][n]


# ---------------------------------------------------------------- 프롬프트
def _source_block(st: dict) -> str:
    """본문에서 인용할 수 있는 출처 목록. **이 목록 밖 근거를 쓰면 _tag_sources 가 [미검증]을 붙인다.**"""
    srcs = st.get("sources") or []
    if not srcs:
        return "(확정 출처 없음 — 근거가 필요한 문장은 「자료 확보 필요」로 적을 것. 출처를 지어내지 말 것)"
    return "\n".join("- [%s] %s %s %s" % (s.get("id"), s.get("org") or "", (s.get("title") or s.get("url") or "")[:70],
                                          source.tag_for(s)) for s in srcs)


def _draft_prompt(st: dict, spec: dict, n: str) -> str:
    vault = "\n\n".join(p.read_text(encoding="utf-8", errors="replace")[:4000]
                        for p in sorted(VAULT.glob("*.txt"))[:6])
    masked_vault, _ = guard.pseudonymize(vault, _names_from_fields())
    prev = ""
    for k in sorted(st["sections"].keys(), key=int):
        if int(k) < int(n) and st["sections"][k].get("status") == "done" and _md_path(k).exists():
            prev += "\n\n=== %s절 발췌 ===\n" % k + _md_path(k).read_text(encoding="utf-8")[:2000]

    lab = outline.section_label(st, n)
    is_summary_like = False        # 요약(0a)은 별도 함수(summary)에서 만든다 — 여기 절은 전부 개조식
    style = ("**약식 모드** — 항목 3~5개, 절 전체 600~1,200자." if _brief(st)
             else "항목 5~10개, 절 전체 1,200~2,500자.")
    extra = ""
    if n == "4":
        extra = ("이 절은 **대안 비교**다. 정본 수치표의 평가기준·가중치·대안만 쓴다. "
                 "**점수를 네가 매기지 마라** — 가중합은 코드가 계산해 표로 삽입한다. "
                 "너는 각 대안의 장단점을 근거와 함께 서술하고, 비교표 자리에 `[[비교표]]` 한 줄만 남겨라. "
                 "가중치·원점수의 확정 여부를 문장으로 쓰지 마라 — 표가 보여준다.")
    elif n == "6":
        extra = "이 절은 **추진 계획**이다. 시기·일정·기한·협조부서·단기/중장기를 반드시 포함한다(코드가 검사한다)."
    elif n == "5":
        extra = "이 절은 **개선방안**이다. 기본방향·추진전략 / 세부사업내용 / **추진체계(추진절차와 방법)** 를 반드시 포함한다."
    if outline.is_public(st):
        extra += " 공공기관 보고서다 — 근거를 제시할 때 **법령·지침 조문을 함께 인용**한다(「○○법」 제○조)."

    return "\n\n".join(x for x in [
        outline.persona_text(st),
        "# 출처 규칙\n" + outline.skill("source"),
        outline.canon_block(st),
        "# 인용 가능한 출처 (이 목록 밖 근거 금지 — 근거가 없으면 「자료 확보 필요」)\n" + _source_block(st),
        "# 투입 자료(가명화됨)\n" + (masked_vault or "(없음)"),
        _section_materials_block(st, n),
        "# 앞 절 발췌(맥락 유지용)\n" + (prev or "(첫 절)"),
        "# 과제 — %s %s 작성" % (lab["number"], spec.get("title", "")),
        ("소제목: " + lab["subhead"]) if lab.get("subhead") else "",
        "항목 구성(그대로):\n" + "\n".join("- " + str(i) for i in (spec.get("items") or [])),
        extra,
        "규칙:\n"
        "- **개조식**으로 쓴다. 3단 들여쓰기: `□`(대항목) → `  ○`(중항목) → `    -`(세부·근거·출처).\n"
        "- 어미는 `~함`·`~임`·`~필요`·`~예상됨`. **서술식(`~합니다`) 금지.**\n"
        "- 근거는 세부 항목(`-`)에 달고 **출처 번호를 `[S-01]` 형태로 표기**한다. 목록에 없는 번호를 쓰지 마라.\n"
        "- 수치는 **정본 수치표의 확정 수치만** 쓴다. 없으면 `[확인 필요]`. **직접 계산하지 마라.**\n"
        "- 「대체로·대부분·많은·어느 정도·대승적」 같은 애매한 표현을 쓰지 마라(코드가 검출한다).\n"
        "- 「TF 구성을 통해 의견 수렴」처럼 절차를 방안으로 위장하지 마라 — 무엇을 어떻게 하겠다는 것인지 적는다.\n"
        "- 표가 필요하면 Markdown 표 + 위에 `표 N. 제목`. 표가 절 전체를 차지하게 하지 마라.\n"
        "- " + style + "\n"
        "- 첫 줄은 `## %s %s`. 마지막에 아무 설명도 덧붙이지 마라." % (lab["number"], spec.get("title", "")),
    ] if x)


def _score_prompt(st: dict, spec: dict, n: str, md: str) -> str:
    lab = outline.section_label(st, n)
    return "\n\n".join([
        "너는 기획·검토 보고서 절 원고의 채점자다. 아래 루브릭으로만 채점한다. 작성자가 아니다.",
        "# 루브릭\n" + outline.skill("rubric"),
        outline.canon_block(st),
        "# 인용 가능한 출처 목록\n" + _source_block(st),
        "# 채점 대상 — %s %s\n" % (lab["number"], spec.get("title", "")) + md,
        '# 출력 — JSON 하나만\n'
        '{"scores":{"논리":1~5,"근거":1~5,"문체":1~5,"수치·출처":1~5,"완결":1~5},"total":0~100,'
        '"fails":[{"axis":"...","where":"...","fix":"..."}],"canon_conflicts":["..."],'
        '"unverified_sources":["출처 목록 밖 근거"]}',
        "주의: 코드가 판정하는 항목(#8 애매표현 · #10 제목대조 · #11 표비중 · #13 추진계획 필수항목 · "
        "#14 논점 커버리지)은 fails 에 넣지 마라 — 중복 지적은 재생성 루프를 헛돌게 한다.",
        "주의: `[확인 필요]` 자리표시는 정본 수치표에 값이 아직 없을 때의 **정상 표기**다 — 감점하지 마라. "
        "반대로 `[확인 필요]` 없이 수치를 지어낸 경우는 「수치·출처」 1점.",
    ])


# ---------------------------------------------------------------- LLM 3자리 런타임 배선
# 화면 좌측 LLM 칩(작업 / 1차 검증 / 2차 검증)은 「설치·로그인 확인」일 뿐이다.
# 그 역할이 실제 파이프라인에서 불리는지는 아래 두 함수로 대조한다(「정의됨 ≠ 호출됨」).
# ★ 원자재와 달리 **이름과 역할이 일치한다.**

def score_section(st: dict, spec: dict, n: str, md: str) -> dict:
    """화면 「1차 검증」 — 절별 채점(90점 게이트).

    providers=["claude"] 단독. 초고를 쓴 대화 맥락이 없는 **별도 호출**이라 자기검증이 아니다.
    검증 전용 모델 자리(`claude_model_verify`)가 설정돼 있으면 상위 모델을 쓴다.
    `write_section()` 의 채점·수정 루프가 이 함수를 부른다.
    """
    verify_model = llm._cfg().get("claude_model_verify")
    return llm.guarded_call_json(_score_prompt(st, spec, n, md), purpose="score sec%s" % n,
                         timeout=400, providers=["claude"], model=verify_model)


def consistency_check(st: dict, sections_md: dict) -> dict:
    """화면 「2차 검증」 — 절간 정합성 + 출처 + 1차 점수 재판정 + 종합 정리.

    providers=["codex","claude"] — **Codex 우선으로 다른 회사 AI 에 맡겨 독립성을 확보**한다.
    코드 검사(#10·#13·#14) 결과가 함께 들어간다. `run_all()` 이 전 절 완료 뒤 이 함수를 부른다.
    """
    return outline.consistency_pass(st, sections_md, providers=["codex", "claude"])


# ---------------------------------------------------------------- D-007 — 통과해도 남은 문체·표기 지적
# 실제 사고: 2절이 초고 92점으로 통과했는데, 채점표엔 「내부 작업 용어 'calc.py 산출 후 정본 수치표
# 반영 (전/필요)' 삭제 — 결재 보고서 표현으로 교체」지적이 남았고, 최종 본문에 `[확인 필요] — calc.py
# 산출 후 정본 수치표 반영 전`이 그대로 나갔다. 점수가 통과선을 넘었다고 남은 지적을 버리지 않는다.
_STYLE_AXES = {"문체", "표기"}
_STYLE_WORDS = ("용어", "표현", "표기", "문체")
_JARGON_RE = re.compile(r"calc\.py|\bcanon\b|\bcrosscheck\b", re.I)


def _is_style_fail(f: dict) -> bool:
    axis = str(f.get("axis") or "")
    if axis in _STYLE_AXES:
        return True
    blob = axis + " " + str(f.get("where") or "") + " " + str(f.get("fix") or "")
    return any(w in blob for w in _STYLE_WORDS)


def _normalize_open_issue(f: dict) -> dict:
    return {"axis": f.get("axis", ""), "text": f.get("where") or f.get("text") or "", "fix": f.get("fix", "")}


def _internal_jargon_issues(md: str) -> list[dict]:
    """최종 원고에 calc.py·canon·crosscheck 같은 내부 용어가 남으면 적발해 open_issues 에 넣는다."""
    hits = sorted(set(m.group(0) for m in _JARGON_RE.finditer(md or "")))
    return [{"axis": "표기", "text": "본문에 내부 용어 「%s」가 남아 있습니다" % h,
             "fix": "내부 파일명·함수명이 아니라 결재 보고서 표현으로 바꿀 것"} for h in hits]


def _pass_with_style_correction(st: dict, spec: dict, n: str, md: str, sc: dict, total: int, pass_score: int):
    """통과(sc)했더라도 문체·표기 지적이 남아 있으면 **1회만** 교정하고 재채점한다.
    교정 후 점수가 통과선 밑으로 떨어지면 교정 전 판본을 그대로 유지한다(교정이 품질을 깎으면 안 된다).
    반환: (최종 md, 최종 총점, open_issues) — open_issues 는 state.sections[n].open_issues 로 저장된다."""
    fails = list(sc["data"].get("fails", []))
    style_fails = [f for f in fails if _is_style_fail(f)]
    final_md, final_fails, final_total = md, fails, total
    if style_fails:
        fx = _fix(st, spec, n, md, {"fails": style_fails})
        _bump(n, _call=1)
        if fx["ok"]:
            md2 = _restore_lost_comparison_placeholder(n, md, _postprocess(fx["text"], st, n))
            sc2 = score_section(st, spec, n, md2)
            _bump(n, _call=1)
            if sc2["ok"]:
                total2 = sc2["data"].get("total") or _total(sc2["data"].get("scores", {}))
                if (total2 >= pass_score and not sc2["data"].get("canon_conflicts")
                        and not sc2["data"].get("unverified_sources")):
                    _save_version(n, md2, "style_fix")
                    _append_critique(n, {"at": store.now_iso(), "total": total2, "scores": sc2["data"].get("scores"),
                                         "fails": sc2["data"].get("fails", []), "provider": sc2["provider"]})
                    final_md, final_fails, final_total = md2, list(sc2["data"].get("fails", [])), total2
                    store.log("AI", "%s절 문체·표기 교정 1회 반영 — %d→%d점" % (n, total, total2))
                else:
                    store.log("시스템", "%s절 문체 교정이 통과선 아래로 떨어져 되돌림(%d→%d)" % (n, total, total2))
            # sc2 실패(호출 오류)면 조용히 교정 전 판본을 유지한다.
        else:
            store.log("시스템", "%s절 문체 교정 호출 실패 — 교정 전 판본 유지: %s" % (n, llm.human_reason(fx["error"])))
    open_issues = [_normalize_open_issue(f) for f in final_fails] + _internal_jargon_issues(final_md)
    return final_md, final_total, open_issues


def _fix(st: dict, spec: dict, n: str, md: str, critique: dict) -> dict:
    fails = list(critique.get("fails", []))
    fails += [{"axis": "정본", "where": c, "fix": "정본 수치표 정의로 통일"} for c in critique.get("canon_conflicts", [])]
    fails += [{"axis": "출처", "where": c, "fix": "출처 목록 밖 근거 — 제거하거나 목록 안 출처로 교체"}
              for c in critique.get("unverified_sources", [])]
    # 코드가 잡은 것도 수정 지시에 함께 넣는다(채점자는 지적하지 않지만 고치기는 해야 한다).
    for v in guard.check_vague(md)[:8]:
        fails.append({"axis": "문체", "where": v["where"],
                      "fix": "애매한 표현 「%s」 — 숫자나 구체 범위로 바꿀 것(공식 체크리스트 #8)" % v["term"]})
    prompt = "\n\n".join(x for x in [
        outline.persona_text(st),
        outline.canon_block(st),
        "# 인용 가능한 출처 목록\n" + _source_block(st),
        _section_materials_block(st, n),
        "# 현재 원고 — %s절\n" % n + md,
        "# 수정 지시 — **아래 항목만** 고친다. 나머지 문장은 그대로 둔다(전체 재작성 금지).\n"
        + json.dumps(fails, ensure_ascii=False, indent=1),
        "# 주의 — `[미검증]`·`[확인 필요]` 태그는 시스템이 자동으로 붙인 표식이다. 태그만 지우지 마라. "
        "출처 번호가 목록에 없으면 목록 안 출처로 바꾸거나 근거 없는 서술로 고쳐라. "
        "수치는 정본 확정 수치로 바꾸거나 정성 서술로 바꿔라. 태그 자체는 출력에 넣지 마라(시스템이 다시 판정한다).",
        _N4_FIX_NOTE if n == "4" else "",
        "# 출력 — 수정된 절 전체 Markdown 만(끝까지, 절단 금지). 설명 금지.",
    ] if x)
    return llm.guarded_call(prompt, purpose="fix sec%s" % n, timeout=600)


def revise_section(n: str, request: str) -> dict:
    """부분 수정 — 「4절 비교표 설명이 부족하다」처럼 말로 지정한 부분만 고친다. 고치기 전 반드시 백업 후 재채점."""
    st = store.load_state()
    if st.get("blocked"):
        raise Blocked("차단 상태: %s" % st["blocked"]["code"])
    spec = _section_spec(st, n)
    p = _md_path(n)
    if not p.exists():
        raise Blocked("%s절 원고가 아직 없습니다 — 먼저 작성이 필요합니다" % n)
    md = re.sub(r"\n*<!-- guard: .*?-->\n*$", "", p.read_text(encoding="utf-8"), flags=re.S)
    _save_version(n, md, "before_revise")   # 고치기 전 판본 자동 백업(필수)
    prompt = "\n\n".join(x for x in [
        outline.persona_text(st),
        outline.canon_block(st),
        "# 인용 가능한 출처 목록\n" + _source_block(st),
        _section_materials_block(st, n),
        "# 현재 원고 — %s절\n" % n + md,
        "# 사용자 요청 — **요청한 부분만** 고친다. 그 외 문장·항목 구성은 그대로 둔다(전체 재작성 금지).\n" + request,
        _N4_FIX_NOTE if n == "4" else "",
        "# 출력 — 수정된 절 전체 Markdown 만(끝까지, 절단 금지). 설명 금지.",
    ] if x)
    r = llm.guarded_call(prompt, purpose="revise sec%s" % n, timeout=600)
    if not r["ok"]:
        store.log("시스템", "%s절 부분 수정 실패: %s" % (n, llm.human_reason(r["error"])), error=r["error"])
        return store.load_state()["sections"][n]
    md2 = _restore_lost_comparison_placeholder(n, md, _postprocess(r["text"], st, n))
    _save_version(n, md2, "revise")
    store.log("사용자", "%s절 부분 수정 반영: %s" % (n, request[:60]))
    sc = score_section(st, spec, n, md2)     # 반영 후 재채점
    _bump(n, _call=1)
    if sc["ok"]:
        total = sc["data"].get("total") or _total(sc["data"].get("scores", {}))
        _append_critique(n, {"at": store.now_iso(), "total": total, "scores": sc["data"].get("scores"),
                             "fails": sc["data"].get("fails", []), "provider": sc["provider"]})
        pass_score = _limits(st)[2]
        done = total >= pass_score and not sc["data"].get("canon_conflicts") and not sc["data"].get("unverified_sources")
        _bump(n, status=("done" if done else "stalled"), score=total,
              **({} if done else {"note": "부분 수정 후 재채점 미달(%d점)" % total}))
        store.log("AI", "%s절 부분 수정 후 재채점 — %d점" % (n, total))
    return store.load_state()["sections"][n]


# ---------------------------------------------------------------- 후처리 (코드 강제 구간)
_SRC_REF = re.compile(r"\[(S-\d{2,3})\]")
# D-010 정본 전문 결함 — 가중치가 이미 사용자 확정인데 4절 본문이 "미확정"·"확정되지 않음"이라고
# 적으면(사실과 다름) export 후처리 목록에서 알린다. "미확정 가중치" · "가중치가 확정되지 않아" 양방향.
_WEIGHT_MISMATCH_RE = re.compile(r"가중치[^\n]{0,15}(미확정|확정되지\s*않|미정)|(미확정|확정되지\s*않|미정)[^\n]{0,15}가중치")


def _tag_sources(md: str, st: dict) -> str:
    """본문의 `[S-01]` 참조가 확정 출처 목록에 있는지 판정하고 등급 태그를 붙인다.

    목록에 없는 번호 → `[미검증]`. 이미 붙은 태그는 떼고 다시 판정한다(수정 루프에서 중복 누적 방지).
    """
    by_id = {s.get("id"): s for s in (st.get("sources") or [])}
    md = re.sub(r"\[(?:원부검증|출처확인|내부자료|미검증|검증대기)\]", "", md)

    def _repl(m):
        sid = m.group(1)
        rec = by_id.get(sid)
        if not rec:
            return "[%s][미검증]" % sid
        tag = source.tag_for(rec)
        return "[%s]%s" % (sid, tag)
    return _SRC_REF.sub(_repl, md)


def _postprocess(text: str, st: dict, n: str = "") -> str:
    """출력 필터 + 출처 태그 + 수치 대조 + 페르소나·애매표현 검사 결과를 HTML 주석으로 남긴다(채점자·V1 이 본다)."""
    md = text.strip()
    if md.startswith("```"):
        md = re.sub(r"^```\w*\n|\n```$", "", md)
    md, removed = guard.filter_output(md)
    md = _tag_sources(md, st)
    # D-012(V2 지적 2) — 4절(대안 비교)에서만 엄격 모드: 대안 표기가 있는 표의 단위 없는 숫자는
    # 정본에 같은 값이 있어도 무조건 적발한다. 다른 절은 종전 동작(비용·일정표 등 오탐 방지).
    issues = calc.crosscheck(md, st.get("canon", {}), strict_alt_tables=(n == "4"))
    # D-010(V1 4차) — 위치 결함: 첫 일치(replace(...,1))로 꽂으면 적발된 자리가 아니라 문서에서
    # 처음 나오는 같은 글자에 붙는다(예: 적발 숫자 "4" → 앞쪽 "2024년"의 4에 붙어 "2024 [확인 필요]년"),
    # 같은 숫자가 두 번 적발되면 표시가 한쪽에 겹쳐 쌓이고 다른 쪽은 비게 된다.
    # → crosscheck 가 돌려준 실제 위치(start/end)에, **뒤에서부터** 슬라이스로 꽂는다.
    #   뒤(큰 offset)부터 처리해야 앞쪽(작은 offset) 위치가 아직 안 바뀐 md 기준으로 유효하다.
    for it in sorted(issues, key=lambda x: x["end"], reverse=True):
        md = md[:it["end"]] + " [확인 필요]" + md[it["end"]:]
    pi = guard.persona_check(md)
    vg = guard.check_vague(md)
    note = {"filtered": removed, "numbers_unverified": len(issues),
            "persona_issues": pi[:10], "vague_terms": [v["term"] for v in vg][:10]}
    return md + "\n\n<!-- guard: %s -->\n" % json.dumps(note, ensure_ascii=False)


def _total(scores: dict) -> int:
    vals = [int(scores.get(a, 0)) for a in RUBRIC_AXES]
    return int(round(sum(vals) / 25 * 100)) if vals else 0


def _save_version(n: str, md: str, tag: str):
    p = _md_path(n); p.write_text(md, encoding="utf-8")
    vdir = OUT / "md" / "versions"; vdir.mkdir(parents=True, exist_ok=True)
    vp = vdir / ("sec%s_%s_%s.md" % (n, tag, time.strftime("%H%M%S"))); vp.write_text(md, encoding="utf-8")
    _bump(n, versions=(store.load_state()["sections"].get(n, {}).get("versions", []) + [str(vp.name)]))


def _append_critique(n: str, entry: dict):
    def _set(s):
        s["sections"].setdefault(n, {}).setdefault("critique", []).append(entry)
    store.update_state(_set)


# ---------------------------------------------------------------- 4절 비교표 (코드가 계산)
def build_comparison_table(st: dict, raw_scores: dict | None = None) -> dict:
    """정본 수치표의 평가기준·가중치·대안 + 사용자 원점수 → 가중합 표. **LLM 이 점수를 매기지 않는다.**"""
    c = st.get("canon", {})
    raw = raw_scores if raw_scores is not None else (c.get("option_scores") or {})
    return calc.weighted_score(c.get("criteria") or [], c.get("options") or [], raw)


def set_criteria_weights(weights: dict) -> dict:
    """🔒 **사용자 전용 경로** — 4절 평가기준 가중치를 확정한다.

    ★ V2 2차 재확인 Critical 2026-09-21 —
      종전에는 목차 `frame` 안의 `by:"user"` 플래그를 믿었다. 그런데 frame 은 **LLM 응답**이라
      LLM 이 그 플래그를 써 보내면 위조가 통했다(자기신고). 플래그를 믿는 설계 자체를 버린다.
      → 가중치는 **이 함수로 들어온 것만** 정본이 된다. 여기서 `by="user"` 를 **코드가** 찍는다.

    weights: {"기준명": 40, ...} — 합 100. 정본 수치표에 이미 있는 기준명만 받는다.
    반환 {"criteria": [...], "errors": [...]}
    """
    st = store.load_state()
    crit = list((st.get("canon") or {}).get("criteria") or [])
    if not crit:
        return {"criteria": [], "errors": ["평가기준이 없습니다 — 목차 승인이 먼저입니다"]}

    known = {c.get("name") for c in crit}
    unknown = [k for k in (weights or {}) if k not in known]
    missing = [n for n in known if n not in (weights or {})]
    errs = []
    if unknown:
        errs.append("정본 수치표에 없는 평가기준입니다: %s" % ", ".join(map(str, unknown[:6])))
    if missing:
        errs.append("가중치가 비어 있는 기준이 있습니다: %s" % ", ".join(map(str, missing[:6])))
    if errs:
        return {"criteria": crit, "errors": errs}

    staged = []
    for c in crit:
        c2 = dict(c)
        c2["weight"] = weights[c["name"]]
        c2["by"] = "user"                    # ← 코드가 찍는다. 외부 입력의 by 값은 쓰지 않는다.
        c2["confirmed_at"] = store.now_iso()
        staged.append(c2)

    errs = list(calc.validate_criteria(staged))   # 합 100·중복·양수 검증
    if errs:
        return {"criteria": crit, "errors": errs}

    store.update_state(lambda s: s.setdefault("canon", {}).__setitem__("criteria", staged))
    store.log("사용자", "평가기준 가중치 확정 — %s" % ", ".join("%s %s" % (c["name"], c["weight"]) for c in staged))
    return {"criteria": staged, "errors": []}


def set_option_scores(scores: dict) -> dict:
    """사용자가 각 대안 × 평가기준 원점수를 입력한다(AI 가 아니라)."""
    store.update_state(lambda s: s.setdefault("canon", {}).__setitem__("option_scores", scores))
    return build_comparison_table(store.load_state())


# ---------------------------------------------------------------- 전체 실행
def run_all(progress=None) -> dict:
    """목차 승인 후 → 전 절 → 2차 검증 → 출처 검증 → 요약 → export. 각 단계 체크포인트."""
    st = store.load_state()
    if not st["outline"].get("approved"):
        raise Blocked("목차 미승인")
    for s in sorted(st["outline"]["sections"], key=lambda c: int(c["n"])):
        n = str(s["n"])
        if store.load_state()["sections"].get(n, {}).get("status") == "done":
            continue
        write_section(n)
        if progress:
            progress(n)

    st = store.update_state(lambda s: s.__setitem__("phase", "consistency"))
    mds = {n: _md_path(n).read_text(encoding="utf-8") for n in st["sections"] if _md_path(n).exists()}
    cp = consistency_check(st, mds)                      # ← 화면 「2차 검증」 실호출
    # D-009 — 2차 검증 지적이 건수 한 줄만 남고 내용이 아무 데도 안 남던 결함. 화면 B(renderConsistency)가
    # `state.consistency.issues[*].{section,text,fix}` 를 그대로 읽는다 — 이 키·모양을 반드시 지킨다.
    cp_issues = cp.get("issues") or []
    norm_issues = [{"section": str(i.get("section") or ""), "text": i.get("detail") or i.get("text") or "",
                    "fix": i.get("fix") or ""} for i in cp_issues]
    revised_sections = []
    if cp_issues:
        per_section = {}
        for i in cp_issues:
            s = str(i.get("section") or "")
            if s:
                per_section[s] = per_section.get(s, 0) + 1
        store.log("AI", "2차 검증 지적 %d건 — %s" % (
            len(cp_issues), ", ".join("%s절 %d건" % (k, v) for k, v in sorted(per_section.items(), key=lambda kv: kv[0])) or "절 구분 없음"))
        for n in {str(i.get("section")) for i in cp_issues if i.get("section")}:
            if n in mds:
                fx = _fix(st, _section_spec(st, n), n, mds[n],
                          {"fails": [i for i in cp_issues if str(i.get("section")) == n]})
                if fx["ok"]:
                    fixed_md = _restore_lost_comparison_placeholder(n, mds[n], _postprocess(fx["text"], st, n))
                    _save_version(n, fixed_md, "consistency")
                    revised_sections.append(n)
    store.update_state(lambda s: s.__setitem__("consistency", {
        "at": store.now_iso(), "issues": norm_issues, "revised_sections": revised_sections}))

    store.update_state(lambda s: s.__setitem__("phase", "verifying"))
    verify_sources()
    store.update_state(lambda s: s.__setitem__("phase", "summary"))
    summary()
    return export()


def verify_sources() -> dict:
    """본문에 실제 인용된 출처만 검증(전 후보 아님 — 시간 절약)."""
    st = store.load_state()
    used = _used_sources(st)
    verified = source.verify_all(used)
    store.update_state(lambda s: s.__setitem__("sources", _merge_sources(s.get("sources") or [], verified)))
    g = source.export_gate(verified)
    store.log("시스템", _source_summary_ko(g["summary"]))
    return g


def _merge_sources(all_srcs: list[dict], verified: list[dict]) -> list[dict]:
    by_id = {v.get("id"): v for v in verified}
    return [by_id.get(s.get("id"), s) for s in all_srcs]


def _used_sources(st: dict) -> list[dict]:
    """본문이 **참조한** 출처 전부. 등록되지 않은 번호도 포함한다.

    ★ V2(Codex) Critical 지적 2026-09-21 — 종전에는 `state.sources` 에 있는 것만 돌려줬다.
      그러면 본문에 `[S-99]`(없는 번호)를 쓰면 «인용이 없다»로 처리돼 **export 게이트가 그냥 통과**했다.
      화면에는 `[미검증]` 태그가 찍히는데 DOCX 는 만들어지는 모순이었다.
      없는 번호는 **미검증 레코드로 만들어** 게이트에 넘긴다 — 지어낸 출처 번호가 통과할 길을 막는다.
    """
    text = "\n".join(_md_path(n).read_text(encoding="utf-8") for n in st["sections"] if _md_path(n).exists())
    used_ids = list(dict.fromkeys(_SRC_REF.findall(text)))
    by_id = {s.get("id"): s for s in (st.get("sources") or [])}
    out = []
    for sid in used_ids:
        rec = by_id.get(sid)
        if rec is None:
            out.append({"id": sid, "status": source.GRADE_UNVERIFIED,
                        "title": "(본문이 참조했으나 출처 목록에 없음)",
                        "note": "출처 목록에 없는 번호입니다 — 본문에서 지우거나 실제 출처를 등록하십시오."})
        else:
            out.append(rec)
    return out


def _source_summary_ko(summary: dict) -> str:
    """검증 결과 dict → 사람이 읽는 한국어 문장(화면 기록에 그대로 찍힌다 — dict 노출 금지)."""
    rate = summary.get("auto_success_rate")
    rate_s = ("%d%%" % round(rate * 100)) if rate is not None else "해당 없음"
    bits = ["원부검증 %d" % summary.get("registry", 0), "출처확인 %d" % summary.get("live", 0)]
    if summary.get("manual_review"):
        bits.append("사용자 증빙 %d" % summary["manual_review"])
    if summary.get("internal_pending"):
        bits.append("내부자료 대기 %d" % summary["internal_pending"])
    bits.append("미검증 %d" % summary.get("unverified", 0))
    if summary.get("blocked"):
        bits.append("검증대기 %d" % summary["blocked"])
    bits.append("자동 확인율 %s" % rate_s)
    return "출처 %d건 — %s" % (summary.get("total", 0), " · ".join(bits))


def _provider_ko(p: str) -> str:
    """내부 식별자 → 화면·로그 표기(소문자 내부 식별자 노출 금지)."""
    return {"claude": "Claude Code CLI", "codex": "Codex CLI"}.get(p, p or "")


def summary() -> dict:
    """요약 생성 — `enterprise` 는 Executive Summary(서술식), `public` 은 보고요지(개조식)."""
    st = store.load_state()
    p = outline.active_profile(st)
    mds = {n: _md_path(n).read_text(encoding="utf-8") for n in st["sections"] if _md_path(n).exists()}
    digest = "\n\n".join("=== %s절 ===\n%s" % (n, m[:2500]) for n, m in sorted(mds.items(), key=lambda kv: int(kv[0])))
    narrative = (p.get("summary_style") != "bullet")
    style = ("**서술식**(`~합니다`체 존댓말) 1페이지 이내. 결론을 먼저 쓴다."
             if narrative else
             "**개조식**(`~함`·`~임`) 3~5줄. `□`·`○` 들여쓰기. 결론을 먼저 쓴다.")
    r = llm.guarded_call_json("\n\n".join([
        outline.persona_text(st),
        outline.canon_block(st),
        "# 전 절 발췌\n" + digest,
        "# 과제 — 「%s」 작성. %s\n무엇을 왜 권고하며, 얼마가 들고, 언제까지인지가 들어가야 한다. "
        "수치는 정본 수치표에 있는 것만 쓴다." % (p.get("summary_title", "요약"), style),
        '# 출력 — JSON 하나만\n{"summary":"...","key_points":["...","..."]}',
    ]), purpose="summary", timeout=400)
    if r["ok"] and isinstance(r["data"], dict):
        d = dict(r["data"])
        d["summary"], _ = guard.filter_output(d.get("summary", ""))
        store.update_state(lambda s: s.setdefault("meta", {}).update(d))
    return r


def export() -> dict:
    """**도메인 가드 2 — `[미검증]` 출처가 1건이라도 있으면 DOCX 를 만들지 않는다.** 경고가 아니라 차단."""
    st = store.load_state()
    written = [n for n in st.get("sections", {}) if _md_path(n).exists()]
    if not written:
        # 빈 보고서를 DOCX 로 내보내지 않는다 — 본문이 없으면 출처 게이트도 통과해 버린다(조립 중 실측).
        store.log("시스템", "export 중단 — 작성된 절이 없음")
        raise Blocked("작성된 절이 없습니다 — 먼저 본문을 작성해야 내보낼 수 있습니다.")
    used = _used_sources(st)
    g = source.export_gate(used)
    if not g["ok"]:
        store.update_state(lambda s: s.__setitem__("phase", "blocked_export"))
        store.log("시스템", "export 차단 — 미검증·증빙 누락 %d건" % len(g["blocking"]))
        return {"ok": False, "reason": "export_gate", "gate": g}

    sections = []
    for n in sorted(st["sections"], key=int):
        if not _md_path(n).exists():
            continue
        lab = outline.section_label(st, n)
        md = re.sub(r"<!-- guard:.*?-->\n?", "", _md_path(n).read_text(encoding="utf-8"), flags=re.S)
        sections.append({"n": n, "number": lab["number"], "title": lab["title"],
                         "subhead": lab.get("subhead"), "md": md})

    meta = dict(st.get("meta", {}))
    it = st["intake"]; prof = outline.active_profile(st)
    meta.setdefault("title", it.get("topic", ""))
    meta.setdefault("recipient", it.get("recipient", ""))
    meta.setdefault("org_name", prof.get("org_name", ""))
    meta.setdefault("dept", prof.get("dept", ""))
    meta.setdefault("author", prof.get("writer_name", ""))
    meta.setdefault("doc_type", prof.get("doc_type", "검토보고"))
    meta["comparison"] = build_comparison_table(st)

    safe = re.sub(r'[<>:"/\\|?*]', "_", meta["title"])[:40] or "report"
    res = docx_build.build(sections, meta, used, prof, st["settings"],
                           str(OUT / ("%s_%s.docx" % (safe, time.strftime("%Y%m%d")))))

    # 상한 도달(미달) 절은 사용자가 반드시 알아야 한다 — 조용히 실려 나가지 않게 후처리 목록 맨 위에.
    stalled = ["%s절 — %s" % (n, c.get("note") or "미달")
               for n, c in sorted(st["sections"].items(), key=lambda kv: int(kv[0])) if c.get("status") == "stalled"]
    if stalled:
        res["postprocess"] = ["⚠ 미완성 절(1차 검증 미달·상한 도달) — 직접 손질하거나 「N절 다시 쓰기」: "
                              + " / ".join(stalled)] + res["postprocess"]

    # D-010 정본 전문 결함 — PC3 E2E: 재수정 결과에서 4절 자리표시가 유실되고(→ docx 가 절 끝에
    # 코드 표를 보증 삽입), 가중치가 이미 확정됐는데 4절 본문이 "미확정·산출 불가" 라고 적은 사고.
    # LLM 문장은 코드가 고쳐 쓰지 않는다 — **알리기만** 한다. 맨 위(stalled 보다도 위)에 적는다.
    notices = []
    if res.get("comparison_guarantee_used"):
        notices.append("4절 비교표 자리표시 유실 — 코드 표를 절 끝에 넣음")
    canon_criteria = (st.get("canon") or {}).get("criteria") or []
    weights_confirmed = bool(canon_criteria) and all(c.get("by") == "user" for c in canon_criteria)
    sec4_md = next((s["md"] for s in sections if s["n"] == "4"), "")
    if weights_confirmed and _WEIGHT_MISMATCH_RE.search(sec4_md):
        notices.append("4절 서술이 정본과 불일치 — 가중치는 확정됨, 해당 문장 확인 필요")
    if notices:
        res["postprocess"] = notices + res["postprocess"]

    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "후처리_목록.md").write_text(
        "# Word 후처리 필요 항목\n" + "\n".join("- [ ] " + p for p in res["postprocess"])
        + ("\n\n경고:\n" + "\n".join("- " + w for w in res["warnings"]) if res["warnings"] else ""),
        encoding="utf-8")
    store.update_state(lambda s: (s.__setitem__("export", {"path": res["path"], "postprocess": res["postprocess"],
                                                           "valid": res["valid"]}),
                                  s.__setitem__("phase", "done")))
    store.log("시스템", "DOCX 생성 — %s (열림 검증 %s)" % (Path(res["path"]).name, "OK" if res["valid"] else "실패"))
    return {"ok": res["valid"], **res}


# ---------------------------------------------------------------- 화면 계약
def status() -> dict:
    st = store.load_state()
    secs = st.get("sections", {})
    return {"phase": st["phase"],
            "approved": st.get("outline", {}).get("approved"),
            "sections": {n: {"status": c.get("status"), "score": c.get("score"), "calls": c.get("calls")}
                         for n, c in secs.items()},
            "sources": source.export_gate(st.get("sources", []))["summary"],
            "blocked": st.get("blocked"),
            "export": st.get("export"),
            "history": store.history_summary()}


def tool_rows(live: bool = False) -> list[dict]:
    """좌측 「도구」 패널 — found 는 True/False/None(확인 안 함) 세 값."""
    keys = {}
    try:
        keys = store.load_config("keys.json", {}) or {}
    except Exception:
        keys = {}
    def _has(mod):
        try:
            __import__(mod); return True
        except ImportError:
            return False
    has_pandas = _has("pandas")
    has_openpyxl = _has("openpyxl")
    # ★D-006 — pandas 만 보고 「있음」이라 말하던 것을 정직화. xlsx 는 openpyxl 도 필요하다.
    st = store.load_state()
    figs = (st.get("canon") or {}).get("figures") or {}
    it = (st.get("intake") or {}).get("files") or []
    table_files = [f for f in it if Path(f).suffix.lower() in (".csv", ".xlsx", ".xls")]
    canon_table_figs = sum(1 for k, v in figs.items()
                           if any(Path(f).stem in k for f in table_files)) if table_files else 0
    table_desc = "csv (pandas)" + ("·xlsx (openpyxl)" if has_openpyxl else "")
    table_note = "정본 등재 %d건" % canon_table_figs if table_files else "없어도 지표 계산은 동작"
    if has_pandas and not has_openpyxl:
        table_note += " · xlsx 는 openpyxl 미설치로 못 읽음"
    return [
        {"label": "수치 계산·대조", "desc": "증감률·구성비·가중합 — 코드가 계산(calc.py)", "found": True, "note": "LLM 개입 없음"},
        {"label": "표 파일 읽기", "desc": table_desc, "found": has_pandas, "note": table_note},
        {"label": "PDF 읽기", "desc": "투입 자료 (pypdf)", "found": _has("pypdf"), "note": ""},
        {"label": "DOCX 조립", "desc": "보고서 출력 (python-docx)", "found": _has("docx"), "note": ""},
        {"label": "출처 실접속 검증", "desc": "URL 접속 + 본문 대조", "found": True, "note": "허용 도메인 %d개" % len(source.allowed_domains())},
        {"label": "공공 통계 원부", "desc": "KOSIS·ECOS 조회", "found": bool(keys.get("kosis") or keys.get("ecos")),
         "note": "키 없으면 URL 실접속 검증으로 대체"},
    ]


def kb_rows() -> dict:
    """좌측 「지식베이스」 패널 — ①~④ + 작업 지식."""
    st = store.load_state()
    n_vault = len(list(VAULT.glob("*.txt"))) if VAULT.exists() else 0
    figs = len((st.get("canon") or {}).get("figures") or {})
    srcs = len(st.get("sources") or [])
    return {
        "kb-inject-row": {"label": "① 직접 주입", "desc": "규칙 5종 + 조직 프로필",
                          "found": (APP / "skills" / "structure.md").exists(), "note": "skills/*.md · config/org_profile.json"},
        "kb-rag-row": {"label": "② RAG", "desc": "투입 자료 볼트", "found": n_vault > 0, "note": "%d건" % n_vault},
        "kb-api-row": {"label": "③ API", "desc": "공공 통계 원부", "found": None, "note": "조회 시 확인"},
        "kb-mcp-row": {"label": "④ MCP", "desc": "사용 안 함", "found": None, "note": "해당 없음"},
        "kb-experience-row": {"label": "작업 지식", "desc": "정본 수치표·출처 목록",
                              "found": bool(figs or srcs), "note": "확정 수치 %d · 출처 %d" % (figs, srcs)},
    }
