# -*- coding: utf-8 -*-
"""guard.py — 안전 체계(코드 강제). 프롬프트 부탁이 아니라 실행 전후 검사·차단.

부품 출처(BOM 🟡): 원자재 thesis-agent `app/guard.py`
  sha256 100184519e8542f97482e5f545831bad9454b65f738356bfccaac68deba9f740 (2026-09-20)
  ← 그 위로는 공증에이전트 rules.py `pseudonymize`·`restore` (PO 소유 내부 자산)
재단 내용: ① 가명화 패턴에 사내 식별자(사번·사업자등록번호·계좌) 추가 ② 판정 문구를 학술(표절·IRB)
  → 결재 문서용(법무·감사·승인)으로 전면 교체 ③ 심사 어조 검사 폐기, 개조식 이탈 검사로 대체
자체 제작(🏭): `check_vague()` — 국가공무원인재개발원 「정책기획 실습」(2018) p.084
  「보고서 고도화 작업」 체크리스트 **#8 애매한 표현 자제**를 코드로 판정한다.

헌법 제약:
- 법적·제도적 최종 판정 문구 생성 금지 → `filter_output()`이 문장을 치환하고 고지문을 붙인다.
- 사내 실명·식별자는 LLM 전송 전 가명화 → `pseudonymize()`, 전송 직전 `scan_leak()` 히트 = 호출 중단(fail-closed).
- AI 활용 고지 기본 포함 → `ai_disclosure()` (settings.ai_disclosure=False로만 해제).

⚠️ 새 입력 경로를 추가하면 `engine._names_from_fields`에 등록한다 — 빠뜨리면 실명이 샌다.
"""
from __future__ import annotations
import re, string

# ---------------------------------------------------------------- 가명화
_RRN_RE = re.compile(r"(?<!\d)\d{6}-?\d{7}(?!\d)")
_PHONE_RE = re.compile(
    r"(?<!\d)01[016789][-.\s]?\d{3,4}[-.\s]?\d{4}(?!\d)"
    r"|(?<!\d)0\d{1,2}[-.)]\s?\d{3,4}[-.\s]\d{4}(?!\d)")
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_ADDR_RE = re.compile(
    r"[가-힣A-Za-z0-9]+(?:로|길)\s*\d+(?:-\d+)?(?:\s*,?\s*\d+동)?(?:\s*,?\s*\d+호)?"
    r"|\d+(?:-\d+)?번지(?:\s*\d+호)?"
    r"|(?:[가-힣]+(?:아파트|빌라|오피스텔)\s*)?\d+동\s*\d+호")
# ★재단 — 사내 자료 대응(MBO 보안 강화). 기업·공공 문서에 실제로 섞여 들어오는 식별자.
_EMPNO_RE = re.compile(r"(?:사번|사원번호|직원번호|공무원번호)\s*[:：]?\s*([A-Za-z]{0,3}-?\d{4,10})")
_BIZNO_RE = re.compile(r"(?<!\d)\d{3}-\d{2}-\d{5}(?!\d)")                       # 사업자등록번호
_CORPNO_RE = re.compile(r"(?<!\d)\d{6}-\d{7}(?!\d)")                            # 법인등록번호(주민번호와 형식 동일 — 주민번호 규칙이 먼저 잡음)
_ACCOUNT_RE = re.compile(r"(?:계좌|계좌번호)\s*[:：]?\s*(\d{2,6}-\d{2,6}-\d{2,8})")

_PATTERNS = (
    ("주민번호", _RRN_RE),
    ("사업자번호", _BIZNO_RE),
    ("사번", _EMPNO_RE),
    ("계좌", _ACCOUNT_RE),
    ("연락처", _PHONE_RE),
    ("이메일", _EMAIL_RE),
    ("주소", _ADDR_RE),
)


def pseudonymize(text: str, names: list[str] | None = None) -> tuple[str, dict]:
    """식별자 토큰 치환. (masked, mapping{token: 원문}).

    mapping(토큰→원문)은 **메모리에서만** 오간다 — 파일에 기록하지 않는다.
    반면 치환 대상 *이름 목록*은 `state.pseudonym_names`에 저장된다(재시작 후 복원용, 원자재 V1 D3).
    `names`에는 인명뿐 아니라 거래처명·부서명 등 고유명사를 함께 넣는다 — 정규식으로 잡을 수 없는 것들이다.
    """
    mapping: dict = {}
    counters = {k: 0 for k, _ in _PATTERNS}
    masked = str(text)

    def _sub(pattern, category, s):
        def _repl(m):
            orig = m.group(0)
            for tok, o in mapping.items():
                if o == orig and tok.startswith("[%s#" % category):
                    return tok
            counters[category] += 1
            tok = "[%s#%d]" % (category, counters[category])
            mapping[tok] = orig
            return tok
        return pattern.sub(_repl, s)

    for cat, pat in _PATTERNS:
        masked = _sub(pat, cat, masked)

    labeled = []
    for i, nm in enumerate(names or []):
        nm = str(nm).strip()
        if len(nm) < 2:
            continue
        label = string.ascii_uppercase[i] if i < 26 else str(i + 1)
        labeled.append((nm, "[관계자%s]" % label))
    for nm, tok in sorted(labeled, key=lambda x: -len(x[0])):   # 긴 이름부터(부분 겹침 방지)
        if nm in masked:
            masked = masked.replace(nm, tok)
            mapping[tok] = nm
    for nm, tok in labeled:                                        # 로마자 이름은 성·이름 따로도
        if " " in nm:
            for part in nm.split():
                part = part.strip(".,")
                if len(part) >= 3:
                    masked = re.sub(r"(?<![0-9A-Za-z])" + re.escape(part) + r"(?![0-9A-Za-z])", tok, masked)
    return masked, mapping


def restore(text: str, mapping: dict) -> str:
    out = text
    for tok, orig in sorted(mapping.items(), key=lambda kv: -len(kv[0])):
        out = out.replace(tok, orig)
        bare = tok.strip("[]")
        out = re.sub(r"(?<![가-힣A-Za-z0-9])" + re.escape(bare) + r"(?![가-힣A-Za-z0-9#])", orig, out)
    return out


def scan_leak(text: str) -> list[str]:
    """전송 직전 2차 스캔 — 히트가 있으면 호출을 **막는다**(fail-closed, 경고 아님). 반환: 발견 카테고리 목록."""
    hits = []
    for cat, pat in _PATTERNS:
        if cat == "주소":
            continue   # 주소 패턴은 오탐이 잦아 2차 스캔에서는 제외(1차에서 이미 치환)
        if pat.search(text):
            hits.append(cat)
    return hits


# ---------------------------------------------------------------- 출력 필터 — 판정 문구 차단
# 이 에이전트는 초안을 쓸 뿐, 법무·감사·결재 판정을 내리지 않는다. 그런 문장이 결재 문서에 실리면
# 조직이 그 판정을 근거로 움직이게 된다. 고정 문구형이라 정규식으로 막는다(판단형은 프롬프트+대조로).
_VERDICT_PATTERNS = [
    (re.compile(r"법(적|률)(으로|상)?\s*(아무런\s*)?문제(가|는)?\s*없(다|음|습니다)[^.。\n]*[.。]?"),
     "법적 적합성은 법무 부서의 검토가 필요하다."),
    # ★ 개조식 명사형 종결(「아님」·「없음」·「가능」)을 반드시 포함한다 — 실측 2026-09-22.
    #   이 제품의 본문 문체가 개조식(명사형 종결)인데 서술형 어미만 잡고 있어
    #   「규정 위반이 아님」·「감사 지적 없음」·「승인 가능」이 그대로 통과했다(7건 중 4건).
    #   자기가 쓰는 문체를 자기 필터가 못 보던 구멍. 되돌리지 마라.
    (re.compile(r"(관련\s*)?(규정|법령|지침)(에|을)?\s*위반(이|한\s*것은)?\s*(아니(다|며|고|라고 본다|라고 판단)|아님)[^.。\n]*[.。]?"),
     "규정 위반 여부는 소관 부서와 감사 부서의 판단이 필요하다."),
    (re.compile(r"감사\s*(에서)?\s*지적\s*(사항)?(을|이)?\s*(받지\s*않(는다|을 것|음)|없(다|음|을 것))[^.。\n]*[.。]?"),
     "감사 지적 가능성은 감사 부서의 판단 사항이다."),
    # 「가능성 검토」·「가능한지 확인」·「가능 시점 협의」 같은 유보 표현까지 막으면 정상 문장이 죽는다.
    #   → 어미가 붙은 단정(가능하다/함/합니다/하며…)만 자유롭게 잡고,
    #     어미 없는 맨 「가능」은 «절 끝»(개조식 항목의 끝)일 때만 판정으로 본다.
    (re.compile(r"(승인|결재)(이|가|은|는)?\s*(가능|확실)"
                r"(?:(하[다며고여]|함|합니다)[^.。\n]*[.。]?|(?=\s*(?:[.。\n]|$)))"),
     "승인 여부는 결재권자가 판단한다."),
    (re.compile(r"((본|이)\s*(방안|계획|사업)은\s*)?(적법|합법)(하다|함|하다고\s*판단(된다|됨))(?![가-힣])[^.。\n]*[.。]?"),
     "적법성은 법무 부서의 검토가 필요하다."),
    (re.compile(r"위법\s*(소지|사항|요소)(가|는)?\s*없(다|음|을 것)[^.。\n]*[.。]?"),
     "위법 소지 여부는 법무 부서의 검토가 필요하다."),
    (re.compile(r"예산\s*(집행|편성)(에|이)?\s*(문제(가)?\s*없|가능)(다|음|하다|합니다)[^.。\n]*[.。]?"),
     "예산 집행 가능 여부는 예산 부서의 확인이 필요하다."),
    (re.compile(r"(개인정보|정보보호)\s*(법)?\s*(상)?\s*(문제(가)?\s*없|적합)(다|음|하다)[^.。\n]*[.。]?"),
     "개인정보 처리 적합성은 개인정보 보호책임자의 검토가 필요하다."),
    (re.compile(r"AI(가|로)\s*작성(하였|했|되었)(다|음|습니다)[^.。\n]*[.。]?"),
     "본 문서의 AI 활용 범위는 붙임 「AI 활용 고지」에 따른다."),
]
NOTICE = ("※ 법적·규정·감사·승인 등 제도적 판정은 이 도구가 내리지 않는다. "
          "소관 부서(법무·감사·예산·결재권자)의 검토가 필요하다.")


def filter_output(text: str) -> tuple[str, list[str]]:
    """자기 단정 문구를 고지문으로 치환. 반환 (text, 치환된 원문 목록)."""
    removed = []
    out = text
    for pat, repl in _VERDICT_PATTERNS:
        for m in pat.finditer(out):
            removed.append(m.group(0))
        out = pat.sub(repl, out)
    return out, removed


# ---------------------------------------------------------------- 페르소나 이탈 검사
_FIRST_PERSON = re.compile(r"(?<![가-힣])(저는|제가|나는|내가|저희는|필자는)\s")
_ABSOLUTE = re.compile(r"(명백히|확실히|절대(로)?|분명히|의심의 여지 없이|틀림없이)")
# ★재단 — 원자재의 「심사 어조」 검사를 폐기하고, 개조식 본문에 서술식 어미가 섞이는 것을 잡는다.
#   요약 절(Executive Summary / 보고요지 서술식)은 호출 측에서 검사 대상에서 제외한다.
_NARRATIVE_ENDING = re.compile(r"(합니다|입니다|습니다|였습니다|겠습니다)[.。\s]")


def persona_check(text: str, allow_narrative: bool = False) -> list[dict]:
    """규칙 위반 위치 목록. 3회 재생성 후에도 남으면 미달 보고.

    allow_narrative=True 면 서술식 어미를 허용한다(요약 절 전용).
    """
    rules = [("1인칭", _FIRST_PERSON), ("단정 부사", _ABSOLUTE)]
    if not allow_narrative:
        rules.append(("서술식 어미(개조식 위반)", _NARRATIVE_ENDING))
    issues = []
    for name, pat in rules:
        for m in pat.finditer(text):
            s = max(0, m.start() - 20); e = min(len(text), m.end() + 20)
            issues.append({"rule": name, "where": text[s:e].replace("\n", " ")})
    return issues


# ---------------------------------------------------------------- 🏭 애매 표현 검출 (체크리스트 #8)
# 근거: 국가공무원인재개발원 「정책기획 실습」(2018) p.084 고도화 체크리스트 #8
#       "『대체로, 대부분, 많은, 어느 정도, 대승적』 등 애매한 표현 자제"
# 교재가 "등"으로 열어 둔 목록이므로, 앞 5개(공식 예시)에 실무에서 같은 문제를 일으키는 표현을 더했다.
# 목록을 늘리고 줄이는 것은 이 상수 하나만 고치면 된다 — 코드 다른 곳에 흩뿌리지 않는다.
VAGUE_TERMS_OFFICIAL = ["대체로", "대부분", "많은", "어느 정도", "대승적"]
VAGUE_TERMS_EXTRA = ["상당수", "상당한", "다소", "일부", "적지 않은", "전반적으로",
                     "적극적으로", "조속히", "철저히", "내실 있게", "효율적으로", "적절히"]
_VAGUE_RE = re.compile("|".join(re.escape(t) for t in VAGUE_TERMS_OFFICIAL + VAGUE_TERMS_EXTRA))


def check_vague(text: str) -> list[dict]:
    """애매한 표현 검출. 반환 [{term, official, where}].

    차단이 아니라 **검출**이다 — 결과를 수정 프롬프트에 주입해 숫자·구체 범위로 바꾸게 한다.
    채점자(rubric)는 이 항목을 중복 지적하지 않는다(코드가 판정하는 항목).
    """
    out = []
    for m in _VAGUE_RE.finditer(text):
        term = m.group(0)
        s = max(0, m.start() - 20); e = min(len(text), m.end() + 20)
        out.append({
            "term": term,
            "official": term in VAGUE_TERMS_OFFICIAL,
            "where": text[s:e].replace("\n", " "),
        })
    return out


# ---------------------------------------------------------------- AI 활용 고지
DEFAULT_DISCLOSURE = (
    "본 보고서의 초안 작성·자료 정리·서식 조판 과정에 생성형 AI 도구(보고서 작성 에이전트 — Claude 등 대규모 언어모델 기반)가 사용되었다. "
    "현황 판단, 대안 선정, 최종 의사결정은 작성자와 결재권자가 수행하였으며, "
    "본문의 모든 수치는 코드로 산출되었고 모든 출처는 원부 조회 또는 실접속 본문 대조로 확인하였다(붙임 「출처 검증표」). "
    "AI 활용 범위와 고지 방식은 소속 기관의 규정을 따른다.")


def ai_disclosure(profile: dict, settings: dict) -> str | None:
    """settings.ai_disclosure가 명시적으로 False가 아니면 항상 문구 반환(조직 프로필 문구 우선)."""
    if settings.get("ai_disclosure") is False:
        return None
    return (profile or {}).get("ai_disclosure_text") or DEFAULT_DISCLOSURE
