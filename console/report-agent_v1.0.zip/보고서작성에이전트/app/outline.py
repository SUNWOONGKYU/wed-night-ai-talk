# -*- coding: utf-8 -*-
"""outline.py — 목차 생성, 승인 게이트, 정본 수치표(canon), 절간 정합성 패스.

부품 출처(BOM 🟡): 원자재 thesis-agent `app/outline.py`
  sha256 1365f871f687c3c8b66c16163edcd15f579c9b97e243a703df9c14f521dd46de (2026-09-20)
재단: 논문 3단 목차 → 보고서 8절 + 조직 프로필 절번호 매핑 / 정본 시트 → **정본 수치표**
자체 제작(🏭): `check_title_match`(#10) · `check_plan_fields`(#13) · **`check_issue_coverage`(#14)**
  — 국가공무원인재개발원 「정책기획 실습」(2018) p.083~084 「보고서 고도화 작업」 체크리스트.
  **LLM 판단 없이 코드가 판정한다.**

원칙:
- 목차 미승인(`state.outline.approved == False`)이면 절 생성 호출을 engine 이 거부한다(도메인 가드 1).
- 정본 수치표(용어·논점·수치·평가기준·대안)는 **매 절 프롬프트 앞에 재주입** — 컨텍스트 붕괴 대응.
- 평가기준 가중치는 **사용자가 정한다.** 합 100 검증은 `calc.validate_criteria`.
- LLM 출력은 JSON 하나만(fail-closed).
"""
from __future__ import annotations
import json, re
from pathlib import Path

try:
    from . import llm, store, guard, calc, source  # type: ignore
except ImportError:
    import llm, store, guard, calc, source  # type: ignore

APP = Path(__file__).resolve().parent
SKILLS = APP / "skills"

# LLM 이 쓰는 절은 1~7. 8(붙임/참고자료)은 출처 검증표로 자동 조립된다(docx_build).
WRITTEN_SECTIONS = ["1", "2", "3", "4", "5", "6", "7"]
ROMAN = ["Ⅰ", "Ⅱ", "Ⅲ", "Ⅳ", "Ⅴ", "Ⅵ", "Ⅶ"]


def skill(name: str) -> str:
    p = SKILLS / (name + ".md")
    return p.read_text(encoding="utf-8") if p.exists() else ""


# ---------------------------------------------------------------- 조직 프로필
def active_profile(st: dict) -> dict:
    """state.org_profile(병합본) 또는 config/org_profile.json 의 active 프리셋."""
    op = st.get("org_profile") or {}
    if op.get("section_titles"):
        return op
    cfg = store.load_config("org_profile.json") or {}   # ⚠️ load_config 는 확장자까지 받는다(CONFIG_DIR / name)
    active = op.get("active") or cfg.get("active") or "enterprise"
    preset = dict(((cfg.get("presets") or {}).get(active)) or {})
    for k in ("org_name", "dept", "writer_name", "writer_rank", "contact"):
        if cfg.get(k):
            preset.setdefault(k, cfg[k])
    preset.setdefault("active", active)
    return preset


def is_public(st: dict) -> bool:
    return (active_profile(st).get("active") or "enterprise") == "public"


def section_label(st: dict, n: str) -> dict:
    """절 번호·제목·소제목. `public` 이면 2·3 → Ⅱ, 4·5 → Ⅲ 로 합쳐 출력한다(내부 상태는 8절 유지).

    반환 {"number", "title", "subhead", "merged_with"}
    """
    p = active_profile(st)
    titles = p.get("section_titles") or {}
    title = titles.get("s" + n, "")
    subhead = (p.get("subheads") or {}).get("s" + n)
    merged = [g for g in (p.get("merge_sections") or []) if ("s" + n) in g]
    if p.get("section_numbering") == "roman":
        order = ["s1", "s2", "s4", "s6", "s7"]          # 로마자 번호가 붙는 대표 절
        rep = "s" + n
        for g in (p.get("merge_sections") or []):
            if rep in g:
                rep = g[0]
        idx = order.index(rep) if rep in order else None
        number = (ROMAN[idx] + ".") if idx is not None else ""
    else:
        number = n + "."
    return {"number": number, "title": title, "subhead": subhead,
            "merged_with": [g for g in merged] or None}


def persona_text(st: dict) -> str:
    p = active_profile(st)
    it = st.get("intake", {})
    return (skill("persona")
            .replace("{org_name}", p.get("org_name") or it.get("org_name", ""))
            .replace("{dept}", p.get("dept") or it.get("dept", ""))
            .replace("{org_type}", "공공기관" if is_public(st) else "기업")
            .replace("{writer_rank}", p.get("writer_rank") or ""))


# ---------------------------------------------------------------- 목차 + 정본 수치표 초안
def propose(st: dict, materials_digest: str, names: list[str]) -> dict:
    """입력(주제·자료 요약)에서 검토 논점·평가기준·대안·목차 초안. 반환 {'ok','frame','outline','error'}"""
    # 가명화·누출 스캔은 **llm 관문**(guarded_call_json)이 일괄 수행한다 — 여기서 따로 하지 않는다.
    # (V2 지적: 관문이 한 곳에만 있으면 새 호출부가 늘 때 또 빠진다)
    masked = materials_digest
    it = st.get("intake", {})
    p = active_profile(st)
    brief = (
        "규칙: 절은 구조 규칙 표의 1~7절. **약식 모드** — 각 절 items 2~3개, 항 제목은 명사형."
        if (st.get("settings") or {}).get("length_mode") == "brief" else
        "규칙: 절은 구조 규칙 표의 1~7절. 각 절 items 2~5개, 항 제목은 명사형."
    )
    prompt = "\n\n".join([
        persona_text(st),
        "# 구조 규칙\n" + skill("structure"),
        "# 출처 규칙(요약)\n근거는 사용자 자료 또는 실제 조회 결과에서만 온다. 지어낸 출처·수치 금지. 확인 안 된 수치는 [확인 필요].",
        "# 과제\n조직 유형: %s · 문서 유형: %s · 언어: 한국어\n주제: %s\n수신: %s\n보유 자료: %s"
        % ("공공기관" if is_public(st) else "기업", p.get("doc_type", "검토보고"),
           it.get("topic", ""), it.get("recipient", ""), it.get("data_desc", "없음")),
        "# 투입 자료 요약(가명화됨)\n" + masked[:12000],
        "# 출력 — JSON 하나만. 설명문 금지.\n"
        '{"frame":{"purpose":"검토 목적 한 문단",'
        '"issues":["논점1 — 2·3절에서 제기하고 5·6절에서 반드시 다룰 것","논점2 ..."],'
        '"terms":{"용어":"정의"},'
        '"criteria":[{"name":"평가기준명","by":"ai_suggested"}],'
        '"options":[{"key":"opt1","label":"1안 ..."},{"key":"opt2","label":"2안 ..."},{"key":"opt3","label":"3안 ..."}],'
        '"figures_needed":[{"key":"지표명","why":"어느 절에 쓰나","how":"어떤 자료로 산출하나"}]},'
        '"outline":[{"n":1,"title":"추진 배경 및 목적","items":["..."]},{"n":2,"title":"현황 분석","items":[...]}, ...]}',
        brief,
        "주의 1: **대안(options)은 3개 이상**이어야 한다.",
        "주의 2: **평가기준의 가중치(weight)를 네가 정하지 마라.** 기준 이름만 제안하고 weight 는 절대 쓰지 마라 — "
        "가중치는 사용자가 승인 단계에서 직접 넣는다. AI 가 가중치를 정하면 결론을 먼저 정해 놓고 "
        "근거를 맞춘 보고서가 된다.",
        "주의 3: **수치를 지어내지 마라.** figures_needed 에 '무엇이 필요한지'만 적는다. 값은 코드가 산출한다.",
        "주의 4: issues(검토 논점)는 2·3절에서 제기하고 5·6절에서 반드시 다뤄질 항목이다 — 뒤에서 버릴 논점은 넣지 마라.",
    ])
    r = llm.guarded_call_json(prompt, purpose="outline", names=names, timeout=400)
    if not r["ok"]:
        return {"ok": False, "error": r["error"] or "JSON 파싱 실패"}
    d = r["data"]
    if not isinstance(d, dict) or "outline" not in d or "frame" not in d:
        keys = list(d.keys())[:8] if isinstance(d, dict) else type(d).__name__
        store.log("시스템", "목차 응답 형식 오류 — 키 %s" % keys, raw=(r.get("raw") or "")[:600])
        return {"ok": False, "error": "응답에 frame/outline 없음 (받은 키: %s) — 다시 시도하세요" % keys}
    for s in d["outline"]:
        s.setdefault("items", [])
    return {"ok": True, "frame": d["frame"], "outline": d["outline"], "provider": r["provider"]}


def validate_frame(frame: dict) -> list[str]:
    """승인 전 검증 — **가중치는 사용자가 넣어야 한다** · 합 100 · 대안 3개 이상.

    ★ V2(Codex) Critical 지적 2026-09-21 — 종전에는 목차 프롬프트가 LLM 에게 weight 까지 생성하게 하고,
      `approve` 가 그것을 그대로 정본에 복사했다. 시운전 산출물이 증거다(출처 0건인데 30·25·20·15·10 단정).
      「AI 가 가중치를 정하면 결론을 정해 놓고 근거를 맞춘 보고서가 된다」는 이 제품 스스로의 금지를 어긴 것이다.
      → AI 가 제안한 기준(`by == "ai_suggested"`)은 **사용자가 가중치를 넣기 전까지 승인되지 않는다.**
    """
    crit = frame.get("criteria") or []
    errs = []
    # ★ V2 2차 재확인 Critical 2026-09-21 — 종전에는 `by == "user"` 플래그를 믿었다.
    #   그런데 `frame` 은 **LLM 응답에서 온 dict** 다 — 신뢰 경계 밖이다.
    #   LLM 이 `by:"user"` 라고 써 보내면 그대로 통과했다(자기신고 위조).
    #   프롬프트로 "쓰지 마라"고 한 것은 **부탁**이지 강제가 아니다 — 헌법: 금지는 코드가 막는다.
    #   → **frame 의 weight 는 어떤 경우에도 정본이 되지 않는다.**
    #     가중치는 `engine.set_criteria_weights()`(사용자 전용 경로)로만 확정된다.
    weighted = [c.get("name") or "(이름 없음)" for c in crit if c.get("weight") not in (None, "")]
    if weighted:
        errs.append("가중치는 목차 승인 단계에서 확정할 수 없습니다 — 목차를 먼저 승인한 뒤 "
                    "「평가기준 가중치」 화면에서 직접 넣으십시오. (AI 가 제안한 값은 정본이 되지 않습니다: %s)"
                    % ", ".join(str(x) for x in weighted[:6]))
        return errs
    if not crit:
        errs.append("평가기준(이름)이 비어 있습니다 — 4절 대안 비교에 필요합니다")
    opts = frame.get("options") or []
    if len(opts) < 3:
        errs.append("대안은 3개 이상이어야 합니다 (현재 %d개) — 4절 대안 비교가 성립하지 않습니다" % len(opts))
    if not (frame.get("issues") or []):
        errs.append("검토 논점(issues)이 비어 있습니다 — 2·3절 ↔ 5·6절 커버리지 대조의 기준이 됩니다")
    return errs


class ApproveBlocked(Exception):
    """승인 전 보완이 필요한 상태 — 정본을 만들지 않는다."""


def approve(st: dict, outline: list[dict], frame: dict) -> None:
    """사용자 승인 → 정본 수치표 생성 + 절 상태 초기화. 이후 절 생성 허용.

    ★ V2(Codex) 재확인 지적 2026-09-21 — 종전에는 `engine.approve_outline` 만 검증하고
      이 함수는 frame 을 **그대로 정본에 복사**했다. 그래서 이 함수를 직접 부르면
      AI 가 만든 가중치가 그대로 확정됐다. 「관문을 만들고 강제를 안 한」 셈이다.
      → **검증을 여기서 스스로 한다.** 호출부가 늘어도 빠질 수 없다.
    """
    errs = validate_frame(frame)
    if errs:
        raise ApproveBlocked("승인 전 보완이 필요합니다:\n- " + "\n- ".join(errs))
    st["outline"] = {"sections": outline, "approved": True, "approved_at": store.now_iso()}
    c = st.setdefault("canon", {})
    c["terms"] = frame.get("terms", {})
    c["issues"] = frame.get("issues", [])
    c["criteria"] = frame.get("criteria", [])
    c["options"] = frame.get("options", [])
    c["purpose"] = frame.get("purpose", "")
    # ★D-006 — 목차 LLM 이 적은 「필요한 수치 계획」을 정본에 저장(이전에는 저장조차 안 됐다).
    #   canon_block() 이 이 목록과 canon.figures 를 대조해 «계산 불가» 항목을 따로 보여줄 수 있게 한다.
    c["figures_needed"] = frame.get("figures_needed", [])
    c.setdefault("figures", {})
    c.setdefault("sources", [])
    # ★D-006 짝 — calc._SKIP_AFTER 에서 「명·개·건·개소·개사·부서·과·팀」을 뺐기 때문에,
    #   본문의 "대안 3개"·"평가기준 2개"·"검토 논점 1건" 같은 **구조 수치**가 정본에 없으면
    #   crosscheck 가 과잉 차단한다. 그래서 구조 수치도 코드가 계산해 정본에 올린다.
    calc.register(c, "대안 수", len(c["options"]), "목차 승인", formula="LEN(canon.options)", unit="개")
    calc.register(c, "평가기준 수", len(c["criteria"]), "목차 승인", formula="LEN(canon.criteria)", unit="개")
    calc.register(c, "검토 논점 수", len(c["issues"]), "목차 승인", formula="LEN(canon.issues)", unit="건")
    st["sections"] = {str(s["n"]): {"status": "pending", "score": None, "calls": 0,
                                    "started": None, "critique": [], "versions": [], "minutes": 0.0}
                      for s in outline}
    st["phase"] = "writing"
    store.log("사용자", "목차 승인 — %d절" % len(outline))


# ---------------------------------------------------------------- 정본 수치표 재주입
CANON_FIGURES_DISPLAY_CAP = 80          # 표 파일 집계로 등재 건수가 많아지면 프롬프트가 폭주한다


def canon_block(st: dict) -> str:
    """매 절 프롬프트 앞에 붙는 정본 수치표. **여기 없는 수치를 본문에 쓰면 crosscheck 가 잡는다.**"""
    c = st.get("canon", {})
    all_figs = c.get("figures") or {}
    items = list(all_figs.items())
    # D-007 근원 대응 — 예전에는 `formula`(예: "LEN(canon.options)")를 그대로 보여줬다. 내부 계산식·
    # 함수명이 프롬프트에 있으면 LLM 이 결재 문서 본문에 그대로 옮겨 적는다(실측: "calc.py 산출 후
    # 정본 수치표 반영" 이 원고에 남음). 사람이 읽는 사실(기준시점·출처·등급)만 남기고 수식은 뺀다.
    figs = "\n".join(
        "- %s = %s%s (기준 %s · 출처 %s %s)" % (
            k, v.get("value"), (" " + (v.get("unit") or "")).rstrip(),
            v.get("basis_date") or "—",
            v.get("source_id") or "—", ("[" + v["grade"] + "]") if v.get("grade") else "")
        for k, v in items[:CANON_FIGURES_DISPLAY_CAP]
    ) or "- (아직 없음 — 본문에 수치를 쓰지 말고 [확인 필요]로 남길 것)"
    if len(items) > CANON_FIGURES_DISPLAY_CAP:
        figs += "\n- 외 %d건 생략 — 전체는 정본 수치표(canon.figures) 참조" % (len(items) - CANON_FIGURES_DISPLAY_CAP)

    # ★D-006 — figures_needed 중 등재된 키와 대응이 없는 항목은 따로 알린다(단순 부분일치 규칙 — LLM 판정 아님).
    unmatched = []
    for need in (c.get("figures_needed") or []):
        key = (need.get("key") if isinstance(need, dict) else str(need)) or ""
        key = key.strip()
        if not key:
            continue
        if not any(key in fk or fk in key for fk in all_figs.keys()):
            unmatched.append(key)

    crit = "\n".join("- %s (가중치 %s)" % (x.get("name"), x.get("weight")) for x in (c.get("criteria") or [])) or "- (없음)"
    opts = "\n".join("- %s: %s" % (x.get("key"), x.get("label")) for x in (c.get("options") or [])) or "- (없음)"
    srcs = "\n".join("- [%s] %s %s %s" % (x.get("id"), x.get("org") or "", (x.get("title") or "")[:60], source.tag_for(x))
                     for x in (c.get("sources") or [])) or "- (후보 없음 — 근거를 지어내지 말 것)"
    issues = "\n".join("- " + str(i) for i in (c.get("issues") or [])) or "- (없음)"

    lines = ["# 정본 수치표 (이 문서와 다른 정의·수치·기준을 쓰지 말 것)",
             "※ 내부 파일명·함수명·코드 식별자(예: calc.py, canon, crosscheck, LEN(...) 같은 수식)를 "
             "본문 문장에 쓰지 마라 — 결재 문서 독자가 알 필요 없는 내부 구현이다. "
             "「코드가 계산함」처럼 필요할 때만 짧게 말로 적어라.",
             "## 검토 목적\n" + (c.get("purpose") or "—"),
             "## 용어 정의\n" + ("\n".join("- %s: %s" % kv for kv in (c.get("terms") or {}).items()) or "- (없음)"),
             "## 검토 논점 (2·3절에서 제기 → 5·6절에서 반드시 다룰 것)\n" + issues,
             "## 확정 수치 (코드 산출 — 이 목록 밖 수치 사용 금지)\n" + figs,
             "## 평가기준·가중치 (4절, 사용자 확정 — 임의 변경 금지)\n" + crit,
             "## 대안 목록 (4·5절)\n" + opts,
             "## 확정 출처 (이 목록 밖 근거 사용 금지)\n" + srcs]
    if unmatched:
        lines.append("## 계산 불가 — [확인 필요]로 둘 것 (목차 단계에서 필요하다고 적었으나 산출되지 않음)\n"
                     + "\n".join("- " + u for u in unmatched))

    ol = st.get("outline", {}).get("sections", [])
    if ol:
        lines.append("## 목차\n" + "\n".join(
            "%s %s — %s" % (section_label(st, str(s["n"]))["number"], s.get("title", ""),
                            " / ".join(str(i) for i in (s.get("items") or [])[:6]))
            for s in ol))
    return "\n".join(lines)


# ================================================================ 🏭 공식 체크리스트 코드 검사
# 근거: 국가공무원인재개발원 「정책기획 실습」(2018) p.083~084
# 이 셋은 LLM 이 아니라 코드가 판정한다 — 채점자(rubric)는 중복 지적하지 않는다.

def _tok(s: str) -> set:
    return source._tokens(s)


TITLE_MATCH_THRESHOLD = 0.34


def check_title_match(report_title: str, sections: list[dict], body: dict[str, str] | None = None) -> list[dict]:
    """#10 보고제목과 본문 제목이 동일한가 점검.

    보고제목의 핵심 토큰이 **절 제목 + 전 절 본문** 어디에서도 안 보이면 제목과 내용이 따로 노는 것이다.
    (교재 예시: 「지방재정개혁 상황보고」인데 본문 제목이 「지방재정개혁(안) 반대」·「현재 여론동향」)

    임계 0.34 — 제목의 핵심어 중 3분의 1도 본문에 안 나오면 지적한다. 보고서 제목에는
    「검토」·「방안」 같은 형식어가 섞여 있어 전수 일치를 요구하면 오탐만 난다(조립 중 실측 2026-09-20).
    """
    if not report_title:
        return [{"rule": "#10 제목 대조", "detail": "보고 제목이 비어 있음"}]
    parts = [(s.get("title") or "") + " " + " ".join(str(i) for i in (s.get("items") or []))
             for s in (sections or [])]
    if body:
        parts.extend(str(v) for v in body.values())      # 전 절 본문 — 1절만 보지 않는다
    t, b = _tok(report_title), _tok(" ".join(parts))
    if not t:
        return []
    missing = sorted(t - b)
    ratio = len(t & b) / len(t)
    if ratio < TITLE_MATCH_THRESHOLD:
        return [{"rule": "#10 제목 대조",
                 "detail": "보고 제목의 핵심어가 본문에 나타나지 않음 (일치 %.0f%%). 본문에 없는 말: %s"
                           % (ratio * 100, ", ".join(missing[:6]))}]
    return []


_PLAN_FIELDS = {
    "시기·일정": ["일정", "시기", "월", "분기", "상반기", "하반기", "단계"],
    "기한": ["기한", "까지", "완료", "마감", "목표일"],
    "협조부서": ["협조", "부서", "관계기관", "유관", "담당"],
    "단기/중장기": ["단기", "중기", "장기", "중장기", "연차"],
}


def check_plan_fields(plan_text: str) -> list[dict]:
    """#13 '추진계획' 작성 시 시기·일정·기한·협조부서·단기/중장기 포함 여부."""
    text = plan_text or ""
    out = []
    for field, kws in _PLAN_FIELDS.items():
        if not any(k in text for k in kws):
            out.append({"rule": "#13 추진계획 필수항목", "detail": "6절에 '%s' 관련 서술이 없음" % field})
    return out


def check_issue_coverage(issues: list[str], later_text: str, threshold: float = 0.4) -> list[dict]:
    """#14 **현황·문제점에서 언급된 내용은 추진계획·개선방안에서 반드시 언급 — 일관성.**

    2·3절에서 제기한 논점(canon.issues)이 5·6절 본문에서 다뤄졌는지 토큰 겹침으로 판정한다.
    이것이 2차 검증 정합성 패스의 공식 근거다.
    """
    out = []
    later = _tok(later_text)
    for iss in (issues or []):
        t = _tok(iss)
        if not t:
            continue
        cov = len(t & later) / len(t)
        if cov < threshold:
            out.append({"rule": "#14 논점 커버리지",
                        "detail": "논점 「%s」이(가) 개선방안·추진계획에서 다뤄지지 않음 (일치 %.0f%%)"
                                  % (str(iss)[:60], cov * 100)})
    return out


def structural_checks(st: dict, body: dict[str, str]) -> list[dict]:
    """위 세 검사를 한 번에. engine 의 2차 검증이 부른다."""
    c = st.get("canon", {})
    it = st.get("intake", {})
    sections = st.get("outline", {}).get("sections", [])
    issues = []
    issues += check_title_match(it.get("topic", ""), sections, body)
    issues += check_plan_fields(body.get("6", ""))
    issues += check_issue_coverage(c.get("issues") or [], (body.get("5", "") + "\n" + body.get("6", "")))
    return issues


# ---------------------------------------------------------------- 절간 정합성 패스 (2차 검증 본체)
def consistency_pass(st: dict, sections_md: dict[str, str], providers: list[str] | None = None) -> dict:
    """화면 「2차 검증」의 본체 — 전 절 완료 후 1회.

    절간 정합성뿐 아니라 ① 1차 검증(절별 채점) 점수가 후하지 않았는지 재판정 ② 1차 검증이 놓친 결함까지 본다.
    **코드 검사(structural_checks) 결과를 함께 넣어** LLM 이 그 항목을 다시 판단하지 않게 한다.
    providers: engine 이 ["codex","claude"] 로 명시 호출한다 — 다른 회사 AI 로 독립성 확보.
    """
    score_lines = ["%s절 — 1차 검증 %s점 (%s)" % (k, (st.get("sections", {}).get(k) or {}).get("score"),
                                                (st.get("sections", {}).get(k) or {}).get("status"))
                   for k in sorted(st.get("sections", {}).keys(), key=int)]
    code_found = structural_checks(st, sections_md)
    code_block = ("\n".join("- [%s] %s" % (i["rule"], i["detail"]) for i in code_found)
                  if code_found else "- (코드 검사 지적 없음)")

    prompt = "\n\n".join([
        canon_block(st),
        "# 과제 ① 절간 정합성\n아래 전 절 원고를 정본 수치표와 대조해 **불일치만** 찾아라. 문체·품질 평가 금지. "
        "찾을 것: 용어 정의 불일치 · 지표명/단위/기준시점 불일치 · 같은 출처를 다른 연도로 인용 · "
        "수치 불일치(2절↔4절↔7절) · 요약↔5절 권고안 불일치 · **4절 가중합 1위 안과 5절 권고안이 다른데 사유 설명이 없음**.",
        "# 각 절 1차 검증 결과 — 재판정 대상\n" + ("\n".join(score_lines) if score_lines else "(없음)"),
        "# 과제 ② 1차 점수 재판정\n위 점수가 실제 원고 수준에 비해 후하지 않았는지 다시 판단하라. "
        '후하다고 판단되면 issues 에 type="점수재판정" 으로 그 절·근거·바로잡을 방향을 적어라.',
        "# 과제 ③ 놓친 결함 지적\n1차 검증이 놓쳤을 법한 절별 결함을 찾아 issues 에 type=\"결함\" 으로 추가하라.",
        "# 코드가 이미 판정한 항목 (다시 판단하지 말 것 — 참고만)\n" + code_block,
        "\n\n".join("=== %s절 ===\n%s" % (k, v[:9000]) for k, v in sorted(sections_md.items(), key=lambda kv: int(kv[0]))),
        '# 출력 — JSON 하나만\n{"issues":[{"section":"3","type":"용어|지표|출처|수치|요약|대안|점수재판정|결함",'
        '"detail":"어디가 어떻게 다른가","fix":"무엇으로 맞출 것인가"}]}',
    ])
    r = llm.guarded_call_json(prompt, purpose="consistency", timeout=500, providers=providers)
    if not r["ok"]:
        # LLM 이 실패해도 **코드 검사 결과는 살린다** — 정합성 검사 전체가 날아가지 않게.
        return {"ok": False, "issues": [{"section": "", "type": "구조검사", "detail": i["detail"], "fix": ""} for i in code_found],
                "error": r["error"]}
    issues = (r["data"] or {}).get("issues", []) if isinstance(r["data"], dict) else []
    issues += [{"section": "", "type": "구조검사", "detail": i["detail"], "fix": "해당 절 보완"} for i in code_found]
    return {"ok": True, "issues": issues, "provider": r["provider"]}
