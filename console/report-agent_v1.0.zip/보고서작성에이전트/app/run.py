# -*- coding: utf-8 -*-
"""run.py — 터미널 진입점 (GUI 와 같은 engine.py 를 부른다. 자동화·원격·디버깅용, 병행 유지).

```
python run.py intake --topic "청사 주차난 해소 방안 검토" [--org public|enterprise]
                     [--to 기획조정실장] [--data "..."] [--file a.pdf --file b.xlsx]
                     [--names "김철수,대한물산"] [--force]
python run.py outline                 # 목차 제안
python run.py approve                 # 현재 제안 목차 승인(가중치 합 100·대안 3개 이상 통과해야 함)
python run.py run                     # 승인된 목차로 끝까지
python run.py section 3               # 3절만 (재)작성
python run.py scores o1=비용:4,효과:5 o2=...   # 4절 대안 원점수 입력(사람이 정한다)
python run.py verify | export | status | probe [--live]
python run.py settings length_mode=brief pass_score=90
```

⚠️ 이 파일은 **engine.py 의 실제 함수 이름과 시그니처에 묶여 있다.** 엔진을 고치면 여기도 같이 고친다.
   (V1 출하 검증 2026-09-21 지적 — 원자재 시그니처가 그대로 남아 호출 즉시 죽던 상태였다.)
"""
import sys, json, argparse
from pathlib import Path
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import engine, llm, store  # noqa: E402


def _parse_scores(items: list[str]) -> dict:
    """`o1=비용:4,효과:5` 꼴 → {"o1": {"비용": 4.0, "효과": 5.0}}"""
    out = {}
    for it in items:
        key, _, rest = it.partition("=")
        if not key or not rest:
            print("형식 오류(예: o1=비용:4,효과:5):", it); sys.exit(2)
        cells = {}
        for pair in rest.split(","):
            name, _, val = pair.partition(":")
            try:
                cells[name.strip()] = float(val)
            except ValueError:
                print("점수는 숫자여야 합니다:", pair); sys.exit(2)
        out[key.strip()] = cells
    return out


def main():
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd")

    i = sub.add_parser("intake")
    i.add_argument("--topic", required=True)
    i.add_argument("--org", default="enterprise", choices=["enterprise", "public"])
    i.add_argument("--to", dest="recipient", default="")
    i.add_argument("--data", default="")
    i.add_argument("--file", action="append", default=[])
    i.add_argument("--names", default="")
    i.add_argument("--force", action="store_true")

    sub.add_parser("outline"); sub.add_parser("approve"); sub.add_parser("run")
    sub.add_parser("verify"); sub.add_parser("export"); sub.add_parser("status")
    c = sub.add_parser("section"); c.add_argument("n")
    sc = sub.add_parser("scores"); sc.add_argument("kv", nargs="+", help="예: o1=비용:4,효과:5")
    p = sub.add_parser("probe"); p.add_argument("--live", action="store_true")
    s = sub.add_parser("settings"); s.add_argument("kv", nargs="*", help="예: length_mode=brief pass_score=90")
    a = ap.parse_args()

    try:
        if a.cmd == "intake":
            st = engine.intake(a.topic, org_type=a.org, recipient=a.recipient, data_desc=a.data,
                               files=a.file, names=[n.strip() for n in a.names.split(",") if n.strip()],
                               force=a.force)
            print("접수 완료 →", st["phase"])
        elif a.cmd == "outline":
            r = engine.propose_outline()
            print(json.dumps(r.get("outline") or r, ensure_ascii=False, indent=1))
        elif a.cmd == "approve":
            print(engine.approve_outline()["phase"])
        elif a.cmd == "run":
            print(json.dumps(engine.run_all(progress=lambda n: print("%s절 완료" % n)),
                             ensure_ascii=False, indent=1))
        elif a.cmd == "section":
            print(json.dumps(engine.write_section(a.n), ensure_ascii=False, indent=1))
        elif a.cmd == "scores":
            r = engine.set_option_scores(_parse_scores(a.kv))
            if r.get("errors"):
                print("보완 필요:\n- " + "\n- ".join(r["errors"])); sys.exit(2)
            print(json.dumps(r["ranking"], ensure_ascii=False, indent=1))
        elif a.cmd == "verify":
            print(json.dumps(engine.verify_sources()["summary"], ensure_ascii=False))
        elif a.cmd == "export":
            print(json.dumps(engine.export(), ensure_ascii=False, indent=1))
        elif a.cmd == "probe":
            print(json.dumps(llm.probe(live=a.live), ensure_ascii=False, indent=1))
        elif a.cmd == "settings":
            allowed = {"ai_disclosure", "max_calls_per_section", "max_minutes_per_section",
                       "pass_score", "length_mode"}
            upd = {}
            for kv in a.kv:
                k, _, v = kv.partition("=")
                if k not in allowed:
                    print("허용되지 않는 설정: %s (가능: %s)" % (k, ", ".join(sorted(allowed)))); sys.exit(2)
                if k == "length_mode":
                    upd[k] = v
                elif k == "ai_disclosure":
                    upd[k] = v.lower() in ("1", "true", "on")
                else:
                    try:
                        upd[k] = int(v)
                    except ValueError:
                        print("%s 는 숫자여야 합니다: %s" % (k, v)); sys.exit(2)
            if upd.get("length_mode") not in (None, "full", "brief"):
                print("length_mode 는 full 또는 brief"); sys.exit(2)
            store.update_state(lambda st: st["settings"].update(upd))
            print(json.dumps(store.load_state()["settings"], ensure_ascii=False))
        else:
            print(json.dumps(engine.status(), ensure_ascii=False, indent=1))
    except engine.Blocked as e:
        print("차단:", e); sys.exit(2)


if __name__ == "__main__":
    main()
