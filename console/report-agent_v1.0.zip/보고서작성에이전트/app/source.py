# -*- coding: utf-8 -*-
"""source.py — 출처 실존·내용 검증 게이트 (지어낸 근거 0건 보증의 코드 부분).

이 모듈이 이 에이전트의 **핵심 차별점**이다. 규칙 원본은 `app/skills/source.md`.

부품 출처(BOM 🟡): 원자재 thesis-agent `app/cite.py`
  sha256 cc3a2c8e0af50a3a69408ce44b749f14d6264c37be840b328e15426e0a7e0e08 (2026-09-20)
  ← 그 위로는 opendraft `multi_source.py`·`base.py` (MIT, Copyright (c) federicodeponte)
     커밋 89128b30d9857cf9b871cbebc88ec07832260b9a — THIRD_PARTY_NOTICES.md 참조

승계(🟢): `_get_json`(throttle·429 재시도·404=정상 구분) · 병렬 조회(ThreadPoolExecutor) ·
  **원부 값 강제 교체** · **장애(blocked) ↔ 미확인(unverified) 구분** · `export_gate` ·
  `set_manual_review`(증빙 fail-closed) · `tag_for` · `verification_table`
폐기(🔴): 학술 DB 어댑터 일체(`_crossref`·`_s2`·`_s2_batch`·`_openalex`·`_arxiv`·`search`) ·
  DOI 체계(`normalize_doi`·`is_korean`·`required_confirmations`) — 보고서에는 DOI 원부가 없다.
자체 제작(🏭): 2단 등급제 · 공공 통계 원부 어댑터(`_kosis`·`_ecos`) · **URL 실접속 + 본문 대조**
  (`_live_fetch`·`content_match`) · 허용 도메인 로더(skills/web_allowlist.md 단일 출처)

원칙
- **LLM 은 근거를 생성하지 않는다.** 후보는 vault(사용자 자료) 또는 실제 조회 결과뿐.
- **「URL 이 살아있다」는 검증이 아니다.** 그 페이지 본문에 인용 내용이 실제로 있어야 한다.
- 검증 못 한 것을 "검증됨"으로 적지 않는다. API 장애는 blocked — 미확인과 구분한다.
"""
from __future__ import annotations
import json, re, time, html, urllib.request, urllib.parse, urllib.error
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

try:
    from . import store  # type: ignore
except ImportError:
    import store  # type: ignore

APP = Path(__file__).resolve().parent
SKILLS = APP / "skills"

UA = "report-agent/1.0 (local desktop; contact: none)"
TEXT_SIM_THRESHOLD = 0.5        # 문장 대조 임계 — opendraft 실측값 승계(철자·조사 차이 흡수)
_MIN_INTERVAL = 0.3             # 같은 호스트 연속 호출 간격
_last_call: dict = {}

# ---------------------------------------------------------------- 등급 (skills/source.md 와 1:1)
GRADE_REGISTRY = "registry"          # [원부검증] 공공 통계 API 조회 성공 + 값 일치
GRADE_LIVE = "live"                  # [출처확인] URL 실접속 200 + 본문 대조 성공
GRADE_INTERNAL = "internal"          # [내부자료] 사내 문서 — 자동검증 대상 아님
GRADE_MANUAL = "manual_review"       # 사용자 증빙(4요소)
GRADE_UNVERIFIED = "unverified"      # [미검증] 접속 실패·본문에 없음·값 불일치
GRADE_BLOCKED = "blocked"            # [검증대기] API·네트워크 장애로 판정 불가

EXPORTABLE = {GRADE_REGISTRY, GRADE_LIVE, GRADE_MANUAL}
# ⚠️ internal 은 EXPORTABLE 에 없다 — 사내 문서는 사용자 증빙(manual_review)으로 승격해야 나간다.


# ---------------------------------------------------------------- 텍스트 유사도 (🟢 opendraft 승계)
_STOP = frozenset("의 가 이 은 는 을 를 에 에서 으로 로 와 과 도 만 및 등 a an the of on in for and or to with is are at by from as its it this that".split())


def _tokens(t: Optional[str]) -> set:
    if not t:
        return set()
    tk = set(re.findall(r"[a-z0-9가-힣]+", str(t).lower()))
    return (tk - _STOP) or tk


def text_similarity(a: Optional[str], b: Optional[str]) -> float:
    x, y = _tokens(a), _tokens(b)
    if not x or not y:
        return 0.0
    return len(x & y) / min(len(x), len(y))


# ---------------------------------------------------------------- 허용 도메인 (🏭, SSOT = skills/web_allowlist.md)
_ALLOW_CACHE: dict = {"mtime": None, "domains": None}


def allowed_domains() -> list[str]:
    """`skills/web_allowlist.md` 의 백틱 안 도메인을 읽는다. **코드에 하드코딩하지 않는다.**"""
    p = SKILLS / "web_allowlist.md"
    if not p.exists():
        return []
    mt = p.stat().st_mtime
    if _ALLOW_CACHE["mtime"] == mt and _ALLOW_CACHE["domains"] is not None:
        return _ALLOW_CACHE["domains"]
    text = p.read_text(encoding="utf-8")
    doms = []
    for m in re.finditer(r"`([^`]+)`", text):
        tok = m.group(1).strip().lower()
        if re.fullmatch(r"\.?[a-z0-9.-]+\.[a-z]{2,}", tok):
            doms.append(tok.lstrip("."))
    doms = sorted(set(doms))
    _ALLOW_CACHE.update({"mtime": mt, "domains": doms})
    return doms


def is_allowed(url: str) -> bool:
    try:
        host = (urllib.parse.urlparse(url).hostname or "").lower()
    except ValueError:
        return False
    if not host:
        return False
    return any(host == d or host.endswith("." + d) for d in allowed_domains())


# ---------------------------------------------------------------- HTTP (🟢 승계, urllib만)
def _throttle(key: str, need: float = _MIN_INTERVAL) -> None:
    gap = time.monotonic() - _last_call.get(key, 0)
    if gap < need:
        time.sleep(need - gap)


def _get_json(url: str, headers: dict | None = None, timeout: int = 20, throttle_key: str = "", _retry: bool = False):
    """(data, err). err=None & data=None → '정상 응답인데 없음'. err 있음 → 장애(blocked 사유)."""
    if throttle_key:
        _throttle(throttle_key)
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", "replace")
        _last_call[throttle_key] = time.monotonic()
        try:
            return json.loads(raw), None
        except ValueError:
            return None, "parse: JSON 아님"
    except urllib.error.HTTPError as e:
        _last_call[throttle_key] = time.monotonic()
        if e.code == 404:
            return None, None                     # 없음 = 정상 응답
        if e.code == 429 and not _retry:
            time.sleep(12)
            return _get_json(url, headers, timeout, throttle_key, _retry=True)
        return None, "HTTP %d" % e.code           # 장애
    except (urllib.error.URLError, TimeoutError, ValueError) as e:
        return None, "network: %s" % e


_TAG_RE = re.compile(r"<(script|style)[^>]*>.*?</\1>", re.S | re.I)
_ANY_TAG = re.compile(r"<[^>]+>")


def normalize_url(url: str) -> str:
    """IRI → URI. 한글·공백이 든 경로·질의를 퍼센트 인코딩한다.

    국내 공공 사이트 URL 에 한글이 그대로 들어오는 일이 잦다. 인코딩하지 않으면 urllib 가
    UnicodeEncodeError(ValueError 하위)를 던지고, 그게 네트워크 장애로 오분류돼
    **미확인이어야 할 출처가 「검증대기」로 남아 영원히 재시도**된다(조립 중 실측 2026-09-20).
    """
    try:
        p = urllib.parse.urlsplit(str(url).strip())
    except ValueError:
        return str(url)
    try:
        host = p.hostname.encode("idna").decode("ascii") if p.hostname else ""
    except (UnicodeError, AttributeError):
        host = p.hostname or ""
    netloc = host + ((":%d" % p.port) if p.port else "")
    if p.username:
        netloc = p.username + (":" + p.password if p.password else "") + "@" + netloc
    path = urllib.parse.quote(p.path, safe="/%:@&=+$,;~*'()!")
    query = urllib.parse.quote(p.query, safe="/%:@&=+$,;?~*'()!")
    return urllib.parse.urlunsplit((p.scheme, netloc, path, query, ""))   # fragment 는 서버로 안 보낸다


def _live_fetch(url: str, timeout: int = 20):
    """🏭 URL 실접속 → 본문 텍스트. (text, err). 허용 도메인 밖이면 즉시 거부."""
    if not is_allowed(url):
        return None, "not_allowed"
    if not str(url).lower().startswith(("http://", "https://")):
        return None, "scheme"
    host = urllib.parse.urlparse(url).hostname or "host"
    safe_url = normalize_url(url)
    _throttle(host)
    try:
        req = urllib.request.Request(safe_url, headers={"User-Agent": UA,
                                                        "Accept": "text/html,application/xhtml+xml,*/*"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            ctype = (r.headers.get("Content-Type") or "").lower()
            body = r.read(3_000_000)
    except urllib.error.HTTPError as e:
        return None, "HTTP %d" % e.code
    except UnicodeError as e:
        # 인코딩 실패는 장애가 아니라 **주소가 잘못된 것** — 재시도 대상으로 두지 않는다.
        return None, "badurl: %s" % e
    except (urllib.error.URLError, TimeoutError, ValueError) as e:
        return None, "network: %s" % e
    finally:
        _last_call[host] = time.monotonic()

    enc = "utf-8"
    m = re.search(r"charset=([A-Za-z0-9_-]+)", ctype)
    if m:
        enc = m.group(1)
    text = body.decode(enc, "replace")
    if "html" in ctype or "<html" in text[:2000].lower():
        text = _TAG_RE.sub(" ", text)
        text = _ANY_TAG.sub(" ", text)
        text = html.unescape(text)
    return re.sub(r"\s+", " ", text).strip(), None


# ---------------------------------------------------------------- 🏭 본문 대조
_NUM_TOKEN = re.compile(r"-?\d{1,3}(?:,\d{3})+(?:\.\d+)?|-?\d+(?:\.\d+)?")


def _num_variants(tok: str) -> set:
    """1234.5 ↔ 1,234.5 ↔ 1234.50 등 표기 차이를 흡수."""
    t = tok.replace(",", "")
    out = {tok, t}
    try:
        f = float(t)
    except ValueError:
        return out
    out.update({("%g" % f), ("%.1f" % f), ("%.2f" % f).rstrip("0").rstrip(".")})
    if f == int(f):
        out.add(str(int(f)))
        out.add("{:,}".format(int(f)))
    else:
        out.add("{:,}".format(f))
    return {x for x in out if x}


# ── 한국어 문맥 대조 ───────────────────────────────────────────────
# ★ V2 4차 재확인까지 네 번 고친 끝에 **접근을 바꿨다**(2026-09-21).
#   종전: 조사 목록을 손으로 적고 어간을 떼어 비교 → 복합 조사(「에는」)·조각(「것으」)·
#        의존명사 제외 과잉이 꼬리를 물었다. 정규식으로 형태소 분석을 흉내 내는 짓이었다.
#   지금: **조사는 말 뒤에 붙는다**는 성질만 쓴다 — 앞부분이 같으면 같은 말로 본다.
#        목록도, 예외도, 조각도 없다.
_PREFIX_MIN = 2          # 같은 말로 보려면 앞 2글자 이상이 같아야 한다(한글은 2글자면 변별된다)
_MAX_TAIL = 5            # 뒤에 붙을 수 있는 조사 길이 상한.
                         # 3 으로 잡았다가 「대상으로부터」·「담당자에게서는」(4글자)이 막혔다(V2 실측 2026-09-22).
                         # 올려도 과잉 매칭이 늘지 않는 이유 — 꼬리 글자가 전부 _TAIL_CHARS 여야 하므로
                         # 「대상자에게」(자)·「교육과정에서」(정)처럼 명사 조각이 섞이면 그대로 걸린다.
# 조사·어미에 쓰이는 **글자**만 모았다. 구(句) 목록이 아니라 글자 집합이라
# 「에는·으로도·에게만」 같은 복합 조사가 저절로 통과하고, 「자선정」 같은 어절은 걸린다.
_TAIL_CHARS = frozenset("은는이가을를의에서으로도만과와게께라야조차마저부터까지보다처럼")
# 1글자 꼬리는 **홀로 쓰이는 조사**만 인정한다.
# (「서」는 「에서」의 일부일 뿐 홀로는 조사가 아니다 — 이걸 허용하면 「보고」 ↔ 「보고서」가 같은 말이 된다)
_TAIL_ONE = frozenset("은는이가을를의에도만과와로야라")


# 용언 활용 어미 — 「상승」 ↔ 「상승하였다」 처럼 **의미의 뿌리는 같고 서술만 붙은** 경우.
# ⚠️ 여기서 목록을 쓰는 것은 앞서 실패한 「어간 떼기」와 다르다.
#    그때는 말을 **잘라내** 조각이 남고 예외가 꼬리를 물었다.
#    지금은 잘라내지 않고 **꼬리가 이 목록에 있는가만 본다** — 목록에 없으면 그냥 다른 말로 본다(fail-safe).
_TAIL_VERB = frozenset("""하였다 하였음 하였고 하였으며 했다 했음 한다 하는 하여 해 함 됨 되었다 된다 되는 되어
                          이다 임 이었다 였다 있다 있음 없다 없음 시켰다 시킴""".split())


def _is_particle_tail(tail: str) -> bool:
    """접두가 같을 때 **뒤에 남은 부분**이 조사(또는 서술 어미)인가. 빈 문자열이면 동일어."""
    if tail == "":
        return True
    if tail in _TAIL_VERB:
        return True
    if len(tail) == 1:
        return tail in _TAIL_ONE
    return len(tail) <= _MAX_TAIL and all(ch in _TAIL_CHARS for ch in tail)


def _same_word(a: str, b: str) -> bool:
    """공통 접두가 같고 **양쪽에 남은 꼬리가 둘 다 조사**면 같은 말로 본다.

    「이탈률이」 ↔ 「이탈률은」 — 공통 접두 「이탈률」, 꼬리 「이」·「은」 → 같은 말.
    「대상자선정」 ↔ 「대상」    — 공통 접두 「대상」,   꼬리 「자선정」 → 조사가 아니므로 다른 말.
    """
    n = 0
    for x, y in zip(a, b):
        if x != y:
            break
        n += 1
    if n < _PREFIX_MIN:
        return False
    return _is_particle_tail(a[n:]) and _is_particle_tail(b[n:])


def _appears_in(word: str, page_tokens: set) -> bool:
    """`word` 가 본문에 (조사가 붙은 형태로라도) 나오는가.

    ★ V2 4차까지 네 번 고친 끝에 얻은 방식(2026-09-21).
      조사 **구(句) 목록**을 적고 어간을 떼는 방식은 복합 조사·조각·의존명사 예외가 꼬리를 물었다.
      지금은 ① 공통 접두 ② 남은 꼬리가 조사 **글자**로만 이루어졌는가 — 두 가지만 본다.
      영문·숫자는 접두 비교가 위험하므로(report ↔ reportedly) 완전 일치만 인정한다.

    ⚠️ 판정이 애매하면 **막는 쪽**이 맞다 — 이 제품은 확인 못 한 것을 확인됐다고 적지 않는다.
       놓친 인용은 사용자가 「검토 증빙」으로 올릴 수 있지만, 잘못 통과시킨 근거는 되돌릴 수 없다.
    """
    if word in page_tokens:
        return True
    if not re.search(r"[가-힣]", word):
        return False
    return any(_same_word(word, t) for t in page_tokens if re.search(r"[가-힣]", t))


def content_match(page_text: str, claim: str) -> dict:
    """🏭 인용 내용이 그 페이지 본문에 실제로 있는지 판정.

    「HTTP 200 이니까 출처가 확인됐다」를 막는 함수다. 두 조건을 모두 본다:
      ① claim 에 숫자가 있으면 **그 숫자가 전부 본문에 존재**해야 한다(표기 변형 허용)
      ② 문장 토큰 겹침이 임계(0.5) 이상이어야 한다
    반환 {"ok", "similarity", "numbers_found", "numbers_missing", "reason"}
    """
    page = re.sub(r"\s+", " ", page_text or "")
    page_nospace = page.replace(",", "")
    nums = _NUM_TOKEN.findall(claim or "")
    found, missing = [], []
    for n in nums:
        if any((v in page) or (v.replace(",", "") in page_nospace) for v in _num_variants(n)):
            found.append(n)
        else:
            missing.append(n)
    sim = text_similarity(claim, page)
    # ★ V2(Codex) Critical 지적 2026-09-21 — 종전에는 숫자가 있으면 문맥 검사를 **건너뛰었다**.
    #   그러면 전혀 다른 맥락(예: "열람실 좌석 18.7 제곱미터")에 같은 숫자만 있어도 [출처확인]이 나가
    #   「URL 이 살아있다는 건 검증이 아니다」라는 이 제품의 주장이 통째로 무너진다.
    #   → 숫자와 문맥을 **둘 다** 본다.
    #
    #   문맥 판정은 토큰 유사도가 아니라 **핵심어 포함률**로 한다. 한국어는 조사가 붙어
    #   「이탈률」과 「이탈률은」이 다른 토큰이 되므로, 유사도만 쓰면 정상 인용도 떨어진다(실측).
    #   숫자를 뺀 핵심어가 본문에 부분 문자열로 들어 있는 비율을 본다.
    page_tokens = _tokens(page)
    key_words = [w for w in _tokens(claim) if not any(c.isdigit() for c in w) and len(w) >= 2]
    hit = [w for w in key_words if _appears_in(w, page_tokens)]
    ctx_ratio = (len(hit) / len(key_words)) if key_words else 0.0

    # ★ V2(Codex) 재확인 지적 2026-09-21 — 앞선 수정에서 「숫자뿐인 인용은 문맥을 따질 수 없다」며
    #   `ctx_ratio = 1.0` 을 줬는데, 그게 **원래 fail-open 과 같은 결과**였다.
    #   숫자만 있는 인용은 그 숫자가 무엇을 가리키는지 알 수 없으므로 **통과시키지 않는다.**
    #   사용자가 「검토 증빙」으로 올릴 수는 있다 — 자동 판정만 거부한다.
    if not key_words:
        return {"ok": False, "similarity": round(sim, 2), "context_ratio": 0.0,
                "numbers_found": found, "numbers_missing": missing,
                "reason": "인용에 수치만 있고 무엇에 대한 수치인지가 없어 대조할 수 없음 — "
                          "지표명·대상을 함께 적거나 「검토 증빙」으로 처리하십시오"}

    # 임계 — 종전 0.5 는 「핵심어 절반만 겹쳐도 통과」라 느슨했다(V2 지적). 2/3 로 올린다.
    need_ctx = (2.0 / 3.0 - 1e-9) if nums else TEXT_SIM_THRESHOLD   # 2/3 — 0.67 로 쓰면 2/3 이 미달로 떨어진다
    basis = ctx_ratio if nums else max(ctx_ratio, sim)
    ok = (not missing) and (basis >= need_ctx)

    reason = ""
    if missing:
        reason = "본문에 없는 수치: " + ", ".join(missing[:5])
    elif basis < need_ctx:
        missed = [w for w in key_words if w not in page]
        reason = ("문맥 일치도 미달 (%.2f < %.2f) — 같은 숫자가 다른 맥락에 있을 뿐일 수 있음%s"
                  % (basis, need_ctx, (" · 본문에 없는 말: " + ", ".join(missed[:5])) if missed else ""))
    return {"ok": ok, "similarity": round(sim, 2), "context_ratio": round(ctx_ratio, 2),
            "numbers_found": found, "numbers_missing": missing, "reason": reason}


# ---------------------------------------------------------------- 🏭 공공 통계 원부 어댑터
def _keys() -> dict:
    try:
        return store.load_config("keys") or {}
    except Exception:
        return {}


def _kosis(rec: dict):
    """KOSIS 국가통계포털. 필요 키: keys.json 의 `kosis`.

    rec 필수: table_id(orgId+tblId) · item(itmId) · period(prdDe) · obj(objL1)
    반환 (found|None, err). err='no_key' 는 **장애가 아니라 미구성**이다 — 호출 측이 live 로 폴백한다.
    """
    key = _keys().get("kosis")
    if not key:
        return None, "no_key"
    q = {
        "method": "getList", "apiKey": key, "format": "json", "jsonVD": "Y",
        "orgId": rec.get("org_id", "101"), "tblId": rec.get("table_id", ""),
        "itmId": rec.get("item", ""), "objL1": rec.get("obj", "ALL"),
        "prdSe": rec.get("period_type", "Y"), "startPrdDe": rec.get("period", ""),
        "endPrdDe": rec.get("period", ""),
    }
    url = "https://kosis.kr/openapi/Param/statisticsParameterData.do?" + urllib.parse.urlencode(q)
    data, err = _get_json(url, throttle_key="kosis")
    if err:
        return None, err
    if not data:
        return None, None
    if isinstance(data, dict) and data.get("errCd"):
        return None, None                       # 조회 결과 없음(정상 응답)
    rows = data if isinstance(data, list) else []
    if not rows:
        return None, None
    r0 = rows[0]
    return {"value": r0.get("DT"), "unit": r0.get("UNIT_NM"), "period": r0.get("PRD_DE"),
            "label": r0.get("ITM_NM") or r0.get("TBL_NM"), "provider": "KOSIS"}, None


def _ecos(rec: dict):
    """한국은행 ECOS. 필요 키: keys.json 의 `ecos`. rec 필수: table_id · period_type · period · item"""
    key = _keys().get("ecos")
    if not key:
        return None, "no_key"
    parts = [key, "json", "kr", "1", "5", rec.get("table_id", ""),
             rec.get("period_type", "A"), rec.get("period", ""), rec.get("period", "")]
    if rec.get("item"):
        parts.append(rec["item"])
    url = "https://ecos.bok.or.kr/api/StatisticSearch/" + "/".join(urllib.parse.quote(str(p), safe="") for p in parts)
    data, err = _get_json(url, throttle_key="ecos")
    if err:
        return None, err
    if not data:
        return None, None
    body = (data.get("StatisticSearch") or {}) if isinstance(data, dict) else {}
    rows = body.get("row") or []
    if not rows:
        return None, None
    r0 = rows[0]
    return {"value": r0.get("DATA_VALUE"), "unit": r0.get("UNIT_NAME"), "period": r0.get("TIME"),
            "label": r0.get("ITEM_NAME1"), "provider": "ECOS"}, None


REGISTRIES = {"kosis": _kosis, "ecos": _ecos}


def _values_equal(a, b, tol: float = 1e-6) -> bool:
    try:
        return abs(float(str(a).replace(",", "")) - float(str(b).replace(",", ""))) <= tol
    except (TypeError, ValueError):
        return str(a).strip() == str(b).strip()


# ---------------------------------------------------------------- 검증
def _now() -> str:
    return store.now_iso()


def verify_one(rec: dict) -> dict:
    """출처 레코드 1건 검증 → 등급 부여. 원본 dict 을 변형하지 않고 사본을 돌려준다.

    rec.kind: "registry" | "live" | "internal"  (없으면 provider/url/doc 로 추론)
    """
    rec = dict(rec)
    rec["checked_at"] = _now()
    kind = rec.get("kind") or ("registry" if rec.get("provider") else ("live" if rec.get("url") else "internal"))
    rec["kind"] = kind

    if rec.get("status") == GRADE_MANUAL:          # 사용자 증빙은 재검증하지 않는다
        return rec

    if kind == "internal":
        rec["status"] = GRADE_INTERNAL
        rec["note"] = "사내 자료 — 자동검증 대상 아님. 사용자 증빙(확인자·일시·방식·위치)으로 승격 필요."
        return rec

    # ── Tier 1: 공공 통계 원부
    if kind == "registry":
        fn = REGISTRIES.get(str(rec.get("provider", "")).lower())
        if fn is None:
            rec["status"] = GRADE_UNVERIFIED
            rec["note"] = "지원하지 않는 원부 provider: %r (지원: %s)" % (rec.get("provider"), ", ".join(REGISTRIES))
            return rec
        found, err = fn(rec)
        if err == "no_key":
            # 키 미구성은 **장애가 아니다.** URL 이 있으면 Tier 2 로 내려가 정직하게 판정한다.
            rec["note"] = "원부 API 키 미구성(config/keys.json) — URL 실접속 검증으로 대체 시도"
            if rec.get("url"):
                kind = rec["kind"] = "live"
            else:
                rec["status"] = GRADE_UNVERIFIED
                rec["note"] += " · URL 도 없어 검증 불가 — URL 제공 또는 사용자 증빙 필요"
                return rec
        elif err:
            rec["status"] = GRADE_BLOCKED
            rec["note"] = "원부 조회 장애(%s) — 복구 후 재검증" % err
            return rec
        elif found is None:
            rec["status"] = GRADE_UNVERIFIED
            rec["note"] = "원부에 해당 항목이 없음 — 통계표ID·항목·시점을 확인하거나 출처를 교체"
            return rec
        else:
            rec["registry"] = found
            claimed = rec.get("value")
            if claimed is not None and not _values_equal(claimed, found.get("value")):
                # ★ 원부 값 강제 교체 — 실존 통계표에 엉뚱한 숫자를 붙인 근거가 그대로 실리지 않게.
                rec["value_input"] = claimed
                rec["value"] = found.get("value")
                rec["note"] = "입력값(%s)이 원부 값(%s)과 달라 **원부 값으로 교체**함" % (claimed, found.get("value"))
            else:
                rec["value"] = found.get("value")
            rec.setdefault("unit", found.get("unit"))
            rec.setdefault("period", found.get("period"))
            rec["status"] = GRADE_REGISTRY
            rec["confirmed_by"] = found.get("provider")
            return rec

    # ── Tier 2: URL 실접속 + 본문 대조
    url = rec.get("url") or ""
    if not url:
        rec["status"] = GRADE_UNVERIFIED
        rec["note"] = "URL 이 없어 검증 불가"
        return rec
    if not is_allowed(url):
        rec["status"] = GRADE_UNVERIFIED
        rec["note"] = "[비허용 출처] 허용 도메인 목록(skills/web_allowlist.md) 밖 — 본문 근거로 쓸 수 없음"
        return rec

    page, err = _live_fetch(url)
    if err in ("not_allowed", "scheme"):
        rec["status"] = GRADE_UNVERIFIED
        rec["note"] = "[비허용 출처] " + err
        return rec
    if err:
        if str(err).startswith("badurl"):
            rec["status"] = GRADE_UNVERIFIED       # 주소 자체가 잘못됨 → 재시도해도 같다
            rec["note"] = "URL 형식 오류(%s) — 주소를 확인하거나 출처를 교체" % err
        elif str(err).startswith(("HTTP 4",)):
            rec["status"] = GRADE_UNVERIFIED       # 404·403 = 그 자리에 문서가 없다 → 미확인
            rec["note"] = "URL 접속 실패(%s) — 링크 만료 가능. 교체하거나 사용자 증빙 필요" % err
        else:
            rec["status"] = GRADE_BLOCKED          # 5xx·네트워크 = 판정 불가 → 재시도
            rec["note"] = "접속 장애(%s) — 복구 후 재검증" % err
        return rec

    claim = rec.get("claim") or rec.get("quote") or rec.get("title") or ""
    if not claim:
        rec["status"] = GRADE_UNVERIFIED
        rec["note"] = "대조할 인용 내용(claim)이 비어 있음 — 접속만으로는 검증이 아님"
        return rec
    m = content_match(page, claim)
    rec["match"] = m
    if m["ok"]:
        rec["status"] = GRADE_LIVE
        rec["confirmed_by"] = "URL 실접속 + 본문 대조"
    else:
        rec["status"] = GRADE_UNVERIFIED
        rec["note"] = "페이지는 열렸으나 본문에 해당 내용이 없음 — " + (m["reason"] or "대조 실패")
    return rec


def verify_all(sources: list[dict], max_workers: int = 4) -> list[dict]:
    """전체 검증(병렬). blocked 가 하나라도 있으면 state.blocked 를 세운다."""
    if not sources:
        store.update_state(lambda st: st.__setitem__("blocked", None))
        return []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        out = list(ex.map(verify_one, sources))
    if any(c.get("status") == GRADE_BLOCKED for c in out):
        store.update_state(lambda st: st.__setitem__(
            "blocked", {"code": "BLOCKED_SOURCE_VERIFICATION", "since": store.now_iso(),
                        "retries": (st.get("blocked") or {}).get("retries", 0) + 1}))
    else:
        store.update_state(lambda st: st.__setitem__("blocked", None))
    return out


def set_manual_review(rec: dict, reviewer: str, method: str, evidence: str, at: str = "") -> dict:
    """🟢 사용자 증빙 승격. **확인자·확인 방식·증빙 위치·확인일시 4요소가 모두 없으면 거부**(fail-closed)."""
    if not (reviewer and method and evidence):
        raise ValueError("확인자·확인 방식·증빙(URL 또는 문서 위치) 세 가지가 모두 필요합니다.")
    rec = dict(rec)
    rec["manual_review"] = {"reviewer": reviewer, "method": method, "evidence": evidence,
                            "at": at or store.now_iso()}
    rec["status"] = GRADE_MANUAL
    return rec


# ---------------------------------------------------------------- export 게이트 (🟢 승계)
def export_gate(sources: list[dict]) -> dict:
    """{'ok': bool, 'blocking': [...], 'summary': {...}}. **ok=False 면 DOCX 조립 금지.**

    경고가 아니라 차단이다 — 지어낸 근거가 결재 문서로 나가는 것을 막는 마지막 관문.
    """
    blocking = [c for c in sources if c.get("status") not in EXPORTABLE]
    # 자동검증 성공률의 분모에서 internal·manual_review 는 뺀다 — 성공률을 부풀리지 않는다.
    auto = [c for c in sources if c.get("status") not in (GRADE_INTERNAL, GRADE_MANUAL)]
    auto_ok = [c for c in auto if c.get("status") in (GRADE_REGISTRY, GRADE_LIVE)]
    return {
        "ok": not blocking,
        "blocking": blocking,
        "summary": {
            "total": len(sources),
            "registry": sum(1 for c in sources if c.get("status") == GRADE_REGISTRY),
            "live": sum(1 for c in sources if c.get("status") == GRADE_LIVE),
            "internal_pending": sum(1 for c in sources if c.get("status") == GRADE_INTERNAL),
            "manual_review": sum(1 for c in sources if c.get("status") == GRADE_MANUAL),
            "unverified": sum(1 for c in sources if c.get("status") == GRADE_UNVERIFIED),
            "blocked": sum(1 for c in sources if c.get("status") == GRADE_BLOCKED),
            "auto_success_rate": (round(len(auto_ok) / len(auto), 3) if auto else None),
        },
    }


def tag_for(rec: dict) -> str:
    """본문에 붙는 등급 태그. 읽는 사람이 어디를 의심해야 할지 보이게 한다."""
    s = rec.get("status")
    if s == GRADE_REGISTRY:
        return "[원부검증]"
    if s == GRADE_LIVE:
        return "[출처확인]"
    if s == GRADE_INTERNAL:
        return "[내부자료]"
    if s == GRADE_MANUAL:
        return ""                      # 사용자가 증빙한 것은 태그 없이 본문에
    if s == GRADE_BLOCKED:
        return "[검증대기]"
    return "[미검증]"


# ---------------------------------------------------------------- 붙임 출처 검증표
def verification_table(sources: list[dict]) -> list[list[str]]:
    """붙임에 들어가는 검증표. **전 항목을 나열한다 — 실패한 것도 사유와 함께.**"""
    rows = [["번호", "출처", "URL / 통계표ID", "확인 방식", "등급", "확인 일시"]]
    for i, c in enumerate(sources, 1):
        org = c.get("org") or c.get("publisher") or ""
        title = c.get("title") or c.get("claim") or ""
        year = c.get("year") or c.get("period") or ""
        bib = " ".join(x for x in [org, ("「%s」" % title[:70]) if title else "", ("(%s)" % year) if year else ""] if x).strip() or "—"

        ident = c.get("url") or c.get("table_id") or c.get("doc") or "—"

        if c.get("manual_review"):
            mr = c["manual_review"]
            how = "사용자 증빙 — %s, %s" % (mr.get("reviewer", ""), mr.get("method", ""))
        elif c.get("status") == GRADE_REGISTRY:
            how = "공공 통계 API 조회(%s)" % (c.get("confirmed_by") or c.get("provider") or "")
            if c.get("value_input") is not None:
                how += " · 입력값 %s → 원부값 %s 로 교체" % (c["value_input"], c.get("value"))
        elif c.get("status") == GRADE_LIVE:
            m = c.get("match") or {}
            how = "URL 실접속 + 본문 대조(일치도 %s)" % m.get("similarity", "—")
        elif c.get("status") == GRADE_INTERNAL:
            how = "사내 자료 — 자동검증 대상 아님"
        else:
            how = c.get("note") or "검증 실패"

        rows.append([str(i), bib, str(ident), how, tag_for(c) or c.get("status", ""), c.get("checked_at", "")])
    return rows


# ---------------------------------------------------------------- 후보 관리
def add_candidate(sources: list[dict], rec: dict) -> list[dict]:
    """후보 등록(중복 제거). 후보는 vault 또는 실제 조회 결과에서만 온다 — LLM 이 만들지 않는다."""
    key = (rec.get("url") or "") + "|" + (rec.get("table_id") or "") + "|" + (rec.get("doc") or "") + "|" + (rec.get("title") or "")
    for c in sources:
        ck = (c.get("url") or "") + "|" + (c.get("table_id") or "") + "|" + (c.get("doc") or "") + "|" + (c.get("title") or "")
        if ck == key:
            return sources
    rec = dict(rec)
    rec.setdefault("id", "S-%02d" % (len(sources) + 1))
    rec.setdefault("status", None)
    sources.append(rec)
    return sources
