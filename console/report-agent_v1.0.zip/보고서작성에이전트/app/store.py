# -*- coding: utf-8 -*-
"""store.py — state.json·history.json·logs 원자적 쓰기 + 잠금.

부품 출처(BOM 🟢): 공증 사무 보조 에이전트 store.py `_atomic_write_json` + RLock 3종.
- tmp 파일명에 pid·thread id를 넣어 동시 쓰기 lost-update 방지 → os.replace.
- 상태(state)·이력(history)·로그(log)는 각각 다른 락 — 한 락에 몰면 로그 때문에 상태 저장이 밀린다.
"""
from __future__ import annotations
import json, os, shutil, threading, time, datetime
from pathlib import Path

APP = Path(__file__).resolve().parent
STATE_PATH = APP / "state.json"
HISTORY_PATH = APP / "history.json"
LOG_DIR = APP / "logs"
CONFIG_DIR = APP / "config"

_STATE_LOCK = threading.RLock()
_HISTORY_LOCK = threading.RLock()
_LOG_LOCK = threading.Lock()


class _FileLock:
    """프로세스 간 상호배제 — UI 서버와 run.py 가 동시에 state 를 쓰는 것을 막는다(threading 락은 한 프로세스 안에서만 유효).
    V4.3 이식(templates/store_skeleton.py)."""
    def __init__(self, path: Path, timeout: float = 8.0):
        self.lock = path.with_suffix(path.suffix + ".lock"); self.timeout = timeout; self.fd = None

    def __enter__(self):
        t0 = time.monotonic()
        while True:
            try:
                self.fd = os.open(str(self.lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY); os.write(self.fd, str(os.getpid()).encode()); return self
            except FileExistsError:
                try:
                    if time.time() - self.lock.stat().st_mtime > 60:      # 죽은 프로세스가 남긴 잠금
                        self.lock.unlink()
                        continue
                except OSError:
                    pass
                if time.monotonic() - t0 > self.timeout:
                    raise TimeoutError("state 잠금 대기 초과 — 다른 프로세스(UI/run.py)가 쓰는 중")
                time.sleep(0.05)

    def __exit__(self, *a):
        try:
            if self.fd is not None:
                os.close(self.fd)
            self.lock.unlink()
        except OSError:
            pass


def _atomic_write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name("%s.%d.%d.tmp" % (path.name, os.getpid(), threading.get_ident()))
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass


def _read_json(path: Path, default):
    if not path.exists():
        return default
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        # 손상 파일은 옆에 보존하고 기본값으로 — 조용히 덮어쓰지 않는다
        bad = path.with_suffix(path.suffix + ".corrupt.%d" % int(time.time()))
        try:
            os.replace(path, bad)
        except OSError:
            pass
        return default


# ---------------------------------------------------------------- state
def default_state() -> dict:
    return {
        "version": 1,
        "created": now_iso(),
        "org_profile": {},            # 조직 프로필(org_profile.json 의 active 프리셋 병합본 — 기업/공공)
        "intake": {},                 # 조직 유형·주제·수신·입력 파일·가명화 대상 명단 유무
        "outline": {"sections": [], "approved": False, "approved_at": None},
        # 정본 수치표 — 본문 수치의 유일한 출처. LLM 이 여기 없는 수치를 쓰면 crosscheck 가 [확인 필요] 로 잡는다.
        "canon": {
            "terms": {},              # 용어 정의 {용어: 정의}
            "issues": [],             # 검토 논점 — 2·3절에서 제기 → 5·6절 커버리지 대조(체크리스트 #14)의 기준
            "figures": {},            # {지표명: {value, unit, basis_date, formula, source_id, grade}}
            "criteria": [],           # 4절 평가기준 [{name, weight}] — 가중치 합 100, 사용자가 정한다
            "options": [],            # 4절 대안 [{key, label}] — 3개 이상
            "sources": [],            # 확정 출처 id 목록
        },
        "pseudonym_names": [],        # 가명화 대상 실명 — 재시작 후에도 복원돼야 실명이 새지 않는다(원자재 V1 D3)
        "sections": {},               # "1": {"status": "pending|drafting|done|stalled", "score": .., "calls": n, "started": iso, "critique": [], "versions": []}
        "sources": [],                # source.py 레코드 (등급: registry|live|internal|manual_review|unverified|blocked)
        "phase": "intake",            # intake|outline|awaiting_approval|writing|consistency|verifying|exporting|done|blocked
        "blocked": None,              # {"code": "BLOCKED_SOURCE_VERIFICATION", "since": iso, "retries": n}
        "export": {"path": None, "postprocess": []},
        "settings": {"ai_disclosure": True, "max_calls_per_section": 15, "max_minutes_per_section": 30, "pass_score": 90, "length_mode": "full"},   # length_mode: full(정식) | brief(약식 — 시제·실습)
    }


def load_state() -> dict:
    with _STATE_LOCK:
        st = _read_json(STATE_PATH, None)
        if st is None:
            st = default_state()
            _atomic_write_json(STATE_PATH, st)
        return st


BACKUP_DIR = STATE_PATH.parent / "state_backups"
_PHASE_MARK = {"v": None}


def backup_state(tag: str = "manual") -> Path:
    """state.json 스냅샷 — state_backups/state_{tag}_{ts}.json. 최근 20개만 보관."""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    dst = BACKUP_DIR / ("state_%s_%s.json" % (tag, datetime.datetime.now().strftime("%Y%m%d_%H%M%S")))
    if STATE_PATH.exists():
        shutil.copy2(STATE_PATH, dst)
    olds = sorted(BACKUP_DIR.glob("state_*.json"), key=lambda p: p.stat().st_mtime)
    for p in olds[:-20]:
        try:
            p.unlink()
        except OSError:
            pass
    return dst


def save_state(st: dict) -> None:
    with _STATE_LOCK, _FileLock(STATE_PATH):
        # 단계가 바뀔 때마다 직전 상태를 스냅샷 — 덮어쓰기 사고(2026-09-17) 복구용. 재시작 직후에는 파일의 phase 를 기준으로 삼는다
        # (V4.3 수정 — 이전엔 새 프로세스마다 _PHASE_MARK 가 None 으로 리셋돼 재부팅 때마다 "phase_intake" 백업이 잘못 쌓였다).
        if STATE_PATH.exists():
            if _PHASE_MARK["v"] is None:
                _PHASE_MARK["v"] = (_read_json(STATE_PATH, {}) or {}).get("phase")
            if _PHASE_MARK["v"] is not None and st.get("phase") != _PHASE_MARK["v"]:
                backup_state("phase_%s" % _PHASE_MARK["v"])
        _PHASE_MARK["v"] = st.get("phase")
        st["updated"] = now_iso()
        _atomic_write_json(STATE_PATH, st)


def update_state(fn) -> dict:
    """fn(state) -> None. 읽기-수정-쓰기를 한 락 안에서."""
    with _STATE_LOCK:
        st = load_state()
        fn(st)
        save_state(st)
        return st


# ---------------------------------------------------------------- history (호출 집계)
def append_history(entry: dict) -> None:
    with _HISTORY_LOCK:
        h = _read_json(HISTORY_PATH, {"version": 1, "calls": []})
        entry.setdefault("ts", now_iso())
        h["calls"].append(entry)
        _atomic_write_json(HISTORY_PATH, h)


def history_summary() -> dict:
    with _HISTORY_LOCK:
        h = _read_json(HISTORY_PATH, {"calls": []})
    calls = h.get("calls", [])
    return {
        "total_calls": len(calls),
        "by_provider": _count(calls, "provider"),
        "failures": sum(1 for c in calls if not c.get("ok", True)),
    }


def _count(items, key):
    out = {}
    for it in items:
        out[it.get(key, "?")] = out.get(it.get(key, "?"), 0) + 1
    return out


# ---------------------------------------------------------------- log (행위자 구분)
def log(actor: str, message: str, **extra) -> None:
    """actor: '사용자' | '시스템' | 'AI'. 공증 에이전트 ACTOR 규칙 — 누가 한 일인지 구분."""
    LOG_DIR.mkdir(exist_ok=True)
    line = {"ts": now_iso(), "actor": actor, "msg": message}
    if extra:
        line.update(extra)
    with _LOG_LOCK:
        with open(LOG_DIR / ("%s.jsonl" % datetime.date.today().isoformat()), "a", encoding="utf-8") as f:
            f.write(json.dumps(line, ensure_ascii=False) + "\n")


def recent_logs(n: int = 100) -> list:
    LOG_DIR.mkdir(exist_ok=True)
    files = sorted(LOG_DIR.glob("*.jsonl"))
    out = []
    for fp in files[-2:]:
        with open(fp, encoding="utf-8") as f:
            for ln in f:
                try:
                    out.append(json.loads(ln))
                except json.JSONDecodeError:
                    continue
    return out[-n:]


# ---------------------------------------------------------------- config
def load_config(name: str, default: dict | None = None) -> dict:
    return _read_json(CONFIG_DIR / name, default or {})


def save_config(name: str, data: dict) -> None:
    _atomic_write_json(CONFIG_DIR / name, data)


def now_iso() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")
