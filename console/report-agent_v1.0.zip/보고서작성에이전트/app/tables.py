# -*- coding: utf-8 -*-
"""tables.py — 표 파일(csv/xlsx) 결정론 집계 (D-006).

헌법 5조 실행부: **수치는 코드가 계산한다.** 사용자가 올린 표(csv/xlsx)의 행 수·합계·평균·
범주별 집계·연도별 추이를 LLM 없이 순수 파이썬(+pandas)으로 산출해 `calc.register_result` 로
`canon.figures` 에 등재하는 것이 이 모듈의 유일한 일이다.

이전에는(D-006 결함) `engine._digest_files()` 가 표 파일을 "[표 형식 파일 — calc.py 로 산출] 파일명"
한 줄로만 남기고, 그 산출을 실제로 부르는 코드가 어디에도 없었다 — 그래서 표의 수치가 보고서에
절대 들어가지 못했다. `engine.approve_outline()` 이 승인 시점에 이 모듈을 호출해 그 구멍을 메운다.

LLM 에게는 `schema_summary()` 만 보여준다 — 열 이름·자료형·행 수·범주 값 목록뿐, 합계·평균 같은
**값은 절대 넣지 않는다**(LLM 이 암산해서 지어내는 경로를 원천 차단).
"""
from __future__ import annotations
import re
from pathlib import Path

try:
    from . import calc  # type: ignore
except ImportError:
    import calc  # type: ignore

try:
    import pandas as pd            # 표 파일 적재 전용
except ImportError:
    pd = None

# 파일당·전체 등재 상한 — 조용히 자르지 않는다(notes 에 생략 건수를 남긴다).
MAX_FIGURES_PER_FILE = 60
MAX_FIGURES_TOTAL = 150
MAX_CATEGORY_UNIQUE = 12          # 이보다 고유값이 많으면 범주열로 보지 않는다(식별자 열 오탐 방지)

_UNIT_RE = re.compile(r"\(([^()]+)\)\s*$")           # 열 이름 끝 괄호 → 단위. 예: "계약금액(백만원)"
_YEAR_NAME_RE = re.compile(r"연도|년도|year", re.I)


class TableReadError(Exception):
    """표 파일을 읽을 수 없음 — 사유를 담아 호출부(engine)가 로그·화면에 정직하게 남길 수 있게 한다."""


def available() -> bool:
    """pandas 설치 여부. xlsx 는 openpyxl 도 필요(없으면 read_table 이 TableReadError 를 낸다)."""
    return pd is not None


# ---------------------------------------------------------------- 표 적재
def read_table(path):
    """csv/xlsx/xls → DataFrame. 실패는 예외를 삼키지 않고 사유를 담아 TableReadError 로 알린다.

    csv 인코딩: utf-8-sig 우선 → 실패(UnicodeDecodeError)하면 cp949 재시도
    (한국 엑셀에서 내보낸 CSV 는 cp949 가 흔하다). 금액 열의 천단위 쉼표(`"1,150"`)는 `thousands=","` 로 처리.
    """
    if not available():
        raise TableReadError("pandas 미설치 — 표 파일(xlsx/csv) 집계 불가. `pip install pandas` 필요")
    p = Path(path)
    if not p.exists():
        raise TableReadError("파일 없음: %s" % p.name)
    suf = p.suffix.lower()
    if suf == ".csv":
        try:
            return pd.read_csv(p, encoding="utf-8-sig", thousands=",")
        except UnicodeDecodeError:
            try:
                return pd.read_csv(p, encoding="cp949", thousands=",")
            except Exception as e:
                raise TableReadError(
                    "%s 읽기 실패(csv) — utf-8-sig·cp949 모두 실패: %s" % (p.name, e)) from e
        except Exception as e:
            raise TableReadError("%s 읽기 실패(csv): %s" % (p.name, e)) from e
    if suf in (".xlsx", ".xls"):
        try:
            return pd.read_excel(p)
        except ImportError as e:
            raise TableReadError("%s 읽기 실패 — openpyxl 미설치: %s" % (p.name, e)) from e
        except Exception as e:
            raise TableReadError("%s 읽기 실패(xlsx): %s" % (p.name, e)) from e
    raise TableReadError("지원하지 않는 표 형식: %s (지원: csv/xlsx/xls)" % (p.suffix or "(확장자 없음)"))


# ---------------------------------------------------------------- 구조 요약 (목차 LLM 전용 — 값 없음)
def schema_summary(path) -> str:
    """목차 제안 LLM 용 **구조 요약만**. 열 이름·자료형·행 수·범주 값 목록만 — 합계·평균 등 값은 절대 넣지 않는다.

    LLM 이 「figures_needed」를 구체적으로 계획할 수 있게 열 구조는 보여주되,
    값을 보여주면 LLM 이 암산해서 본문에 옮겨 적는 경로가 생긴다 — 그것을 막는 게 이 함수의 존재 이유.
    """
    try:
        df = read_table(path)
    except TableReadError as e:
        return "[표 구조 요약 실패] %s" % e
    lines = ["행 수: %d" % len(df)]
    for col in df.columns:
        s = df[col]
        num = pd.to_numeric(s, errors="coerce")
        is_num = num.notna().sum() >= max(1, int(len(s) * 0.9)) and num.notna().sum() > 0
        kind = "숫자" if is_num else "문자"
        uniq = s.dropna().astype(str).unique()
        if not is_num and 0 < len(uniq) <= MAX_CATEGORY_UNIQUE:
            lines.append("- %s (%s, 범주값: %s)" % (col, kind, ", ".join(sorted(uniq)[:MAX_CATEGORY_UNIQUE])))
        else:
            lines.append("- %s (%s)" % (col, kind))
    return "\n".join(lines)


# ---------------------------------------------------------------- 결정론 집계 (값 산출 — 여기서만)
def _unit_of(col: str) -> str:
    m = _UNIT_RE.search(str(col).strip())
    return m.group(1).strip() if m else ""


def _base_name(col: str) -> str:
    return _UNIT_RE.sub("", str(col)).strip()


def _round_num(x, digits: int = 4):
    """정수로 떨어지면 int, 아니면 반올림한 float. (1150.0 → 1150)"""
    if x is None:
        return None
    r = round(float(x), digits)
    return int(r) if float(r).is_integer() else r


# D-012(V2R2 지적 2) — 엑셀에서 «숫자가 텍스트 서식」으로 저장된 칸(복사·붙여넣기로 흔함)은
# '1,150' 처럼 천단위 쉼표가 든 문자열로 들어온다. csv 는 read_table 의 `thousands=","` 가 처리하지만
# xlsx·직접 공급 DataFrame 은 이 쉼표 때문에 pd.to_numeric 이 실패해 **숫자열로도 못 잡히고**
# (고유값이 12개 이하면 범주열로, 넘으면 통째로) 열 전체가 조용히 사라졌다(합계·평균 미등재, notes 도 없음).
# 「깔끔한 천단위 쉼표 숫자」만 쉼표를 제거해 숫자 판정에 태우고, 괄호 음수 `(1,150)`·`△1,150`·`▲`
# 같은 회계 표기는 **음수로 추정하지 않고** 그대로 둔다 — 그러면 pd.to_numeric 이 그대로 실패해
# 기존 fail-closed(_numeric_cell_issues) 가 «깨진 칸」으로 잡는다(회계 해석은 사람 몫).
_THOUSANDS_TEXT_RE = re.compile(r"^-?\d{1,3}(?:,\d{3})+(?:\.\d+)?$")


def _normalize_numeric_series(s):
    """문자열 칸의 순수 천단위 쉼표만 제거한 새 시리즈. 쉼표 없는 값·괄호/△/▲ 등은 그대로 둔다."""
    if s.dtype != object:
        return s

    def norm_one(v):
        if isinstance(v, str):
            t = v.strip()
            if _THOUSANDS_TEXT_RE.match(t):
                return t.replace(",", "")
        return v
    return s.map(norm_one)


def _is_numeric_series(s, n_total: int) -> "tuple":
    num = pd.to_numeric(s, errors="coerce")
    ok = num.notna().sum() >= max(1, int(n_total * 0.9)) and num.notna().sum() > 0
    return ok, num


def _numeric_cell_issues(raw, num) -> "tuple":
    """(비숫자·비결측 칸 수, 그 칸의 원본 값 예시 목록, 결측 칸 수).

    D-012(V2 지적 3) — 숫자열로 판정된(90% 이상 숫자 변환) 열에도 나머지 10% 안에 수식(`=100+200`)·
    문자 같은 «깨진 칸»이 섞일 수 있다. `pd.to_numeric(errors="coerce")`는 이를 조용히 NaN 으로 바꿔
    결측과 구분이 안 됐다 — 그래서 합계·평균이 그 칸을 빼고 계산된 값을 «정상 집계»인 것처럼 등재했다.
    여기서 «원래 비어 있지 않은데 숫자 변환에 실패한 칸»(=깨진 칸)과 «원래 빈 칸»(=결측)을 구분한다.
    """
    blank_mask = raw.isna() | (raw.astype(str).str.strip() == "")
    bad_mask = num.isna() & ~blank_mask
    bad_vals = raw[bad_mask].astype(str).tolist()
    return int(bad_mask.sum()), bad_vals, int(blank_mask.sum())


def _is_year_series(base: str, num, n_total: int) -> bool:
    if _YEAR_NAME_RE.search(base):
        return True
    vals = num.dropna()
    if vals.empty or vals.notna().sum() < n_total * 0.9:
        return False
    return bool(vals.apply(lambda x: float(x).is_integer() and 1900 <= x <= 2100).all())


def profile_table(path, source_id: str, basis_date: str = "") -> "tuple":
    """표 파일 1건 → (figures, notes). figures 원소: {"key","value","unit","formula"}.

    등재 대상 — 행 수 / 숫자 열 합계·평균 / 범주 열(고유값 ≤12) 값별 건수·숫자열 합계 /
    연도형 열의 연도별 건수·숫자열 합계 + 인접·처음→끝 증감률 + 범주열×연도 건수.
    파일당·전체 등재 상한(MAX_FIGURES_PER_FILE·MAX_FIGURES_TOTAL) — 잘리면 notes 에
    몇 건을 등재하지 못했는지 반드시 남긴다.
    """
    fname = Path(path).name
    stem = Path(path).stem
    df = read_table(path)
    n_rows = int(len(df))

    figures: list = []
    notes: list = []
    skipped = {"n": 0}

    def add(key, value, unit, formula):
        if len(figures) >= MAX_FIGURES_PER_FILE:
            skipped["n"] += 1
            return
        figures.append({"key": key, "value": value, "unit": unit, "formula": formula})

    add("%s · 행 수" % stem, n_rows, "건", "COUNT(%s)" % fname)

    numeric_cols, categorical_cols, year_cols = [], [], []
    for col in df.columns:
        base = _base_name(col)
        unit = _unit_of(col)
        # D-012(V2R2 지적 2) — 숫자열 판정(90%)·합계/평균 계산 모두 「천단위 쉼표 제거 후」 값으로 한다.
        # 정규화는 순수 쉼표 숫자만 건드리므로 괄호 음수·△·▲ 는 그대로 남아 아래 fail-closed 가 잡는다.
        norm_col = _normalize_numeric_series(df[col])
        is_num, num = _is_numeric_series(norm_col, n_rows)
        if is_num and _is_year_series(base, num, n_rows):
            year_cols.append((col, base, unit, num))
            continue
        if is_num:
            # D-012(V2 지적 3) fail-closed — 깨진(비숫자·비결측) 칸이 하나라도 있으면 이 열의
            # 합계·평균·연도별 합산 계열을 아예 등재하지 않는다(행 수 등 무관 집계는 그대로 유지).
            bad_n, bad_vals, blank_n = _numeric_cell_issues(norm_col, num)
            if bad_n > 0:
                sample = bad_vals[0] if bad_vals else "?"
                notes.append(
                    "%s · %s: 숫자가 아닌 칸 %d개(예: '%s') — 합계·평균을 정본에 올리지 않음"
                    % (fname, base, bad_n, sample))
                continue
            if blank_n > 0:
                notes.append("%s · %s: 빈 칸 %d개 제외" % (fname, base, blank_n))
            numeric_cols.append((col, base, unit, num))
            continue
        uniq = df[col].dropna().astype(str).unique()
        if 0 < len(uniq) <= MAX_CATEGORY_UNIQUE:
            categorical_cols.append((col, base, unit))

    # 숫자 열 — 합계·평균
    for col, base, unit, num in numeric_cols:
        vals = num.dropna()
        if vals.empty:
            continue
        add("%s · %s 합계" % (stem, base), _round_num(vals.sum()), unit, "SUM(%s[%s])" % (fname, col))
        add("%s · %s 평균" % (stem, base), _round_num(round(float(vals.mean()), 1)), unit,
            "AVG(%s[%s])" % (fname, col))

    # 범주 열 — 값별 건수 + 숫자열 합계
    for col, base, unit in categorical_cols:
        counts = df[col].astype(str).value_counts()
        for val, cnt in counts.items():
            add("%s · %s=%s · 건수" % (stem, base, val), int(cnt), "건",
                "COUNT(%s WHERE %s=%s)" % (fname, base, val))
            mask = df[col].astype(str) == val
            for ncol, nbase, nunit, num in numeric_cols:
                sub = num[mask].dropna()
                if sub.empty:
                    continue
                add("%s · %s=%s · %s 합계" % (stem, base, val, nbase), _round_num(sub.sum()), nunit,
                    "SUM(%s WHERE %s=%s)[%s]" % (fname, base, val, ncol))

    # 연도형 열 — 연도별 건수·숫자열 합계 + 증감률 + 범주×연도 건수
    for col, base, unit, num in year_cols:
        years = sorted(int(y) for y in num.dropna().unique())
        counts_by_year = {}
        for y in years:
            mask_y = num == y
            cnt = int(mask_y.sum())
            counts_by_year[y] = cnt
            add("%s · %s=%s · 건수" % (stem, base, y), cnt, "건", "COUNT(%s WHERE %s=%s)" % (fname, base, y))
            for ncol, nbase, nunit, nnum in numeric_cols:
                sub = nnum[mask_y].dropna()
                if sub.empty:
                    continue
                add("%s · %s=%s · %s 합계" % (stem, base, y, nbase), _round_num(sub.sum()), nunit,
                    "SUM(%s WHERE %s=%s)[%s]" % (fname, base, y, ncol))

        if len(years) >= 2:
            for i in range(1, len(years)):
                y0, y1 = years[i - 1], years[i]
                r = calc.pct_change(counts_by_year[y1], counts_by_year[y0])
                f = r.get("formula", "")
                if r.get("note"):
                    f = f + " — " + r["note"]
                add("%s · %s 건수 증감률 %s→%s" % (stem, base, y0, y1), r.get("value"), r.get("unit"), f)
            r_all = calc.pct_change(counts_by_year[years[-1]], counts_by_year[years[0]])
            f_all = r_all.get("formula", "")
            if r_all.get("note"):
                f_all = f_all + " — " + r_all["note"]
            add("%s · %s 건수 증감률 %s→%s(전체)" % (stem, base, years[0], years[-1]),
                r_all.get("value"), r_all.get("unit"), f_all)

            for ncol, nbase, nunit, nnum in numeric_cols:
                year_sums = {}
                for y in years:
                    sub = nnum[num == y].dropna()
                    year_sums[y] = float(sub.sum()) if not sub.empty else None
                have = [y for y in years if year_sums[y] is not None]
                for i in range(1, len(have)):
                    y0, y1 = have[i - 1], have[i]
                    r = calc.pct_change(year_sums[y1], year_sums[y0])
                    f = r.get("formula", "")
                    if r.get("note"):
                        f = f + " — " + r["note"]
                    add("%s · %s=%s→%s · %s 합계 증감률" % (stem, base, y0, y1, nbase), r.get("value"), r.get("unit"), f)
                if len(have) >= 2:
                    r_all = calc.pct_change(year_sums[have[-1]], year_sums[have[0]])
                    f_all = r_all.get("formula", "")
                    if r_all.get("note"):
                        f_all = f_all + " — " + r_all["note"]
                    add("%s · %s=%s→%s(전체) · %s 합계 증감률" % (stem, base, have[0], have[-1], nbase),
                        r_all.get("value"), r_all.get("unit"), f_all)

        # 범주열 × 연도 건수 — 예: 공종=충전기 × 연도별 건수
        for ccol, cbase, cunit in categorical_cols:
            for val in df[ccol].astype(str).unique():
                mask_val = df[ccol].astype(str) == val
                for y in years:
                    cnt = int((mask_val & (num == y)).sum())
                    if cnt == 0:
                        continue
                    add("%s · %s=%s · %s=%s · 건수" % (stem, cbase, val, base, y), cnt, "건",
                        "COUNT(%s WHERE %s=%s AND %s=%s)" % (fname, cbase, val, base, y))

    if skipped["n"]:
        notes.append("%s: 정본 수치 상한(%d건)에 걸려 %d건을 등재하지 못했습니다 — 필요하면 별도로 확인하세요"
                     % (fname, MAX_FIGURES_PER_FILE, skipped["n"]))
    return figures, notes
