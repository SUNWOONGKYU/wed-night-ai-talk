# -*- coding: utf-8 -*-
"""ui.py — 로컬 웹 GUI 서버 (표준 라이브러리만). 에신 「로컬 GUI(웹) 출하 표준」 ui.py 필수 요건 8.

부품 출처(BOM 🟢): 공증 ui.py — 출입증 토큰(사용자 로컬 폴더, 쿠키 승격 302), 고정 포트 + SO_EXCLUSIVEADDRUSE(Windows),
terminate_previous(잠금 PID → 같은 ui.py 파이썬 → 포트 점유자), 경로 탈출 차단, 덮어쓰기 금지, 조용한 종료, favicon 204, 종료 안내.
재단: 라우트를 보고서 도메인으로. 액션봇은 실행형(+confirm) — 공증(조회 전용)과 다름.
V4.2(C1) 추가: /api/setup·/api/setup/run — setup_helper.py 명령표로 Claude/Codex 설치·로그인 단추를 화면에서 실행.

실행: python ui.py  (시작.bat이 부른다). 환경변수: UI_ALLOW_MULTI=1(다중 인스턴스 허용), NO_BROWSER=1(탭 자동 열기 끔).
"""
from __future__ import annotations
import http.server, socketserver, socket, json, os, re, sys, time, uuid, secrets, subprocess, threading, webbrowser, urllib.parse, io
from email.parser import BytesParser
from email.policy import default as _email_policy
from http import HTTPStatus
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.stderr.reconfigure(encoding="utf-8", errors="replace")
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import store, llm, engine, source, guard, calc, outline, docx_build, setup_helper, uicontract  # noqa: E402

UI_DIR = BASE / "ui"
UPLOAD_DIR = BASE / "uploads"; UPLOAD_DIR.mkdir(exist_ok=True)
RUNTIME_DIR = BASE / ".runtime"; RUNTIME_DIR.mkdir(exist_ok=True)
LOCK_FILE = RUNTIME_DIR / "ui.lock"
# 브랜드 — 소속·개인 이름을 앞에 붙이고 싶으면 여기에 넣는다(예: BRAND = "한국개발"). 비워 두면 이름만 쓴다.
# 화면 헤더·창 제목·DOCX 고지문에 다 반영된다. index.html 의 <title>·<h1>·종료 안내문도 같이 고칠 것.
BRAND = ""                                              # PO 지시로 브랜드 없이 출하(2026-09-22)
APP_NAME = ("%s 보고서 작성 에이전트" % BRAND).strip()   # BRAND 가 비면 앞 공백이 남으므로 strip
VERSION = "1.0"
PORT = 7752
COOKIE = "report_auth"
MAX_BODY = 64 * 1024 * 1024
INSTANCE = uuid.uuid4().hex


# ---------------------------------------------------------------- 토큰 (공증 🟢)
def _token_path() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return Path(base) / "report-agent" / "token"        # 원자재 식별자 제거(V1 2026-09-22). 폴더명이 바뀌므로 토큰은 새로 발급된다


def _load_or_make_token(renew: bool = False) -> str:
    p = _token_path()
    if not renew:
        try:
            t = p.read_text(encoding="ascii").strip()
            if re.fullmatch(r"[A-Za-z0-9_-]{20,64}", t):
                return t
        except Exception:
            pass
    t = secrets.token_urlsafe(24)
    try:
        p.parent.mkdir(parents=True, exist_ok=True); p.write_text(t, encoding="ascii")
    except Exception:
        pass
    return t


TOKEN = _load_or_make_token("--new-token" in sys.argv)


# ---------------------------------------------------------------- 프로세스 관리 (공증 🟢)
def _run_ps(script: str) -> str:
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], capture_output=True, text=True, timeout=15, encoding="utf-8", errors="replace")
        return r.stdout or ""
    except Exception:
        return ""


def _kill_pid(pid: int) -> bool:
    if pid <= 0 or pid == os.getpid():
        return False
    try:
        r = subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], capture_output=True, timeout=12, shell=False)
        return r.returncode == 0
    except Exception:
        return False


def _find_sibling_pids() -> list:
    me = os.getpid(); marker = str(Path(__file__).resolve()).lower()
    out = _run_ps("Get-CimInstance Win32_Process -Filter \"Name='python.exe' or Name='pythonw.exe'\" | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress")
    try:
        data = json.loads(out) if out.strip() else []
    except Exception:
        return []
    if isinstance(data, dict):
        data = [data]
    return [int(r.get("ProcessId") or 0) for r in data if r.get("ProcessId") and int(r["ProcessId"]) != me and marker in (r.get("CommandLine") or "").lower()]


def _port_owner(port: int) -> int:
    out = _run_ps(f"(Get-NetTCPConnection -LocalPort {port} -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1).OwningProcess")
    try:
        return int(out.strip())
    except Exception:
        return 0


def _read_lock() -> dict:
    try:
        return json.loads(LOCK_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_lock(port: int) -> None:
    LOCK_FILE.write_text(json.dumps({"pid": os.getpid(), "port": port, "instance": INSTANCE, "started": time.time()}), encoding="utf-8")


def terminate_previous() -> int:
    """화면은 마지막 하나만 — 기존 서버 전부 종료."""
    killed = set()
    pid = int(_read_lock().get("pid") or 0)
    if pid and pid != os.getpid() and _kill_pid(pid):
        killed.add(pid)
    for p in _find_sibling_pids():
        if p not in killed and _kill_pid(p):
            killed.add(p)
    owner = _port_owner(PORT)
    if owner and owner != os.getpid() and owner not in killed and _kill_pid(owner):
        killed.add(owner)
    for _ in range(20):
        if _port_owner(PORT) == 0:
            break
        time.sleep(0.15)
    return len(killed)


# ---------------------------------------------------------------- 서버
class _Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):   # Windows — 이미 LISTEN 중인 포트 재바인딩 차단
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


_JOBS: dict[str, dict] = {}
_JOBS_LOCK = threading.Lock()
_ACTIVE_MUTATION = {"jid": None, "name": ""}
_PROBE = {"cli": None, "running": False}      # 부팅 시 배경 실호출 결과 캐시
PROFILE_REQUIRED = list(engine.PROFILE_REQUIRED)   # 비어 있으면 좌측 「기준」 블록을 펼친다 (단일 출처 = engine)


def _background_probe():
    _PROBE["running"] = True
    try:
        _PROBE["cli"] = llm.probe(live=True)
    finally:
        _PROBE["running"] = False   # 상태를 바꾸는 작업은 한 번에 하나만(V2 2026-09-17 D4 — 두 창 동시 실행 경쟁 방지)


class Busy(Exception):
    pass


def _valid_section(n: str) -> bool:
    """목차에 실제로 있는 절 번호인지 — 장별 API(저장·재작성·부분수정·자료첨부)가 임의 번호를 받지 않게 막는다(V1.0 UAT 관찰 반영)."""
    st = store.load_state()
    return n in {str(c.get("n")) for c in (st.get("outline") or {}).get("sections", [])}


def _job(fn, *a, **kw) -> str:
    """상태를 바꾸는 백그라운드 작업. 이미 하나가 돌고 있으면 Busy — 호출자는 409로 돌려준다."""
    jid = uuid.uuid4().hex[:12]
    with _JOBS_LOCK:
        act = _ACTIVE_MUTATION["jid"]
        if act and _JOBS.get(act, {}).get("status") == "running":
            raise Busy("다른 작업(%s)이 진행 중입니다 — 끝난 뒤 다시 누르세요" % _ACTIVE_MUTATION["name"])
        _JOBS[jid] = {"status": "running", "started": time.time(), "result": None, "error": None, "name": getattr(fn, "__name__", "job")}
        _ACTIVE_MUTATION.update(jid=jid, name=getattr(fn, "__name__", "job"))

    def _run():
        try:
            res = fn(*a, **kw)
            with _JOBS_LOCK:
                _JOBS[jid].update(status="done", result=res)
        except engine.Blocked as e:
            store.log("시스템", "작업 막힘: %s" % e, job=jid)   # 결함 A — 감사 기록에도 사유를 남긴다(예전엔 화면에 전혀 안 보였다)
            with _JOBS_LOCK:
                _JOBS[jid].update(status="blocked", error=str(e))
        except Exception as e:
            store.log("시스템", "작업 오류: %s" % e, job=jid)
            with _JOBS_LOCK:
                _JOBS[jid].update(status="error", error=llm.human_reason(str(e)) + " (" + str(e)[:120] + ")")
        finally:
            with _JOBS_LOCK:
                if _ACTIVE_MUTATION["jid"] == jid:
                    _ACTIVE_MUTATION.update(jid=None, name="")
    threading.Thread(target=_run, daemon=True).start()
    return jid


def _safe_filename(name: str) -> str:
    name = Path(str(name).replace("\\", "/")).name
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return name or "upload"


def _unique(p: Path) -> Path:   # 덮어쓰기 금지
    if not p.exists():
        return p
    k = 2
    while p.with_name("%s(%d)%s" % (p.stem, k, p.suffix)).exists():
        k += 1
    return p.with_name("%s(%d)%s" % (p.stem, k, p.suffix))


# 액션봇 — 실행형: 화이트리스트 액션 + 비가역은 needs_confirm
_ACTIONS = {
    "status": {"irreversible": False, "desc": "진행 상태 조회"},
    "propose_outline": {"irreversible": False, "desc": "목차 초안 생성"},
    "approve_outline": {"irreversible": True, "desc": "목차 승인(이후 절 생성 시작)"},
    "write_section": {"irreversible": False, "desc": "특정 절 (재)작성"},
    "run_all": {"irreversible": False, "desc": "승인된 목차로 끝까지 진행"},
    "verify_sources": {"irreversible": False, "desc": "출처 실접속·원부 검증"},
    "set_option_scores": {"irreversible": False, "desc": "대안별 평가 원점수 입력(가중합은 코드가 계산)"},
    "export": {"irreversible": True, "desc": "DOCX 생성"},
}


def _chat(message: str) -> dict:
    """액션봇: 메시지 → 같은 LLM 채널로 의도 파악(JSON) → 화이트리스트 액션 실행 또는 답변. 비가역은 confirm 필요."""
    st = engine.status()
    prompt = "\n\n".join([
        "너는 「보고서 작성 에이전트」 안의 액션봇이다. 사용자의 말을 읽고 (a) 실행할 액션 하나를 고르거나 (b) 그냥 답한다. 보고서 내용을 대신 쓰지 않는다.",
        "허용 액션: " + json.dumps({k: v["desc"] for k, v in _ACTIONS.items()}, ensure_ascii=False),
        "현재 상태: " + json.dumps(st, ensure_ascii=False)[:2000],
        "사용자: " + message[:2000],
        '출력 — JSON 하나만: {"action": "status|propose_outline|approve_outline|write_section|run_all|verify_sources|set_option_scores|export|null", "args": {"section":"3"} 또는 {}, "reply": "사용자에게 할 말(한국어, 2문장 이내)"}',
    ])
    # ★ V2 재확인 지적 2026-09-21 — 액션봇 대화는 **사용자가 직접 타이핑**하는 곳이라
    #   실명·사번이 그대로 들어온다. 관문(가명화 + 누출 스캔 fail-closed)을 반드시 거친다.
    r = llm.guarded_call_json(prompt, purpose="chat", timeout=120)
    if not r["ok"]:
        return {"reply": "잠시 답을 만들지 못했습니다 — " + llm.human_reason(r["error"]), "action": None}
    d = r["data"] or {}
    act = d.get("action") if d.get("action") in _ACTIONS else None
    out = {"reply": d.get("reply", ""), "action": act, "args": d.get("args") or {}}
    if act and _ACTIONS[act]["irreversible"]:
        out["needs_confirm"] = True
        out["reply"] = (out["reply"] + " — 되돌리기 어려운 작업입니다. «그대로 진행»을 누르면 실행합니다.").strip()
    return out


def _run_action(act: str, args: dict) -> dict:
    if act not in _ACTIONS:
        raise engine.Blocked("허용되지 않은 액션: %s" % act)
    if act == "status":
        return engine.status()
    if act == "propose_outline":
        return {"job": _job(engine.propose_outline)}
    if act == "approve_outline":
        # 결함 B — 화면 버튼(approve())은 승인 뒤 곧바로 /api/run(run_all)을 이어서 부른다.
        # 채팅 액션봇으로 승인했을 때도 같은 후속 동작을 하게 맞춘다(안 맞으면 채팅 승인은 목차만
        # 확정되고 절 집필이 시작되지 않아 사용자가 "왜 안 써지나" 를 겪는다).
        st = engine.approve_outline(args.get("outline"))
        return {"phase": st["phase"], "job": _job(engine.run_all)}
    if act == "write_section":
        return {"job": _job(engine.write_section, str(args.get("section", "1")))}
    if act == "run_all":
        return {"job": _job(engine.run_all)}
    if act == "verify_sources":
        return {"job": _job(engine.verify_sources)}
    if act == "export":
        return {"job": _job(engine.export)}
    if act == "set_option_scores":
        return engine.set_option_scores(args.get("scores") or {})
    return {}


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "report-agent/" + VERSION          # 응답 헤더로 노출된다 — 원자재 이름을 남기지 않는다

    def log_message(self, *a):          # 조용히
        pass

    # ---- 인증
    def _authed(self) -> bool:
        c = self.headers.get("Cookie", "")
        return ("%s=%s" % (COOKIE, TOKEN)) in c

    def _send(self, code: int, body: bytes | str, ctype="application/json; charset=utf-8", extra: dict | None = None):
        if isinstance(body, str):
            body = body.encode("utf-8")
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers(); self.wfile.write(body)
        except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
            pass

    def _json(self, code: int, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False, default=str))

    def _body(self) -> bytes:
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            raise ValueError("본문 너무 큼")
        return self.rfile.read(n) if n else b""

    # ---- GET
    def do_GET(self):
        u = urllib.parse.urlsplit(self.path); q = urllib.parse.parse_qs(u.query)
        if u.path == "/favicon.ico":
            return self._send(HTTPStatus.NO_CONTENT, b"", "image/x-icon")
        if u.path == "/" and q.get("t", [""])[0] == TOKEN:     # 토큰 → 쿠키 승격 → 302
            return self._send(HTTPStatus.FOUND, b"", extra={"Location": "/", "Set-Cookie": "%s=%s; HttpOnly; SameSite=Strict; Path=/" % (COOKIE, TOKEN)})
        if not self._authed():
            return self._send(HTTPStatus.FORBIDDEN, "403 — 이 화면은 시작.bat이 연 주소로만 들어올 수 있습니다. 검은 창의 주소를 다시 여세요.", "text/plain; charset=utf-8")
        if u.path == "/":
            return self._send(HTTPStatus.OK, (UI_DIR / "index.html").read_bytes(), "text/html; charset=utf-8")
        if u.path == "/api/status":
            try:
                return self._json(200, {"ok": True, **engine.status(), "instance": INSTANCE})
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})
        if u.path == "/api/probe":
            live = q.get("live", ["0"])[0] == "1"
            deps = {"pypdf": _has("pypdf"), "python-docx": _has("docx"), "pandas": _has("pandas")}
            net = {}
            if live:
                # 「출처 실접속 검증」이 실제로 되는지 확인 — 허용 도메인 1곳에 실제로 붙어 본다(설치확인 ≠ 작동확인).
                txt, err = source._live_fetch("https://kosis.kr/index/index.do", timeout=8)
                net["source_live"] = (err is None and bool(txt))
            # 켤 때 배경에서 실호출을 한 번 해 둔다(설치확인 ≠ 작동확인). 그동안은 「확인하는 중…」, 끝나면 그 결과. [상태 새로 고침]은 다시 실호출.
            if live:
                cli = llm.probe(live=True); _PROBE["cli"] = cli; _PROBE["running"] = False
            else:
                cli = _PROBE.get("cli") or llm.probe(live=False)
            def _slot(c, note=""):
                if not c or not c.get("found"):
                    return {"found": False, "note": "설치되지 않음"}
                if c.get("live") is not None:
                    return {"found": bool(c.get("live")), "note": (c.get("detail") or "") if c.get("live") else "설치됨 · 응답 없음(로그인 확인)"}
                return {"found": None, "note": "확인하는 중…" if _PROBE.get("running") else "확인 못 함 — [상태 새로 고침]"}
            llm3 = {"작업": _slot(cli.get("claude")), "1차 검증": _slot(cli.get("claude")), "2차 검증": _slot(cli.get("codex"))}
            st = store.load_state()
            tools = engine.tool_rows(live=live)
            for t in tools:                       # 실접속 확인 결과를 해당 행에 반영
                if t["label"] == "출처 실접속 검증" and live:
                    t["found"] = net.get("source_live")
                    t["note"] = t["note"] + ("" if net.get("source_live") else " · 연결 실패 — 인터넷 확인")
            prof = st.get("org_profile") or {}
            kb = engine.kb_rows()
            try:
                bdir = store.BACKUP_DIR; n = len(list(bdir.glob("state_*.json"))) if bdir.exists() else 0
                backup = {"line": "단계가 바뀔 때마다 · 최근 20개 보관 (지금 %d개)" % n, "detail": "app/state_backups/ 에 state_{단계}_{일시}.json 으로 쌓입니다. 잘못 초기화됐으면 최신 파일을 state.json 으로 복사하십시오."}
            except Exception:
                backup = {"line": "확인 못 함", "detail": ""}
            return self._json(200, {"ok": True, "cli": cli, "llm": llm3, "tools": tools, "kb": kb, "backup": backup, "deps": deps, "net": net, "settings": st.get("settings"), "profile": prof, "version": VERSION, "app_name": APP_NAME})
        if u.path == "/api/setup":                                   # 설치 도우미 상태(LLM 두 자리 설치·로그인, V4.2 신설 — C1)
            return self._json(200, setup_helper.상태(_PROBE.get("cli") or llm.probe(live=False)))
        if u.path == "/api/criteria":                    # 평가기준·대안·원점수 (3b 화면)
            st = store.load_state(); c = (st.get("canon") or {})
            crit = c.get("criteria") or []
            return self._json(200, {"ok": True, "criteria": crit,
                                    "confirmed": bool(crit) and all(x.get("by") == "user" for x in crit),
                                    "options": c.get("options") or [],
                                    "scores": c.get("option_scores") or {}})
        if u.path == "/api/state":
            return self._json(200, store.load_state())
        if u.path == "/api/org_profile":
            cfg = store.load_config("org_profile.json", {}) or {}
            prof = dict(store.load_state().get("org_profile") or {})
            return self._json(200, {"ok": True, "profile": prof, "presets": list((cfg.get("presets") or {}).keys()),
                                    "required": PROFILE_REQUIRED})
        if u.path == "/api/job":
            # 결함 A — HTTP 상태(r.status)와 작업 상태(job.status: running/done/blocked/error)를
            # **같은 키에 겹쳐 쓰지 않는다.** job 을 "job" 키 아래 감싸서 index.html 의 r.job.status 가
            # 실제로 채워지게 한다(전에는 job dict 를 그대로 최상위로 돌려줘서 job.status 가 HTTP status를
            # 덮어써 폴링이 5초 만에 "연결이 끊겼습니다"로 오판했다).
            with _JOBS_LOCK:
                j = _JOBS.get(q.get("id", [""])[0])
            return self._json(200 if j else 404, {"ok": bool(j), "job": j})
        if u.path == "/api/logs":
            return self._json(200, {"logs": store.recent_logs(int(q.get("n", ["80"])[0]))})
        if u.path == "/api/section":
            n = q.get("n", ["1"])[0]; p = engine._md_path(n)
            return self._json(200, {"n": n, "md": p.read_text(encoding="utf-8") if p.exists() else ""})
        if u.path == "/api/chat/log":
            return self._json(200, {"log": _CHAT_LOG[-60:]})
        if u.path == "/api/open-folder":
            which = q.get("which", ["output"])[0]
            target = {"output": engine.OUT, "logs": store.LOG_DIR, "backups": store.BACKUP_DIR, "app": BASE, "uploads": UPLOAD_DIR}.get(which, engine.OUT)
            try:
                os.startfile(str(target))
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})
            return self._json(200, {"ok": True})
        if u.path == "/api/open-file":
            which = q.get("which", [""])[0]
            if which != "docx":
                return self._json(400, {"ok": False, "error": "알 수 없는 which"})
            path = (store.load_state().get("export") or {}).get("path")
            if not path:
                return self._json(200, {"ok": False, "error": "아직 생성된 보고서 파일이 없습니다"})
            try:
                os.startfile(path)
            except Exception as e:
                return self._json(500, {"ok": False, "error": str(e)})
            return self._json(200, {"ok": True})
        if u.path == "/api/summary":
            st = store.load_state(); meta = st.get("meta") or {}
            title = (st.get("org_profile") or {}).get("summary_title") or "요약"
            return self._json(200, {"ok": True, "title": title, "summary": meta.get("summary", ""),
                                    "key_points": meta.get("key_points") or []})
        if u.path == "/api/changelog":                          # 화면 푸터 「변경 이력」 접이칸 — /manual과 같은 방식(BASE.parent)
            p = BASE.parent / "이번에 바뀐 것.md"     # 원자재가 쓰던 이력 파일은 논문 에이전트 내용이라 화면에 노출되면 안 된다(출하 검사 실측 2026-09-22)
            return self._json(200, {"ok": True, "md": p.read_text(encoding="utf-8") if p.exists() else ""})
        if u.path in ("/api/manual", "/manual"):                # index.html 의 「사용자 매뉴얼」 링크는 /manual (V1 실측 404 2026-09-17)
            p = BASE.parent / "사용자 매뉴얼(설치 및 사용법).html"
            return self._send(200, p.read_bytes() if p.exists() else "매뉴얼 파일 없음".encode(), "text/html; charset=utf-8")
        return self._send(HTTPStatus.NOT_FOUND, b"404", "text/plain")

    # ---- POST
    def do_POST(self):
        if not self._authed():
            return self._json(403, {"ok": False, "error": "인증 없음"})
        u = urllib.parse.urlsplit(self.path)
        try:
            return self._post_dispatch(u)
        except Busy as e:
            return self._json(409, {"ok": False, "busy": True, "error": str(e)})

    def _post_dispatch(self, u):
        try:
            if u.path == "/api/upload":
                return self._upload(urllib.parse.parse_qs(u.query))
            raw_body = self._body()
            try:
                data = json.loads(raw_body.decode("utf-8") or "{}")
            except UnicodeDecodeError as e:
                # 요청 본문이 UTF-8 이 아니다 — **AI 문제가 아니다.** 원인을 그대로 알려준다.
                # (시운전 중 실측 2026-09-21: cp949 로 보낸 요청이 「AI 호출을 마치지 못했습니다」로
                #  보고돼 엉뚱한 곳을 보게 만들었다. 정직한 오류 표시가 이 제품의 방침이다.)
                return self._json(400, {"ok": False,
                                        "error": "요청 본문이 UTF-8 이 아닙니다 — 화면을 새로 고치고 다시 시도하세요.",
                                        "detail": "본문 디코딩 실패: %s" % e})
            except ValueError as e:
                return self._json(400, {"ok": False,
                                        "error": "요청 형식이 올바르지 않습니다(JSON 아님).",
                                        "detail": str(e)[:200]})
            if u.path == "/api/intake":
                prev = store.load_state()
                if prev.get("sections") and not data.get("force"):
                    return self._json(409, {"ok": False, "needs_confirm": True,
                                            "message": "이미 진행 중인 보고서(「%s」, %d개 절)가 있습니다. 새 보고서를 시작하면 현재 상태를 백업한 뒤 초기화합니다. 계속할까요?" % ((prev.get("intake") or {}).get("topic", "")[:30], len(prev["sections"]))})
                st = engine.intake(data.get("topic", ""), org_type=data.get("org_type", "enterprise"),
                                   recipient=data.get("recipient", ""), data_desc=data.get("data_desc", ""),
                                   files=data.get("files", []), names=data.get("names", []),
                                   sources=data.get("sources", []), profile=data.get("profile"),
                                   force=bool(data.get("force")))
                store.log("사용자", "주제·자료 입력 제출" + (" (이전 보고서 백업 후 초기화)" if data.get("force") else ""))
                return self._json(200, {"ok": True, "phase": st["phase"]})
            if u.path == "/api/outline/propose":
                store.log("사용자", "[목차 생성] 누름")
                return self._json(202, {"ok": True, "job": _job(engine.propose_outline)})
            if u.path == "/api/outline/approve":
                store.log("사용자", "[목차 승인] 누름")
                st = engine.approve_outline(data.get("outline"))
                return self._json(200, {"ok": True, "phase": st["phase"]})
            if u.path == "/api/run":
                store.log("사용자", "[끝까지 진행] 누름")
                return self._json(202, {"ok": True, "job": _job(engine.run_all)})
            if u.path == "/api/section/rewrite":
                n = str(data.get("n", "1"))
                if not _valid_section(n):
                    return self._json(400, {"ok": False, "error": "목차에 없는 절 번호입니다: %s" % n})
                store.update_state(lambda s: s["sections"].get(n, {}).update(status="pending", calls=0, critique=[]))
                store.log("사용자", "[%s장 다시 쓰기] 누름" % n)
                return self._json(202, {"ok": True, "job": _job(engine.write_section, n)})
            if u.path == "/api/section/save":
                n = str(data.get("n", "1")); md = data.get("md")
                if not _valid_section(n):
                    return self._json(400, {"ok": False, "error": "목차에 없는 절 번호입니다: %s" % n})
                if not (md or "").strip():
                    return self._json(400, {"ok": False, "error": "원고 내용이 비어 있습니다"})
                p = engine._md_path(n)
                if p.exists():
                    engine._save_version(n, p.read_text(encoding="utf-8"), "manual")   # 덮어쓰기 전 반드시 백업
                p.write_text(md, encoding="utf-8")
                store.log("사용자", "%s장 원고 직접 고치기 저장" % n)
                return self._json(200, {"ok": True})
            if u.path == "/api/section/revise":
                n = str(data.get("n", "1")); req = (data.get("request") or "").strip()
                if not _valid_section(n):
                    return self._json(400, {"ok": False, "error": "목차에 없는 절 번호입니다: %s" % n})
                if not req:
                    return self._json(400, {"ok": False, "error": "수정 요청 내용이 비어 있습니다"})
                store.log("사용자", "[%s장 부분 수정] %s" % (n, req[:80]))
                return self._json(202, {"ok": True, "job": _job(engine.revise_section, n, req)})
            if u.path == "/api/summary/redo":
                store.log("사용자", "[요약만 다시 쓰기] 누름")
                return self._json(202, {"ok": True, "job": _job(engine.summary)})
            if u.path == "/api/sources/verify":
                store.log("사용자", "[출처 검증] 누름")
                return self._json(202, {"ok": True, "job": _job(engine.verify_sources)})
            if u.path == "/api/sources/manual":
                idx = int(data.get("index")); st = store.load_state()
                st["sources"][idx] = source.set_manual_review(st["sources"][idx], data.get("reviewer", ""), data.get("method", ""), data.get("evidence", ""))
                store.save_state(st); store.log("사용자", "출처 #%d 사용자 증빙 저장" % (idx + 1))
                return self._json(200, {"ok": True})
            if u.path == "/api/criteria/weights":         # 🔒 사용자 전용 — 가중치 확정
                store.log("사용자", "[평가기준 가중치 확정] 누름")
                r = engine.set_criteria_weights(data.get("weights") or {})
                return self._json(200 if not r.get("errors") else 400, {"ok": not r.get("errors"), **r})
            if u.path == "/api/options/scores":           # 🔒 사용자 전용 — 대안 원점수
                store.log("사용자", "[대안 원점수 입력] 누름")
                r = engine.set_option_scores(data.get("scores") or {})
                return self._json(200 if not r.get("errors") else 400, {"ok": not r.get("errors"), **r})
            if u.path == "/api/export":
                store.log("사용자", "[DOCX 생성] 누름")
                return self._json(202, {"ok": True, "job": _job(engine.export)})
            if u.path == "/api/org_profile":
                allowed = set(engine.PROFILE_FIELDS) | {"ai_disclosure_text", "docx_template"}
                upd = {k: v for k, v in data.items() if k in allowed}
                if upd.get("active") not in (None, "enterprise", "public"):
                    return self._json(400, {"ok": False, "error": "조직 유형은 enterprise 또는 public 이어야 합니다"})
                cfg = dict(store.load_config("org_profile.json", {}) or {})
                # 프리셋(기업/공공 양식 정의)은 건드리지 않고 상위 필드만 갱신한다.
                for k, v in upd.items():
                    cfg[k] = v
                store.save_config("org_profile.json", cfg)
                # state 에는 «선택된 프리셋 + 사용자 입력»을 병합해 넣는다(화면·조립이 이 값을 읽는다).
                active = upd.get("active") or cfg.get("active") or (store.load_state().get("org_profile") or {}).get("active") or "enterprise"
                merged = dict(((cfg.get("presets") or {}).get(active)) or {})
                merged["active"] = active
                for k in engine.PROFILE_FIELDS:
                    if cfg.get(k):
                        merged[k] = cfg[k]
                merged.update({k: v for k, v in upd.items() if k not in ("active",)})
                store.update_state(lambda s: s.__setitem__("org_profile", merged))
                store.log("사용자", "조직 기준 저장(%s): %s" % ("공공기관" if active == "public" else "기업", ", ".join(sorted(upd.keys()))))
                return self._json(200, {"ok": True, "profile": merged})
            if u.path == "/api/setup/run":                           # 설치 도우미 단추 — 표에 박힌 명령만(V4.2 신설 — C1)
                return self._json(200, setup_helper.실행(str(data.get("key", ""))))
            if u.path == "/api/settings":
                allowed = {"ai_disclosure", "max_calls_per_section", "max_minutes_per_section", "pass_score", "length_mode"}
                if data.get("length_mode") not in (None, "full", "brief"):
                    return self._json(400, {"ok": False, "error": "length_mode는 full 또는 brief"})
                store.update_state(lambda s: s["settings"].update({k: v for k, v in data.items() if k in allowed}))
                return self._json(200, {"ok": True, "settings": store.load_state()["settings"]})
            if u.path == "/api/chat":
                msg = (data.get("message") or "").strip()
                # 결함 B — 확인 재전송(confirm:true)에는 원래 제안된 action·args 가 실려 있어야 실행된다.
                # (index.html chatSend() 를 함께 고침 — 여기 조건은 그대로 유지)
                if data.get("confirm") and data.get("action"):
                    store.log("사용자", "AI 대화 확인: %s" % data["action"])
                    res = _run_action(data["action"], data.get("args") or {})
                    job = res.get("job") if isinstance(res, dict) else None
                    entry = {"ts": store.now_iso(), "role": "bot",
                             "reply": "실행했습니다: %s" % _ACTIONS[data["action"]]["desc"],
                             "result": res, "job": job}
                    _CHAT_LOG.append(entry); return self._json(200, {"ok": True, **entry})
                _CHAT_LOG.append({"ts": store.now_iso(), "role": "user", "text": msg})
                res = _chat(msg)
                if res.get("action") and not res.get("needs_confirm"):
                    res["result"] = _run_action(res["action"], res.get("args") or {})
                job = (res.get("result") or {}).get("job") if isinstance(res.get("result"), dict) else None
                entry = {"ts": store.now_iso(), "role": "bot", **res, "job": job}
                _CHAT_LOG.append(entry); store.log("AI", res.get("reply", "")[:80], action=res.get("action"))
                return self._json(200, {"ok": True, **entry})
            return self._json(404, {"ok": False, "error": "no route"})
        except Busy:
            raise                                   # do_POST 에서 409 {busy:true} 로 응답 (V2 D4)
        except engine.Blocked as e:
            return self._json(409, {"ok": False, "blocked": True, "error": str(e)})
        except Exception as e:
            store.log("시스템", "요청 오류 %s: %s" % (u.path, e))
            return self._json(500, {"ok": False, "error": llm.human_reason(str(e)), "detail": str(e)[:200]})

    def _upload(self, q: dict | None = None):
        """multipart/form-data — cgi 모듈 없이(파이썬 3.13+ 제거) email.parser로 파싱.
        ?section=N 이 있으면 저장한 파일을 그 절 전용 자료(state.sections[n].materials)에도 붙인다(B4)."""
        ctype = self.headers.get("Content-Type", "")
        if "multipart/form-data" not in ctype:
            return self._json(400, {"ok": False, "error": "multipart 필요"})
        raw = self._body()
        msg = BytesParser(policy=_email_policy).parsebytes(b"Content-Type: " + ctype.encode() + b"\r\nMIME-Version: 1.0\r\n\r\n" + raw)
        saved = []
        for part in msg.iter_parts():
            fname = part.get_filename()
            if not fname:
                continue
            dest = _unique(UPLOAD_DIR / _safe_filename(fname))
            if not str(dest.resolve()).startswith(str(UPLOAD_DIR.resolve())):
                return self._json(403, {"ok": False, "error": "경로 탈출"})
            with open(dest, "wb") as f:
                f.write(part.get_payload(decode=True) or b"")
            saved.append(str(dest))
        section = ((q or {}).get("section") or [None])[0]
        if section and not _valid_section(section):
            return self._json(400, {"ok": False, "error": "목차에 없는 절 번호입니다: %s" % section})
        if section and saved:
            def _set(s):
                c = s["sections"].setdefault(section, {"status": "pending", "calls": 0, "critique": [], "versions": [], "materials": []})
                c.setdefault("materials", []).extend(saved)
            store.update_state(_set)
            store.log("사용자", "%s장 보충자료 업로드 %d건" % (section, len(saved)))
            # 결함 E — 반영 가능한 형식인지(집필 프롬프트에 실제로 들어가는지) 화면이 정직하게 보게 한다.
            materials = engine.section_materials_status(saved)
            return self._json(200, {"ok": True, "files": saved, "materials": materials})
        else:
            store.log("사용자", "자료 업로드 %d건" % len(saved))
        return self._json(200, {"ok": True, "files": saved})


_CHAT_LOG: list[dict] = []


def _has(mod: str) -> bool:
    import importlib.util
    return importlib.util.find_spec(mod) is not None


def main():
    if os.environ.get("UI_ALLOW_MULTI") != "1":
        n = terminate_previous()
        if n:
            print("Closed %d previous window server(s)." % n)
    try:
        srv = _Server(("127.0.0.1", PORT), Handler)
    except OSError:
        print("Port %d is already in use. The screen server was NOT started." % PORT)
        print("Most likely it is already running: open http://localhost:%d/?t=%s" % (PORT, TOKEN))
        print("If you are sure it is dead, close that window first and run again.")
        sys.exit(1)
    _write_lock(PORT)
    url = "http://localhost:%d/?t=%s" % (PORT, TOKEN)
    print("%s v%s — http://localhost:%d  (local only)" % (APP_NAME, VERSION, PORT))
    # ★ 출입증(토큰) 붙은 주소를 «반드시» 찍는다 — 원자재에 있던 줄인데 옮기며 빠졌다(실측 2026-09-23).
    #   ① 모바일 콘솔의 「화면 안에 띄우기」 중계는 이 창의 글자를 읽어 주소를 알아낸다. 토큰 없는 주소를 받으면
    #      출입증을 못 받아 모든 요청이 403 → 폰 화면이 하얗게 된다(PO 스크린샷으로 확인).
    #   ② 403 안내문은 「검은 창의 주소를 다시 여세요」라고 한다. 이 줄이 없으면 자동으로 열린 탭을 닫은
    #      사용자는 다시 들어갈 주소가 없다. 되돌리지 마라.
    print(url, flush=True)   # 파이프로 읽는 쪽(모바일 콘솔·주소 연결기)이 버퍼에 갇힌 줄을 못 받는 일이 없게
    print("Close this window to stop.  브라우저 탭을 닫아도 서버는 살아 있습니다 — 다 쓰셨으면 이 검은 창을 닫으세요.")
    if os.environ.get("NO_BROWSER") != "1":
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    threading.Thread(target=_background_probe, daemon=True).start()   # LLM 두 자리 실호출 — 화면은 그동안 「확인하는 중…」
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        try:
            LOCK_FILE.unlink()
        except OSError:
            pass


if __name__ == "__main__":
    main()
