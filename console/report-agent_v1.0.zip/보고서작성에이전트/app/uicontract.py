# -*- coding: utf-8 -*-
"""uicontract.py — 서버 결과 ↔ 화면의 단일 계약.

부품 출처(BOM 🟡): 원자재 thesis-agent `app/uicontract.py`
  sha256 97e6e23967a91927f1ce038b742434e98f659177816f78428b38b98c85c27654 (2026-09-20)
재단: 키 이름 교체(chapters→sections · citations→sources · profile→org_profile · canon→정본 수치표)

## 왜 있나
반복된 함정 「백엔드 원칙이 화면까지 안 이어짐」 — 백엔드가 새 키를 반환해도 화면이 그 값을 안 읽으면 소용없다.
개발 사본의 계약 시험들이 이 표를 근거로 「선언 ≠ 실제 사용」을 기계적으로 잡는다.

## 손댈 때
`/api/status`·`/api/state`·`/api/probe` 응답에 새 키를 넣었으면 여기에 한 줄을 같이 적는다.
「화면에 안 그린다」가 맞는 결정이면 renderer=None 으로 적고 **왜**를 note 에 쓴다 — 조용히 빠뜨리는 것만 막는다.
⚠️ 이 표는 «그리는지»만 본다. «옳게 그리는지»는 각 항목의 시험이 따로 잡는다.
"""

# /api/status 응답 최상위 키 → 렌더러 (engine.status() 반환 그대로)
STATUS_CONTRACT: dict[str, dict] = {
    "phase":     {"renderer": "renderStages", "element": "stage-list", "note": "우측 진행 단계. refresh() 안 idx 매핑(intake~done)으로 renderStages 호출"},
    "approved":  {"renderer": None, "element": None, "note": "화면에 별도 배지로 그리지 않는다 — approved 여부는 phase(awaiting_approval→writing 전이)로 간접 표현됨"},
    "sections":  {"renderer": "refresh", "element": "secProg", "note": "절별 상태·점수·호출수 — refresh() 가 #secProg 에 직접 그린다"},
    "sources":   {"renderer": "refresh", "element": "srcSum", "note": "export_gate 요약(원부검증/출처확인/미검증 건수) — 개별 레코드는 state.sources 를 renderSources 가 그린다(아래 STATE_CONTRACT)"},
    "blocked":   {"renderer": None, "element": None, "note": "화면에 차단 코드를 별도로 노출하지 않는다 — phase 가 멈춘 것으로만 간접 확인됨(연결 끊김 배지 #safe-unknown 은 HTTP 실패용이지 이 값을 안 읽는다). 확인이 필요한 사항 목록.md 참조"},
    "export":    {"renderer": None, "element": None, "note": "화면은 /api/state 의 state.export 를 대신 쓴다 — status().export 는 현재 화면에서 읽는 곳이 없다(중복 필드)"},
    "history":   {"renderer": None, "element": None, "note": "호출 누계는 화면에 안 그린다 — 로그 폴더에서 본다"},
}

# /api/state 응답 키 → 렌더러 (화면이 실제로 읽는 것만 적는다 — store.default_state() 전체가 아니다)
STATE_CONTRACT: dict[str, dict] = {
    "intake":          {"renderer": "renderJobList", "element": "gate-list", "note": "topic 유무로 진행 중 항목 1건 표시"},
    "outline":         {"renderer": "renderChips", "element": "secChips", "note": "승인 대기 중이면 renderOutline(#outline·#frame)도 같이 부른다. outline.sections 를 읽는다"},
    "_pending_frame":  {"renderer": "renderOutline", "element": "frame", "note": "목차 승인 대기 중 검토 논점·평가기준·대안 미리보기(awaiting_approval 단계에서만)"},
    "sources":         {"renderer": "renderSources", "element": "srcTbl", "note": "출처 레코드 표 — 출처·URL/통계표ID·확인 방식·등급·증빙 버튼"},
    "export":          {"renderer": "refresh", "element": "exportInfo", "note": "DOCX 경로·열림검증·후처리 목록"},
    "settings":        {"renderer": "refresh", "element": "lm", "note": "분량 모드·AI 고지·상한(#lm #disc #lim)"},
    "phase":           {"renderer": None, "element": None, "note": "status().phase 를 쓴다 — state.phase 를 화면이 따로 안 읽음"},
    "org_profile":     {"renderer": "loadStandards", "element": "standards-form", "note": "조직 유형·기관명·부서·작성자·직급·연락처 — /api/org_profile 로 별도 로드(STD_FIELDS 매핑)"},
    "canon":           {"renderer": "refresh", "element": None, "note": "정본 수치표는 서버 내부용 — 화면엔 확정 수치·출처 건수만 probe 의 kb-experience-row 로 요약 노출. D-008(2026-09-23): refresh() 가 canon.criteria 존재 + 3b 폼 부재를 감지해 loadCriteria() 를 부르고, weight 미확정이면 #crit-warn 안내를 띄운다(폼이 이미 있으면 목록이 실제로 바뀐 경우만 다시 그림 — 입력 중인 값 보존)"},
    "sections":        {"renderer": "refresh", "element": "secProg", "note": "status().sections 로 상태·점수·호출수를 그리고(#secProg), D-007(2026-09-23)부터 state.sections[n].open_issues 도 같은 refresh() 루프에서 읽어 「통과 — 남은 지적 N건」을 덧붙인다(없으면 기존 표시 그대로)"},
    "consistency":     {"renderer": "renderConsistency", "element": "consistency-out", "note": "D-009(2026-09-23) — 2차 검증 지적(절·내용·수정방향). renderConsistency 가 #fold-consistency 를 그린다. 키 없음(구버전 상태·2차 검증 전)이면 접이칸을 통째로 숨김"},
    "pseudonym_names": {"renderer": None, "element": None, "note": "가명화 대상 실명 — **화면에 표시하지 않는다**(실명을 다시 띄우면 가명화의 의미가 없다). 접수 폼 입력 후 화면에서 지운다"},
    "blocked":         {"renderer": None, "element": None, "note": "status().blocked 와 동일한 미노출 사유(위 참조)"},
}

# /api/probe 는 뼈대 JS(verifyRows·chipRow)가 고정 계약으로 그린다: llm(3자리) · tools[] · kb{} · backup
PROBE_CONTRACT: dict[str, dict] = {
    "llm":      {"renderer": "verifyRows", "element": "llm-status", "note": "세 자리 고정 — 작업/1차 검증/2차 검증. 화면 칩은 '설치·로그인 확인'이고, 실제 실행 배선은 engine.score_section/consistency_check(런타임)가 별도"},
    "tools":    {"renderer": "chipRow", "element": "status-list", "note": "수치 계산·표 파일·PDF·DOCX·출처 실접속·공공 통계 원부. found True/False/None 세 값"},
    "kb":       {"renderer": "chipRow", "element": "kb-inject-row", "note": "①~④ + 작업 지식(정본 수치표) 행 id 로 매핑"},
    "backup":   {"renderer": None, "element": "backup-line", "note": "loadStatus 가 직접 textContent 로 채운다(backup-detail 도 같이)"},
    "deps":     {"renderer": None, "element": None, "note": "tools 배열을 만드는 서버 내부 계산값 — 화면은 tools 만 읽는다(중복 원본)"},
    "net":      {"renderer": None, "element": None, "note": "「출처 실접속 검증」 행을 만드는 내부 계산값 — 화면은 tools 만 읽는다"},
    "settings": {"renderer": None, "element": None, "note": "/api/state 의 state.settings 를 화면이 대신 쓴다(중복 필드, probe 쪽은 읽는 곳 없음)"},
    "profile":  {"renderer": "loadStatus", "element": "standards-summary", "note": "org_profile 병합본 — loadStatus 가 lastProfile 에 캐시해 fillFromProfile(조직 유형 자동 선택)에 쓴다"},
}
