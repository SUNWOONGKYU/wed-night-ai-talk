@echo off
pushd "%~dp0"
chcp 65001 > nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
where python > nul 2>&1
if errorlevel 1 goto nopython
if exist "app\.deps_ok" goto run
echo Installing dependencies - first run only ...
rem -- Check pip itself first. A broken pip dies with a Python traceback
rem -- that tells a normal user nothing. Catch it early and say what to do.
python -m pip --version > nul 2>&1
if errorlevel 1 goto pipbroken
python -m pip install -q -r app\requirements.txt
if errorlevel 1 goto depfail
echo ok > "app\.deps_ok"
goto run
:pipbroken
echo.
echo [ERROR] The Python package installer - pip - is broken on this PC.
echo         This is a problem with Python itself, not with this program.
echo.
echo         Run this command, then start again:
echo.
echo             python -m ensurepip --upgrade
echo.
echo         If that does not help, reinstall Python from python.org.
echo.
ping -n 12 127.0.0.1 > nul
goto end
:depfail
echo.
echo [ERROR] Could not install the required packages.
echo         The real reason is printed below.
echo.
python -m pip install -r app\requirements.txt
echo.
echo         If the message above mentions pip itself, run:
echo.
echo             python -m ensurepip --upgrade
echo.
echo         Otherwise check your network or proxy, then start again.
echo.
ping -n 12 127.0.0.1 > nul
goto end
:run
python app\ui.py
if errorlevel 1 goto failed
goto end
:nopython
echo [ERROR] Python not found. Install from https://www.python.org/downloads/ and check Add Python to PATH.
ping -n 6 127.0.0.1 > nul
goto end
:failed
echo [INFO] Screen server did not start. See the message above.
ping -n 8 127.0.0.1 > nul
:end
popd
