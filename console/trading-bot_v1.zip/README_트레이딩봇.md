# 매매 자동화 봇 (Trading Automation Bot) 무료 배포판 v1.1 — 설명서

원맥스 구매자에게 무료로 드리는 **한국 주식선물 매매 자동화 봇**입니다.
신호가 나면 텔레그램으로 승인을 받아 주문·청산을 대신 실행해 주는 프로그램이지, 알아서 돈을 벌어 주는 프로그램이 아닙니다.
사용자 PC 에서, 사용자 본인의 증권사(한국투자증권) 키로, 사용자가 텔레그램에서 승인한 매수(CALL)·매도(PUT)·청산만 실행합니다. 스스로 진입하는 경우는 없습니다.
개발자가 사용자의 돈이나 키에 손댈 방법은 없습니다. 반대로, 모든 매매 판단과 결과도 사용자 책임입니다.

> **먼저 읽을 것**
> - 이 봇은 투자자문·투자일임이 아닙니다. 매매 도구일 뿐이며 수익을 약속하지 않습니다.
> - 처음에는 반드시 **모의투자**(`KIS_PAPER_MODE=true`)로 돌리세요. 실계좌 전환은 맨 아래 별도 절차를 읽고 스스로 결정하세요.
> - 기본 제공 샘플 전략(5대장2졸병)은 **교육용**입니다. 개발자 자체 분석에서도 뚜렷한 우위(엣지)가 확인되지 않았습니다.

---

## v1.1 변경 (2026-09-21)

| 항목 | 내용 |
|---|---|
| ① 근월물 자동 갱신 | `build_futures_map.py` 가 만기(매월 둘째 목요일)가 지난 월물을 빼고 가장 가까운 월물(근월물)을 고릅니다. 이전 판은 분기물(3·6·9·12월)만 봐서 9월물 만기 뒤 주문이 "선물옵션종목이 없습니다" 오류로 막혔습니다. `restart_trader.ps1` 이 매일 기동 전에 이 갱신을 자동으로 돌립니다(실패하면 기존 맵으로 계속). 동봉 `futures_code_map.json` 은 10월물 |
| ② 매수·매도 모두 승인 + 당일 시작 승인 | 매수(CALL)·매도(PUT) 신호 모두 텔레그램 승인 요청 → 사람이 결정, 자동 진입 없음(`PUT_ENABLED=True` 는 매도 신호도 승인 요청을 보낸다는 뜻). 청산도 손절·익절·트레일링 조건이 되면 "청산 승인 / 보류"를 묻습니다(`EXIT_APPROVAL_REQUIRED=True`; 손절만 120초 무응답 시 안전을 위해 자동 청산, 익절·트레일링은 보류 후 10분마다 재요청). 장 시작 전에는 "오늘 매매 시작 / 오늘은 쉼" 승인을 먼저 받습니다(`DAY_START_APPROVAL_REQUIRED=True`; 승인 전엔 신규 진입 없이 청산 감시만) |
| ③ 리스크 기본값 | 하루 손실 한도 5만 원(`MAX_DAILY_LOSS=50_000`) · 동시 보유 최대 2포지션(`SENTRY_MAX_POSITIONS=2`) · 기본 1계약(`SENTRY_DEFAULT_QTY_STOCK=1`). 이전 판 30만 원·5포지션·2계약에서 낮췄습니다. 돌파 트랙 자동매수도 꺼 둠(`AUTO_BUY_VETTED=False`) |
| ④ 승인 메시지 전송 재시도 | 텔레그램 전송이 일시 네트워크 장애로 실패하면 3회(5·10초 간격) 다시 보냅니다. 승인 요청이 조용히 사라지던 문제를 막습니다 |
| ⑤ 명칭 | "트레이딩 봇" → "매매 자동화 봇 / Trading Automation Bot". 하는 일은 같습니다 — 신호가 나면 텔레그램으로 승인을 받아 주문·청산을 대신 실행 |

---

## 1. 무엇을 하는 프로그램인가

```
[scanner_web.py]  262종목(주식선물 기초자산) 1분봉을 1분마다 스캔 → 신호 점수 (웹 화면 http://localhost:5050)
        │
[trader.py]  스캔 결과를 받아 아래 관문을 차례로 통과한 종목만 주문 후보로 올림 (매수(CALL) 기준. 매도(PUT) 신호는 5)와 승인만 거침)
   1) 시장 레짐   : KODEX200 당일 등락이 -0.3% 아래(하락장)면 매수 안 함
   2) 상승 종목   : 월/주/일봉이 상승 추세인 종목만 (htf_filter.py)
   3) 추격 방지   : 당일 +5% 이상 오른 종목은 안 삼
   4) 재검증      : 주문 직전 신호를 다시 계산해 뒷북이면 취소
   5) 리스크      : 최대 2포지션 · 하루 손실 5만 원 넘으면 그날 신규 매수 중단
        │
   ▶ (장 시작 전) 텔레그램으로 "오늘 매매 시작 / 오늘은 쉼" 승인 — 승인 전엔 신규 매수 없음
   ▶ 후보마다(매수 CALL·매도 PUT 모두) 텔레그램으로 "승인 / 거절" 버튼 전송 (180초 안에 응답 없으면 자동 취소)
        │
   ▶ 승인 시 주식선물 지정가 주문 (KIS Open API)
        │
   ▶ 청산도 승인: 손절 -3% · 익절 +5% · 트레일링 스탑 3% (익절선 넘은 뒤 고점 대비 -3%) 조건이 되면
     텔레그램으로 "청산 승인 / 보류" 전송. 손절만 120초 무응답 시 자동 청산, 익절·트레일링은 보류 후 10분마다 재요청
```

- 매수(CALL)·매도(PUT) 신호 모두 승인 요청이 옵니다. 어느 쪽도 사람이 "승인"을 누르기 전에는 주문하지 않습니다. 매도(PUT) 신호를 아예 받지 않으려면 `config.py` 의 `PUT_ENABLED=False`.
- 장 마감 강제청산은 없습니다 (오버나잇 보유). 손절/익절 청산 요청은 장중에만 옵니다.
- 텔레그램에서 `정지` / `재개` / `min_score 70` / `잔고` / `포지션` / `스캔` / `상태` 같은 명령으로 실시간 제어할 수 있습니다.
- 사용자가 직접 만든 전략(`strategies/*.json`)은 기본적으로 **신호 표시만** 합니다. 실제 주문에 쓰려면 `config.py` 의 `STRATEGY_LIVE_ENABLED=True` 와 전략 파일의 `"live": true` 를 둘 다 켜야 합니다.

---

## 2. 준비물

| 항목 | 설명 |
|---|---|
| Windows PC | 장중(08:45~15:45)에 켜져 있어야 합니다. 절전 모드 끄기 권장 |
| Python 3.11 이상 | https://www.python.org/downloads/ (설치 시 "Add python.exe to PATH" 체크). 3.13 에서 검증 |
| 한국투자증권 계좌 + Open API | https://apiportal.koreainvestment.com → 로그인 → API 신청 → **앱키 / 앱시크릿**. 모의투자 앱을 따로 만들 수 있습니다. 주식선물 거래가 가능한 계좌(선물옵션 계좌 개설·교육 이수)가 필요합니다 |
| 텔레그램 봇 | 텔레그램에서 `@BotFather` → `/newbot` → **토큰** 복사. 만든 봇에게 아무 말이나 보낸 뒤 브라우저에서 `https://api.telegram.org/bot<토큰>/getUpdates` 를 열면 `"chat":{"id":숫자}` 가 **chat id** |

---

## 3. 설치

```powershell
# 1) 압축을 원하는 폴더에 푼다 (예: C:\trading-bot). 한글·공백 없는 경로 권장.
cd C:\trading-bot

# 2) 라이브러리 설치
pip install -r requirements.txt

# 3) 설정 파일 만들기
copy .env.example .env
notepad .env        # KIS 앱키·시크릿·계좌번호, 텔레그램 토큰·chat id 입력. KIS_PAPER_MODE=true 유지
```

`.env` 는 증권사 키가 들어 있는 파일입니다. 절대 남에게 보내거나 인터넷에 올리지 마세요 (`.gitignore` 에 이미 제외돼 있습니다).

### 처음 한 번 (선택)
```powershell
python build_futures_map.py     # 주식선물 종목코드 매핑 갱신 — 만기(매월 둘째 목요일)가 지난 월물을 빼고 가장 가까운 월물 선택. 기본 파일(10월물) 동봉됨. 만기 다음 날 한 번 실행 권장
python build_name_cache.py      # 종목명 캐시 갱신. 기본 파일 동봉됨
python strategy_engine.py       # 전략 파일 검증 → 각 전략 OK 표시 확인
```

---

## 4. 실행

실행 창 두 개가 필요합니다.

```powershell
# 실행 창 1: 스캐너 웹 (먼저 켠다) — 브라우저에 http://localhost:5050 가 열린다
python scanner_web.py

# 실행 창 2: 트레이더
python trader.py
```

정상이면 `trader.py` 로그에 이렇게 나옵니다.
```
  Trader 자동매매 트레이더 시작 (모의투자)
  스캔간격: 60초 / 최소점수: 65점
  손절: 3.0% / 익절: 5.0% / 트레일링: 3.0%
  최대포지션: 2개 / 일일한도: 30건, 50,000원
[KIS] Token acquired, expires: ...
[FuturesMap] 매핑 로드: 250개 (10월물)
```
- `.env 에 KIS_APP_KEY ... 없습니다` → `.env` 를 아직 안 채운 것입니다.
- `KIS 토큰 발급 실패` → 앱키/시크릿이 틀렸거나, 모의투자 키를 실전 모드(또는 그 반대)로 쓰고 있는 것입니다.
- 장 외 시간에는 `장 외 — N분 후 개장 대기` 만 반복합니다. 정상입니다.
- `[FuturesMap]` 의 월물이 이미 만기가 지난 달이면 `python build_futures_map.py` 를 한 번 실행하세요. 주문 시 `선물옵션종목이 없습니다` 오류가 나면 이 경우입니다.

스캐너 웹은 기본적으로 **이 PC 에서만** 열립니다. 같은 공유기 안의 핸드폰에서 보려면 `.env` 에 `SCANNER_HOST=0.0.0.0` 을 넣으세요 (공용 네트워크에서는 넣지 마세요 — 웹 화면에서 봇을 켜고 끌 수 있습니다).

### 매일 08:45 자동 기동 (작업 스케줄러)
`restart_trader.ps1` 은 휴장일을 건너뛰고, 주식선물 종목 맵을 근월물로 갱신(`build_futures_map.py`)하고, 묵은 `trader.py` 를 정리한 뒤 새로 띄웁니다. 관리자 PowerShell 에서 한 번만:

```powershell
$proj = "C:\trading-bot"    # 압축 푼 폴더
$act = New-ScheduledTaskAction -Execute "powershell.exe" `
       -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$proj\restart_trader.ps1`"" -WorkingDirectory $proj
$trg = New-ScheduledTaskTrigger -Daily -At 08:45
Register-ScheduledTask -TaskName "TradingBot-Trader" -Action $act -Trigger $trg -Description "매매 자동화 봇 매일 08:45 재시작"
```
`scanner_web.py` 도 같이 자동으로 띄우려면 작업을 하나 더 등록합니다 (08:40, `-Execute python -Argument scanner_web.py -WorkingDirectory $proj`). 해제는 `Unregister-ScheduledTask -TaskName "TradingBot-Trader"`.

로그는 `logs/` 와 `data/logs/` 에 쌓입니다. `rotate_logs.ps1` 을 로그온 시 실행 작업으로 걸어 두면 파일이 무한히 커지지 않습니다.

---

## 5. 전략 만들기

전략 하나 = `strategies/` 안의 JSON 파일 하나입니다. 규격과 쓸 수 있는 지표는 `strategies/README.md` 에 있습니다.

- **콘솔 시스템(Claude Code)으로**: 이 폴더에서 Claude Code 를 켜고
  `/전략만들기 RSI 30 이하 + 거래량 20일평균 2배 + 20일선 위, 이름은 눌림목반등`
  라고 말하면 JSON 을 만들고 검증하고 스캐너에 올려 줍니다 (`.claude/skills/전략만들기/` 에 스킬 동봉).
- **손으로**: `strategies/눌림목반등_예시.json` 을 복사해 조건을 바꾼 뒤 `python strategy_engine.py` 로 검증합니다.
- 스캐너 웹의 "전략" 탭에서 전략별 통과 종목과 겹침을 볼 수 있고, 켜기/끄기(`enabled`)도 됩니다.
- 실제 주문에 쓰려면 (1) 전략 파일에 `"live": true`, (2) `config.py` 의 `STRATEGY_LIVE_ENABLED = True`. 둘 다 켜기 전에는 신호만 표시합니다. 켜더라도 레짐·추세·추격방지·승인 관문은 그대로 거칩니다.

### 일봉 백테스트 (선택)
`python strategy_backtest.py <전략id>` 는 262종목 일봉 캐시(`research_backtest/daily_cache.pkl`)가 필요합니다. 용량 때문에 동봉하지 않았습니다. 만들려면 `python research_backtest/fetch_daily.py` (pykrx 로 2023년~오늘 일봉 수집, 10~20분). 분봉 전략을 일봉에 얹어 "성향"을 보는 참고용이며 과거 성적은 미래를 보장하지 않습니다.

---

## 6. 안전 장치와 기본값 (config.py)

| 항목 | 기본값 | 의미 |
|---|---|---|
| `APPROVAL_REQUIRED` | `True` | **끄지 말 것.** 매수 전 텔레그램 승인 필수 |
| `EXIT_APPROVAL_REQUIRED` | `True` | **끄지 말 것.** 청산(손절·익절·트레일링)도 텔레그램 승인. 손절만 120초 무응답 시 자동 청산 |
| `DAY_START_APPROVAL_REQUIRED` | `True` | **끄지 말 것.** 장 시작 전 "오늘 매매 시작" 승인. 승인 전엔 신규 매수 없음 |
| `KIS_PAPER_MODE` (.env) | `true` | 모의투자 서버. 실계좌는 아래 절차 |
| `MAX_DAILY_LOSS` | 50,000원 | 하루 누적 손실이 닿으면 그날 신규 매수 중단. 본인이 하루에 잃어도 되는 금액으로 |
| `MAX_DAILY_TRADES` | 30건 | 하루 최대 매매 수 |
| `SENTRY_MAX_POSITIONS` | 2 | 동시 보유 최대 |
| `SENTRY_STOP_LOSS_PCT / TAKE_PROFIT_PCT / TRAILING_PCT` | 3 / 5 / 3 % | 청산 요청 조건 |
| `PUT_ENABLED` | `True` | 매도(PUT) 신호도 승인 요청. `False` 면 매도 신호 무시(매수만) |
| `STRATEGY_LIVE_ENABLED` | `False` | 사용자 전략은 신호만. 켜야 주문 후보 |
| `AUTO_BUY_VETTED` | `False` | 돌파 트랙 한정 승인 생략 자동매수. 배포판은 꺼 둠 |
| `ENTRY_MAX_DAY_CHG_PCT` | 5.0 | 당일 +5% 이상 오른 종목 매수 금지 |
| `SENTRY_DEFAULT_QTY_STOCK` | 1계약 | 기본 주문 수량. 자금이 커지면 늘려도 됨 |

봇이 자동으로 남기는 기록: `data/algo_research.db`(신호·5/10/30분 결과 SQLite), `wiki/`(일별 신호·거래 노트, 마크다운). 둘 다 이 PC 안에만 남고 어디로도 전송되지 않습니다.

---

## 7. 실계좌 전환 절차 — 경고

**이 절을 읽기 전에는 `KIS_PAPER_MODE` 를 바꾸지 마세요. 실계좌에서는 진짜 돈이 나갑니다.**

1. 모의투자로 **최소 2~4주** 돌려 보고, 승인 요청 빈도·손절 작동·오버나잇 보유가 본인 성향에 맞는지 확인합니다.
2. 실전용 앱키를 별도로 발급받습니다 (모의투자 키로는 실계좌 주문이 되지 않습니다).
3. `.env` 수정:
   - `KIS_PAPER_MODE=false`
   - `KIS_APP_KEY / KIS_APP_SECRET` = 실전 키, `KIS_ACCOUNT` = 실계좌 앞 8자리
4. 기본값(1계약 · 2포지션 · 하루 손실 5만 원)은 그대로 두고, `MAX_DAILY_LOSS` 는 본인이 하루에 잃어도 되는 금액에 맞춥니다. 늘리는 쪽은 실계좌에서 몇 주 지켜본 뒤에 하세요.
5. `trader.py` 를 다시 켜고 첫 줄 로그가 `(실전)` 인지 확인합니다. 첫날은 "오늘 매매 시작" 승인 뒤 매수 승인 요청을 전부 **거절**하며 흐름만 봅니다.
6. 주식선물은 레버리지 상품입니다. 증거금의 몇 배가 오르내리며, 한 계약의 손실이 예치금을 넘길 수 있습니다. 봇의 손절은 장중 지정가 주문이라 급락·호가 공백에서는 체결이 밀릴 수 있고, 손절 승인 요청에 120초 안에 답하지 않으면 자동으로 청산됩니다.
7. 언제든 멈추려면 텔레그램에 `정지`, 또는 `trader.py` 실행 창을 닫으세요. 이미 보유한 포지션은 자동으로 청산되지 않으니 HTS/MTS 에서 직접 정리하세요.

---

## 8. 고지

- 이 소프트웨어는 투자자문업·투자일임업이 아니며, 특정 종목 매수·매도를 권유하지 않습니다.
- 모든 매매 판단·주문·결과(수익과 손실)는 전적으로 사용자 본인의 책임입니다. 개발자는 사용자의 키·계좌·주문에 접근하지 않으며 어떤 손실도 보상하지 않습니다.
- 샘플 전략과 기본값은 교육·출발점용이며 수익을 보장하지 않습니다. 과거 백테스트 결과는 미래 수익을 의미하지 않습니다.
- 증권사 API 장애, 네트워크 끊김, PC 절전, 텔레그램 지연 등으로 주문·청산이 의도와 다르게 될 수 있습니다. 봇을 켜 둔 동안에도 계좌를 직접 확인하세요.
- 반드시 모의투자로 먼저 사용하세요.

---

## 9. 파일 안내

| 파일 | 역할 |
|---|---|
| `trader.py` | 메인 루프 (관문·당일 시작 승인·매수/매도 승인·주문·청산 승인) |
| `scanner_web.py` / `scanner_262_52.py` | 스캐너 웹(5050) / 262종목 2단계 스캔 |
| `analysis.py` | 지표 엔진 (소나·RSI·ADX·스토캐·MACD·거래량·Williams %R) |
| `strategy_engine.py` / `strategy_backtest.py` | 전략 JSON 평가 / 일봉 백테스트(선택) |
| `htf_filter.py` · `algo_precision.py` · `momentum_strategy.py` · `breakout_strategy.py` | 상위 추세 선별 · 정밀진입 점수 · 모멘텀 스윙 · 장전 돌파 트랙 |
| `kis.py` · `futures_map.py` · `futures_code_map.json` | 증권사 API · 주식→주식선물 코드 매핑 |
| `telegram_notify.py` · `chart_gen.py` | 승인 요청/알림/명령(전송 3회 재시도) · 승인 메시지 차트 |
| `algo_db.py` · `vault_writer.py` | 로컬 기록 (SQLite / 마크다운) |
| `config.py` · `.env` | 설정 / 비밀키 |
| `config_data/` | 샘플 신호 규격·관심종목(샘플)·휴장일(매년 갱신)·규칙·주식선물 마스터 파일 |
| `strategies/` | 사용자 전략 JSON |
| `restart_trader.ps1` · `is_trading_day.ps1` · `rotate_logs.ps1` | 스케줄러용 (기동 전 근월물 맵 갱신 포함) |
| `build_futures_map.py` · `build_name_cache.py` · `research_backtest/fetch_daily.py` | 데이터 갱신 도구 (월물 갱신 · 종목명 · 일봉) |
