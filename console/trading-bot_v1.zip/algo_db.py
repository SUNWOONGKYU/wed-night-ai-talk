# -*- coding: utf-8 -*-
"""
알고리즘 로컬 연구 DB (SQLite)
- 신호 기록 + 5분/10분/30분 결과 자동 추적
- 시장 국면 분류 (A상승/B하락/C횡보)
- 일일/주간 성과 요약
- 알고리즘 개선 제안
"""
import sqlite3
import json
import logging
import os
from datetime import datetime, timedelta, timezone

log = logging.getLogger(__name__)

_KST = timezone(timedelta(hours=9))

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'algo_research.db')


def _conn():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    """테이블 생성 (없으면)"""
    with _conn() as con:
        con.executescript("""
            CREATE TABLE IF NOT EXISTS signals (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                stock_code    TEXT    NOT NULL,
                stock_name    TEXT    NOT NULL,
                signal_type   TEXT    NOT NULL,   -- CALL / PUT
                score         INTEGER NOT NULL,
                boss_count    INTEGER NOT NULL DEFAULT 0,
                soldier_count INTEGER NOT NULL DEFAULT 0,
                entry_price   REAL    NOT NULL DEFAULT 0,
                signal_time   TEXT    NOT NULL,   -- ISO datetime (KST)
                factors_json  TEXT,
                status        TEXT    NOT NULL DEFAULT 'pending'
                                      CHECK(status IN ('pending','tracked','done'))
            );

            CREATE TABLE IF NOT EXISTS outcomes (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                signal_id   INTEGER NOT NULL REFERENCES signals(id),
                price_5m    REAL,
                price_10m   REAL,
                price_30m   REAL,
                pct_5m      REAL,
                pct_10m     REAL,
                pct_30m     REAL,
                win_5m      INTEGER,  -- 0 / 1
                win_10m     INTEGER,
                updated_at  TEXT
            );

            CREATE TABLE IF NOT EXISTS daily_summary (
                id                 INTEGER PRIMARY KEY AUTOINCREMENT,
                date               TEXT NOT NULL UNIQUE,
                regime             TEXT,          -- A / B / C
                total_signals      INTEGER DEFAULT 0,
                call_signals       INTEGER DEFAULT 0,
                put_signals        INTEGER DEFAULT 0,
                win_rate_5m        REAL,
                win_rate_10m       REAL,
                avg_return_5m      REAL,
                avg_return_10m     REAL,
                top_score_win_rate REAL           -- 60점 이상 신호 승률
            );

            CREATE TABLE IF NOT EXISTS market_regime (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                date            TEXT NOT NULL UNIQUE,
                regime          TEXT NOT NULL,
                kospi_change_pct REAL,
                kospi_open      REAL,
                kospi_close     REAL
            );
        """)
    log.info(f'[AlgoDB] DB 초기화 완료: {DB_PATH}')


def record_signal(stock_code, stock_name, signal_type, score,
                  boss_count, soldier_count, entry_price, factors_dict):
    """
    signals 테이블에 신호 기록.
    Returns: signal_id (int)
    """
    # 가드: 지수 의사종목(KOSPI200 등)은 실거래 대상이 아니므로 연구 DB에 기록 안 함
    _nm = stock_name or ''
    if 'KOSPI200' in _nm or '선물지수' in _nm:
        log.debug(f'[AlgoDB] 지수 의사종목 기록 스킵: {_nm}')
        return None
    # 가드: entry_price 비정상이면 결과 추적 불가 → 기록 안 함
    if not entry_price or entry_price <= 0:
        log.debug(f'[AlgoDB] entry_price 비정상 기록 스킵: {_nm} {entry_price}')
        return None
    kst_now = datetime.now(_KST).strftime('%Y-%m-%d %H:%M:%S')
    factors_str = json.dumps(factors_dict, ensure_ascii=False) if factors_dict else '{}'
    try:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO signals
                   (stock_code, stock_name, signal_type, score,
                    boss_count, soldier_count, entry_price, signal_time, factors_json, status)
                   VALUES (?,?,?,?,?,?,?,?,?,'pending')""",
                (stock_code, stock_name, signal_type, score,
                 boss_count, soldier_count, entry_price, kst_now, factors_str)
            )
            signal_id = cur.lastrowid
            # outcomes 행 미리 생성
            con.execute(
                "INSERT INTO outcomes (signal_id) VALUES (?)",
                (signal_id,)
            )
        log.info(f'[AlgoDB] 신호 기록: {stock_name} {signal_type} {score}점 (id={signal_id})')
        return signal_id
    except Exception as e:
        log.error(f'[AlgoDB] record_signal 오류: {e}')
        return None


def record_outcome(signal_id, offset_min, current_price, entry_price, signal_type):
    """
    outcomes 업데이트.
    offset_min: 5 / 10 / 30
    pct = (current - entry) / entry * 100
    win = CALL이면 pct>0, PUT이면 pct<0
    """
    if not entry_price or entry_price == 0:
        return
    # 가드: 가격 조회 실패(0/음수) 또는 비현실적 변동(|pct|>=20%, 가격피드 글리치)은 손상값 → 무시
    if not current_price or current_price <= 0:
        log.debug(f'[AlgoDB] current_price 비정상 결과 스킵: signal_id={signal_id} {current_price}')
        return
    pct = (current_price - entry_price) / entry_price * 100
    if abs(pct) >= 20:
        log.debug(f'[AlgoDB] 비현실 pct({pct:+.1f}%) 결과 스킵: signal_id={signal_id}')
        return
    if signal_type == 'CALL':
        win = 1 if pct > 0 else 0
    else:
        win = 1 if pct < 0 else 0

    now_str = datetime.now(_KST).strftime('%Y-%m-%d %H:%M:%S')

    col_price = {5: 'price_5m', 10: 'price_10m', 30: 'price_30m'}.get(offset_min)
    col_pct   = {5: 'pct_5m',   10: 'pct_10m',   30: 'pct_30m'}.get(offset_min)
    col_win   = {5: 'win_5m',   10: 'win_10m'}.get(offset_min)  # 30m은 win 없음

    if not col_price:
        return

    try:
        with _conn() as con:
            # outcomes 행이 있는지 확인, 없으면 생성
            row = con.execute("SELECT id FROM outcomes WHERE signal_id=?", (signal_id,)).fetchone()
            if not row:
                con.execute("INSERT INTO outcomes (signal_id) VALUES (?)", (signal_id,))

            if col_win:
                con.execute(
                    f"UPDATE outcomes SET {col_price}=?, {col_pct}=?, {col_win}=?, updated_at=? "
                    f"WHERE signal_id=?",
                    (current_price, round(pct, 4), win, now_str, signal_id)
                )
            else:
                con.execute(
                    f"UPDATE outcomes SET {col_price}=?, {col_pct}=?, updated_at=? "
                    f"WHERE signal_id=?",
                    (current_price, round(pct, 4), now_str, signal_id)
                )
        log.info(f'[AlgoDB] 결과 기록: signal_id={signal_id} {offset_min}분 {pct:+.2f}% win={win if col_win else "N/A"}')
    except Exception as e:
        log.error(f'[AlgoDB] record_outcome 오류: {e}')


def get_pending_followups(before_dt):
    """
    status='pending'이고 signal_time < before_dt 인 신호들 반환.
    Returns: [(signal_id, stock_code, signal_type, entry_price, signal_time), ...]
    """
    try:
        before_str = before_dt.strftime('%Y-%m-%d %H:%M:%S')
        with _conn() as con:
            rows = con.execute(
                "SELECT id, stock_code, signal_type, entry_price, signal_time "
                "FROM signals WHERE status='pending' AND signal_time < ?",
                (before_str,)
            ).fetchall()
        return [(r['id'], r['stock_code'], r['signal_type'],
                 r['entry_price'], r['signal_time']) for r in rows]
    except Exception as e:
        log.error(f'[AlgoDB] get_pending_followups 오류: {e}')
        return []


def mark_done(signal_id):
    """status='done'으로 변경"""
    try:
        with _conn() as con:
            con.execute("UPDATE signals SET status='done' WHERE id=?", (signal_id,))
    except Exception as e:
        log.error(f'[AlgoDB] mark_done 오류: {e}')


def compute_daily_summary(date_str):
    """
    해당 날짜 signals+outcomes 조인해서 daily_summary INSERT/UPDATE.
    date_str: 'YYYY-MM-DD'
    """
    try:
        with _conn() as con:
            # 해당 날짜 신호 + 결과 조인
            rows = con.execute(
                """SELECT s.signal_type, s.score,
                          o.pct_5m, o.pct_10m, o.win_5m, o.win_10m
                   FROM signals s
                   LEFT JOIN outcomes o ON o.signal_id = s.id
                   WHERE substr(s.signal_time, 1, 10) = ?""",
                (date_str,)
            ).fetchall()

            if not rows:
                log.info(f'[AlgoDB] {date_str} 신호 없음 — 일일요약 스킵')
                return

            total    = len(rows)
            calls    = sum(1 for r in rows if r['signal_type'] == 'CALL')
            puts     = sum(1 for r in rows if r['signal_type'] == 'PUT')

            w5_list  = [r for r in rows if r['win_5m'] is not None]
            w10_list = [r for r in rows if r['win_10m'] is not None]

            wr5  = (sum(r['win_5m']  for r in w5_list)  / len(w5_list)  * 100) if w5_list  else None
            wr10 = (sum(r['win_10m'] for r in w10_list) / len(w10_list) * 100) if w10_list else None

            pcts5  = [r['pct_5m']  for r in rows if r['pct_5m']  is not None]
            pcts10 = [r['pct_10m'] for r in rows if r['pct_10m'] is not None]

            avg5  = sum(pcts5)  / len(pcts5)  if pcts5  else None
            avg10 = sum(pcts10) / len(pcts10) if pcts10 else None

            # 60점 이상 신호 승률 (5분 기준)
            top_rows = [r for r in w5_list if r['score'] >= 60]
            top_wr = (sum(r['win_5m'] for r in top_rows) / len(top_rows) * 100) if top_rows else None

            # market_regime 조회
            regime_row = con.execute(
                "SELECT regime FROM market_regime WHERE date=?", (date_str,)
            ).fetchone()
            regime = regime_row['regime'] if regime_row else None

            con.execute(
                """INSERT INTO daily_summary
                   (date, regime, total_signals, call_signals, put_signals,
                    win_rate_5m, win_rate_10m, avg_return_5m, avg_return_10m, top_score_win_rate)
                   VALUES (?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(date) DO UPDATE SET
                     regime=excluded.regime,
                     total_signals=excluded.total_signals,
                     call_signals=excluded.call_signals,
                     put_signals=excluded.put_signals,
                     win_rate_5m=excluded.win_rate_5m,
                     win_rate_10m=excluded.win_rate_10m,
                     avg_return_5m=excluded.avg_return_5m,
                     avg_return_10m=excluded.avg_return_10m,
                     top_score_win_rate=excluded.top_score_win_rate""",
                (date_str, regime, total, calls, puts,
                 round(wr5, 2) if wr5 is not None else None,
                 round(wr10, 2) if wr10 is not None else None,
                 round(avg5, 4) if avg5 is not None else None,
                 round(avg10, 4) if avg10 is not None else None,
                 round(top_wr, 2) if top_wr is not None else None)
            )
        log.info(f'[AlgoDB] 일일요약: {date_str} 총{total}건 '
                 f'5분승률={wr5:.1f}%' if wr5 is not None else f'[AlgoDB] 일일요약: {date_str} 총{total}건')
    except Exception as e:
        log.error(f'[AlgoDB] compute_daily_summary 오류: {e}')


def record_regime(date_str, regime, change_pct, kospi_open, kospi_close):
    """market_regime INSERT/UPDATE"""
    try:
        with _conn() as con:
            con.execute(
                """INSERT INTO market_regime (date, regime, kospi_change_pct, kospi_open, kospi_close)
                   VALUES (?,?,?,?,?)
                   ON CONFLICT(date) DO UPDATE SET
                     regime=excluded.regime,
                     kospi_change_pct=excluded.kospi_change_pct,
                     kospi_open=excluded.kospi_open,
                     kospi_close=excluded.kospi_close""",
                (date_str, regime, change_pct, kospi_open, kospi_close)
            )
        log.info(f'[AlgoDB] 시장 국면 기록: {date_str} {regime} ({change_pct:+.2f}%)')
    except Exception as e:
        log.error(f'[AlgoDB] record_regime 오류: {e}')


def get_win_rate(days=30, min_score=50):
    """
    최근 N일 승률 조회.
    Returns dict: {win_rate_5m, win_rate_10m, total, by_score: {50: ..., 55: ..., 60: ...}}
    """
    try:
        cutoff = (datetime.now(_KST) - timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
        with _conn() as con:
            rows = con.execute(
                """SELECT s.score, s.signal_type,
                          o.win_5m, o.win_10m
                   FROM signals s
                   LEFT JOIN outcomes o ON o.signal_id = s.id
                   WHERE s.signal_time >= ? AND s.score >= ?""",
                (cutoff, min_score)
            ).fetchall()

        if not rows:
            return {'win_rate_5m': 0, 'win_rate_10m': 0, 'total': 0, 'by_score': {}}

        total = len(rows)
        w5_rows  = [r for r in rows if r['win_5m']  is not None]
        w10_rows = [r for r in rows if r['win_10m'] is not None]

        wr5  = sum(r['win_5m']  for r in w5_rows)  / len(w5_rows)  * 100 if w5_rows  else 0
        wr10 = sum(r['win_10m'] for r in w10_rows) / len(w10_rows) * 100 if w10_rows else 0

        # 점수 구간별 승률
        by_score = {}
        for threshold in (50, 55, 60, 65, 70):
            sub = [r for r in w5_rows if r['score'] >= threshold]
            if sub:
                by_score[threshold] = round(sum(r['win_5m'] for r in sub) / len(sub) * 100, 1)

        return {
            'win_rate_5m':  round(wr5, 1),
            'win_rate_10m': round(wr10, 1),
            'total': total,
            'by_score': by_score,
        }
    except Exception as e:
        log.error(f'[AlgoDB] get_win_rate 오류: {e}')
        return {'win_rate_5m': 0, 'win_rate_10m': 0, 'total': 0, 'by_score': {}}


def get_weekly_report():
    """
    최근 7일 daily_summary 집계.
    Returns dict
    """
    try:
        cutoff = (datetime.now(_KST) - timedelta(days=7)).strftime('%Y-%m-%d')
        with _conn() as con:
            rows = con.execute(
                "SELECT * FROM daily_summary WHERE date >= ? ORDER BY date DESC",
                (cutoff,)
            ).fetchall()

        if not rows:
            return {'days': 0, 'total_signals': 0, 'avg_win_rate_5m': 0,
                    'avg_win_rate_10m': 0, 'rows': []}

        total_signals = sum(r['total_signals'] for r in rows)
        wr5_list  = [r['win_rate_5m']  for r in rows if r['win_rate_5m']  is not None]
        wr10_list = [r['win_rate_10m'] for r in rows if r['win_rate_10m'] is not None]

        return {
            'days': len(rows),
            'total_signals': total_signals,
            'avg_win_rate_5m':  round(sum(wr5_list)  / len(wr5_list),  1) if wr5_list  else 0,
            'avg_win_rate_10m': round(sum(wr10_list) / len(wr10_list), 1) if wr10_list else 0,
            'rows': [dict(r) for r in rows],
        }
    except Exception as e:
        log.error(f'[AlgoDB] get_weekly_report 오류: {e}')
        return {'days': 0, 'total_signals': 0, 'avg_win_rate_5m': 0,
                'avg_win_rate_10m': 0, 'rows': []}


def suggest_improvements():
    """
    승률 분석 기반 개선 제안 텍스트 반환.
    """
    lines = []
    try:
        # 전체 최근 30일 데이터
        cutoff = (datetime.now(_KST) - timedelta(days=30)).strftime('%Y-%m-%d %H:%M:%S')
        with _conn() as con:
            rows = con.execute(
                """SELECT s.score, s.signal_type,
                          o.win_5m, o.win_10m
                   FROM signals s
                   LEFT JOIN outcomes o ON o.signal_id = s.id
                   WHERE s.signal_time >= ?
                     AND o.win_5m IS NOT NULL""",
                (cutoff,)
            ).fetchall()

        if not rows:
            return '분석할 데이터가 없습니다. 신호가 충분히 쌓이면 자동 제안이 생성됩니다.'

        total = len(rows)

        # 1) 점수 구간별 승률 비교
        score_groups = {}
        for threshold in (50, 55, 60, 65, 70):
            sub = [r for r in rows if r['score'] >= threshold]
            if len(sub) >= 5:
                wr = sum(r['win_5m'] for r in sub) / len(sub) * 100
                score_groups[threshold] = (wr, len(sub))

        if score_groups:
            best_thresh = max(score_groups, key=lambda k: score_groups[k][0])
            worst_thresh = min(score_groups, key=lambda k: score_groups[k][0])
            best_wr, best_cnt = score_groups[best_thresh]
            worst_wr, worst_cnt = score_groups[worst_thresh]

            if best_thresh != 50 and best_wr - score_groups.get(50, (0,))[0] >= 10:
                lines.append(
                    f'{best_thresh}점 이상 신호 승률 {best_wr:.0f}% vs '
                    f'50점 기준 {score_groups.get(50,(0,))[0]:.0f}% '
                    f'→ 최소점수를 {best_thresh}점으로 올릴 것'
                )

        # 2) CALL vs PUT 승률 비교
        call_rows = [r for r in rows if r['signal_type'] == 'CALL']
        put_rows  = [r for r in rows if r['signal_type'] == 'PUT']

        call_wr = sum(r['win_5m'] for r in call_rows) / len(call_rows) * 100 if call_rows else None
        put_wr  = sum(r['win_5m'] for r in put_rows)  / len(put_rows)  * 100 if put_rows  else None

        if call_wr is not None and put_wr is not None:
            if call_wr - put_wr >= 15:
                lines.append(
                    f'PUT 신호 승률 {put_wr:.0f}% vs CALL {call_wr:.0f}% '
                    f'→ 하락장(B국면)에서만 PUT 진입 권장'
                )
            elif put_wr - call_wr >= 15:
                lines.append(
                    f'CALL 신호 승률 {call_wr:.0f}% vs PUT {put_wr:.0f}% '
                    f'→ 상승장(A국면)에서만 CALL 진입 권장'
                )

        # 3) 시장 국면별 승률
        with _conn() as con:
            regime_rows = con.execute(
                """SELECT mr.regime, o.win_5m
                   FROM signals s
                   JOIN outcomes o ON o.signal_id = s.id
                   JOIN market_regime mr ON mr.date = substr(s.signal_time, 1, 10)
                   WHERE s.signal_time >= ? AND o.win_5m IS NOT NULL""",
                (cutoff,)
            ).fetchall()

        if regime_rows:
            by_regime = {}
            for r in regime_rows:
                rg = r['regime']
                if rg not in by_regime:
                    by_regime[rg] = []
                by_regime[rg].append(r['win_5m'])

            regime_labels = {'A': 'A상승', 'B': 'B하락', 'C': 'C횡보'}
            best_rg = max(by_regime, key=lambda k: sum(by_regime[k]) / len(by_regime[k]))
            best_rg_wr = sum(by_regime[best_rg]) / len(by_regime[best_rg]) * 100
            if best_rg_wr >= 60:
                lines.append(
                    f'{regime_labels.get(best_rg, best_rg)} 국면에서 승률 {best_rg_wr:.0f}% '
                    f'→ {regime_labels.get(best_rg, best_rg)} 국면 집중 매매 고려'
                )

        # 4) 총평
        overall_wr = sum(r['win_5m'] for r in rows) / total * 100
        if overall_wr >= 60:
            lines.append(f'전체 5분 승률 {overall_wr:.0f}% (총{total}건) - 현재 알고리즘 양호')
        elif overall_wr < 45:
            lines.append(f'전체 5분 승률 {overall_wr:.0f}% (총{total}건) - 알고리즘 재검토 필요')
        else:
            lines.append(f'전체 5분 승률 {overall_wr:.0f}% (총{total}건) - 개선 여지 있음')

        if not lines:
            return '현재 데이터로는 유의미한 차이가 없습니다. 더 많은 신호가 필요합니다.'

        return '\n'.join(lines)

    except Exception as e:
        log.error(f'[AlgoDB] suggest_improvements 오류: {e}')
        return f'분석 오류: {e}'
