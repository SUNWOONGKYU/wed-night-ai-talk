# -*- coding: utf-8 -*-
"""
정밀 타점 알고리즘 v1.0  —  5-Layer Scoring System

KIS 1분봉(진짜 OHLCV) → 1분봉 추세 컨텍스트 + 3분봉 진입 타이밍

레이어별 배점 (총 100점):
  A. 1분봉 추세 컨텍스트  25점  (최소 10점)
  B. 3분봉 소나 크로스 품질  35점  (최소 15점)
  C. 3분봉 모멘텀 확인  20점  (최소 8점)
  D. 1분봉 캔들 품질  10점
  E. 1분봉 거래량  10점

엔트리 기준:
  S 등급: 90점 이상  (포지션 100%)
  A 등급: 80~89점   (포지션 80%)
  B 등급: 70~79점   (포지션 60%)
  미진입: 70점 미만
"""
import pandas as pd
import numpy as np
import logging
from datetime import datetime, time as dtime

log = logging.getLogger(__name__)

# ─── 공통 유틸 ────────────────────────────────────────────────────────

def _s(v) -> float:
    """NaN → 0.0"""
    if v is None:
        return 0.0
    try:
        f = float(v)
        return 0.0 if np.isnan(f) or np.isinf(f) else f
    except Exception:
        return 0.0


def _clamp(v, lo=0, hi=100):
    return max(lo, min(hi, v))


# ─── 지표 계산 ────────────────────────────────────────────────────────

def _calc_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    OHLCV DataFrame → 전 지표 계산.
    컬럼: open/high/low/close/volume (소문자)
    """
    df = df.copy()
    h, l, c, v = df['high'], df['low'], df['close'], df['volume']

    # ── 소나 (Stochastic Momentum Index) ──────────────────────────────
    k_period = 14
    ll = l.rolling(k_period).min()
    hh = h.rolling(k_period).max()
    mid = (hh + ll) / 2
    rng = (hh - ll) / 2
    raw = ((c - mid) / rng.replace(0, np.nan)) * 100
    # 3중 EWM 평활화 (기존 rolling mean보다 반응 빠름)
    sm1 = raw.ewm(span=3, adjust=False).mean()
    sm2 = sm1.ewm(span=3, adjust=False).mean()
    df['sonar_k'] = sm2
    df['sonar_d'] = df['sonar_k'].ewm(span=3, adjust=False).mean()

    # ── RSI (14) ──────────────────────────────────────────────────────
    delta = c.diff()
    gain  = delta.where(delta > 0, 0.0).rolling(14).mean()
    loss  = (-delta.where(delta < 0, 0.0)).rolling(14).mean()
    df['rsi'] = 100 - 100 / (1 + gain / loss.replace(0, np.nan))

    # ── DI+, DI-, ADX (14) ───────────────────────────────────────────
    pdm = h.diff().clip(lower=0)
    ndm = (-l.diff()).clip(lower=0)
    pdm[pdm < ndm] = 0
    ndm[ndm < pdm] = 0
    tr  = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    atr = tr.rolling(14).mean()
    df['plus_di']  = 100 * pdm.rolling(14).mean() / atr
    df['minus_di'] = 100 * ndm.rolling(14).mean() / atr
    dx = 100 * (df['plus_di'] - df['minus_di']).abs() / (df['plus_di'] + df['minus_di']).replace(0, np.nan)
    df['adx']  = dx.rolling(14).mean()

    # ── Stochastic K (14, 3) ─────────────────────────────────────────
    df['stoch_k'] = (100 * ((c - ll) / (hh - ll).replace(0, np.nan))).rolling(3).mean()

    # ── MACD (12, 26, 9) ─────────────────────────────────────────────
    ema12 = c.ewm(span=12, adjust=False).mean()
    ema26 = c.ewm(span=26, adjust=False).mean()
    df['macd']      = ema12 - ema26
    df['macd_sig']  = df['macd'].ewm(span=9, adjust=False).mean()
    df['macd_hist'] = df['macd'] - df['macd_sig']

    # ── 이동평균 ─────────────────────────────────────────────────────
    df['ma20']  = c.rolling(20).mean()
    df['ema8']  = c.ewm(span=8,  adjust=False).mean()
    df['ema21'] = c.ewm(span=21, adjust=False).mean()
    df['ema60'] = c.ewm(span=60, adjust=False).mean()

    # ── 볼린저 밴드 (20, 2σ) ─────────────────────────────────────────
    bb_std = c.rolling(20).std()
    df['bb_upper'] = df['ma20'] + 2 * bb_std
    df['bb_lower'] = df['ma20'] - 2 * bb_std
    df['bb_width'] = df['bb_upper'] - df['bb_lower']

    # ── 거래량 비율 ───────────────────────────────────────────────────
    df['vol_ma20'] = v.rolling(20).mean()
    df['vol_ratio'] = v / df['vol_ma20'].replace(0, np.nan)

    return df


def _resample_3min(df: pd.DataFrame) -> pd.DataFrame | None:
    """1분봉 RangeIndex DataFrame → 3분봉 OHLCV (3봉씩 묶기)"""
    n = len(df)
    if n < 10:
        return None
    rows = []
    for i in range(0, n - (n % 3), 3):
        chunk = df.iloc[i:i+3]
        rows.append({
            'open':   float(chunk['open'].iloc[0]),
            'high':   float(chunk['high'].max()),
            'low':    float(chunk['low'].min()),
            'close':  float(chunk['close'].iloc[-1]),
            'volume': float(chunk['volume'].sum()),
        })
    return pd.DataFrame(rows) if len(rows) >= 10 else None


# ─── 하드 필터 ────────────────────────────────────────────────────────

def _hard_filter(df1: pd.DataFrame, df3: pd.DataFrame,
                 side: str, now: datetime | None = None) -> str | None:
    """
    None 반환 = 통과. 문자열 반환 = 거부 이유.
    df1: 1분봉 (지표 계산 완료), df3: 3분봉 (지표 계산 완료)
    """
    if len(df3) < 3 or len(df1) < 5:
        return '데이터 부족'

    cur3  = df3.iloc[-1]
    cur1  = df1.iloc[-1]
    prev1 = df1.iloc[-2]

    # HF-1: 유동성
    vol3 = _s(cur3['volume'])
    avg1 = _s(df1['volume'].iloc[-20:].mean())
    if vol3 < 50 and avg1 < 30:
        return '유동성 부족'

    # HF-2: 극단 ADX
    adx3 = _s(cur3['adx'])
    if adx3 > 55 or adx3 < 8:
        return f'ADX 극단({adx3:.1f})'

    # HF-3: 크로스 위치 (소나K 범위)
    sk = _s(cur3['sonar_k'])
    if side == 'CALL' and sk > 40:
        return f'소나K 과매수({sk:.1f}) 골든크로스 불가'
    if side == 'PUT'  and sk < -40:
        return f'소나K 과매도({sk:.1f}) 데드크로스 불가'

    # HF-4: 갭/스파이크 (1분봉 직전 대비 1.5% 이상 급변)
    c0 = _s(cur1['close']); c1 = _s(prev1['close'])
    if c1 > 0 and abs(c0 - c1) / c1 > 0.015:
        return f'1분봉 스파이크({abs(c0-c1)/c1*100:.2f}%)'

    # HF-5: 휩쏘 감지 — 최근 3개 3분봉 내 반대 크로스 존재
    if len(df3) >= 4:
        opposite = 'PUT' if side == 'CALL' else 'CALL'
        for i in range(len(df3) - 3, len(df3) - 1):
            kp = _s(df3['sonar_k'].iloc[i-1]); dp = _s(df3['sonar_d'].iloc[i-1])
            kc = _s(df3['sonar_k'].iloc[i]);   dc = _s(df3['sonar_d'].iloc[i])
            is_gc = kp <= dp and kc > dc
            is_dc = kp >= dp and kc < dc
            if (opposite == 'CALL' and is_gc) or (opposite == 'PUT' and is_dc):
                return '휩쏘 감지 (반대 크로스 3봉 이내)'

    # HF-6: 장 개시/마감 근접
    if now:
        t = now.time()
        if dtime(9, 0) <= t <= dtime(9, 5):
            return '장 개시 5분 이내'
        if t >= dtime(15, 40):
            return '장 마감 5분 이내'

    return None


# ─── Layer A: 1분봉 추세 컨텍스트 (25점) ────────────────────────────

def _layer_a(df1: pd.DataFrame, side: str) -> int:
    cur = df1.iloc[-1]
    score = 0

    close = _s(cur['close'])
    ma20  = _s(cur['ma20'])
    ema8  = _s(cur['ema8'])
    ema21 = _s(cur['ema21'])
    ema60 = _s(cur['ema60'])
    adx1  = _s(cur['adx'])
    bb_w  = _s(cur['bb_width'])
    bb_mid = _s(cur['ma20'])

    # A-1: MA20 위치 + 기울기 (8점)
    ma20_prev = _s(df1['ma20'].iloc[-4]) if len(df1) >= 4 else ma20
    ma_slope_up = ma20 > ma20_prev * 1.0002  # 0.02% 이상 상승
    ma_slope_dn = ma20 < ma20_prev * 0.9998
    if side == 'CALL':
        if close > ma20 and ma_slope_up:  score += 8
        elif close > ma20:                score += 4
    else:
        if close < ma20 and ma_slope_dn:  score += 8
        elif close < ma20:                score += 4

    # A-2: EMA 스택 (7점)
    if side == 'CALL':
        if ema8 > ema21 > ema60:  score += 7
        elif ema8 > ema21:        score += 4
    else:
        if ema8 < ema21 < ema60:  score += 7
        elif ema8 < ema21:        score += 4

    # A-3: ADX 강도 (5점)
    if   20 <= adx1 <= 35:  score += 5
    elif 15 <= adx1 < 20 or 35 < adx1 <= 45: score += 3
    elif 10 <= adx1 < 15:  score += 1

    # A-4: 볼린저 밴드 위치 (5점)
    bb_w_prev = _s(df1['bb_width'].iloc[-4]) if len(df1) >= 4 else bb_w
    bb_expanding = bb_w > bb_w_prev * 1.02
    if side == 'CALL':
        if close > bb_mid and bb_expanding:  score += 5
        elif close > bb_mid:                 score += 3
    else:
        if close < bb_mid and bb_expanding:  score += 5
        elif close < bb_mid:                 score += 3

    return score


# ─── Layer B: 3분봉 소나 크로스 품질 (35점) ─────────────────────────

def _layer_b(df3: pd.DataFrame, side: str) -> int:
    if len(df3) < 3:
        return 0
    score = 0
    n = len(df3)
    cur   = df3.iloc[-1]
    prev  = df3.iloc[-2]

    sk_c = _s(cur['sonar_k']);  sd_c = _s(cur['sonar_d'])
    sk_p = _s(prev['sonar_k']); sd_p = _s(prev['sonar_d'])

    # B-1: 크로스 위치 — 과매도/과매수 깊이 (10점)
    if side == 'CALL':
        k_at_cross = sk_p  # 크로스 직전 K 값
        if   k_at_cross < -60: score += 10
        elif k_at_cross < -40: score += 8
        elif k_at_cross < -20: score += 5
        elif k_at_cross <   0: score += 2
    else:
        k_at_cross = sk_p
        if   k_at_cross > 60:  score += 10
        elif k_at_cross > 40:  score += 8
        elif k_at_cross > 20:  score += 5
        elif k_at_cross >  0:  score += 2

    # B-2: 축적 기간 — 크로스 전 K≈D 수렴 구간 봉수 (8점)
    accum = 0
    for i in range(n - 2, max(0, n - 21), -1):
        diff = abs(_s(df3['sonar_k'].iloc[i]) - _s(df3['sonar_d'].iloc[i]))
        if diff <= 6.0:
            accum += 1
        else:
            break
    if   accum >= 8: score += 8
    elif accum >= 5: score += 5
    elif accum >= 3: score += 3
    elif accum >= 1: score += 1

    # B-3: 크로스 모멘텀 / 가속도 (7점)
    cross_power_cur  = sk_c - sd_c
    cross_power_prev = sk_p - sd_p
    delta = cross_power_cur - cross_power_prev
    if side == 'CALL':
        if   delta > 10: score += 7
        elif delta >  7: score += 5
        elif delta >  4: score += 3
        elif delta >  1: score += 1
    else:
        if   delta < -10: score += 7
        elif delta <  -7: score += 5
        elif delta <  -4: score += 3
        elif delta <  -1: score += 1

    # B-4: 크로스 이후 K선 연속성 (5점)
    # 현재 봉이 크로스 봉 자체면 +2, 크로스 이후 1봉 더 유지했으면 +5
    if side == 'CALL':
        sustained = sk_c > sd_c  # 현재 봉에서도 K > D
        if sustained and sk_c > sk_p:  score += 5  # K가 크로스 후에도 상승 중
        elif sustained:                score += 2
    else:
        sustained = sk_c < sd_c
        if sustained and sk_c < sk_p:  score += 5
        elif sustained:                score += 2

    # B-5: DI 방향 일치 (5점)
    pdi = _s(cur['plus_di']); mdi = _s(cur['minus_di'])
    if side == 'CALL':
        if pdi > mdi and mdi < 30:   score += 5
        elif pdi > mdi:              score += 2
    else:
        if mdi > pdi and pdi < 30:   score += 5
        elif mdi > pdi:              score += 2

    return score


# ─── Layer C: 모멘텀 확인 (20점) ─────────────────────────────────────

def _layer_c(df3: pd.DataFrame, side: str) -> int:
    if len(df3) < 3:
        return 0
    score = 0
    cur   = df3.iloc[-1]
    prev  = df3.iloc[-2]

    mh_c = _s(cur['macd_hist'])
    mh_p = _s(prev['macd_hist'])
    rsi  = _s(cur['rsi'])
    stk  = _s(cur['stoch_k'])

    # C-1: MACD 히스토그램 (8점 + 패널티)
    # 부호와 방향만 사용 (가격 스케일 무관)
    # rising = 히스토그램이 이전 봉 대비 개선 방향으로 변화
    if side == 'CALL':
        rising = mh_c > mh_p           # 음수이더라도 덜 음수 = 개선
        if   mh_c > 0 and rising:   score += 8   # 양수이고 상승 중
        elif mh_c > 0:               score += 4   # 양수이나 평탄/하락
        elif rising:                 score += 2   # 음수이나 개선 중
        else:                        pass          # 음수이고 악화 → 0점
        if not rising and mh_c < mh_p * 1.3:      # 히스토그램이 급격히 나빠짐
            score -= 3
    else:
        rising = mh_c < mh_p           # 데드크로스: 더 음수 = 개선
        if   mh_c < 0 and rising:   score += 8
        elif mh_c < 0:               score += 4
        elif rising:                 score += 2
        else:                        pass
        if not rising and mh_c > mh_p * 1.3:
            score -= 3

    score = max(score, 0)

    # C-2: RSI 위치 (6점)
    if side == 'CALL':
        if   30 < rsi < 50: score += 6
        elif 50 <= rsi < 60: score += 3
        elif rsi >= 60:      score += 1
    else:
        if   50 < rsi < 70: score += 6
        elif 40 <= rsi <= 50: score += 3
        elif rsi <= 40:      score += 1

    # C-3: 스토캐스틱 K (6점)
    if side == 'CALL':
        if   20 < stk < 50:  score += 6
        elif 50 <= stk < 65: score += 3
        elif stk <= 20:      score += 2
    else:
        if   50 < stk < 80:  score += 6
        elif 35 <= stk <= 50: score += 3
        elif stk >= 80:      score += 2

    return score


# ─── Layer D: 캔들 품질 (10점) ───────────────────────────────────────

def _layer_d(df1: pd.DataFrame, side: str) -> int:
    if len(df1) < 2:
        return 0
    score = 0
    cur  = df1.iloc[-1]
    prev = df1.iloc[-2]

    o = _s(cur['open']); h = _s(cur['high'])
    l = _s(cur['low']);  c = _s(cur['close'])

    # D-1: 방향성 캔들 (5점)
    is_bull = c > o
    is_prev_bull = _s(prev['close']) > _s(prev['open'])
    if side == 'CALL':
        if is_bull:                      score += 3
        if is_bull and is_prev_bull:     score += 2
    else:
        if not is_bull:                  score += 3
        if (not is_bull) and (not is_prev_bull): score += 2

    # D-2: 꼬리 비율 (5점)
    body = abs(c - o)
    upper = h - max(c, o)
    lower = min(c, o) - l
    rng   = h - l

    if rng < 1e-9 or body < 1e-9:
        score += 2  # 도지: 중립
    else:
        if side == 'CALL':
            ratio = lower / body
            if   ratio > 1.5: score += 5
            elif ratio > 0.5: score += 3
            elif ratio > 0.1: score += 2
            else:             score += 1
        else:
            ratio = upper / body
            if   ratio > 1.5: score += 5
            elif ratio > 0.5: score += 3
            elif ratio > 0.1: score += 2
            else:             score += 1

    return score


# ─── Layer E: 거래량 (10점) ──────────────────────────────────────────

def _layer_e(df1: pd.DataFrame) -> int:
    if len(df1) < 5:
        return 0
    score = 0
    cur   = df1.iloc[-1]

    # E-1: 크로스 봉 거래량 (5점)
    vr = _s(cur['vol_ratio'])
    if   vr >= 2.0: score += 5
    elif vr >= 1.5: score += 3
    elif vr >= 1.0: score += 1

    # E-2: 거래량 추세 — 최근 3봉 (5점)
    if len(df1) >= 3:
        v1 = _s(df1['volume'].iloc[-3])
        v2 = _s(df1['volume'].iloc[-2])
        v3 = _s(df1['volume'].iloc[-1])
        if   v3 > v2 > v1:        score += 5
        elif v3 > v1 and v3 > v2: score += 3
        elif v3 > v1:             score += 1

    return score


# ─── 메인 함수 ───────────────────────────────────────────────────────

GRADE_THRESHOLD = {
    'S': 90,
    'A': 80,
    'B': 70,
}

LAYER_MIN = {
    'A': 10,
    'B': 15,
    'C': 8,
}


def score_entry(df_1min_raw: pd.DataFrame, side: str,
                now: datetime | None = None) -> dict:
    """
    KIS 1분봉 원시 OHLCV DataFrame → 진입 점수 & 판단.

    Parameters
    ----------
    df_1min_raw : 최소 60행 이상 1분봉 OHLCV (open/high/low/close/volume)
    side        : 'CALL' or 'PUT'
    now         : 현재 시각 (장 시간 필터용, None이면 스킵)

    Returns
    -------
    dict:
        entry      : bool
        grade      : 'S'|'A'|'B'|None
        total      : int (0~100)
        layers     : {'A':int, 'B':int, 'C':int, 'D':int, 'E':int}
        reject     : str or None  (거부 이유)
        sonar_k    : float (3분봉 현재 소나K)
        sonar_d    : float (3분봉 현재 소나D)
        price      : float (최신 종가)
    """
    result = {
        'entry': False, 'grade': None, 'total': 0,
        'layers': {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'E': 0},
        'reject': None, 'sonar_k': 0.0, 'sonar_d': 0.0, 'price': 0.0,
    }

    if df_1min_raw is None or len(df_1min_raw) < 30:
        result['reject'] = '1분봉 데이터 부족'
        return result

    # 지표 계산
    try:
        df1 = _calc_indicators(df_1min_raw.reset_index(drop=True))
    except Exception as e:
        result['reject'] = f'지표 계산 오류: {e}'
        return result

    # 3분봉 리샘플
    df3_raw = _resample_3min(df1)
    if df3_raw is None or len(df3_raw) < 20:
        result['reject'] = '3분봉 데이터 부족'
        return result
    try:
        df3 = _calc_indicators(df3_raw)
    except Exception as e:
        result['reject'] = f'3분봉 지표 계산 오류: {e}'
        return result

    result['price']   = _s(df1.iloc[-1]['close'])
    result['sonar_k'] = _s(df3.iloc[-1]['sonar_k'])
    result['sonar_d'] = _s(df3.iloc[-1]['sonar_d'])

    # 소나 크로스 확인 (필수 트리거)
    sk_c = _s(df3.iloc[-1]['sonar_k']); sd_c = _s(df3.iloc[-1]['sonar_d'])
    sk_p = _s(df3.iloc[-2]['sonar_k']); sd_p = _s(df3.iloc[-2]['sonar_d'])
    golden = sk_p <= sd_p and sk_c > sd_c and sk_c < 45
    dead   = sk_p >= sd_p and sk_c < sd_c and sk_c > -45

    if side == 'CALL' and not golden:
        result['reject'] = f'소나 골든크로스 없음 (K={sk_c:.1f} D={sd_c:.1f})'
        return result
    if side == 'PUT' and not dead:
        result['reject'] = f'소나 데드크로스 없음 (K={sk_c:.1f} D={sd_c:.1f})'
        return result

    # 하드 필터
    reject = _hard_filter(df1, df3, side, now)
    if reject:
        result['reject'] = reject
        return result

    # 5개 레이어 점수 계산
    a = _clamp(_layer_a(df1, side), 0, 25)
    b = _clamp(_layer_b(df3, side), 0, 35)
    c = _clamp(_layer_c(df3, side), 0, 20)
    d = _clamp(_layer_d(df1, side), 0, 10)
    e = _clamp(_layer_e(df1),        0, 10)

    result['layers'] = {'A': a, 'B': b, 'C': c, 'D': d, 'E': e}

    # 레이어 최소 기준
    if a < LAYER_MIN['A']:
        result['reject'] = f'Layer A 미달: {a}점 (최소 {LAYER_MIN["A"]}점)'
        result['total'] = a + b + c + d + e
        return result
    if b < LAYER_MIN['B']:
        result['reject'] = f'Layer B 미달: {b}점 (최소 {LAYER_MIN["B"]}점)'
        result['total'] = a + b + c + d + e
        return result
    if c < LAYER_MIN['C']:
        result['reject'] = f'Layer C 미달: {c}점 (최소 {LAYER_MIN["C"]}점)'
        result['total'] = a + b + c + d + e
        return result

    total = a + b + c + d + e
    result['total'] = total

    if total >= GRADE_THRESHOLD['S']:
        result['entry'] = True;  result['grade'] = 'S'
    elif total >= GRADE_THRESHOLD['A']:
        result['entry'] = True;  result['grade'] = 'A'
    elif total >= GRADE_THRESHOLD['B']:
        result['entry'] = True;  result['grade'] = 'B'
    else:
        result['reject'] = f'총점 미달: {total}/100 (기준: 70점)'

    return result


def check_precision_entry(code: str, name: str = '',
                          min_grade: str = 'B') -> dict | None:
    """
    KIS 1분봉 fetch → 정밀 점수 계산 → 진입 신호 반환.

    min_grade: 'B'(70+), 'A'(80+), 'S'(90+)

    Returns dict or None:
    {
        'side': 'CALL'|'PUT',
        'code': str, 'name': str, 'price': float,
        'score': int, 'grade': str,
        'layers': dict,
        'sonar_k': float, 'sonar_d': float,
    }
    """
    grade_min_score = {'S': 90, 'A': 80, 'B': 70}.get(min_grade, 70)

    try:
        from scanner_262_52 import get_minute_bars_kis
        # 3분봉 60개 = 1분봉 180개 + 지표 워밍업 30개 = 210개 → pages=7
        bars = get_minute_bars_kis(code, pages=7)
        if not bars or len(bars) < 30:
            return None

        df_raw = pd.DataFrame(bars)
        if 'ts' in df_raw.columns:
            df_raw = df_raw.drop(columns=['ts'])
        df_raw = df_raw.reset_index(drop=True)

        now = datetime.now()

        # CALL / PUT 모두 체크 (어느 쪽이든 신호 있으면 반환)
        for side in ('CALL', 'PUT'):
            res = score_entry(df_raw, side, now)
            if res['entry'] and res['total'] >= grade_min_score:
                log.info(
                    f'[Precision] ★ {name}({code}) {side} {res["grade"]}등급 '
                    f'{res["total"]}점 | '
                    f'A:{res["layers"]["A"]} B:{res["layers"]["B"]} '
                    f'C:{res["layers"]["C"]} D:{res["layers"]["D"]} '
                    f'E:{res["layers"]["E"]} | '
                    f'소나K:{res["sonar_k"]:.1f} 가격:{res["price"]:,.0f}원'
                )
                return {
                    'side':    side,
                    'code':    code,
                    'name':    name or code,
                    'price':   res['price'],
                    'score':   res['total'],
                    'grade':   res['grade'],
                    'layers':  res['layers'],
                    'sonar_k': res['sonar_k'],
                    'sonar_d': res['sonar_d'],
                }
            else:
                log.debug(
                    f'[Precision] {name}({code}) {side} 미진입: '
                    f'{res.get("reject","?")} (총점:{res["total"]})'
                )

        return None

    except Exception as e:
        log.warning(f'[Precision] {name}({code}) 오류: {e}')
        return None
