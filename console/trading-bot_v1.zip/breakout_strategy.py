# -*- coding: utf-8 -*-
"""
breakout_strategy.py — 장전 NXT 돌파매수 전략 (2026-06-24 신설)

배경: 6대장(analysis.py)은 눌림목/역추세 매수 시스템이라 RSI 30~65·스토캐 등 필터로
      '갭상승 + 거래량 폭발 돌파'를 구조적으로 차단한다. 강한 상승일엔 신호가 침묵.
      → 추세 리더의 '돌파(모멘텀)' 진입을 잡는 별도 트랙이 필요.

흐름(트레이더가 호출):
  1) 장전(08:00~08:50) stage_premarket(): 일봉으로 추세 리더 선별 + NXT 프리마켓 시세로
     기준선(전일고가·전일종가·MA20·20일평균거래량·프리마켓가) 고정 → 워치리스트 반환.
  2) 09:00~ scan_breakouts(staged): 각 종목 실시간 시세 조회 →
     (전일고가/프리마켓고가 돌파) + (당일 등락률 >= MIN) + (거래량 페이스 급증) + (MA20 위)
     충족 시 매수 후보 반환. 6대장 필터는 적용하지 않는다(돌파는 과매수 구간에서 터짐).
  3) 트레이더가 후보를 _execute_order(승인 필수)로 진입.

데이터: 일봉=momentum_strategy._daily(pykrx 캐시), 실시간=kis.get_stock_price(market).
정본 근거: wiki/연구/ (스크린=research_backtest 추세필터), 사용자 지시(2026-06-24).
"""
import logging
import datetime as dt

log = logging.getLogger('breakout')

# 파라미터 (config.py에서 오버라이드)
BREAKOUT_MIN_PCT = 2.0       # 당일 최소 등락률(%) — 이만큼은 올라야 '돌파'로 인정
BREAKOUT_VOL_SURGE = 1.5     # 거래량 페이스 배수(정상 페이스 대비) 이상이면 급증
BREAKOUT_RET60_MIN = 10.0    # 60일 추세 최소(%) — 추세 리더만
BREAKOUT_MAX_PRICE = 500000  # 가격 상한(봇 자금/선물 가격필터와 정합)
BREAKOUT_ENTRY_BUFFER = 0.02 # 기준선 +이내에서만 진입(추격 금지). 0.02=기준선 +2%까지만.
TOP_N = 5

# 장초반 조기진입 파라미터 (러너를 +5% 추격 전에 일찍 잡기)
OPENING_WINDOW_MIN = 30      # 09:00~09:00+이 분까지만 조기진입
OPENING_MIN_CHG_PCT = 0.5    # 최소 상승(전일종가 대비)
OPENING_MAX_CHG_PCT = 5.0    # 이 미만에서만(전역 +5% 가드와 정합 — 추격 금지)

_SESSION_OPEN = (9, 0)       # 정규장 시작
_SESSION_MIN = 390           # 09:00~15:30 = 390분


def _kst_now():
    return dt.datetime.utcnow() + dt.timedelta(hours=9)


def _session_fraction(now=None):
    """장 시작(09:00)부터 경과한 정규장 비율(0~1). 장전이면 0에 가깝게."""
    now = now or _kst_now()
    open_dt = now.replace(hour=_SESSION_OPEN[0], minute=_SESSION_OPEN[1], second=0, microsecond=0)
    mins = (now - open_dt).total_seconds() / 60.0
    if mins <= 0:
        return 0.0
    return min(1.0, mins / _SESSION_MIN)


def _daily(code):
    import momentum_strategy as _mom
    return _mom._daily(code)


def _daily_completed(code):
    """완성된 일봉만 반환(오늘 미완성 봉 제외). 장중 pykrx가 당일 부분봉을 마지막 행에
    포함시켜 '전일 고가' 기준선이 오염되는 것을 방지."""
    df = _daily(code)
    if df is None or len(df) == 0:
        return df
    try:
        today = _kst_now().date()
        last = df.index[-1]
        last_d = last.date() if hasattr(last, 'date') else None
        if last_d == today:
            df = df.iloc[:-1]
    except Exception:
        pass
    return df


def stage_premarket(universe, top_n=None):
    """장전 워치리스트 고정. universe=[{'code','name'},...].
    반환: {code: {name, prev_high, prev_close, ma20, avg20vol, ret60, premarket}}
    추세 리더(MA20·MA60 정배열 + ret60>=MIN + 가격<=상한)만 담는다."""
    top_n = top_n or TOP_N
    import kis
    staged = {}
    scored = []
    for u in universe:
        code, name = u['code'], u['name']
        df = _daily_completed(code)
        if df is None or len(df) < 65:
            continue
        c = df['close']; h = df['high']; v = df['volume']
        px = float(c.iloc[-1])
        ma20 = float(c.rolling(20).mean().iloc[-1])
        ma60 = float(c.rolling(60).mean().iloc[-1])
        ret60 = (px / float(c.iloc[-1 - 60]) - 1) * 100 if len(c) > 61 else 0.0
        if not (px > ma60 and ma20 > ma60 and ret60 >= BREAKOUT_RET60_MIN):
            continue
        if px > BREAKOUT_MAX_PRICE:
            continue
        prev_high = float(h.iloc[-1])      # 마지막 완성 일봉(전일) 고가
        avg20vol = float(v.iloc[-20:].mean())
        # NXT 프리마켓 시세(있으면 기준선 보강)
        pm = 0
        try:
            q = kis.get_stock_price(code, market='NX')
            pm = int((q or {}).get('price', 0) or 0)
        except Exception:
            pm = 0
        scored.append((ret60, code, dict(
            name=name, prev_high=prev_high, prev_close=px,
            ma20=ma20, avg20vol=avg20vol, ret60=round(ret60, 1), premarket=pm,
        )))
    scored.sort(key=lambda x: -x[0])
    for ret60, code, info in scored[:top_n]:
        staged[code] = info
    log.info(f'[Breakout] 장전 워치리스트 {len(staged)}종목: '
             + ', '.join(f"{v['name']}({v['ret60']}%)" for v in staged.values()))
    return staged


def scan_breakouts(staged, already=None):
    """워치리스트에서 돌파 발생 종목 반환. already=이미 진입/트리거된 code 집합.
    반환: [{'code','name','price','chg','reason','score'}]"""
    import kis
    already = already or set()
    frac = _session_fraction()
    out = []
    for code, info in staged.items():
        if code in already:
            continue
        try:
            q = kis.get_stock_price(code, market='UN')  # KRX+NXT 통합 현재가
        except Exception as e:
            log.debug(f'[Breakout] {code} 시세 실패: {e}')
            continue
        if not q:
            continue
        price = int(q.get('price', 0) or 0)
        chg = float(q.get('change_pct', 0) or 0)
        vol = int(q.get('volume', 0) or 0)
        if price <= 0:
            continue
        ref_high = max(info['prev_high'], info.get('premarket', 0) or 0)
        # 돌파 요건 (+추격방지 밴드: 기준선 바로 위에서만)
        broke = ref_high < price <= ref_high * (1 + BREAKOUT_ENTRY_BUFFER)
        strong = chg >= BREAKOUT_MIN_PCT
        # 거래량 페이스 급증: 누적거래량이 (20일평균 × 경과비율 × 배수)를 초과
        pace_need = info['avg20vol'] * max(frac, 0.05) * BREAKOUT_VOL_SURGE
        vol_surge = vol >= pace_need
        trend_ok = price > info['ma20']
        if broke and strong and vol_surge and trend_ok:
            score = int(min(100, 60 + chg * 2 + info['ret60'] / 10))
            reason = (f"[돌파] 전일고가 {info['prev_high']:,.0f} 돌파 @ {price:,} "
                      f"(+{chg:.1f}%, 거래량 {vol/ max(info['avg20vol'],1):.1f}x, 60일 {info['ret60']}%)")
            out.append(dict(code=code, name=info['name'], price=price, chg=chg,
                            reason=reason, score=score))
            log.info(f'[Breakout] 돌파 포착: {info["name"]} {reason}')
    return out


def scan_opening(staged, already=None):
    """장초반(09:00~09:00+WINDOW) 사전검증 리더의 '조기 강세' 진입.
    조건: 현재가>전일종가 AND 현재가>=당일시가(시초 고점 유지) AND
          MIN<=등락<MAX(상승했으나 아직 +5% 미만 — 추격 아님) AND 현재가>MA20.
    → 러너를 +5% 추격 전에 일찍 잡는다(예: 시초가 부근). 전역 +5% 가드와 충돌 없음."""
    import kis
    already = already or set()
    now = _kst_now()
    open_dt = now.replace(hour=_SESSION_OPEN[0], minute=_SESSION_OPEN[1], second=0, microsecond=0)
    mins = (now - open_dt).total_seconds() / 60.0
    if mins < 0 or mins > OPENING_WINDOW_MIN:
        return []
    out = []
    for code, info in staged.items():
        if code in already:
            continue
        try:
            q = kis.get_stock_price(code, market='UN')
        except Exception:
            continue
        if not q:
            continue
        price = int(q.get('price', 0) or 0)
        chg = float(q.get('change_pct', 0) or 0)
        op = int(q.get('open', 0) or 0)
        if price <= 0:
            continue
        prev_close = info['prev_close']
        ma20 = info['ma20']
        if (price > prev_close and op > 0 and price >= op
                and OPENING_MIN_CHG_PCT <= chg < OPENING_MAX_CHG_PCT
                and price > ma20):
            score = int(min(95, 60 + chg * 3 + info['ret60'] / 10))
            reason = (f"[장초반강세] 시가 {op:,}·전일종가 {prev_close:,.0f} 상회 @ {price:,} "
                      f"(+{chg:.1f}%, 60일 {info['ret60']}%)")
            out.append(dict(code=code, name=info['name'], price=price, chg=chg,
                            reason=reason, score=score))
            log.info(f'[Breakout] 장초반강세 포착: {info["name"]} {reason}')
    return out


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    import json, os
    wl = os.path.join(os.path.dirname(__file__), 'config_data', 'watchlist.json')
    with open(wl, encoding='utf-8') as f:
        uni = json.load(f).get('watchlist', [])
    print(f'유니버스 {len(uni)}종목 / 장 경과율 {_session_fraction():.2f}')
    staged = stage_premarket(uni)
    for code, v in staged.items():
        print(f"  {v['name']:12s} {code} 전일고가 {v['prev_high']:,.0f} MA20 {v['ma20']:,.0f} "
              f"60일 {v['ret60']}% 프리마켓 {v['premarket']:,}")
    print('--- 돌파 스캔 ---')
    for c in scan_breakouts(staged):
        print(' ', c)
