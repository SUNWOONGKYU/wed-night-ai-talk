# -*- coding: utf-8 -*-
"""
주식선물 코드 매핑 빌더 (KIS 마스터 파일)
형식: 1|단축코드|표준코드|종목명|...|순서|기초자산코드|기초자산명
실행: python build_futures_map.py
"""
import sys, os, json, io, zipfile, requests
from datetime import datetime, date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from Trading_Stock.STOCK_CODES_262 import STOCK_CODES

OUT_FILE = os.path.join(os.path.dirname(__file__), 'futures_code_map.json')
MST_URL = 'https://new.real.download.dws.co.kr/common/master/fo_stk_code_mts.mst.zip'


def _second_thursday(year, month):
    """주식선물 만기일 = 해당 월 둘째 목요일."""
    d = date(year, month, 1)
    first_thu = 1 + (3 - d.weekday()) % 7   # Mon=0..Thu=3
    return date(year, month, first_thu + 7)


def month_priority(today=None):
    """오늘 기준 만료 안 된 분기물(3/6/9/12) 최선월부터 우선순위 리스트 반환.
    만기일(둘째 목요일)이 지난 월물은 건너뛴다 → 매 분기 자동 롤오버."""
    today = today or date.today()
    out = []
    # 2026-09-21 수정: 주식선물은 매월물이 상장된다(9월물 만기 9/10 뒤 최근월물은 10월물). 분기물만 보면 12월물로 튀어
    # 유동성이 나쁘고, 재빌드를 안 하면 만기 지난 코드로 주문해 '선물옵션종목이 없습니다'(APBK0818) 가 난다.
    for yr in (today.year, today.year + 1):
        for m in range(1, 13):
            if _second_thursday(yr, m) >= today:
                ms = f'{m:02d}'
                if ms not in out:
                    out.append(ms)
    return out[:4] or ['03']


MONTH_PRIORITY = month_priority()  # 날짜 기반 자동 산출 (만기 지난 월물 자동 제외)


def download_and_parse():
    """마스터 파일 다운로드 → 파싱"""
    print(f'  다운로드: {MST_URL}')
    r = requests.get(MST_URL, timeout=30)
    r.raise_for_status()
    z = zipfile.ZipFile(io.BytesIO(r.content))
    data = z.read(z.namelist()[0])
    lines = data.split(b'\n')
    print(f'  총 {len(lines):,}줄')

    # base_code -> [(short_code, month)]
    by_base = {}
    for line in lines:
        try:
            txt = line.decode('cp949', errors='replace').strip()
            if not txt:
                continue
            cols = txt.split('|')
            if len(cols) < 8:
                continue
            short_code = cols[1].strip()   # A11604
            base_code  = cols[7].strip()   # 005930
            if not (short_code.startswith('A') and len(base_code) == 6 and base_code.isdigit()):
                continue
            month = short_code[4:6]        # '04'
            if base_code not in by_base:
                by_base[base_code] = []
            by_base[base_code].append((short_code, month))
        except Exception:
            continue

    print(f'  파싱된 기초자산: {len(by_base)}개')
    return by_base


def build_map():
    print(f"\n{'='*60}")
    print(f'  주식선물 코드 매핑 빌더 v3')
    print(f'  대상: {len(STOCK_CODES)}개 종목')
    print(f"{'='*60}\n")

    by_base = download_and_parse()

    target = set(STOCK_CODES.keys())
    found = {}
    reverse = {}

    for stock_code in sorted(target):
        candidates = by_base.get(stock_code, [])
        if not candidates:
            continue
        # 최근월물 우선 선택
        best = None
        for pm in MONTH_PRIORITY:
            for fcode, month in candidates:
                if month == pm:
                    best = fcode
                    break
            if best:
                break
        if not best:
            best = candidates[0][0]

        found[stock_code] = best
        reverse[best] = stock_code
        name = STOCK_CODES.get(stock_code, stock_code)
        print(f'  {stock_code} {name:12s} → {best}')

    print(f"\n{'='*60}")
    print(f'  매핑 완료: {len(found)}/{len(STOCK_CODES)}개')

    months = {}
    for fc in found.values():
        m = fc[4:6]
        months[m] = months.get(m, 0) + 1
    for m, cnt in sorted(months.items()):
        print(f'  {m}월물: {cnt}개')

    with open(OUT_FILE, 'w', encoding='utf-8') as f:
        json.dump({
            'stock_to_futures': found,
            'futures_to_stock': reverse,
            'month': sorted(months.keys())[0] if months else '04',
            'built_at': datetime.now().isoformat(),
        }, f, ensure_ascii=False, indent=2)

    print(f'  저장: {OUT_FILE}')
    print(f"{'='*60}\n")
    return found


if __name__ == '__main__':
    build_map()
