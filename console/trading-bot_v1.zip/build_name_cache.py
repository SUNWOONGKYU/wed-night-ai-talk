"""1회성: 262종목 종목명을 네이버에서 받아 data/stock_names.json 캐시로 저장.
이후 스캔은 이 캐시를 써서 네이버 시세콜을 생략한다."""
import json
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

from Trading_Stock.STOCK_CODES_262 import STOCK_CODES
from scanner_262_52 import get_stock_info_naver

OUT = os.path.join('data', 'stock_names.json')


def main():
    codes = list(STOCK_CODES.keys())
    names = {}
    with ThreadPoolExecutor(max_workers=12) as ex:
        futs = {ex.submit(get_stock_info_naver, c): c for c in codes}
        for fut in as_completed(futs):
            c = futs[fut]
            try:
                name, _price, _rate = fut.result()
                if name and name != c:
                    names[c] = name
            except Exception:
                pass
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump(names, f, ensure_ascii=False, indent=0)
    print(f'saved {len(names)}/{len(codes)} names -> {OUT}')


if __name__ == '__main__':
    main()
