# -*- coding: utf-8 -*-
"""
캔들차트 생성 — 일봉(60개) + 3분봉(60개), 거래량 패널 없음
상승=빨강, 하락=파랑
"""
import os, logging, tempfile
from collections import defaultdict

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.font_manager as fm
import matplotlib.ticker as mticker
import pandas as pd

log = logging.getLogger(__name__)

# ── 한글 폰트 ──────────────────────────────────
def _get_font():
    for name in ['Malgun Gothic', 'NanumGothic', 'AppleGothic', 'Gulim', 'Dotum']:
        if name in {f.name for f in fm.fontManager.ttflist}:
            return name
    return None

_FONT = _get_font()
if _FONT:
    matplotlib.rcParams['font.family'] = _FONT
matplotlib.rcParams['axes.unicode_minus'] = False

# ── 색상 ───────────────────────────────────────
BG   = '#131722'
UP   = '#ef5350'   # 양봉 (빨강)
DOWN = '#2962ff'   # 음봉 (파랑)
GRID = '#2a2e39'
TEXT = '#d1d4dc'


# ── 데이터 조회 ────────────────────────────────

def _fetch_1min(code: str, count: int = 60):
    """KIS 1분봉 최근 count개 (정확한 OHLCV)"""
    try:
        from scanner_262_52 import get_minute_bars_kis
        bars = get_minute_bars_kis(code, pages=max(1, count // 30 + 1))
        if not bars:
            return None
        df = pd.DataFrame(bars)
        df.index = pd.RangeIndex(len(df))
        # ts 컬럼 제거 후 컬럼명 통일
        for col in ['ts']:
            if col in df.columns:
                df = df.drop(columns=[col])
        df = df.rename(columns={'open':'O','high':'H','low':'L','close':'C','volume':'V'})
        df = df[['O','H','L','C','V']].astype(float)
        df = df.tail(count)
        return df if len(df) >= 5 else None
    except Exception as e:
        log.warning(f'[Chart] 1분봉 오류: {e}')
        return None


def _fetch_daily(code: str, count: int = 60):
    """일봉 최근 count개 — pykrx 사용 (KIS 일봉은 ~30개만 반환해 60개를 못 채움 → 차트 깨짐 버그 원인).
    승인 차트의 '일봉(60개)' 패널 전용. 깨끗한 일봉 OHLCV."""
    try:
        from pykrx import stock as _stk
        from datetime import datetime as _dt, timedelta as _td
        end = _dt.now().strftime('%Y%m%d')
        start = (_dt.now() - _td(days=count * 2 + 60)).strftime('%Y%m%d')  # 거래일 여유분
        df = _stk.get_market_ohlcv(start, end, code)
        if df is None or len(df) < 5:
            return None
        df = df.rename(columns={'시가': 'O', '고가': 'H', '저가': 'L', '종가': 'C', '거래량': 'V'})
        df = df[['O', 'H', 'L', 'C', 'V']].astype(float)
        return df.tail(count)
    except Exception as e:
        log.warning(f'[Chart] 일봉 오류: {e}')
        return None


def _fetch_minute(code: str, minutes: int = 3):
    try:
        import requests as _req
        from datetime import datetime as _dt, timedelta as _td
        now = _dt.now()
        url = (
            f'https://api.finance.naver.com/siseJson.naver?symbol={code}'
            f'&requestType=1'
            f'&startTime={(now-_td(days=6)).strftime("%Y%m%d")}'
            f'&endTime={now.strftime("%Y%m%d")}'
            f'&timeframe=minute'
        )
        r = _req.get(url, timeout=6,
                     headers={'User-Agent': 'Mozilla/5.0'}, allow_redirects=False)
        if r.status_code != 200:
            return None

        raw = []
        for line in r.text.split('\n'):
            line = line.strip().rstrip(',')
            if not line or '"202' not in line:
                continue
            line = line.replace('[','').replace(']','').replace('"','')
            parts = [p.strip() for p in line.split(',')]
            if len(parts) < 6:
                continue
            ts, c_s, v_s = parts[0], parts[4], parts[5]
            if c_s in ('null',''):
                continue
            try:
                c = int(c_s); v = int(v_s) if v_s not in ('null','') else 0
                hhmm = ts[8:12]
                if c > 0 and '0900' <= hhmm <= '1530':
                    raw.append({'ts': ts, 'c': c, 'v': v})
            except Exception:
                continue

        if not raw:
            return None
        raw.sort(key=lambda x: x['ts'])

        dg = defaultdict(list)
        for b in raw:
            dg[b['ts'][:8]].append(b)
        result = []
        for date in sorted(dg):
            day = dg[date]
            for i in range(len(day)-1, 0, -1):
                day[i]['v'] = max(day[i]['v'] - day[i-1]['v'], 0)
            result.extend(day)

        df = pd.DataFrame(result)
        df['dt'] = pd.to_datetime(df['ts'], format='%Y%m%d%H%M')
        df = df.set_index('dt').sort_index()
        df['O'] = df['C'] = df['H'] = df['L'] = df['c'].astype(float)
        df['V'] = df['v'].astype(float)
        df = df[['O','H','L','C','V']]

        if minutes > 1:
            df = df.resample(f'{minutes}min', closed='left', label='left').agg(
                O=('O','first'), H=('H','max'),
                L=('L','min'),  C=('C','last'), V=('V','sum')
            ).dropna(subset=['O'])
            df = df.between_time('09:00', '15:30')

        return df.tail(60) if len(df) >= 5 else None
    except Exception as e:
        log.warning(f'[Chart] 분봉 오류: {e}')
        return None


# ── 캔들볼륨 드로잉 (너비=거래량, 별도 패널 없음) ──

def _draw_candles(ax, df: pd.DataFrame, label: str,
                  ma_period: int = 20, signal_color: str = UP,
                  is_daily: bool = False):
    import numpy as np
    ax.set_facecolor(BG)
    ax.spines[:].set_color(GRID)
    ax.tick_params(colors=TEXT, labelsize=8)
    ax.yaxis.tick_right()
    ax.yaxis.set_label_position('right')

    n = len(df)

    # 너비: sqrt(거래량) 으로 정규화 → 극단적 편차 완화
    vols = df['V'].values.copy()
    vols[vols <= 0] = 1
    sqrt_v = vols ** 0.5
    mean_sv = sqrt_v.mean() or 1
    widths = sqrt_v / mean_sv   # 평균=1 기준 상대폭
    widths = [max(w, 0.3) for w in widths]   # 최소 0.3

    x_centers = []
    x = 0.0
    for w in widths:
        x_centers.append(x + w / 2)
        x += w
    total_w = x

    for i, (_, row) in enumerate(df.iterrows()):
        o, h, l, c = row['O'], row['H'], row['L'], row['C']
        w = widths[i]
        xc = x_centers[i]
        color = UP if c >= o else DOWN

        body_b = min(o, c)
        body_h = abs(c - o)
        if body_h < (h - l) * 0.01:
            body_h = (h - l) * 0.01 or 1

        ax.add_patch(mpatches.Rectangle(
            (xc - w/2, body_b), w, body_h,
            linewidth=0, facecolor=color, alpha=0.9, zorder=3
        ))
        ax.plot([xc, xc], [l, h], color=color, linewidth=0.7, zorder=2)

    if n >= ma_period:
        ma = df['C'].rolling(ma_period).mean().values
        ax.plot(x_centers, ma, color='#f0c040', linewidth=1.2,
                zorder=4, label=f'MA{ma_period}')

    last_c = float(df['C'].iloc[-1])
    ax.axhline(last_c, color=signal_color, linewidth=0.8,
               linestyle='--', alpha=0.7, zorder=1)

    ax.set_xlim(0, total_w)
    ax.set_ylim(df['L'].min() * 0.995, df['H'].max() * 1.005)
    ax.grid(True, axis='y', color=GRID, linewidth=0.5, linestyle='--')
    ax.set_ylabel(label, color=TEXT, fontsize=9)

    idx = list(df.index)
    n_labels = min(8, n)
    step = max(n // n_labels, 1)
    tick_pos, tick_labels = [], []
    for i in range(0, n, step):
        tick_pos.append(x_centers[i])
        ts = idx[i]
        if hasattr(ts, 'strftime'):
            lbl = ts.strftime('%m/%d') if is_daily else ts.strftime('%m/%d %H:%M')
        else:
            lbl = str(ts)
        tick_labels.append(lbl)

    ax.xaxis.set_major_locator(mticker.FixedLocator(tick_pos))
    ax.set_xticklabels(tick_labels, rotation=25, ha='right',
                       fontsize=7, color=TEXT)


# ── 메인 생성 함수 ─────────────────────────────

def generate_chart(stock_code: str, stock_name: str,
                   score: int, side: str = 'CALL') -> str | None:
    """
    일봉(60개) + 3분봉(60개) 캔들차트 PNG 생성. 거래량 패널 없음.
    Returns: 임시 파일 경로 (호출자가 삭제 책임)
    """
    daily_df  = _fetch_daily(stock_code, count=60)   # 실제 일봉 (기존 _fetch_1min=1분봉 버그 수정)
    minute_df = _fetch_minute(stock_code, minutes=3)

    if daily_df is None and minute_df is None:
        log.warning(f'[Chart] {stock_name}: 데이터 없음')
        return None

    sig_color = UP if side == 'CALL' else DOWN

    fig, (ax1, ax2) = plt.subplots(
        2, 1, figsize=(11, 8),
        facecolor=BG,
        gridspec_kw={'hspace': 0.45}
    )

    # ── 상단: 일봉 ──────────────────────────────
    if daily_df is not None and len(daily_df) >= 5:
        _draw_candles(ax1, daily_df,
                      label='일봉 (60개)',
                      ma_period=20,
                      signal_color=sig_color,
                      is_daily=True)
    else:
        ax1.set_facecolor(BG)
        ax1.text(0.5, 0.5, '일봉 데이터 없음', ha='center', va='center',
                 color=TEXT, transform=ax1.transAxes, fontsize=11)

    ax1.set_title(
        f'{stock_name}({stock_code})  {side} {score}점',
        color='#ffffff', fontsize=12, fontweight='bold',
        loc='left', pad=8
    )

    # ── 하단: 3분봉 ─────────────────────────────
    if minute_df is not None and len(minute_df) >= 5:
        _draw_candles(ax2, minute_df,
                      label='3분봉 (60개)',
                      ma_period=20,
                      signal_color=sig_color,
                      is_daily=False)
    else:
        ax2.set_facecolor(BG)
        ax2.text(0.5, 0.5, '3분봉 데이터 없음', ha='center', va='center',
                 color=TEXT, transform=ax2.transAxes, fontsize=11)

    ax2.set_title('3분봉 (최근 3시간 / 60개)',
                  color=TEXT, fontsize=10, loc='left', pad=6)

    tmp = tempfile.NamedTemporaryFile(
        suffix='.png', delete=False,
        dir=os.path.join('data', 'logs'),
    )
    fig.savefig(tmp.name, dpi=130, bbox_inches='tight', facecolor=BG)
    plt.close(fig)
    log.info(f'[Chart] {stock_name} 차트: {tmp.name}')
    return tmp.name
