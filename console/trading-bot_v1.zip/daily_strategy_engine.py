# -*- coding: utf-8 -*-
"""
일봉 전략 엔진 — strategies/*.json 중 timeframe == "1d" 인 전략을 종목 일봉(pykrx) + 지수 일봉(KIS) 위에서 평가한다.
분봉 엔진(strategy_engine.py, 1m)과 같은 JSON 규격을 쓰고 x_* 확장 필드를 더 안다. 두 엔진은 timeframe 으로 파일을 나눠 갖는다.

규격 (분봉 규격 + 확장):
{
  "id": "3대장4졸병", "name": "...", "enabled": true, "live": true, "direction": "CALL", "timeframe": "1d",
  "bosses":   [ {조건}, ... ],     # 전부 충족 필수. x_market:true 인 대장은 any[] 를 시장값으로 OR 평가
  "soldiers": [ {조건}, ... ],     # 충족 개수 k
  "scoring":  { "boss": 20, "soldier": 10, "min_score": 70, "min_soldiers": 1 },
  "x_entry":     { "at": "next_open" },                       # 신호일(일봉 확정) 다음 거래일 시가 — 봇은 09시 첫 스캔에 승인 요청
  "x_exit":      { "type": "time", "hold_days": 20, "at": "open" },   # 시간 청산 (운영 전략 청산_일봉트랙.보유_영업일 이 우선)
  "x_portfolio": { "max_positions": 2, "priority": ["score desc", "vol20 asc"], "no_reentry_while_holding": true },
  "x_validation": { ... }                                      # 검증 요약(카드 표시용)
}
점수 = 대장 충족수 × scoring.boss + 졸병 충족수 × scoring.soldier. 통과 = 대장 전부 + 점수 ≥ min_score + 졸병 ≥ min_soldiers.

종목 지표 (일봉 ≥ MIN_BARS 봉, 마지막 확정봉 기준):
  close            종가            dev_ma60   종가/MA60 - 1 (%)       vol20   20일 수익률 표준편차 (%)
  dist_lo250       종가/250일 최저가 - 1 (%)   dist_hi250  종가/250일 최고가 - 1 (%)
  ret3             3일 수익률 (%)   mom20      20일 수익률 (%)         ma60 ma200 rsi14(참고)
  vol20_cs_median  당일 유니버스 vol20 중앙값 (전 종목 계산 후 부여 — 횡단면)
시장 지표 (KODEX200 069500, oversold_strategy._kodex_daily 재사용):
  idx_close  idx_ma200  idx_dd250(250일 최고가 대비 %)

장중(15:40 전)에는 오늘 봉(미확정)을 버리고 전일 확정봉으로 평가한다 → x_entry.at=next_open 과 일치.
평가 결과는 data/daily_strategy_last.json 에 남겨 스캐너 카드(다른 프로세스)가 "오늘 후보"를 읽는다.
"""
import os
import re
import json
import glob
import time
import logging
import datetime as dt

import numpy as np
import pandas as pd

log = logging.getLogger('daily_strategy')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STRATEGY_DIR = os.path.join(BASE_DIR, 'strategies')
LAST_FILE = os.path.join(BASE_DIR, 'data', 'daily_strategy_last.json')
TIMEFRAME = '1d'
MIN_BARS = 260
MIN_PRICE = 2000
FETCH_DAYS = 430                       # 캘린더일 → 약 290 거래일 (250일 고저·MA200 계산 여유)
CONFIRM_TIME = dt.time(15, 40)         # 이 시각 전엔 오늘 봉을 미확정으로 보고 버린다

OPS = {'<', '<=', '>', '>=', '==', 'between'}
STOCK_COLS = ['close', 'dev_ma60', 'vol20', 'dist_lo250', 'dist_hi250', 'ret3', 'mom20', 'ma60', 'ma200', 'rsi14',
              'vol20_cs_median']
MARKET_COLS = ['idx_close', 'idx_ma200', 'idx_dd250']
IND_COLS = STOCK_COLS + MARKET_COLS
DEFAULT_SCORING = {'boss': 20, 'soldier': 10, 'min_score': 70, 'min_soldiers': 1}

_cache = {'mtime': None, 'strategies': []}


# ---------- 로드 / 검증 ----------
def validate(spec):
    """규격 검증. 문제 목록 반환(비어 있으면 OK)."""
    errs = []
    if not isinstance(spec, dict):
        return ['전략 파일이 객체(JSON object)가 아님']
    if not spec.get('id'):
        errs.append('id 없음')
    if spec.get('direction') not in ('CALL', 'PUT'):
        errs.append('direction 은 CALL 또는 PUT')
    if spec.get('timeframe') != TIMEFRAME:
        errs.append(f'timeframe 은 "{TIMEFRAME}"')
    for key in ('hard_filters', 'bosses', 'soldiers'):
        conds = spec.get(key, []) or []
        if not isinstance(conds, list):
            errs.append(f'{key} 는 목록이어야 함')
            continue
        for i, c in enumerate(conds):
            e = _validate_cond(c)
            if e:
                errs.append(f'{key}[{i}]: {e}')
    if not spec.get('bosses'):
        errs.append('bosses 가 비어 있음 (대장 조건 1개 이상)')
    if not isinstance(spec.get('scoring', {}), dict):
        errs.append('scoring 은 객체')
    xe = spec.get('x_exit') or {}
    if xe and not isinstance(xe.get('hold_days', 1), int):
        errs.append('x_exit.hold_days 는 정수(영업일)')
    xp = spec.get('x_portfolio') or {}
    for p in xp.get('priority', []) or []:
        m = re.match(r'^(\w+)\s+(asc|desc)$', str(p))
        if not m or m.group(1) not in ('score', 'k') + tuple(IND_COLS):
            errs.append(f'x_portfolio.priority 항목 잘못됨: {p} ("<지표|score> asc|desc")')
    return errs


def _validate_cond(c):
    if not isinstance(c, dict):
        return '조건은 객체'
    if c.get('x_market'):
        subs = c.get('any')
        if not subs:
            subs = [c] if c.get('op') else []
        if not subs:
            return 'x_market 대장은 any[] (시장 조건 1개 이상) 필요'
        for s in subs:
            e = _validate_simple(s, MARKET_COLS)
            if e:
                return 'any: ' + e
        return None
    return _validate_simple(c, STOCK_COLS)


def _validate_simple(c, cols):
    op = c.get('op')
    if op not in OPS:
        return f'op 잘못됨: {op} (일봉 엔진은 {" ".join(sorted(OPS))} 만)'
    if c.get('ind') not in cols:
        return f'지표 없음: {c.get("ind")}'
    if 'ref' in c:
        if c['ref'] not in cols:
            return f'ref 지표 없음: {c["ref"]}'
    elif op == 'between':
        v = c.get('value')
        if not (isinstance(v, list) and len(v) == 2):
            return 'between 은 value=[하한, 상한]'
    elif not isinstance(c.get('value'), (int, float)):
        return 'value 숫자 필요'
    for sub in c.get('and', []) or []:
        e = _validate_simple(sub, cols)
        if e:
            return 'and: ' + e
    return None


def load_strategies(force=False):
    """strategies/*.json 중 timeframe=="1d" 만 로드 (파일 변경 시 자동 재로드). enabled=false 도 목록엔 포함."""
    try:
        files = sorted(glob.glob(os.path.join(STRATEGY_DIR, '*.json')))
        mtime = tuple((f, os.path.getmtime(f)) for f in files)
    except Exception:
        files, mtime = [], ()
    if not force and _cache['mtime'] == mtime:
        return _cache['strategies']
    out = []
    for f in files:
        try:
            with open(f, encoding='utf-8-sig') as fp:
                spec = json.load(fp)
            if not isinstance(spec, dict) or spec.get('timeframe', '1m') != TIMEFRAME:
                continue
            spec.setdefault('id', os.path.splitext(os.path.basename(f))[0])
            spec.setdefault('name', spec['id'])
            spec.setdefault('enabled', True)
            spec.setdefault('live', False)
            spec.setdefault('sample', False)
            spec['scoring'] = {**DEFAULT_SCORING, **(spec.get('scoring') or {})}
            spec['_file'] = f
            spec['_errors'] = validate(spec)
            out.append(spec)
        except Exception as e:
            out.append({'id': os.path.splitext(os.path.basename(f))[0], 'name': os.path.basename(f), 'enabled': False,
                        'timeframe': TIMEFRAME, '_file': f, '_errors': [f'JSON 읽기 실패: {e}']})
    _cache['mtime'] = mtime
    _cache['strategies'] = out
    return out


def enabled_strategies():
    return [s for s in load_strategies() if s.get('enabled') and not s.get('_errors')]


def live_strategies():
    """봇(trader.py)이 승인 요청까지 가는 전략: enabled && live && 오류 없음."""
    return [s for s in enabled_strategies() if s.get('live')]


# ---------- 데이터 ----------
def _now():
    return dt.datetime.now()


def _confirmed_only(index_dates):
    """오늘 봉이 미확정(15:40 전)이면 오늘 이전 날짜만 True 인 마스크."""
    now = _now()
    today = now.date()
    if now.time() >= CONFIRM_TIME:
        return None
    return [d < today for d in index_dates]


def load_stock_daily(code):
    """종목 일봉(pykrx, oversold_strategy 캐시 재사용) → 확정봉만 DataFrame. 부족하면 None."""
    import oversold_strategy as _ov
    df = _ov._daily(code, days=FETCH_DAYS)
    if df is None or len(df) < MIN_BARS:
        return None
    idx = [pd.Timestamp(x).date() for x in df.index]
    mask = _confirmed_only(idx)
    if mask is not None:
        df = df[mask]
    if len(df) < MIN_BARS:
        return None
    return df


def stock_indicators(df):
    """일봉 DataFrame → 마지막 봉 기준 지표 dict (vol20_cs_median 은 나중에 횡단면으로 부여)."""
    c = df['close'].astype(float)
    close = float(c.iloc[-1])
    ma60 = float(c.rolling(60).mean().iloc[-1])
    ma200 = float(c.rolling(200).mean().iloc[-1])
    ret = c.pct_change()
    vol20 = float(ret.tail(20).std()) * 100
    lo250 = float(df['low'].astype(float).tail(250).min())
    hi250 = float(df['high'].astype(float).tail(250).max())
    delta = c.diff()
    up = delta.clip(lower=0).rolling(14).mean()
    dn = (-delta.clip(upper=0)).rolling(14).mean()
    rs = up / dn.replace(0, np.nan)
    rsi14 = float((100 - 100 / (1 + rs)).iloc[-1])
    vals = {
        'close': close,
        'ma60': ma60, 'ma200': ma200,
        'dev_ma60': (close / ma60 - 1) * 100 if ma60 else np.nan,
        'vol20': vol20,
        'dist_lo250': (close / lo250 - 1) * 100 if lo250 else np.nan,
        'dist_hi250': (close / hi250 - 1) * 100 if hi250 else np.nan,
        'ret3': (close / float(c.iloc[-4]) - 1) * 100,
        'mom20': (close / float(c.iloc[-21]) - 1) * 100,
        'rsi14': rsi14,
        'bar_date': str(pd.Timestamp(df.index[-1]).date()),
    }
    return vals


def market_indicators():
    """KODEX200 일봉 → {idx_close, idx_ma200, idx_dd250, idx_date}. 실패 시 None."""
    import oversold_strategy as _ov
    s = _ov._kodex_daily(days=320)
    if s is None or len(s) < 200:
        return None
    dates = [dt.datetime.strptime(str(d), '%Y%m%d').date() for d in s.index]
    mask = _confirmed_only(dates)
    if mask is not None:
        s = s[mask]
    if len(s) < 200:
        return None
    close = float(s.iloc[-1])
    ma200 = float(s.tail(200).mean())
    hi250 = float(s.tail(250).max())
    return {'idx_close': close, 'idx_ma200': ma200, 'idx_dd250': (close / hi250 - 1) * 100, 'idx_date': str(s.index[-1])}


# ---------- 평가 ----------
def _num(vals, key):
    v = vals.get(key)
    try:
        v = float(v)
    except Exception:
        return None
    return None if np.isnan(v) else v


def eval_simple(c, vals):
    x = _num(vals, c['ind'])
    if x is None:
        return False
    if 'ref' in c:
        y = _num(vals, c['ref'])
        if y is None:
            return False
    else:
        y = c.get('value')
    op = c['op']
    if op == '<': ok = x < y
    elif op == '<=': ok = x <= y
    elif op == '>': ok = x > y
    elif op == '>=': ok = x >= y
    elif op == '==': ok = abs(x - y) < 1e-9
    elif op == 'between': ok = y[0] <= x < y[1]
    else: ok = False
    if ok and c.get('and'):
        ok = all(eval_simple(s, vals) for s in c['and'])
    return bool(ok)


def eval_cond(c, vals, market):
    """대장/졸병 조건 하나. x_market 이면 market dict 에 대해 any[] OR."""
    if c.get('x_market'):
        if not market:
            return False
        subs = c.get('any') or [c]
        return any(eval_simple(s, market) for s in subs)
    return eval_simple(c, vals)


def _cond_id(c, i, prefix):
    return c.get('id') or (c.get('ind') or prefix) + ('' if not i else f'_{i}')


def _cond_label(c, i, prefix):
    return c.get('label') or _cond_id(c, i, prefix)


def evaluate(spec, vals, market):
    """전략 하나 × 종목 하나. 반환 {score, k, boss_ok, bosses_ok, bosses{}, soldiers{}, soldiers_hit[], passed, blocked}"""
    sc = spec['scoring']
    out = {'score': 0, 'k': 0, 'boss_ok': 0, 'bosses_ok': False, 'bosses': {}, 'soldiers': {}, 'soldiers_hit': [],
           'passed': False, 'blocked': None}
    for i, c in enumerate(spec.get('hard_filters', []) or []):
        if not eval_cond(c, vals, market):
            out['blocked'] = _cond_id(c, i, 'hard')
            return out
    for i, c in enumerate(spec.get('bosses', []) or []):
        out['bosses'][_cond_id(c, i, 'boss')] = eval_cond(c, vals, market)
    for i, c in enumerate(spec.get('soldiers', []) or []):
        cid = _cond_id(c, i, 'soldier')
        hit = eval_cond(c, vals, market)
        out['soldiers'][cid] = hit
        if hit:
            out['soldiers_hit'].append(cid)
    out['boss_ok'] = sum(1 for v in out['bosses'].values() if v)
    out['bosses_ok'] = bool(out['bosses']) and all(out['bosses'].values())
    out['k'] = len(out['soldiers_hit'])
    out['score'] = out['boss_ok'] * sc['boss'] + out['k'] * sc['soldier']
    out['passed'] = out['bosses_ok'] and out['score'] >= sc['min_score'] and out['k'] >= sc.get('min_soldiers', 0)
    return out


def _fmt_val(key, v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return '-'
    if key in ('close', 'ma60', 'ma200', 'idx_close', 'idx_ma200'):
        return f'{v:,.0f}'
    if key in ('vol20', 'vol20_cs_median'):
        return f'{v:.2f}%'
    return f'{v:+.1f}%'


def make_reason(spec, res, vals, market, hold_days=None):
    """사람이 읽는 한 줄: 대장 값 · 졸병 충족 목록 → 점수 · 청산 규칙."""
    parts = []
    for i, c in enumerate(spec.get('bosses', []) or []):
        if c.get('x_market'):
            m = market or {}
            parts.append(f'하락장(KODEX200 {_fmt_val("idx_close", m.get("idx_close"))}, 200일선 {_fmt_val("idx_ma200", m.get("idx_ma200"))}, '
                         f'250일고점 {_fmt_val("idx_dd250", m.get("idx_dd250"))})')
        else:
            ind = c.get('ind')
            s = f'{_cond_label(c, i, "대장")} {_fmt_val(ind, vals.get(ind))}'
            if 'ref' in c:
                s += f'/{_fmt_val(c["ref"], vals.get(c["ref"]))}'
            parts.append(s)
    n_sol = len(spec.get('soldiers', []) or [])
    labels = []
    for i, c in enumerate(spec.get('soldiers', []) or []):
        if _cond_id(c, i, 'soldier') in res['soldiers_hit']:
            labels.append(_cond_label(c, i, '졸병'))
    hd = hold_days or (spec.get('x_exit') or {}).get('hold_days')
    exit_txt = f'{hd}영업일 시가청산' if hd else '시간청산'
    xe = spec.get('x_exit') or {}
    if xe.get('stop_loss') is None:
        exit_txt += '(손절 없음·파국 -15%만)'
    return (' · '.join(parts) + f' · 졸병 {res["k"]}/{n_sol}(' + ', '.join(labels) + ')'
            + f' → {res["score"]}점 · {exit_txt}')


def _priority_key(priority):
    """["score desc", "vol20 asc"] → sort key 함수 (값 없으면 뒤로)."""
    rules = []
    for p in priority or ['score desc']:
        m = re.match(r'^(\w+)\s+(asc|desc)$', str(p))
        if m:
            rules.append((m.group(1), m.group(2) == 'desc'))

    def key(c):
        ks = []
        for field, desc in rules:
            v = c.get(field) if field in ('score', 'k') else (c.get('values') or {}).get(field)
            v = _num({'v': v}, 'v')
            ks.append((v is None, (-v if desc else v) if v is not None else 0))
        return tuple(ks)
    return key


def evaluate_universe(universe, strategies=None, market=None, hold_days=None, progress=None, save=True):
    """universe=[{'code','name'},...] → {'date','market','elapsed','n_universe','n_data','vol20_cs_median',
    'candidates': {strategy_id: [ {code,name,price,score,k,bosses_ok,soldiers_hit,values,reason}, ... 우선순위순 ]},
    'evaluated': {strategy_id: n}}. strategies 기본 = enabled_strategies()."""
    t0 = time.time()
    strategies = enabled_strategies() if strategies is None else strategies
    out = {'date': str(_now().date()), 'computed_at': _now().strftime('%Y-%m-%d %H:%M:%S'), 'market': None,
           'n_universe': len(universe), 'n_data': 0, 'vol20_cs_median': None, 'candidates': {}, 'evaluated': {},
           'elapsed': 0.0}
    if not strategies:
        out['elapsed'] = round(time.time() - t0, 1)
        return out
    if market is None:
        try:
            market = market_indicators()
        except Exception as e:
            log.warning(f'[DailyStrategy] 시장 지표 실패: {e}')
            market = None
    out['market'] = market
    rows = []
    for i, u in enumerate(universe):
        try:
            df = load_stock_daily(u['code'])
        except Exception as e:
            log.debug(f'[DailyStrategy] {u["code"]} 일봉 실패: {e}')
            df = None
        if df is None:
            continue
        try:
            vals = stock_indicators(df)
        except Exception as e:
            log.debug(f'[DailyStrategy] {u["code"]} 지표 실패: {e}')
            continue
        if vals['close'] < MIN_PRICE:
            continue
        rows.append((u, vals))
        if progress and (i + 1) % 50 == 0:
            progress(i + 1, len(universe))
    out['n_data'] = len(rows)
    if rows:
        med = float(np.nanmedian([v['vol20'] for _, v in rows]))
        out['vol20_cs_median'] = med
        for _, v in rows:
            v['vol20_cs_median'] = med
    for spec in strategies:
        cands = []
        for u, vals in rows:
            res = evaluate(spec, vals, market)
            if not res['passed']:
                continue
            cands.append({'code': u['code'], 'name': u.get('name', u['code']), 'price': vals['close'],
                          'score': res['score'], 'k': res['k'], 'bosses_ok': res['bosses_ok'],
                          'soldiers_hit': res['soldiers_hit'],
                          'values': {k: (None if (isinstance(v, float) and np.isnan(v)) else v) for k, v in vals.items()},
                          'reason': make_reason(spec, res, vals, market, hold_days)})
        cands.sort(key=_priority_key((spec.get('x_portfolio') or {}).get('priority')))
        out['candidates'][spec['id']] = cands
        out['evaluated'][spec['id']] = len(rows)
    out['elapsed'] = round(time.time() - t0, 1)
    if save:
        _save_last(out)
    return out


def _save_last(out):
    try:
        os.makedirs(os.path.dirname(LAST_FILE), exist_ok=True)
        with open(LAST_FILE, 'w', encoding='utf-8') as f:
            json.dump(out, f, ensure_ascii=False, indent=1, default=str)
    except Exception as e:
        log.debug(f'[DailyStrategy] 결과 저장 실패: {e}')


def load_last():
    """마지막 평가 결과(다른 프로세스가 남긴 것 포함). 없으면 None."""
    try:
        with open(LAST_FILE, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None


# ---------- 카드 / 표 ----------
def scoring_rule(spec):
    sc = spec.get('scoring', DEFAULT_SCORING)
    nb, ns = len(spec.get('bosses', []) or []), len(spec.get('soldiers', []) or [])
    return f'대장 {nb}개 전부(각 {sc["boss"]}점) + 졸병 {ns}개 중 {sc.get("min_soldiers", 1)}개 이상(각 {sc["soldier"]}점) → {sc["min_score"]}점 이상'


def validation_summary(spec):
    """x_validation → 한 줄. 없으면 ''."""
    xv = spec.get('x_validation') or {}
    if not xv:
        return ''
    segs = []
    for key, label in (('train', '학습'), ('valid', '검증'), ('test', '테스트')):
        d = xv.get(key) or {}
        if d:
            segs.append(f'{label} n={d.get("n")} 승률 {d.get("win_rate")}% 평균 {d.get("ev_pct"):+.2f}%'
                        if isinstance(d.get('ev_pct'), (int, float)) else f'{label} n={d.get("n")}')
    s = ' / '.join(segs)
    if xv.get('verdict_deploy'):
        s += f' · 판정: {xv["verdict_deploy"]}'
    return s


def strategy_summary():
    """스캐너 카드용. hits = 오늘(마지막 평가 파일 기준) 후보 — 봇이 09시에 평가해 남긴 것."""
    last = load_last() or {}
    today = str(_now().date())
    out = []
    for s in load_strategies():
        xe = s.get('x_exit') or {}
        hits = []
        if last.get('date') == today:
            hits = [{'code': c['code'], 'name': c['name'], 'price': c['price'], 'rate': None, 'score': c['score'],
                     'direction': s.get('direction'), 'reason': c.get('reason')}
                    for c in (last.get('candidates') or {}).get(s['id'], [])]
        out.append({
            'id': s['id'], 'name': s.get('name'), 'direction': s.get('direction'), 'timeframe': TIMEFRAME,
            'enabled': bool(s.get('enabled')), 'live': bool(s.get('live')), 'sample': bool(s.get('sample')),
            'candidate': bool(s.get('candidate')), 'version': s.get('version'), 'errors': s.get('_errors', []),
            'min_score': s.get('scoring', {}).get('min_score'),
            'n_bosses': len(s.get('bosses', []) or []), 'n_soldiers': len(s.get('soldiers', []) or []),
            'description': s.get('description', ''),
            'scoring_rule': scoring_rule(s), 'validation': validation_summary(s),
            'exit_rule': (f'{xe.get("hold_days")}영업일 {"시가" if xe.get("at") == "open" else ""}청산' if xe.get('hold_days') else ''),
            'hits': hits, 'last_eval': last.get('computed_at') if last.get('date') == today else None,
            'market': last.get('market') if last.get('date') == today else None,
        })
    return out


def format_table(result, spec_id=None):
    """로그/콘솔용 후보 표 (순수 텍스트)."""
    lines = []
    m = result.get('market') or {}
    if m:
        lines.append(f'시장: KODEX200 {m.get("idx_close", 0):,.0f} | 200일선 {m.get("idx_ma200", 0):,.0f} | '
                     f'250일고점 대비 {m.get("idx_dd250", 0):+.1f}% (기준일 {m.get("idx_date")})')
    else:
        lines.append('시장: 지수 일봉 없음 (시장 대장 미충족 처리)')
    lines.append(f'유니버스 {result.get("n_universe")} / 일봉 확보 {result.get("n_data")} / '
                 f'vol20 중앙값 {(result.get("vol20_cs_median") or 0):.2f}% / {result.get("elapsed")}초')
    for sid, cands in (result.get('candidates') or {}).items():
        if spec_id and sid != spec_id:
            continue
        lines.append(f'[{sid}] 후보 {len(cands)}건')
        lines.append(f'  {"순위":>2} {"종목":14s} {"코드":6s} {"종가":>9s} {"점수":>4s} {"졸병":>4s} {"60일선":>7s} {"vol20":>6s} {"저점+":>7s} {"3일":>6s} {"20일":>7s}  졸병')
        for i, c in enumerate(cands, 1):
            v = c['values']
            lines.append(f'  {i:>2} {c["name"][:14]:14s} {c["code"]:6s} {c["price"]:>9,.0f} {c["score"]:>4} {c["k"]:>4} '
                         f'{v.get("dev_ma60", 0):>+7.1f} {v.get("vol20", 0):>6.2f} {v.get("dist_lo250", 0):>+7.1f} '
                         f'{v.get("ret3", 0):>+6.1f} {v.get("mom20", 0):>+7.1f}  {",".join(c["soldiers_hit"])}')
    return '\n'.join(lines)


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    print('== 일봉 전략 파일 ==')
    for s in load_strategies(force=True):
        print(' ', s['id'], '| enabled' if s.get('enabled') else '| disabled', '| live' if s.get('live') else '| 신호만',
              '| 오류:' if s.get('_errors') else '| OK', s.get('_errors') or '')
    if '--check' in sys.argv:
        sys.exit(0)
    try:
        import futures_map
        uni = futures_map.get_futures_universe() or []
    except Exception:
        uni = []
    if not uni:
        wl = os.path.join(BASE_DIR, 'config_data', 'watchlist.json')
        uni = json.load(open(wl, encoding='utf-8')).get('watchlist', [])
    print(f'유니버스 {len(uni)}종목 — 일봉 계산 중 (첫 실행은 pykrx 조회로 수 분)')
    res = evaluate_universe(uni, progress=lambda i, n: print(f'  ... {i}/{n}'))
    print(format_table(res))
