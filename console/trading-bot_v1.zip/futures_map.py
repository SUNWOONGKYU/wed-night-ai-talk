# -*- coding: utf-8 -*-
"""
주식선물 코드 매핑 로더
futures_code_map.json 로드 → stock_code → futures_code 변환
"""
import os, json, logging

log = logging.getLogger(__name__)
_MAP_FILE = os.path.join(os.path.dirname(__file__), 'futures_code_map.json')
_MONTH = '03'  # 기본 월물

_stock_to_futures = {}
_futures_to_stock = {}
_loaded = False


def _load():
    global _stock_to_futures, _futures_to_stock, _loaded
    if _loaded:
        return
    if not os.path.exists(_MAP_FILE):
        log.warning(f'[FuturesMap] 매핑 파일 없음: {_MAP_FILE}')
        log.warning('[FuturesMap] python build_futures_map.py 를 장중에 실행하세요.')
        _loaded = True
        return
    try:
        with open(_MAP_FILE, encoding='utf-8') as f:
            data = json.load(f)
        _stock_to_futures = data.get('stock_to_futures', {})
        _futures_to_stock = data.get('futures_to_stock', {})
        month = data.get('month', _MONTH)
        log.info(f'[FuturesMap] 매핑 로드: {len(_stock_to_futures)}개 ({month}월물)')
    except Exception as e:
        log.error(f'[FuturesMap] 로드 오류: {e}')
    _loaded = True


def get_futures_code(stock_code: str) -> str | None:
    """
    주식코드 → 주식선물 단축코드
    예: '005930' → 'A11603'
    매핑 없으면 None 반환
    """
    _load()
    return _stock_to_futures.get(stock_code)


def get_stock_code(futures_code: str) -> str | None:
    """
    주식선물 단축코드 → 기초자산 주식코드 (역방향)
    예: 'A11604' → '005930'
    """
    _load()
    return _futures_to_stock.get(futures_code)


def has_map() -> bool:
    """매핑 파일 존재 여부"""
    _load()
    return bool(_stock_to_futures)


_names_cache = None


def get_futures_universe():
    """주식선물 가능한 전체 종목을 [{'code','name'}, ...]로 반환.
    이름은 data/stock_names.json(없으면 코드). 모멘텀/돌파 스캔의 유니버스로 사용."""
    global _names_cache
    _load()
    if _names_cache is None:
        try:
            npath = os.path.join(os.path.dirname(__file__), 'data', 'stock_names.json')
            with open(npath, encoding='utf-8') as f:
                _names_cache = json.load(f)
        except Exception:
            _names_cache = {}
    return [{'code': c, 'name': _names_cache.get(c, c)} for c in _stock_to_futures.keys()]
