# -*- coding: utf-8 -*-
"""
htf_filter.py — 상위 타임프레임(월/주/일봉) 추세 선별 (2026-06-18 신설)

매매 알고리즘 1단계 = 종목 선정.
  월봉/주봉/일봉으로 '구조적 상승 추세 + 단기 눌림목' 종목만 후보로 통과시킨다.
분봉 6대장(analysis.py)은 2단계 = 진입 '타이밍'만 담당.

즉: 큰 흐름(월/주/일)이 상승인 종목 중에서, 분봉이 신호를 줄 때만 산다.
하락 추세 종목은 분봉 신호가 떠도 CALL 후보에서 제외한다.
"""
import time
import logging
import pandas as pd
from kis import get_stock_daily_ohlcv

log = logging.getLogger('htf')

# 일/주/월봉은 장중 거의 변하지 않으므로 길게 캐시 (KIS 호출 절약 + 스로틀 방지)
_cache = {}          # code -> (epoch, result)
_CACHE_SEC = 3600    # 1시간


def _ma(s, n):
    return s.rolling(n).mean()


def _rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).rolling(n).mean()
    dn = (-d.clip(upper=0)).rolling(n).mean()
    rs = up / dn.replace(0, 1e-9)
    return 100 - 100 / (1 + rs)


def _tf_trend(df, ma_s, ma_l):
    """한 타임프레임의 추세 지표. 데이터 부족 시 None."""
    if df is None or len(df) < ma_l + 2:
        return None
    c = pd.to_numeric(df['close'], errors='coerce')
    ms, ml = _ma(c, ma_s), _ma(c, ma_l)
    i = -1
    return {
        'above_long': bool(c.iloc[i] > ml.iloc[i]),            # 종가 > 장기MA
        'aligned': bool(ms.iloc[i] > ml.iloc[i]),              # 단기MA > 장기MA (정배열)
        'slope_up': bool(ml.iloc[i] > ml.iloc[i - 1]),         # 장기MA 우상향
        'rsi': float(_rsi(c).iloc[i]) if len(c) > 15 else 50.0,
        'last_red': bool(c.iloc[i] < pd.to_numeric(df['open'], errors='coerce').iloc[i]),  # 최근 음봉
        'close': float(c.iloc[i]),
    }


def evaluate(code):
    """
    월/주/일봉 기준 '상승 가능성' 평가 (CALL 선정 관점).

    반환 dict:
      ok       : CALL 후보 통과 여부 (상위 추세 상승 확인)
      score    : 0~100
      grade    : S/A/B/C/NA
      pullback : 일봉 눌림목(음봉 or RSI 과열 아님) — 분봉 타이밍과 결합하면 '눌림목 매수'
      detail   : 사유 문자열
    """
    now = time.time()
    hit = _cache.get(code)
    if hit and (now - hit[0]) < _CACHE_SEC:
        return hit[1]

    try:
        dM = get_stock_daily_ohlcv(code, 'M', 40)
        dW = get_stock_daily_ohlcv(code, 'W', 60)
        dD = get_stock_daily_ohlcv(code, 'D', 120)
    except Exception as e:
        log.debug(f'[HTF] {code} 조회 오류: {e}')
        # 데이터 실패 시 게이트 미적용(통과) — 우리 조회 실패로 신호를 죽이지 않는다 (false-0 교훈)
        res = {'ok': True, 'score': 50, 'grade': 'NA', 'pullback': False, 'detail': 'HTF조회실패-게이트미적용'}
        return res

    # KIS inquire-daily-price는 타임프레임당 ~30봉만 반환 → 30봉 내 MA 사용
    tM = _tf_trend(dM, 3, 6)     # 월봉: 3·6개월 (장기 추세)
    tW = _tf_trend(dW, 5, 20)    # 주봉: 5·20주 (중기 추세)
    tD = _tf_trend(dD, 5, 20)    # 일봉: 5·20일 (단기 추세)

    if tD is None:
        res = {'ok': True, 'score': 50, 'grade': 'NA', 'pullback': False, 'detail': '일봉 데이터부족-게이트미적용'}
        _cache[code] = (now, res)
        return res

    score = 0
    parts = []

    # 월봉 장기 상승: 25
    if tM and tM['above_long'] and tM['slope_up']:
        score += 25; parts.append('월상승')
    elif tM and tM['above_long']:
        score += 12; parts.append('월보합')

    # 주봉 중기 상승: 25
    if tW and tW['above_long'] and tW['slope_up']:
        score += 25; parts.append('주상승')
    elif tW and tW['above_long']:
        score += 12; parts.append('주보합')

    # 일봉 단기 정배열: 30
    if tD['above_long'] and tD['aligned'] and tD['slope_up']:
        score += 30; parts.append('일정배열')
    elif tD['above_long']:
        score += 15; parts.append('일MA위')

    # 일봉 눌림목(과열 아님 + 음봉): 20 — '음봉을 가지고 타이밍'
    pullback = (tD['rsi'] < 68) and tD['last_red']
    if pullback:
        score += 20; parts.append('눌림목')
    elif tD['rsi'] < 72:
        score += 10; parts.append('비과열')

    grade = 'S' if score >= 85 else 'A' if score >= 70 else 'B' if score >= 55 else 'C'
    # 통과 기준 (2026-06-22 수정): 구조적 추세(월/주봉)가 상승이면 일봉은 눌림목(20일선 아래)이어도 통과.
    #   기존 `tD['above_long']` 하드 조건은 "상승추세 종목의 단기 눌림목 매수"라는 본 필터 설계 목적과
    #   정면 모순이었다(눌림목 = 일봉이 단기MA 아래로 내려온 상태). 그 결과 상승장에서 주도주가 잠깐
    #   눌릴 때 분봉 신호가 떠도 HTF가 전부 차단 → 승인 요청 0건(2026-06-22 실측, 예: 현대차·현대모비스
    #   월상승+주상승 70점 A등급인데 당일 급락으로 일봉<20MA라 폐기).
    #   → 월봉 또는 주봉이 장기MA 위(구조적 상승추세) + 총점 55 이상이면 통과. 일봉 위치는 점수에만 반영.
    structural_up = bool((tM and tM['above_long']) or (tW and tW['above_long']))
    ok = bool(structural_up and score >= 55)

    res = {
        'ok': ok, 'score': score, 'grade': grade, 'pullback': bool(pullback),
        'detail': '+'.join(parts) if parts else '추세약함',
    }
    _cache[code] = (now, res)
    return res
