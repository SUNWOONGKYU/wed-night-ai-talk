﻿# is_trading_day.ps1 — KRX 거래일 판정 게이트 (단일 기준)
#
# 종료 코드로 결과를 알린다:
#   0 = 거래일       (호출자는 계속 진행)
#   1 = 주말/휴장일  (호출자는 기동을 건너뛴다)
#   2 = 판정 불가    (holidays.json 손상 등 — 호출자 판단에 맡김)
#
# 휴장일 목록은 trader.py의 MarketClock._load_holidays()와 동일한
# config_data/holidays.json을 읽는다. 기준을 한 곳에만 두어 어긋나지 않게 한다.
# 주말은 파일에 없어도 항상 차단한다(파일은 공휴일만 담아도 되는 구조).

[CmdletBinding()]
param(
    # 판정 기준일(YYYY-MM-DD). 생략하면 현재 KST 날짜. 검증용으로만 쓴다.
    [string]$Date
)

$ErrorActionPreference = 'Stop'

function Write-Line($msg) {
    Write-Output ("{0} {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg)
}

# 서버 시간대와 무관하게 항상 KST(한국 표준시)로 판정한다.
if ($Date) {
    try {
        $kst = [DateTime]::ParseExact($Date, 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
    } catch {
        Write-Line "[Gate] -Date 형식 오류: '$Date' (YYYY-MM-DD 필요)"
        exit 2
    }
} else {
    $kst = [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTime]::UtcNow, 'Korea Standard Time')
}
$dateStr = $kst.ToString('yyyy-MM-dd')
$dow = $kst.DayOfWeek

# ── 1) 주말 ──
if ($dow -eq [System.DayOfWeek]::Saturday -or $dow -eq [System.DayOfWeek]::Sunday) {
    Write-Line "[Gate] $dateStr ($dow) 주말 - 기동 건너뜀"
    exit 1
}

# ── 2) 공휴일/휴장일 ──
$holFile = Join-Path $PSScriptRoot 'config_data\holidays.json'
if (-not (Test-Path -LiteralPath $holFile)) {
    Write-Line "[Gate] holidays.json 없음 ($holFile) - 주말만 판정, 평일로 진행"
    exit 2
}

try {
    # BOM 없는 UTF-8 파일이므로 인코딩을 명시해 한글이 깨지지 않게 읽는다.
    $raw = [System.IO.File]::ReadAllText($holFile, [System.Text.UTF8Encoding]::new($false))
    $holidays = (ConvertFrom-Json $raw).holidays
} catch {
    Write-Line "[Gate] holidays.json 파싱 실패: $($_.Exception.Message) - 평일로 진행"
    exit 2
}

if ($null -eq $holidays) {
    Write-Line "[Gate] holidays.json에 holidays 항목 없음 - 평일로 진행"
    exit 2
}

$names = $holidays.PSObject.Properties.Name
$hit = $names | Where-Object { $_ -eq $dateStr } | Select-Object -First 1
if ($hit) {
    Write-Line "[Gate] $dateStr 휴장일($($holidays.$hit)) - 기동 건너뜀"
    exit 1
}

# ── 3) 올해가 목록에 아예 없으면 갱신이 밀린 것이다 ──
# 이때 차단하면 정상 거래일에도 못 뜨므로 진행시키되, 반드시 눈에 띄게 남긴다.
$year = $kst.ToString('yyyy')
if (-not ($names | Where-Object { $_.StartsWith($year) })) {
    Write-Line "[Gate] 경고: holidays.json에 ${year}년 휴장일이 없음. KRX 공지로 갱신 필요. 평일로 진행"
    exit 2
}

Write-Line "[Gate] $dateStr ($dow) 거래일 - 진행"
exit 0
