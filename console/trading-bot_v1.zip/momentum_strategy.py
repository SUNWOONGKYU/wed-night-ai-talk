# -*- coding: utf-8 -*-
"""
momentum_strategy.py — 검증된 장기 모멘텀 전략 (2026-06-22 백테스트 정본)

근거: research_backtest/ 8년(2018~2026, 약세장 포함) 백테스트.
  - 장기 60일모멘텀(60일 보유): CAGR +19.2%, MDD -38%, 승률 56% → 시장(+15%/-46%) 우위.
  - 레짐게이트(시장 60일선 위일 때만 진입): 약세장 낙폭 방어, 약한전략 구제 입증.
정본 노트: wiki/연구/project_multi_timeframe_strategies.md, research_backtest/STRATEGY_LIBRARY.md

핵심 규칙:
  진입: (1) 시장 레짐 OK(합성시장 or KOSPI 60일선 위)  AND
        (2) 종목 60일모멘텀 > MOMENTUM_MIN  AND  종가 > 종목 MA60
  랭킹: 60일모멘텀 내림차순 상위 TOP_N
  청산: 진입 후 HOLD_DAYS(영업일) 경과 시 (trader.py가 시간기반 청산)

trader.py가 하루 1회(장초) 호출 → 후보 반환 → 기존 승인/주문 흐름 사용.
"""
import time
import logging
import datetime as dt
import pandas as pd

log = logging.getLogger('momentum')

# 파라미터 (config.py에서 오버라이드 가능)
MOMENTUM_LOOKBACK = 60      # 모멘텀 계산 기간(영업일)
MOMENTUM_MIN = 0.10         # 60일 수익률 최소(10%)
MA_LONG = 60               # 추세 필터 이평
TOP_N = 5                  # 상위 N종목
HOLD_DAYS = 60             # 보유 영업일

_cache = {}                # code -> (epoch, DataFrame)
_CACHE_SEC = 3600 * 6      # 일봉은 자주 안 변함 → 6시간 캐시

# 레짐 판정용 고정 벤치마크(대형주 — 시장 방향 대표). 스캔 유니버스를 바꿔도 레짐은 일관되게
# '시장(대형주 지수) 방향'으로 판정한다. (유니버스 앞 40종목으로 잡으면 유니버스 바뀔 때 레짐이 흔들림)
REGIME_BENCHMARK = [
    '005930', '000660', '005380', '000270', '005490', '035420', '051910',
    '006400', '055550', '105560', '012330', '207940', '068270', '028260',
    '035720', '015760', '017670', '030200', '034730', '003550',
]


def _daily(code, days=400):
    """일봉 OHLCV (pykrx). 캐시. 실패 시 None."""
    now = time.time()
    hit = _cache.get(code)
    if hit and (now - hit[0]) < _CACHE_SEC:
        return hit[1]
    try:
        from pykrx import stock
        end = dt.datetime.now().strftime('%Y%m%d')
        start = (dt.datetime.now() - dt.timedelta(days=days)).strftime('%Y%m%d')
        df = stock.get_market_ohlcv(start, end, code)
        if df is None or len(df) < MA_LONG + 5:
            return None
        df = df.rename(columns={'시가': 'open', '고가': 'high', '저가': 'low', '종가': 'close', '거래량': 'volume'})
        df = df[['open', 'high', 'low', 'close', 'volume']]
        _cache[code] = (now, df)
        return df
    except Exception as e:
        log.debug(f'[Momentum] {code} 일봉 조회 실패: {e}')
        return None


def market_regime_ok(universe_codes):
    """합성 시장지수(유니버스 동일비중) 60일선 위면 강세 → 진입 허용.
    KOSPI 직접 조회는 pykrx 지수 버그로 불안정 → 유니버스 평균으로 대체."""
    closes = []
    sample = universe_codes[:40]  # 속도: 대표 40종목으로 시장방향 추정
    for code in sample:
        df = _daily(code)
        if df is not None and len(df) > MA_LONG + 5:
            closes.append(df['close'].pct_change())
    if len(closes) < 10:
        log.warning('[Momentum] 레짐 판정 데이터 부족 → 보수적으로 진입 보류')
        return False
    R = pd.concat(closes, axis=1)
    idx = (1 + R.mean(axis=1).fillna(0)).cumprod()
    ma = idx.rolling(MA_LONG).mean()
    ok = bool(idx.iloc[-1] > ma.iloc[-1])
    log.info(f'[Momentum] 시장 레짐: {"강세(진입허용)" if ok else "약세(진입보류)"} '
             f'(지수 {idx.iloc[-1]:.3f} vs MA{MA_LONG} {ma.iloc[-1]:.3f})')
    return ok


def get_candidates(universe, top_n=None):
    """검증된 모멘텀 후보 반환. universe=[{'code','name'},...].
    반환: [{'code','name','price','momentum','reason'}], 모멘텀 내림차순 상위 N.
    레짐 약세면 빈 리스트(약세장 진입 안 함)."""
    top_n = top_n or TOP_N
    if not market_regime_ok(REGIME_BENCHMARK):  # 시장 방향은 고정 대형주 벤치마크로 일관 판정
        return []  # 약세장 → 진입 안 함 (레짐게이트)

    scored = []
    for u in universe:
        df = _daily(u['code'])
        if df is None or len(df) < MOMENTUM_LOOKBACK + 5:
            continue
        c = df['close']
        mom = c.iloc[-1] / c.iloc[-1 - MOMENTUM_LOOKBACK] - 1
        ma60 = c.rolling(MA_LONG).mean().iloc[-1]
        price = float(c.iloc[-1])
        # 진입조건: 모멘텀 충족 + 종가 > MA60(상승추세)
        if mom > MOMENTUM_MIN and price > ma60:
            scored.append({
                'code': u['code'], 'name': u['name'], 'price': price,
                'momentum': round(mom * 100, 1),
                'reason': f'장기모멘텀 {mom*100:.0f}%(60일) + MA60위 → {HOLD_DAYS}일 보유',
            })
    scored.sort(key=lambda x: -x['momentum'])
    out = scored[:top_n]
    log.info(f'[Momentum] 후보 {len(out)}종목 (조건충족 {len(scored)}): '
             + ', '.join(f"{c['name']}({c['momentum']}%)" for c in out))
    return out


if __name__ == '__main__':
    # 단독 실행: watchlist로 후보 출력
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    import json, os
    wl = os.path.join(os.path.dirname(__file__), 'config_data', 'watchlist.json')
    with open(wl, encoding='utf-8') as f:
        uni = json.load(f).get('watchlist', [])
    print(f'유니버스 {len(uni)}종목')
    for c in get_candidates(uni):
        print(f"  {c['name']:14s} {c['price']:>9,.0f}원  모멘텀 {c['momentum']}%  {c['reason']}")
