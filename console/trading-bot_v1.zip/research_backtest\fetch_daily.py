# -*- coding: utf-8 -*-
"""262종목 일봉 3.5년치 캐시 (pykrx). 1회 실행 → data/daily_cache.pkl."""
import sys, time, pickle, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pykrx import stock
from Trading_Stock.STOCK_CODES_262 import STOCK_CODES

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'daily_cache.pkl')
import datetime as _dt
START, END = '20230101', _dt.date.today().strftime('%Y%m%d')
codes = list(STOCK_CODES.keys())
cache = {}
if os.path.exists(OUT):
    with open(OUT, 'rb') as f: cache = pickle.load(f)
    print(f'기존 캐시 {len(cache)}종목 로드')

done = 0
for i, code in enumerate(codes):
    if code in cache and len(cache[code]) > 100:
        done += 1; continue
    try:
        df = stock.get_market_ohlcv(START, END, code)
        if df is not None and len(df) > 100:
            df = df.rename(columns={'시가':'open','고가':'high','저가':'low','종가':'close','거래량':'volume'})
            cache[code] = df[['open','high','low','close','volume']].copy()
            done += 1
    except Exception as e:
        print(f'  {code} 실패: {e}')
    if (i+1) % 30 == 0:
        with open(OUT, 'wb') as f: pickle.dump(cache, f)
        print(f'  진행 {i+1}/{len(codes)} (수집 {len(cache)}) 저장')
        time.sleep(0.3)

with open(OUT, 'wb') as f: pickle.dump(cache, f)
print(f'완료: {len(cache)}종목 캐시 → {OUT}')
