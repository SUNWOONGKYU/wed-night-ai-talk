﻿# rotate_logs.ps1 — 무한히 자라는 로그를 1세대만 남기고 갈아탄다.
#
# scanner_web.log는 Flask 접근 로그가 매 초 쌓여 2026-08-29 기준 64MB까지 커졌다.
# 부팅 때마다 한 번 검사해 한도를 넘으면 .1로 밀어내고 새로 시작한다.
# (.1은 다음 회전에서 덮어써지므로 디스크 사용량은 한도의 2배로 묶인다.)

$ErrorActionPreference = 'SilentlyContinue'

$logDir = Join-Path $PSScriptRoot 'logs'

# 파일별 한도. 접근 로그는 크고 값이 낮으므로 작게, 나머지는 넉넉하게 잡는다.
$limits = @{
    'scanner_web.log' = 20MB
    'trader.log'      = 20MB
    'startup.log'     = 1MB
    'sentry.log'      = 5MB
}

foreach ($name in $limits.Keys) {
    $path = Join-Path $logDir $name
    if (-not (Test-Path -LiteralPath $path)) { continue }
    $size = (Get-Item -LiteralPath $path).Length
    if ($size -le $limits[$name]) { continue }
    Move-Item -LiteralPath $path "$path.1" -Force
    Write-Output ("{0} [Rotate] {1} {2:N1}MB -> {1}.1" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $name, ($size / 1MB))
}
