# -*- coding: utf-8 -*-
"""
스캐너 웹뷰어 - 1단계(네이버) | 2단계(KIS) 좌우 나란히 표시
localhost:5050
"""
import sys, os, json, threading, time, webbrowser, subprocess, re
from datetime import datetime
from flask import Flask, render_template_string, jsonify, request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scanner_262_52 import scan_all, get_kospi200_kodex

app = Flask(__name__)

# ── Sentry 자동매매 상태 ──
sentry_state = {
    'running': False,
    'proc': None,
    'logs': [],
    'positions': [],
    'daily_trades': 0,
    'daily_pnl': 0.0,
    'started_at': None,
}

def _sentry_reader(proc):
    """sentry.py stdout/stderr 읽기 스레드"""
    pos_map = {}  # code -> position dict

    for raw in iter(proc.stdout.readline, b''):
        line = raw.decode('utf-8', errors='ignore').strip()
        if not line:
            continue

        ts = datetime.now().strftime('%H:%M:%S')
        sentry_state['logs'].append(f'[{ts}] {line}')
        sentry_state['logs'] = sentry_state['logs'][-100:]

        # 포지션 파싱
        # "주문 체결: 삼성전자 CALL x1 @ 75,000"
        m = re.search(r'주문 체결: (.+?) (CALL|PUT) x(\d+) @ ([\d,]+)', line)
        if m:
            name, side, qty, price = m.group(1), m.group(2), int(m.group(3)), int(m.group(4).replace(',', ''))
            pos_map[name] = {'name': name, 'side': side, 'qty': qty, 'entry': price, 'current': price, 'pnl': 0.0}
            sentry_state['positions'] = list(pos_map.values())

        # 청산 파싱
        m = re.search(r'청산: (.+?) (CALL|PUT) @ ([\d,]+) \(([+-][\d.]+)%\)', line)
        if m:
            name = m.group(1)
            pos_map.pop(name, None)
            sentry_state['positions'] = list(pos_map.values())

        # 일일 매매 통계
        m = re.search(r'일일매매: (\d+)건.*일일손익: ([+-]?[\d,]+)원', line)
        if m:
            sentry_state['daily_trades'] = int(m.group(1))
            sentry_state['daily_pnl'] = float(m.group(2).replace(',', ''))

    sentry_state['running'] = False
    sentry_state['proc'] = None

scan_state = {
    'running': False,
    'stage1': [],
    'stage2': [],
    'futures': None,
    'logs': [],
    'started_at': None,
    'finished_at': None,
    'stage1_loaded': False,
}

# ── KOSPI200 선물 실시간 30틱 차트 ──
_K200_TICK_SIZE  = 0.05   # 최소 호가단위 (0.05pt)
_K200_TICKS_BAR  = 30     # 봉당 틱 수
_K200_MA_PERIOD  = 20     # 이평 기간
_K200_MAX_BARS   = 120    # 보관 최대 봉 수

k200_state = {
    'price': 0.0,       # 현재가 (pt)
    'rate':  0.0,       # 등락률 (%)
    'ts':    '',        # 마지막 업데이트 시각
    'tick_acc': 0.0,    # 현재 봉 누적 틱 (절대값)
    'bar':  None,       # 진행 중 봉 {o,h,l,c,ticks}
    'bars': [],         # 완성된 봉 리스트
    'ma':   [],         # 20MA 값 리스트 (bars와 동일 인덱스)
    'signal': None,     # 'UP'(골든) / 'DOWN'(데드) / None
    'signal_ts': '',
    'alert':  False,    # JS가 소리 낼 때 True → JS 읽은 후 False
}

def _k200_close_bar():
    """진행 중 봉 확정 + 20MA 계산 + 크로스 감지"""
    bar = k200_state['bar']
    if not bar:
        return
    k200_state['bars'].append(bar)
    if len(k200_state['bars']) > _K200_MAX_BARS:
        k200_state['bars'] = k200_state['bars'][-_K200_MAX_BARS:]

    closes = [b['c'] for b in k200_state['bars']]
    if len(closes) >= _K200_MA_PERIOD:
        ma_vals = []
        for i in range(len(closes)):
            if i + 1 >= _K200_MA_PERIOD:
                ma_vals.append(round(sum(closes[i+1-_K200_MA_PERIOD:i+1])/_K200_MA_PERIOD, 2))
            else:
                ma_vals.append(None)
        k200_state['ma'] = ma_vals
    else:
        k200_state['ma'] = [None] * len(closes)

    # 크로스 감지 (최소 2봉 필요)
    ma = k200_state['ma']
    bars = k200_state['bars']
    if len(bars) >= 2 and ma[-1] is not None and ma[-2] is not None:
        prev_c, cur_c = bars[-2]['c'], bars[-1]['c']
        prev_m, cur_m = ma[-2], ma[-1]
        now_s = datetime.now().strftime('%H:%M:%S')
        if prev_c <= prev_m and cur_c > cur_m:
            if k200_state['signal'] != 'UP':
                k200_state['signal'] = 'UP'
                k200_state['signal_ts'] = now_s
                k200_state['alert'] = True
                print(f'[K200] ▲ 골든크로스 {cur_c:.2f}pt > MA{cur_m:.2f}pt ({now_s})')
        elif prev_c >= prev_m and cur_c < cur_m:
            if k200_state['signal'] != 'DOWN':
                k200_state['signal'] = 'DOWN'
                k200_state['signal_ts'] = now_s
                k200_state['alert'] = True
                print(f'[K200] ▼ 데드크로스 {cur_c:.2f}pt < MA{cur_m:.2f}pt ({now_s})')

    k200_state['bar'] = None
    k200_state['tick_acc'] = 0.0

def _futures_basis(spot):
    """KOSPI200 현물지수 → 선물 추정가 (베이시스 보정)
    basis = spot × rf × T/365  (rf=3.5%, T=만기까지 달력일수)
    KOSPI200 선물 만기: 3/6/9/12월 두 번째 목요일
    """
    from datetime import date, timedelta
    today = date.today()
    # 다음 분기 만기일 계산
    def _second_thursday(y, m):
        d = date(y, m, 1)
        dow = d.weekday()  # 0=Mon
        first_thu = d + timedelta(days=(3 - dow) % 7)
        return first_thu + timedelta(weeks=1)

    expiries = []
    for mo in [3, 6, 9, 12]:
        yr = today.year
        exp = _second_thursday(yr, mo)
        if exp >= today:
            expiries.append(exp)
    if not expiries:
        expiries = [_second_thursday(today.year + 1, 3)]
    exp = min(expiries)
    T = max((exp - today).days, 1)
    basis = spot * 0.035 * T / 365
    return round(spot + basis, 2)


_k200_source = '-'  # 현재 사용 중인 소스 추적

def _fetch_kpi200():
    """KOSPI200 선물 추정가 실시간 조회 (2초 폴링용)
    1순위: KIS KOSPI200 현물지수(code=2001) + 베이시스 보정 → 선물 근사
           오차 0~2pt (KODEX200/100 대비 훨씬 정확)
    2순위: KIS KODEX200(069500) ETF / 100 (fallback)
    """
    global _k200_source

    # 1순위: KIS KOSPI200 현물지수 (FHPST02400000) + 베이시스
    try:
        import requests as _req
        from kis import get_access_token, KIS_API_URL, KIS_APP_KEY, KIS_APP_SECRET
        _tok = get_access_token()
        _h = {
            'Content-Type': 'application/json',
            'authorization': 'Bearer ' + _tok,
            'appkey': KIS_APP_KEY,
            'appsecret': KIS_APP_SECRET,
            'tr_id': 'FHPST02400000',
        }
        _p = {'fid_cond_mrkt_div_code': 'U', 'fid_input_iscd': '2001'}
        _r = _req.get(KIS_API_URL + '/uapi/domestic-stock/v1/quotations/inquire-index-price',
                      headers=_h, params=_p, timeout=3)
        _d = _r.json()
        if _d.get('rt_cd') == '0':
            _o = _d.get('output', {})
            _spot = float(_o.get('stck_prpr', '0').replace(',', ''))
            _rate = float(_o.get('prdy_ctrt', '0').replace(',', ''))
            if _spot > 0:
                fut = _futures_basis(_spot)
                if _k200_source != 'KPI200':
                    print(f'[K200] 소스 → KIS현물지수+베이시스: spot={_spot} fut={fut}')
                    _k200_source = 'KPI200'
                return fut, round(_rate, 2)
        else:
            _k200_source = 'ERR:' + str(_d.get('rt_cd')) + _d.get('msg1', '')[:30]
    except Exception as e:
        _k200_source = 'EXC:' + str(e)[:40]

    # 2순위: KIS KODEX200 ETF / 100 (fallback)
    try:
        import requests as _req
        from kis import get_access_token, KIS_API_URL, KIS_APP_KEY, KIS_APP_SECRET
        _tok = get_access_token()
        _h = {
            'Content-Type': 'application/json',
            'authorization': 'Bearer ' + _tok,
            'appkey': KIS_APP_KEY,
            'appsecret': KIS_APP_SECRET,
            'tr_id': 'FHKST01010100',
        }
        _p = {'fid_cond_mrkt_div_code': 'J', 'fid_input_iscd': '069500'}
        _r = _req.get(KIS_API_URL + '/uapi/domestic-stock/v1/quotations/inquire-price',
                      headers=_h, params=_p, timeout=3)
        _d = _r.json()
        if _d.get('rt_cd') == '0':
            _o = _d.get('output', {})
            _etf = float(_o.get('stck_prpr', '0').replace(',', ''))
            _rate = float(_o.get('prdy_ctrt', '0').replace(',', ''))
            if _etf > 0:
                if _k200_source != 'KODEX200':
                    print(f'[K200] 소스 → KODEX200 fallback: etf={_etf}')
                    _k200_source = 'KODEX200'
                return round(_etf / 100.0, 2), round(_rate, 2)
    except Exception:
        pass

    return None, None


def _k200_poller():
    """2초마다 KOSPI200 현물지수 폴링 → 틱 누적 → 30틱 봉 생성
    소스: Naver KPI200 polling API (nv/100 = KOSPI200 지수 pt, KODEX200 ETF 아님)
    """
    prev_price = 0.0
    while True:
        try:
            time.sleep(2)
            now = datetime.now()
            h, m = now.hour, now.minute
            # 장전/장후도 표시 — 9:00 전후 ±30분 허용
            in_mkt = (8 <= h <= 15) and now.weekday() < 5
            if not in_mkt:
                continue
            price, rate = _fetch_kpi200()
            if not price:
                continue
            k200_state['price']  = price
            k200_state['rate']   = rate
            k200_state['ts']     = now.strftime('%H:%M:%S')
            k200_state['source'] = _k200_source

            if prev_price == 0.0:
                prev_price = price
                continue

            # 틱 계산
            diff = abs(price - prev_price)
            ticks = diff / _K200_TICK_SIZE
            prev_price = price

            if ticks < 0.5:
                continue  # 변동 없음

            # 현재 봉 업데이트 or 생성
            if k200_state['bar'] is None:
                k200_state['bar'] = {'o': price, 'h': price, 'l': price, 'c': price, 'ticks': 0}
            bar = k200_state['bar']
            bar['h'] = max(bar['h'], price)
            bar['l'] = min(bar['l'], price)
            bar['c'] = price
            bar['ticks'] = bar.get('ticks', 0) + ticks
            k200_state['tick_acc'] += ticks

            if k200_state['tick_acc'] >= _K200_TICKS_BAR:
                _k200_close_bar()

        except Exception:
            pass

HTML = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>5대장2쫄병 스캐너</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;overflow:hidden}
body{background:#0d1117;color:#e6edf3;font-family:'Malgun Gothic','Segoe UI',sans-serif;display:flex;flex-direction:column}
/* 상단 고정 영역 */
.topbar{display:flex;gap:6px;padding:1px 6px;background:#161b22;border-bottom:1px solid #30363d;align-items:center;flex-shrink:0}
.topbar a{padding:1px 7px;border-radius:4px;font-size:12px;font-weight:600;color:#c9d1d9;text-decoration:none}
.topbar a.active{background:#21262d;color:#58a6ff}
.controls{padding:1px 6px;display:flex;gap:6px;align-items:center;border-bottom:1px solid #30363d;background:#161b22;flex-shrink:0}
.btn{padding:2px 8px;border:none;border-radius:4px;font-size:12px;cursor:pointer;font-weight:700}
.btn-scan{background:#238636;color:#fff}
.btn-scan:hover{background:#2ea043}
.btn-scan:disabled{background:#333;color:#666;cursor:not-allowed}
.badge{padding:1px 6px;border-radius:8px;font-size:11px;font-weight:700}
.badge-idle{background:#21262d;color:#8b949e}
.badge-run{background:#388bfd33;color:#58a6ff;animation:pulse 1.5s infinite}
.badge-done{background:#238636;color:#fff}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
.log-box{padding:0 6px;background:#0d1117;border-bottom:1px solid #21262d;height:16px;overflow:hidden;font-size:10px;color:#555;font-family:monospace;white-space:nowrap;text-overflow:ellipsis;flex-shrink:0;display:flex;align-items:center}
/* KOSPI200 바 (전체 너비) */
.kospi-bar{background:#1c2128;border-bottom:1px solid #d29922;padding:1px 8px;flex-shrink:0;min-height:22px;display:flex;align-items:center;gap:10px}
.kospi-bar.empty{border-color:#444;color:#666;font-size:12px}
/* 패널 */
.panels{display:flex;flex:1;overflow:hidden;min-height:0}
.panel{display:flex;flex-direction:column;overflow:hidden}
.panel-left{flex:0 0 380px;border-right:1px solid #30363d}
.panel-right{flex:1}
.panel-left{border-right:2px solid #30363d}
.panel-hdr{padding:1px 5px;font-size:11px;font-weight:700;border-bottom:1px solid #30363d;display:flex;justify-content:space-between;align-items:center;flex-shrink:0;background:#161b22}
.panel-left .panel-hdr{color:#d29922}
.panel-right .panel-hdr{color:#58a6ff}
.s2-cards{display:flex;gap:3px;padding:1px 5px;border-bottom:1px solid #30363d;flex-shrink:0;background:#161b22}
.scard{background:#21262d;border-radius:3px;padding:0 5px;text-align:center;min-width:38px}
.scard .n{font-size:13px;font-weight:800;line-height:1.2}
.scard .l{font-size:9px;color:#8b949e;line-height:1.1}
.panel-body{flex:1;overflow-y:auto;padding:0;overflow-x:hidden;min-height:0;background:#0d1117}
table{width:100%;border-collapse:collapse}
th{background:#161b22;color:#8b949e;font-size:12px;padding:1px 4px;text-align:left;border-bottom:1px solid #30363d;position:sticky;top:0;z-index:1;white-space:nowrap}
td{padding:0px 4px;border-bottom:1px solid #21262d;font-size:12px;color:#e6edf3;line-height:1.15;white-space:nowrap}
tr:hover{background:#1c2128}
tr.passed{background:#0d2818}
tr.failed{color:#555}
.call{color:#ff6b6b;font-weight:800}
.put{color:#4fc3f7;font-weight:800}
.s-low{color:#555}
.s-call-mid{color:#ffa726;font-weight:700}
.s-call-high{color:#ff5252;font-weight:800}
.s-put-mid{color:#ce93d8;font-weight:700}
.s-put-high{color:#4fc3f7;font-weight:800}
.up{color:#ff5252;font-weight:700}
.down{color:#4fc3f7;font-weight:700}
.tag{display:inline-block;padding:1px 5px;border-radius:3px;font-size:11px;font-weight:700}
.tag-pass{background:#0d2818;color:#3fb950}
.tag-fail{background:#21262d;color:#555}
.empty{text-align:center;padding:6px;color:#555;font-size:13px}
.n-60{color:#ff5252}.n-50{color:#ce93d8}.n-30{color:#666}.n-tot{color:#3fb950}
/* 포지션 바 */
.pos-bar{background:#1a1a2e;border-bottom:1px solid #30363d;padding:0 8px;flex-shrink:0;display:flex;align-items:center;gap:8px;height:18px;font-size:11px}
.pos-bar.empty-pos{color:#484f58}
.pos-item{display:inline-flex;align-items:center;gap:4px;padding:1px 6px;border-radius:3px;background:#21262d}
.pos-call{border-left:2px solid #ff6b6b}
.pos-put{border-left:2px solid #4fc3f7}
.pos-pnl-p{color:#3fb950;font-weight:700}
.pos-pnl-n{color:#f85149;font-weight:700}
/* KOSPI200 30틱 차트 */
.k200-wrap{flex-shrink:0;background:#12151d;border-bottom:1px solid #21262d;height:130px;display:flex;overflow:hidden}
.k200-info{width:116px;flex-shrink:0;padding:5px 8px;border-right:1px solid #21262d;display:flex;flex-direction:column;justify-content:center;gap:1px}
.k200-info .lbl{font-size:9px;color:#555;font-weight:600;letter-spacing:.5px}
.k200-info .price{font-size:15px;font-weight:800;color:#e6edf3;line-height:1.15}
.k200-info .rate{font-size:12px;font-weight:700}
.k200-info .sig{font-size:10px;font-weight:700;padding:1px 4px;border-radius:3px;margin-top:1px;min-height:14px}
.k200-info .ts{font-size:9px;color:#444;margin-top:1px}
.k200-svg-wrap{flex:1;overflow:hidden;position:relative}
</style>
</head>
<body>
<div class="topbar">
  <a href="/" class="active">스캐너</a>
  <a href="/trading">자동매매</a>
  <a href="/system">시스템</a>
  <span style="margin-left:auto;display:flex;align-items:center;gap:10px">
    <span style="color:#d29922;font-size:10px;font-weight:700">K200선물</span>
    <span id="liveFutPrice" style="font-size:16px;font-weight:900;color:#e6edf3;letter-spacing:-.5px">--</span>
    <span id="liveFutRate" style="font-size:12px;font-weight:700">--</span>
    <span id="liveFutTs" style="font-size:9px;color:#555"></span>
    <span style="color:#333;font-size:10px;margin-left:4px" id="clock"></span>
  </span>
</div>
<div class="controls">
  <button class="btn btn-scan" id="btnScan" onclick="startScan()">스캔 시작</button>
  <span class="badge badge-idle" id="sBadge">대기</span>
  <span style="color:#555;font-size:11px" id="elapsed"></span>
</div>
<div class="log-box" id="logBox">스캔 버튼을 눌러 시작하세요.</div>

<!-- 보유 포지션 바 -->
<div class="pos-bar empty-pos" id="posBar">포지션 없음</div>
<!-- KOSPI200 전체 너비 바 (스캔 결과 CALL/PUT 점수) -->
<div class="kospi-bar empty" id="kospiBar">KOSPI200 — 스캔 대기중...</div>

<!-- KOSPI200 30틱 실시간 차트 -->
<div class="k200-wrap">
  <div class="k200-info">
    <div class="lbl">KOSPI200 30틱 MA20</div>
    <div class="sig" id="k200Sig"></div>
    <div class="ts" id="k200Ts">대기중</div>
  </div>
  <div class="k200-svg-wrap">
    <svg id="k200Svg" style="width:100%;height:130px;display:block"></svg>
  </div>
</div>

<div class="panels">
  <!-- 왼쪽: 1단계 -->
  <div class="panel panel-left">
    <div class="panel-hdr">
      <span>1단계 네이버 1분봉 (빠른필터)</span>
      <span id="s1Count" style="font-size:15px;font-weight:800;color:#e6edf3">-</span>
    </div>
    <div class="panel-body" id="s1Body">
      <div class="empty">스캔 대기중</div>
    </div>
  </div>
  <!-- 오른쪽: 2단계 -->
  <div class="panel panel-right">
    <div class="panel-hdr">
      <span>2단계 KIS OHLCV (정밀분석)</span>
      <span id="s2Count" style="font-size:15px;font-weight:800;color:#e6edf3">-</span>
    </div>
    <div class="s2-cards" id="s2Cards" style="display:none">
      <div class="scard"><div class="n n-tot" id="n2Tot">0</div><div class="l">총신호</div></div>
      <div class="scard"><div class="n n-60" id="n2_60">0</div><div class="l">60점</div></div>
      <div class="scard"><div class="n n-50" id="n2_50">0</div><div class="l">45-55</div></div>
      <div class="scard"><div class="n n-30" id="n2_30">0</div><div class="l">30-40</div></div>
    </div>
    <div class="panel-body" id="s2Body">
      <div class="empty">1단계 완료 후 표시</div>
    </div>
  </div>
</div>

<script>
function tick(){document.getElementById('clock').textContent=new Date().toLocaleString('ko-KR')}
setInterval(tick,1000);tick();

let scanning=false, pollT=null, t0=null, autoT=null;

function startScan(){
  if(scanning)return;
  if(autoT){clearTimeout(autoT);autoT=null;}
  scanning=true; t0=Date.now();
  document.getElementById('btnScan').disabled=true;
  document.getElementById('sBadge').className='badge badge-run';
  document.getElementById('sBadge').textContent='스캔중...';
  document.getElementById('logBox').textContent='스캔 시작...\n';
  document.getElementById('s1Body').innerHTML='<div class="empty">스캔 진행중...</div>';
  document.getElementById('s2Body').innerHTML='<div class="empty">1단계 완료 후 표시</div>';
  document.getElementById('s2Cards').style.display='none';
  document.getElementById('s1Count').textContent='-';
  document.getElementById('s2Count').textContent='-';
  document.getElementById('kospiBar').className='kospi-bar empty';
  document.getElementById('kospiBar').innerHTML='KOSPI200 — 스캔중...';
  fetch('/api/scan',{method:'POST'});
  pollT=setInterval(poll,2000);
  elTick();
}

window.onload=function(){
  // 스캔 자동 시작 안 함 (trader.py가 제어) — 화면 갱신만
  pollT=setInterval(poll,2000);
  poll();
};

function elTick(){
  if(!scanning)return;
  document.getElementById('elapsed').textContent=((Date.now()-t0)/1000|0)+'초';
  setTimeout(elTick,500);
}

function renderPositions(positions, dailyPnl){
  let bar=document.getElementById('posBar');
  if(!positions||!positions.length){
    bar.className='pos-bar empty-pos';
    bar.innerHTML='포지션 없음';
    return;
  }
  bar.className='pos-bar';
  let pnlCls=dailyPnl>=0?'pos-pnl-p':'pos-pnl-n';
  let pnlStr=(dailyPnl>=0?'+':'')+dailyPnl.toLocaleString()+'원';
  let html='<span style="color:#8b949e">보유('+positions.length+')</span> ';
  html+=positions.map(p=>{
    let cls=p.side==='CALL'?'pos-call':'pos-put';
    let dc=p.side==='CALL'?'call':'put';
    return '<span class="pos-item '+cls+'"><span class="'+dc+'">'+p.side+'</span> '+p.name+'</span>';
  }).join('');
  html+=' <span style="color:#555">|</span> 일손익 <span class="'+pnlCls+'">'+pnlStr+'</span>';
  bar.innerHTML=html;
}

function poll(){
  fetch('/api/status').then(r=>r.json()).then(d=>{
    let lb=document.getElementById('logBox');
    let logs=d.logs||[];
    lb.textContent=logs.length?logs[logs.length-1]:'';
    renderPositions(d.positions||[], d.daily_pnl||0);
    if(d.stage1&&d.stage1.length>0) renderS1(d.stage1);
    if(d.futures) renderKospi(d.futures);
    if(d.stage2&&d.stage2.length>0) renderS2(d.stage2);
    if(!d.running&&d.finished_at){
      scanning=false;
      // 폴링 유지(clearInterval 제거) — trader.py가 백그라운드로 트리거하는 스캔 결과를
      // 화면이 계속 반영하도록. 멈추면 첫 완료 스냅샷에서 화면이 굳어 '내역 안 보임' 버그.
      document.getElementById('btnScan').disabled=false;
      document.getElementById('sBadge').className='badge badge-done';
      document.getElementById('sBadge').textContent='완료';
      renderS1(d.stage1||[]);
      renderS2(d.stage2||[]);
      if(d.futures) renderKospi(d.futures);
    }
  });
}

function renderKospi(f){
  _lastFutures = f;
  let bar=document.getElementById('kospiBar');
  let csc=f.call_score>=60?'s-call-high':(f.call_score>=45?'s-call-mid':'s-low');
  let psc=f.put_score>=60?'s-put-high':(f.put_score>=45?'s-put-mid':'s-low');
  let ts=f.last_ts?(' <span style="color:#f85149;font-size:10px">'+f.last_ts+'</span>'):'';
  bar.className='kospi-bar';
  // 가격은 topbar(K200선물)에서만 표시 — 여기서는 CALL/PUT 신호 점수만
  bar.innerHTML='<span style="color:#d29922;font-weight:800;font-size:12px">'+(f.name||'KOSPI200')+'</span>'
    +'<span style="color:#666;font-size:10px;margin-left:4px">('+f.bars+'봉'+ts+')</span>'
    +'<span style="color:#e6edf3;font-size:13px;font-weight:800;margin-left:10px">CALL <span class="'+csc+'">'+f.call_score+'</span>점(대'+f.call_boss+'/6 쫄'+f.call_soldier+'/2)'
    +' &nbsp; PUT <span class="'+psc+'">'+f.put_score+'</span>점(대'+f.put_boss+'/6 쫄'+f.put_soldier+'/2)</span>';
}

function renderS1(items){
  if(!items.length){document.getElementById('s1Body').innerHTML='<div class="empty">데이터 없음</div>';return}
  let passed=items.filter(r=>r.passed);
  let failed=items.filter(r=>!r.passed);
  document.getElementById('s1Count').textContent=passed.length+'/'+items.length;
  let sorted=[...passed.sort((a,b)=>Math.max(b.call_score,b.put_score)-Math.max(a.call_score,a.put_score)),
              ...failed.sort((a,b)=>Math.max(b.call_score,b.put_score)-Math.max(a.call_score,a.put_score))];
  let h='<table style="width:100%;table-layout:fixed"><colgroup><col style="width:auto"><col style="width:26px"><col style="width:26px"><col style="width:36px"></colgroup>'
    +'<tr><th>종목</th><th style="text-align:center">C</th><th style="text-align:center">P</th><th style="text-align:center">통과</th></tr>';
  for(let r of sorted){
    let rc=r.rate>=0?'up':'down';
    let rs=r.rate>=0?'+'+r.rate.toFixed(1)+'%':r.rate.toFixed(1)+'%';
    let cs=r.call_score,ps=r.put_score;
    let cCls=cs>=60?'s-call-high':(cs>=45?'s-call-mid':(cs>=30?'s-call-mid':'s-low'));
    let pCls=ps>=60?'s-put-high':(ps>=45?'s-put-mid':(ps>=30?'s-put-mid':'s-low'));
    if(cs<30)cCls='s-low'; if(ps<30)pCls='s-low';
    let tag=r.passed?'<span class="tag tag-pass">PASS</span>':'<span class="tag tag-fail">-</span>';
    h+='<tr class="'+(r.passed?'passed':'failed')+'">'
      +'<td style="overflow:hidden;white-space:nowrap"><a href="https://m.stock.naver.com/domestic/stock/'+r.code+'/total" target="_blank" style="color:#e6edf3;text-decoration:none"><strong>'+(r.name||r.code)+'</strong></a>'
      +' <span class="'+rc+'">'+rs+'</span></td>'
      +'<td class="'+cCls+'" style="text-align:center">'+cs+'</td>'
      +'<td class="'+pCls+'" style="text-align:center">'+ps+'</td>'
      +'<td style="text-align:center">'+tag+'</td></tr>';
  }
  h+='</table>';
  document.getElementById('s1Body').innerHTML=h;
}

function renderS2(items){
  if(!items.length){
    document.getElementById('s2Body').innerHTML='<div class="empty">신호 없음</div>';
    document.getElementById('s2Count').textContent='0';
    return;
  }
  document.getElementById('s2Count').textContent=items.length+'개';
  let t60=items.filter(r=>r.score>=60);
  let t50=items.filter(r=>r.score>=45&&r.score<60);
  let t30=items.filter(r=>r.score>=30&&r.score<45);
  document.getElementById('s2Cards').style.display='flex';
  document.getElementById('n2Tot').textContent=items.length;
  document.getElementById('n2_60').textContent=t60.length;
  document.getElementById('n2_50').textContent=t50.length;
  document.getElementById('n2_30').textContent=t30.length;
  let h='<table style="width:100%;border-collapse:collapse">'
    +'<tr><th style="width:auto">종목 / 신호</th><th style="width:70px">방향/점수</th><th style="width:28px">승</th></tr>';
  const BOSS_LABELS = {
    sonar_golden:'소나GC', sonar_dead:'소나DC',
    di_minus:'DI-', di_plus:'DI+',
    adx:'ADX', rsi:'RSI', stoch:'스토캐', ma_trend:'MA20'
  };
  const SOLD_LABELS = {
    volume:'볼륨', willr:'%R', macd1:'MACD', macd2:'MACD2'
  };
  items.slice().sort((a,b)=>b.score-a.score).forEach(r=>{
    let rc=r.rate>=0?'up':'down';
    let rs=r.rate>=0?'+'+r.rate.toFixed(1)+'%':r.rate.toFixed(1)+'%';
    let dc=r.type==='CALL'?'call':'put';
    let sc=r.type==='CALL'?(r.score>=60?'s-call-high':(r.score>=45?'s-call-mid':'s-low')):(r.score>=60?'s-put-high':(r.score>=45?'s-put-mid':'s-low'));
    let rowStyle=r.pending?'opacity:0.55;font-style:italic':'';
    // 5대장 + 2쫄병 — 종목명 옆 같은 줄에
    let sigInline='';
    if(!r.pending && (r.bosses||r.soldiers)){
      let bosses=r.bosses||{}, soldiers=r.soldiers||{};
      for(let [k,v] of Object.entries(bosses)){
        let lbl=BOSS_LABELS[k]||k;
        sigInline+='<span style="padding:0 2px;margin-left:2px;border-radius:2px;background:'+(v?'#1a4a1a':'#4a1a1a')+';color:'+(v?'#3fb950':'#f85149')+'">'+lbl+'</span>';
      }
      sigInline+='<span style="color:#444;margin:0 2px">|</span>';
      for(let [k,v] of Object.entries(soldiers)){
        let lbl=SOLD_LABELS[k]||k;
        sigInline+='<span style="padding:0 2px;margin-left:2px;border-radius:2px;background:'+(v?'#1a3a4a':'#2a2a1a')+';color:'+(v?'#58a6ff':'#d29922')+'">'+lbl+'</span>';
      }
    } else if(r.pending){
      sigInline='<span style="color:#888;margin-left:4px">KIS분석중...</span>';
    }
    h+='<tr style="'+rowStyle+'">'
      +'<td style="white-space:nowrap;overflow:hidden"><a href="https://m.stock.naver.com/domestic/stock/'+r.code+'/total" target="_blank" style="color:#e6edf3;text-decoration:none"><strong>'+r.name+'</strong></a>'
      +' <span class="'+rc+'">'+rs+'</span>'
      +sigInline+'</td>'
      +'<td style="white-space:nowrap"><span class="'+dc+'">'+r.type+'</span> <span class="'+sc+'">'+r.score+'</span> <span style="color:#555">'+r.boss+'/5·'+r.soldier+'/2</span></td>'
      +'<td>'+(r.wr?r.wr.toFixed(0)+'%':'-')+'</td></tr>';
  });
  h+='</table>';
  document.getElementById('s2Body').innerHTML=h;
}

// ── KOSPI200 30틱 차트 ──
let _k200AudioCtx = null;

function _k200Audio() {
  if (!_k200AudioCtx) {
    try { _k200AudioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch(e) {}
  }
  return _k200AudioCtx;
}

function k200Alarm(sig) {
  const ctx = _k200Audio();
  if (!ctx) return;
  const freqs = sig === 'UP' ? [600, 900, 1200] : [1200, 900, 600];
  const t = ctx.currentTime;
  freqs.forEach((f, i) => {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.type = 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0.28, t + i*0.16);
    g.gain.exponentialRampToValueAtTime(0.001, t + i*0.16 + 0.18);
    o.start(t + i*0.16); o.stop(t + i*0.16 + 0.22);
  });
}

function k200Render(d) {
  const svg = document.getElementById('k200Svg');
  if (!svg) return;
  const W = svg.getBoundingClientRect().width || svg.parentElement.clientWidth || 600;
  const H = 130;
  const bars = d.bars || [], maArr = d.ma || [];
  const N = bars.length;
  if (!N) {
    svg.innerHTML = '<text x="50%" y="68" text-anchor="middle" fill="#555" font-size="11" font-family="Malgun Gothic,sans-serif">30틱 봉 누적 중... (봉 1개 = 30틱)</text>';
    return;
  }
  const PAD_L=42, PAD_R=8, PAD_T=8, PAD_B=14;
  const cW=W-PAD_L-PAD_R, cH=H-PAD_T-PAD_B;
  const slotW=cW/N, bW=Math.max(1, Math.floor(slotW*0.72));
  let lo=Infinity, hi=-Infinity;
  bars.forEach(b=>{lo=Math.min(lo,b.l);hi=Math.max(hi,b.h);});
  maArr.forEach(v=>{if(v!=null){lo=Math.min(lo,v);hi=Math.max(hi,v);}});
  if(d.bar){lo=Math.min(lo,d.bar.l);hi=Math.max(hi,d.bar.h);}
  if(d.price){lo=Math.min(lo,d.price);hi=Math.max(hi,d.price);}
  const buf=(hi-lo||0.5)*0.06; lo-=buf; hi+=buf;
  const rng=hi-lo||0.5;
  const py=v=>PAD_T+(hi-v)/rng*cH;
  const bx=i=>PAD_L+(i+0.5)*slotW-bW/2;
  let h='';
  // grid
  [0.25,0.5,0.75].forEach(pct=>{
    const gp=lo+rng*pct, gy=py(gp).toFixed(1);
    h+=`<line x1="${PAD_L}" y1="${gy}" x2="${(W-PAD_R).toFixed(1)}" y2="${gy}" stroke="#1e2430" stroke-width="1"/>`;
    h+=`<text x="${(PAD_L-2).toFixed(1)}" y="${(parseFloat(gy)+3).toFixed(1)}" text-anchor="end" fill="#3a3f4a" font-size="8" font-family="Consolas,monospace">${gp.toFixed(2)}</text>`;
  });
  // bars
  bars.forEach((b,i)=>{
    const x=bx(i).toFixed(1), midX=(bx(i)+bW/2).toFixed(1);
    const isUp=b.c>=b.o, col=isUp?'#f85149':'#4fc3f7';
    const t=Math.min(py(b.o),py(b.c)).toFixed(1), bh=Math.max(1,Math.abs(py(b.o)-py(b.c))).toFixed(1);
    h+=`<line x1="${midX}" y1="${py(b.h).toFixed(1)}" x2="${midX}" y2="${py(b.l).toFixed(1)}" stroke="${col}" stroke-width="1"/>`;
    h+=`<rect x="${x}" y="${t}" width="${bW}" height="${bh}" fill="${col}" opacity="0.9"/>`;
  });
  // current bar (dashed)
  if(d.bar){
    const b=d.bar, x=bx(N).toFixed(1), midX=(bx(N)+bW/2).toFixed(1);
    if(parseFloat(x)<W-PAD_R){
      const isUp=b.c>=b.o, col=isUp?'#f85149':'#4fc3f7';
      const t=Math.min(py(b.o),py(b.c)).toFixed(1), bh=Math.max(1,Math.abs(py(b.o)-py(b.c))).toFixed(1);
      h+=`<line x1="${midX}" y1="${py(b.h).toFixed(1)}" x2="${midX}" y2="${py(b.l).toFixed(1)}" stroke="${col}" stroke-width="1" stroke-dasharray="2,1"/>`;
      h+=`<rect x="${x}" y="${t}" width="${bW}" height="${bh}" fill="${col}" opacity="0.35"/>`;
    }
  }
  // 20MA line
  let pathD='', prevNull=true;
  maArr.forEach((v,i)=>{
    if(v==null){prevNull=true;return;}
    const px2=(bx(i)+bW/2).toFixed(1), py2=py(v).toFixed(1);
    pathD+=prevNull?`M${px2},${py2}`:`L${px2},${py2}`;
    prevNull=false;
  });
  if(pathD) h+=`<path d="${pathD}" fill="none" stroke="#d29922" stroke-width="1.5" stroke-linejoin="round"/>`;
  // current price line
  if(d.price){
    const cpY=py(d.price).toFixed(1);
    h+=`<line x1="${PAD_L}" y1="${cpY}" x2="${(W-PAD_R).toFixed(1)}" y2="${cpY}" stroke="#555" stroke-width="0.5" stroke-dasharray="3,3"/>`;
  }
  svg.innerHTML=h;
}

// 단일 가격 소스 — k200Poll이 업데이트, renderKospi도 이 값 사용
let _gK200Price = 0, _gK200Rate = 0;
let _lastFutures = null;  // 마지막 스캔 futures 데이터 캐시

function k200Poll() {
  fetch('/api/k200_ticks').then(r=>r.json()).then(d=>{
    const sigEl=document.getElementById('k200Sig');
    const tsEl=document.getElementById('k200Ts');
    // ── topbar 실시간 K200 (가격 표시 유일한 곳) ──
    const fpEl=document.getElementById('liveFutPrice');
    const frEl=document.getElementById('liveFutRate');
    const ftEl=document.getElementById('liveFutTs');
    if(d.price){
      const rt=d.rate||0;
      const col=rt>=0?'#f85149':'#4fc3f7';
      _gK200Price = d.price;
      _gK200Rate = rt;
      if(_lastFutures) renderKospi(_lastFutures);
      // topbar — 유일한 K200선물 가격 표시 위치
      fpEl.textContent=d.price.toFixed(2)+'pt';
      fpEl.style.color=col;
      frEl.textContent=(rt>=0?'+':'')+rt.toFixed(2)+'%';
      frEl.style.color=col;
      ftEl.textContent=d.ts||'';
    }
    if(d.signal==='UP'){
      sigEl.textContent='▲ 골든크로스';
      sigEl.style.background='#0d2818'; sigEl.style.color='#3fb950';
      if(d.signal_ts) tsEl.textContent=d.signal_ts;
    } else if(d.signal==='DOWN'){
      sigEl.textContent='▼ 데드크로스';
      sigEl.style.background='#2d1014'; sigEl.style.color='#f85149';
      if(d.signal_ts) tsEl.textContent=d.signal_ts;
    } else {
      sigEl.textContent=''; sigEl.style.background='transparent';
      if(d.ts) tsEl.textContent=d.ts;
    }
    if(d.alert && d.signal) k200Alarm(d.signal);
    k200Render(d);
  }).catch(()=>{});
}

// AudioContext 초기화 (브라우저 정책: 사용자 클릭 후)
document.addEventListener('click', ()=>_k200Audio(), {once:true});
setInterval(k200Poll, 2000);
k200Poll();
</script>
</body>
</html>"""


SYSTEM_HTML = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Trader Bot - 시스템 현황</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0d1117;color:#c9d1d9;font-family:'Malgun Gothic','Segoe UI',sans-serif;padding:20px}
a{color:#58a6ff;text-decoration:none}
a:hover{text-decoration:underline}
.nav{display:flex;gap:16px;margin-bottom:20px;padding-bottom:12px;border-bottom:1px solid #30363d}
.nav a{padding:6px 14px;border-radius:6px;font-size:13px;font-weight:600}
.nav a.active{background:#21262d;color:#58a6ff}
h1{font-size:20px;color:#58a6ff;margin-bottom:20px}
h2{font-size:15px;color:#d29922;margin:24px 0 12px;padding-bottom:6px;border-bottom:1px solid #30363d}
.arch{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:20px;font-family:'Consolas','Courier New',monospace;font-size:13px;line-height:1.8;white-space:pre;overflow-x:auto;color:#333;margin-bottom:16px}
.arch .hi{color:#58a6ff;font-weight:700}
.arch .ok{color:#3fb950}
.arch .warn{color:#d29922}
table{width:100%;border-collapse:collapse;margin-bottom:16px}
th{background:#161b22;color:#333;font-size:11px;text-transform:uppercase;padding:8px 12px;text-align:left;border-bottom:2px solid #30363d}
td{padding:8px 12px;border-bottom:1px solid #21262d;font-size:13px}
.tag{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.tag-ok{background:#0f5323;color:#3fb950}
.tag-warn{background:#3d2e00;color:#d29922}
.tag-off{background:#21262d;color:#484f58}
.tag-dev{background:#1a1040;color:#bc8cff}
.status-row{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px}
.scard{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:14px 18px;min-width:180px;flex:1}
.scard .label{font-size:11px;color:#333;margin-bottom:4px}
.scard .val{font-size:16px;font-weight:700}
.scard .val.green{color:#3fb950}
.scard .val.yellow{color:#d29922}
.scard .val.gray{color:#484f58}
</style>
</head>
<body>
<div class="nav">
  <a href="/system" class="active">시스템 현황</a>
  <a href="/">스캐너</a>
</div>

<h1>Trader Bot 시스템 현황</h1>

<div class="status-row" id="statusCards">
  <div class="scard"><div class="label">KIS API</div><div class="val" id="kisStatus">확인중...</div></div>
  <div class="scard"><div class="label">스캐너 웹</div><div class="val green">가동중</div></div>
  <div class="scard"><div class="label">트레이더</div><div class="val green">자동매매 루프</div></div>
</div>

<h2>아키텍처</h2>
<div class="arch"><span class="hi">[trader.py]</span> 자동매매 루프 (3분 스캔)
    |-- 시장 레짐 필터 (급등장 CALL 억제)
    |-- 진입 직전 신호 재검증 + 거래 전 텔레그램 승인
    v
<span class="hi">[scanner_web.py]</span> localhost:5050
    |-- scanner_262_52.py (262개 종목 스캔)
    |-- 1단계 네이버 1분봉 -> 2단계 KIS OHLCV
    v
<span class="hi">[분석/주문]</span>
    |-- kis.py (KIS REST API)
    |-- analysis.py (6대장2쫄병 IndicatorEngine)
    |-- vault_writer.py (Obsidian vault 기록)
    |-- knowledge/ (전략/관심종목/규칙/휴장일)</div>

<h2>파일 구성</h2>
<table>
<tr><th>파일</th><th>역할</th><th>상태</th></tr>
<tr><td>trader.py</td><td>자동매매 루프 (3분 스캔/주문/승인)</td><td><span class="tag tag-ok">가동중</span></td></tr>
<tr><td>scanner_web.py</td><td>스캐너 웹뷰어 (이 페이지)</td><td><span class="tag tag-ok">가동중</span></td></tr>
<tr><td>scanner_262_52.py</td><td>262개 종목 6대장2쫄병 2단계 스캐너</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>kis.py</td><td>KIS REST API (시세/주문/잔고)</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>analysis.py</td><td>6대장2쫄병 지표 엔진 (IndicatorEngine)</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>vault_writer.py</td><td>Obsidian vault 신호/결과 기록</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>knowledge.py</td><td>로컬 지식 파일 CRUD</td><td><span class="tag tag-ok">완료</span></td></tr>
<tr><td>config.py</td><td>설정 (KIS/Sentry/레짐 필터)</td><td><span class="tag tag-ok">완료</span></td></tr>
</table>

<h2>5대장2쫄병 신호 체계</h2>
<table>
<tr><th>구분</th><th>지표</th><th>CALL 조건</th><th>PUT 조건</th><th>배점</th></tr>
<tr><td rowspan="5">5대장</td><td>소나 크로스</td><td>K &gt; D, K &lt; 0 (골든)</td><td>K &lt; D, K &gt; 0 (데드)</td><td>10점</td></tr>
<tr><td>DI</td><td>DI- &lt; 42</td><td>DI+ &lt; 38</td><td>10점</td></tr>
<tr><td>ADX</td><td>ADX &lt; 40</td><td>ADX &lt; 45</td><td>10점</td></tr>
<tr><td>RSI</td><td>RSI &gt; 22</td><td>RSI &lt; 72</td><td>10점</td></tr>
<tr><td>스토캐스틱 K</td><td>K &gt; 5</td><td>K &lt; 90</td><td>10점</td></tr>
<tr><td rowspan="2">2쫄병</td><td>볼륨/Williams</td><td>Vol &gt;= 0.3x / %R &gt; -90</td><td>MACD Hist &lt; 0.5</td><td>5점</td></tr>
<tr><td>Williams/%R / MACD</td><td>Williams %R &gt; -90</td><td>MACD Hist &lt; 2.0</td><td>5점</td></tr>
<tr><td colspan="4" style="text-align:right;font-weight:700">최대</td><td><strong>60점</strong></td></tr>
</table>

<h2>스캐너 동작 흐름</h2>
<div class="arch">1단계 <span class="hi">[네이버 1분봉]</span> 262개 종목 빠른 필터
  - Close + Volume만 (O=H=L=C 근사)
  - CALL/PUT 양방향 체크
  - 30점 이상 통과 -> 2단계로
  - 소요: ~4분

2단계 <span class="hi">[KIS 1분봉 OHLCV]</span> 통과 종목 정밀 분석
  - 정확한 Open/High/Low/Close/Volume
  - validate_signal() 승률 50%+ 검증
  - 최종 신호 종목 표시
  - 소요: 종목당 ~5초

점수 색상:
  30점 = <span style="color:#333">회색</span>
  CALL 45점 = <span style="color:#f0883e">주황</span>  /  PUT 45점 = <span style="color:#bc8cff">보라</span>
  CALL 60점 = <span style="color:#ff4444">빨강</span>  /  PUT 60점 = <span style="color:#58a6ff">파랑</span></div>

<h2>외부 연결</h2>
<table>
<tr><th>서비스</th><th>URL</th><th>용도</th></tr>
<tr><td>KIS API</td><td>openapi.koreainvestment.com:9443</td><td>시세/주문/잔고</td></tr>
<tr><td>스캐너 웹</td><td><a href="http://localhost:5050">localhost:5050</a></td><td>262개 종목 스캔 결과</td></tr>
</table>

<script>
// KIS는 토큰 필요해서 간접 확인
document.getElementById('kisStatus').textContent='설정됨';
document.getElementById('kisStatus').className='val green';
</script>
</body>
</html>"""


@app.route('/')
def index():
    from flask import make_response
    resp = make_response(render_template_string(HTML))
    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate'
    resp.headers['Pragma'] = 'no-cache'
    return resp


@app.route('/system')
def system_page():
    return render_template_string(SYSTEM_HTML)





TRADING_HTML = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>자동매매</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#0d1117;color:#c9d1d9;font-family:'Segoe UI',sans-serif;font-size:13px}
.nav{display:flex;gap:16px;padding:8px 20px;background:#161b22;border-bottom:1px solid #30363d}
.nav a{padding:4px 12px;border-radius:6px;font-size:13px;font-weight:600;color:#333;text-decoration:none}
.nav a.active{background:#21262d;color:#58a6ff}
.header{padding:16px 20px;border-bottom:1px solid #21262d;display:flex;align-items:center;gap:16px}
.header h1{font-size:18px;color:#f0f6fc}
.container{display:flex;height:calc(100vh - 100px)}
.sidebar{width:280px;padding:16px;border-right:1px solid #21262d;overflow-y:auto}
.main{flex:1;padding:16px;overflow-y:auto}
.section{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:16px;margin-bottom:16px}
.section h3{color:#58a6ff;margin-bottom:12px;font-size:14px}
.param{display:flex;justify-content:space-between;align-items:center;padding:6px 0;border-bottom:1px solid #21262d}
.param .label{color:#333;font-size:12px}
.param .value{color:#f0f6fc;font-weight:600}
.status-badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600}
.status-ready{background:#1a3a1a;color:#3fb950}
.status-off{background:#3a1a1a;color:#f85149}
.btn{padding:8px 16px;border-radius:6px;border:none;font-size:13px;font-weight:600;cursor:pointer;width:100%;margin-top:8px}
.btn-start{background:#238636;color:#fff}
.btn-start:hover{background:#2ea043}
.btn-stop{background:#da3633;color:#fff}
.btn-stop:hover{background:#f85149}
.positions{display:grid;gap:12px}
.pos-card{background:#161b22;border:1px solid #30363d;border-radius:8px;padding:12px}
.pos-card .name{font-size:14px;font-weight:600;color:#f0f6fc}
.pos-card .dir-call{color:#ff4444}.pos-card .dir-put{color:#58a6ff}
.pos-card .pnl-pos{color:#3fb950}.pos-card .pnl-neg{color:#f85149}
.log-area{background:#0d1117;border:1px solid #30363d;border-radius:6px;padding:8px;max-height:300px;overflow-y:auto;font-family:monospace;font-size:11px;line-height:1.6}
.log-entry{padding:2px 4px}
.stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.stat-box{background:#0d1117;border:1px solid #30363d;border-radius:6px;padding:12px;text-align:center}
.stat-box .val{font-size:20px;font-weight:700;color:#f0f6fc}
.stat-box .lbl{font-size:11px;color:#333;margin-top:4px}
</style>
</head>
<body>
<div class="nav">
  <a href="/">스캐너</a>
  <a href="/trading" class="active">자동매매</a>
  <a href="/system">시스템 현황</a>
</div>
<div class="header">
  <h1>자동매매</h1>
  <span class="status-badge status-ready" id="statusBadge">대기중</span>
</div>
<div class="container">
  <div class="sidebar">
    <div class="section">
      <h3>매매 규칙</h3>
      <div class="param"><span class="label">종목당 투자금</span><span class="value">300만원</span></div>
      <div class="param"><span class="label">최대 종목수</span><span class="value">3종목</span></div>
      <div class="param"><span class="label">손절</span><span class="value">-3% 또는 -10만원</span></div>
      <div class="param"><span class="label">트레일링 활성화</span><span class="value">+3%</span></div>
      <div class="param"><span class="label">3~10% 구간</span><span class="value">50% 되돌림 익절</span></div>
      <div class="param"><span class="label">10%+ 구간</span><span class="value">30% 되돌림 익절</span></div>
    </div>
    <div class="section">
      <h3>진입 조건 (CALL)</h3>
      <div class="param"><span class="label">RSI</span><span class="value">&lt; 30</span></div>
      <div class="param"><span class="label">Bollinger %B</span><span class="value">&lt; 20</span></div>
      <div class="param"><span class="label">CCI</span><span class="value">&lt; -100</span></div>
      <div class="param"><span class="label">Williams %R</span><span class="value">&lt; -80</span></div>
      <div class="param"><span class="label">AROON Down</span><span class="value">&gt; 80</span></div>
    </div>
    <div class="section">
      <h3>진입 조건 (PUT)</h3>
      <div class="param"><span class="label">RSI</span><span class="value">&gt; 80</span></div>
      <div class="param"><span class="label">CCI</span><span class="value">&gt; 150</span></div>
      <div class="param"><span class="label">Bollinger %B</span><span class="value">&gt; 80</span></div>
      <div class="param"><span class="label">연속상승</span><span class="value">&gt;= 3봉</span></div>
      <div class="param"><span class="label">UO</span><span class="value">&gt; 70</span></div>
    </div>
    <button class="btn btn-start" id="btnStart" onclick="startTrading()">자동매매 시작</button>
    <button class="btn btn-stop" id="btnStop" onclick="stopTrading()" style="display:none">자동매매 중지</button>
  </div>
  <div class="main">
    <div class="section">
      <h3>오늘 실적</h3>
      <div class="stats-grid">
        <div class="stat-box"><div class="val" id="totalTrades">0</div><div class="lbl">총 매매</div></div>
        <div class="stat-box"><div class="val" id="winRate">-</div><div class="lbl">승률</div></div>
        <div class="stat-box"><div class="val" id="totalPnl">0원</div><div class="lbl">총 손익</div></div>
      </div>
    </div>
    <div class="section">
      <h3>보유 포지션</h3>
      <div class="positions" id="positions">
        <div style="color:#333;text-align:center;padding:20px">포지션 없음</div>
      </div>
    </div>
    <div class="section">
      <h3>매매 로그</h3>
      <div class="log-area" id="tradeLog">
        <div class="log-entry" style="color:#333">자동매매를 시작하면 로그가 표시됩니다.</div>
      </div>
    </div>
  </div>
</div>
<script>
let pollT=null;

function startTrading(){
  fetch('/api/trading/start',{method:'POST'}).then(r=>r.json()).then(d=>{
    if(d.error){alert(d.error);return;}
    document.getElementById('btnStart').style.display='none';
    document.getElementById('btnStop').style.display='block';
    document.getElementById('statusBadge').textContent='실행중';
    document.getElementById('statusBadge').className='status-badge status-ready';
    startPoll();
  });
}

function stopTrading(){
  fetch('/api/trading/stop',{method:'POST'}).then(()=>{
    document.getElementById('btnStart').style.display='block';
    document.getElementById('btnStop').style.display='none';
    document.getElementById('statusBadge').textContent='대기중';
    document.getElementById('statusBadge').className='status-badge status-off';
  });
}

function startPoll(){
  if(pollT) clearInterval(pollT);
  pollT=setInterval(fetchStatus,2000);
}

function fetchStatus(){
  fetch('/api/trading/status').then(r=>r.json()).then(d=>{
    // 상태 배지
    if(!d.running){
      document.getElementById('btnStart').style.display='block';
      document.getElementById('btnStop').style.display='none';
      document.getElementById('statusBadge').textContent='대기중';
      document.getElementById('statusBadge').className='status-badge status-off';
    }
    // 통계
    document.getElementById('totalTrades').textContent=d.daily_trades||0;
    let pnl=d.daily_pnl||0;
    document.getElementById('totalPnl').textContent=(pnl>=0?'+':'')+pnl.toLocaleString()+'원';
    document.getElementById('totalPnl').style.color=pnl>=0?'#3fb950':'#f85149';
    // 포지션
    let pDiv=document.getElementById('positions');
    if(d.positions&&d.positions.length){
      pDiv.innerHTML=d.positions.map(p=>{
        let dc=p.side==='CALL'?'dir-call':'dir-put';
        let pc=p.pnl>=0?'pnl-pos':'pnl-neg';
        let kindStr=p.kind?(' ['+p.kind+']'):'';
        return '<div class="pos-card"><div class="name">'+p.name+kindStr+' <span class="'+dc+'">'+p.side+'</span></div>'+
          '<div style="font-size:12px;color:#8b949e">진입 '+p.entry.toLocaleString()+'원 × '+p.qty+'계약</div>'+
          '<div class="'+pc+'" style="font-size:12px">'+(p.pnl>=0?'+':'')+p.pnl.toFixed(2)+'%</div></div>';
      }).join('');
    } else {
      pDiv.innerHTML='<div style="color:#555;text-align:center;padding:20px">포지션 없음</div>';
    }
    // 로그
    let logDiv=document.getElementById('tradeLog');
    if(d.logs&&d.logs.length){
      logDiv.innerHTML=d.logs.slice().reverse().map(l=>'<div class="log-entry">'+l+'</div>').join('');
    }
  });
}

// 페이지 로드 시 상태 확인
fetchStatus();
startPoll();
</script>
</body>
</html>"""


@app.route('/api/trading/start', methods=['POST'])
def api_trading_start():
    if sentry_state['running']:
        return jsonify({'error': 'already running'}), 409
    sentry_dir = os.path.dirname(os.path.abspath(__file__))
    proc = subprocess.Popen(
        [sys.executable, 'trader.py'],
        cwd=sentry_dir,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        bufsize=1,
    )
    sentry_state['proc'] = proc
    sentry_state['running'] = True
    sentry_state['logs'] = ['[자동매매 시작]']
    sentry_state['positions'] = []
    sentry_state['daily_trades'] = 0
    sentry_state['daily_pnl'] = 0.0
    sentry_state['started_at'] = datetime.now().isoformat()
    t = threading.Thread(target=_sentry_reader, args=(proc,), daemon=True)
    t.start()
    return jsonify({'status': 'started'})


@app.route('/api/trading/stop', methods=['POST'])
def api_trading_stop():
    proc = sentry_state.get('proc')
    if proc:
        proc.terminate()
        sentry_state['running'] = False
        sentry_state['proc'] = None
        sentry_state['logs'].append('[자동매매 중지]')
    return jsonify({'status': 'stopped'})


@app.route('/api/trading/status')
def api_trading_status():
    return jsonify({
        'running': sentry_state['running'],
        'logs': sentry_state['logs'][-50:],
        'positions': sentry_state['positions'],
        'daily_trades': sentry_state['daily_trades'],
        'daily_pnl': sentry_state['daily_pnl'],
        'started_at': sentry_state['started_at'],
    })


@app.route('/trading')
def trading_page():
    return render_template_string(TRADING_HTML)


@app.route('/api/sentry/update', methods=['POST'])
def api_sentry_update():
    """sentry.py에서 상태 푸시"""
    data = request.get_json(silent=True) or {}
    # sentry.py가 독립 실행 중이어도 running=True로 자동 갱신
    sentry_state['running'] = True
    sentry_state['positions'] = data.get('positions', sentry_state['positions'])
    sentry_state['daily_trades'] = data.get('daily_trades', sentry_state['daily_trades'])
    sentry_state['daily_pnl'] = data.get('daily_pnl', sentry_state['daily_pnl'])
    if not sentry_state['started_at']:
        sentry_state['started_at'] = datetime.now().isoformat()
    if data.get('log'):
        ts = datetime.now().strftime('%H:%M:%S')
        sentry_state['logs'].append(f'[{ts}] {data["log"]}')
        sentry_state['logs'] = sentry_state['logs'][-100:]
    if data.get('logs'):
        for msg in data['logs']:
            ts = datetime.now().strftime('%H:%M:%S')
            sentry_state['logs'].append(f'[{ts}] {msg}')
        sentry_state['logs'] = sentry_state['logs'][-100:]
    return jsonify({'ok': True})


SCAN_COOLDOWN_SEC = 30   # 스캔 완료 후 최소 대기 (병렬화로 스캔 ~15s → 단축)
AUTO_RESCAN_SEC  = 45   # 스캔 완료 후 자동 재스캔 대기 (쿨다운 30s 이후)

_rescan_timer = None  # 자동 재스캔 타이머

def _schedule_next_scan():
    """스캔 완료 후 AUTO_RESCAN_SEC 뒤 자동 재스캔 예약"""
    global _rescan_timer
    if _rescan_timer and _rescan_timer.is_alive():
        _rescan_timer.cancel()

    def _do_rescan():
        if not scan_state['running']:
            # 장 시간(평일 08:45~15:45) 체크
            now = datetime.now()
            weekday = now.weekday()  # 0=월 6=일
            if weekday >= 5:  # 주말
                return
            h, m = now.hour, now.minute
            cur = h * 60 + m
            if not (8 * 60 + 45 <= cur <= 15 * 60 + 45):
                return
            print(f'[AutoScan] 자동 재스캔 시작 ({now.strftime("%H:%M:%S")})')
            # api_scan 직접 호출 (Flask context 없이)
            _start_scan_internal()

    _rescan_timer = threading.Timer(AUTO_RESCAN_SEC, _do_rescan)
    _rescan_timer.daemon = True
    _rescan_timer.start()


def _start_scan_internal():
    """api_scan 로직을 Flask context 없이 직접 실행"""
    if scan_state['running']:
        return
    scan_state['running'] = True
    scan_state['stage1'] = []
    scan_state['stage2'] = []
    scan_state['futures'] = None
    scan_state['logs'] = ['스캔 시작 (자동)...']
    scan_state['started_at'] = datetime.now().isoformat()
    scan_state['finished_at'] = None

    def run():
        class LogCapture:
            def __init__(self): self.lines = []
            def write(self, s):
                if s.strip():
                    self.lines.append(s.strip())
                    scan_state['logs'] = self.lines[-40:]
                sys.__stdout__.write(s)
                return len(s)
            def flush(self): pass

        old_stdout = sys.stdout
        sys.stdout = LogCapture()
        def on_stage1(items): scan_state['stage1'] = items
        def on_stage2(items): scan_state['stage2'] = items
        def on_futures(f):    scan_state['futures'] = f
        try:
            result = scan_all(on_stage1=on_stage1, on_stage2=on_stage2, on_futures=on_futures,
                              k200_rate=k200_state.get('rate', 0.0))
            if isinstance(result, dict):
                scan_state['stage1'] = result.get('stage1', [])
                scan_state['stage2'] = result.get('stage2', [])
                scan_state['futures'] = result.get('futures')
        except Exception as e:
            scan_state['logs'].append(f'[ERROR] {str(e)[:100]}')
        finally:
            sys.stdout = old_stdout
            scan_state['running'] = False
            scan_state['finished_at'] = datetime.now().isoformat()
            _schedule_next_scan()

    threading.Thread(target=run, daemon=True).start()

@app.route('/api/scan', methods=['POST'])
def api_scan():
    if scan_state['running']:
        return jsonify({'error': 'already running'}), 409

    # 쿨다운: 이전 스캔 완료 후 SCAN_COOLDOWN_SEC 이내면 거부
    finished_at = scan_state.get('finished_at')
    if finished_at:
        try:
            elapsed = (datetime.now() - datetime.fromisoformat(finished_at)).total_seconds()
            if elapsed < SCAN_COOLDOWN_SEC:
                return jsonify({'error': 'cooldown', 'wait': int(SCAN_COOLDOWN_SEC - elapsed)}), 429
        except Exception:
            pass

    scan_state['running'] = True
    scan_state['stage1'] = []
    scan_state['stage2'] = []
    scan_state['futures'] = None
    scan_state['logs'] = ['스캔 시작 (최대 15분 소요)...']
    scan_state['started_at'] = datetime.now().isoformat()
    scan_state['finished_at'] = None

    def run():
        class LogCapture:
            def __init__(self):
                self.lines = []
            def write(self, s):
                if s.strip():
                    self.lines.append(s.strip())
                    scan_state['logs'] = self.lines[-40:]
                sys.__stdout__.write(s)
                return len(s)
            def flush(self):
                pass

        old_stdout = sys.stdout
        sys.stdout = LogCapture()
        def on_stage1(items):
            scan_state['stage1'] = items
            s1_pass = len([x for x in items if x.get('passed')])
            scan_state['logs'].append(f'[1단계 완료] {s1_pass}/{len(items)}개 통과 → 2단계 KIS 분석 시작...')

        def on_stage2(items):
            scan_state['stage2'] = items

        def on_futures(f):
            scan_state['futures'] = f

        result = None
        try:
            result = scan_all(on_stage1=on_stage1, on_stage2=on_stage2, on_futures=on_futures,
                              k200_rate=k200_state.get('rate', 0.0))

            if isinstance(result, dict):
                scan_state['stage1'] = result.get('stage1', [])
                scan_state['stage2'] = result.get('stage2', [])
                scan_state['futures'] = result.get('futures')
                s1_cnt = len([x for x in scan_state['stage1'] if x.get('passed')])
                scan_state['logs'].append(f'[완료] 1단계: {s1_cnt}개 통과/{len(scan_state["stage1"])}개 스캔')
                scan_state['logs'].append(f'[완료] 2단계: {len(scan_state["stage2"])}개 신호 확정')
            elif isinstance(result, list):
                scan_state['stage2'] = result
                scan_state['logs'].append(f'[완료] 신호 {len(result)}개')
            else:
                scan_state['logs'].append('[경고] 스캔 결과 형식 오류')
        except Exception as e:
            scan_state['logs'].append(f'[ERROR] {str(e)[:100]}')
        finally:
            sys.stdout = old_stdout
            scan_state['running'] = False
            scan_state['finished_at'] = datetime.now().isoformat()
            # 스캔 완료 후 AUTO_RESCAN_SEC 뒤 자동 재스캔
            _schedule_next_scan()

    t = threading.Thread(target=run, daemon=True)
    t.start()
    return jsonify({'status': 'started'})


def _to_json_safe(obj):
    """numpy bool/int/float → Python 기본 타입 변환 (JSON 직렬화 오류 방지)"""
    import numpy as np
    if isinstance(obj, dict):
        return {k: _to_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_to_json_safe(v) for v in obj]
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    return obj


@app.route('/api/status')
def api_status():
    return jsonify(_to_json_safe({
        'running': scan_state['running'],
        'stage1': scan_state['stage1'],
        'stage2': scan_state['stage2'],
        'futures': scan_state['futures'],
        'logs': scan_state['logs'],
        'started_at': scan_state['started_at'],
        'finished_at': scan_state['finished_at'],
        'stage1_loaded': scan_state.get('stage1_loaded', False),
        'positions': sentry_state['positions'],
        'daily_pnl': sentry_state['daily_pnl'],
        'daily_trades': sentry_state['daily_trades'],
        'strategies': _strategy_list(),
        'kis_configured': _kis_configured(),
    }))


def _kis_configured():
    """사용자 KIS 앱키가 .env 에 있는지 (없으면 2단계 정밀 신호·실매매 비활성, 1단계 네이버 스캔만)"""
    try:
        import config as _c
        return bool((_c.KIS_APP_KEY or '').strip() and (_c.KIS_APP_SECRET or '').strip())
    except Exception:
        return False


def _strategy_list():
    """strategies/*.json 목록 (전략 탭용). strategy_engine 없으면 []"""
    try:
        import strategy_engine
        return strategy_engine.strategy_summary()
    except Exception:
        return []


@app.route('/api/strategies')
def api_strategies():
    """전략 목록 + 전략별 현재 통과 종목(최근 스캔 stage2 기준)"""
    strategies = _strategy_list()
    hits = {}
    for it in scan_state.get('stage2', []) or []:
        for st in it.get('strategies', []) or []:
            if st.get('passed'):
                hits.setdefault(st['id'], []).append({'code': it.get('code'), 'name': it.get('name'), 'price': it.get('price'),
                                                      'rate': it.get('rate'), 'score': st.get('score'), 'direction': st.get('direction')})
    for st in strategies:
        st['hits'] = sorted(hits.get(st['id'], []), key=lambda x: -(x.get('score') or 0))
    # 겹침: 2개 이상 전략에 동시에 걸린 종목
    overlap = {}
    for it in scan_state.get('stage2', []) or []:
        ids = [st['id'] for st in (it.get('strategies') or []) if st.get('passed')]
        if len(ids) >= 2:
            overlap[it['code']] = {'name': it.get('name'), 'strategies': ids}
    return jsonify(_to_json_safe({'strategies': strategies, 'overlap': overlap, 'finished_at': scan_state['finished_at'], 'kis_configured': _kis_configured()}))


@app.route('/api/strategies/<sid>/enabled', methods=['POST'])
def api_strategy_toggle(sid):
    """전략 켜기/끄기: 파일의 enabled 만 바꾼다 (폰에서 토글)"""
    import os, json as _json
    try:
        import strategy_engine
        target = None
        for st in strategy_engine.load_strategies(force=True):
            if st['id'] == sid:
                target = st['_file']
        if not target:
            return jsonify({'success': False, 'error': '없는 전략'}), 404
        body = request.get_json(silent=True) or {}
        with open(target, encoding='utf-8-sig') as fp:
            spec = _json.load(fp)
        spec['enabled'] = bool(body.get('enabled', not spec.get('enabled', True)))
        with open(target, 'w', encoding='utf-8') as fp:
            _json.dump(spec, fp, ensure_ascii=False, indent=2)
        strategy_engine.load_strategies(force=True)
        return jsonify({'success': True, 'id': sid, 'enabled': spec['enabled']})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/k200_debug')
def api_k200_debug():
    """KOSPI200 소스 디버그 — FHPST02400000 raw 응답 확인"""
    import requests as _req
    try:
        from kis import get_access_token, KIS_API_URL, KIS_APP_KEY, KIS_APP_SECRET
        _tok = get_access_token()
        _h = {
            'Content-Type': 'application/json',
            'authorization': 'Bearer ' + _tok,
            'appkey': KIS_APP_KEY,
            'appsecret': KIS_APP_SECRET,
            'tr_id': 'FHPST02400000',
        }
        _p = {'fid_cond_mrkt_div_code': 'U', 'fid_input_iscd': '2001'}
        _r = _req.get(KIS_API_URL + '/uapi/domestic-stock/v1/quotations/inquire-index-price',
                      headers=_h, params=_p, timeout=5)
        _d = _r.json()
        _o = _d.get('output', {})
        _spot_raw = _o.get('stck_prpr', '?')
        _spot = float(_spot_raw.replace(',', '')) if _spot_raw != '?' else 0
        _fut = _futures_basis(_spot) if _spot > 0 else 0
        return jsonify({
            'rt_cd': _d.get('rt_cd'),
            'msg1': _d.get('msg1', ''),
            'stck_prpr': _spot_raw,
            'spot': _spot,
            'futures_estimate': _fut,
            'basis': round(_fut - _spot, 2),
            'source': _k200_source,
            'k200_state_price': k200_state.get('price'),
            'output_keys': list(_o.keys()),
        })
    except Exception as e:
        return jsonify({'error': str(e)})


@app.route('/api/k200_ticks')
def api_k200_ticks():
    """KOSPI200 30틱 차트 데이터 반환 (alert 플래그 소비)"""
    data = dict(k200_state)
    if k200_state['alert']:
        k200_state['alert'] = False
    if data.get('bar'):
        data['bar'] = dict(data['bar'])
    data['bars'] = list(data.get('bars', []))[-80:]
    data['ma']   = list(data.get('ma',   []))[-80:]
    return jsonify(data)


if __name__ == '__main__':
    port = 5050
    print(f"\n  Scanner Web Viewer: http://localhost:{port}")
    print(f"  1단계(네이버) | 2단계(KIS) 좌우 나란히 표시\n")
    threading.Thread(target=_k200_poller, daemon=True, name='k200-tick-poller').start()
    webbrowser.open(f'http://localhost:{port}')
    # 배포판: 기본 127.0.0.1 (같은 PC 에서만 접속). 같은 공유기 안의 핸드폰에서 보려면 .env 에 SCANNER_HOST=0.0.0.0
    app.run(host=os.getenv('SCANNER_HOST', '127.0.0.1'), port=port, debug=False)
