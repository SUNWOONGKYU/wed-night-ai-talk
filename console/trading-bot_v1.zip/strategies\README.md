# strategies/ — 전략 파일 폴더 (전략 하나 = JSON 파일 하나)

스캐너(`scanner_262_52.py`)가 이 폴더의 `*.json` 을 **전부** 읽어 같은 262종목·같은 분봉 위에서 동시에 평가한다.
만드는 방법은 GUI 가 아니라 Claude Code 에게 말로: "RSI 30 이하 + 거래량 2배 조건으로 '눌림목반등' 전략 만들어줘" → 이 규격의 파일이 생긴다.

## 규격
```json
{
  "id": "눌림목반등",            // 파일명과 동일. 화면·결과에 쓰는 키
  "name": "눌림목 반등",         // 표시명
  "version": "v1",
  "description": "무슨 아이디어인지 한두 줄",
  "enabled": true,               // false = 스캔 제외 (켜기/끄기)
  "live": false,                 // true = 실매매 봇(trader.py) 후보. 기본 false = 신호만
  "sample": false,               // 기본 제공 샘플 표시용
  "direction": "CALL",           // CALL(매수) | PUT(매도)
  "timeframe": "1m",
  "hard_filters": [ ... ],       // 하나라도 실패 → 그 종목은 이 전략에서 0점(신호 없음)
  "bosses":   [ ... ],           // 대장 조건: 각 scoring.boss 점. 전부 충족해야 통과
  "soldiers": [ ... ],           // 졸병 조건: 각 scoring.soldier 점. min_soldiers 개 이상
  "scoring": { "boss": 10, "soldier": 5, "min_score": 65, "min_soldiers": 1 }
}
```

## 조건 문법
| 형태 | 예 | 뜻 |
|---|---|---|
| 값 비교 | `{ "ind": "rsi", "op": "<", "value": 30 }` | RSI < 30 |
| 구간 | `{ "ind": "adx", "op": "between", "value": [15, 45] }` | 15 ≤ ADX < 45 |
| 지표끼리 | `{ "ind": "close", "op": ">", "ref": "ma20" }` | 종가 > 20일선 |
| 골든크로스 | `{ "op": "cross_up", "a": "sonar_k", "b": "sonar_d" }` | 직전봉 a≤b, 현재봉 a>b |
| 데드크로스 | `{ "op": "cross_down", "a": "macd", "b": "macd_sig" }` | |
| 부가조건 | `{ ..., "and": [ {조건}, ... ] }` | 주조건 + and 전부 |
op: `<` `<=` `>` `>=` `==` `between` `cross_up` `cross_down`. 각 조건에 `"id"` 를 주면 결과에 그 이름으로 표시된다.

## 쓸 수 있는 지표
`open high low close volume` · `sonar_k sonar_d`(소나 SMI 14,3,3) · `rsi`(14) · `plus_di minus_di adx`(14) · `stoch_k`(14,3) · `macd macd_sig macd_hist`(12,26,9) · `vol_ratio`(20봉 평균 대비) · `willr`(14) · `ma5 ma10 ma20 ma60` · `ema20` · `bb_upper bb_lower`(20,2σ) · `atr`(14)

## 규칙
- `5대장2졸병.json` 은 기본 제공 **샘플·교육용**이다. 우리 분석에서 엣지가 확인되지 않았고, 성적을 약속하지 않는다. 출발점으로 복사해서 바꿔 쓴다.
- 여러 전략이 같은 종목에 동시에 걸리면 스캐너가 "겹침"으로 표시한다.
- 실매매는 `live: true` 인 전략만 후보. 기본은 전부 신호만.
- 검증: `python strategy_engine.py` → 각 파일 OK/오류 목록.

---

## 일봉(1d) 전략 — `daily_strategy_engine.py` (2026-09-21 추가)

같은 JSON 규격에 `"timeframe": "1d"` 를 쓰면 **분봉 엔진이 아니라 일봉 엔진**이 맡는다(분봉 엔진 `strategy_engine.py` 는 1d 파일을 건너뛴다).
평가 시점은 하루 1회 — 봇(trader.py)이 **09시 첫 스캔**에 전일 확정 일봉으로 전 종목을 계산해 후보를 텔레그램 승인 요청한다(`x_entry.at = next_open`).
스캐너 카드에는 "일봉" 뱃지와 봇이 남긴 오늘 후보(`data/daily_strategy_last.json`)가 표시된다. 예: `3대장4졸병.json` (근거: `3대장4졸병_근거.md`).

### 1d 규격 (분봉 규격 + x_* 확장)
```json
{
  "id": "3대장4졸병", "name": "3대장 4졸병 (일봉 과매도 반등)", "direction": "CALL", "timeframe": "1d",
  "enabled": true, "live": true,
  "bosses": [
    { "id": "bear_market_gate", "label": "하락장 게이트", "x_market": true,
      "any": [ { "ind": "idx_close", "op": "<", "ref": "idx_ma200" }, { "ind": "idx_dd250", "op": "<=", "value": -15 } ] },
    { "id": "oversold_ma60", "label": "60일선 -15% 이하", "ind": "dev_ma60", "op": "<=", "value": -15 },
    { "id": "low_volatility", "label": "저변동", "ind": "vol20", "op": "<", "ref": "vol20_cs_median" }
  ],
  "soldiers": [ { "id": "deeper_oversold", "ind": "dev_ma60", "op": "<=", "value": -18 }, ... ],
  "scoring": { "boss": 20, "soldier": 10, "min_score": 70, "min_soldiers": 1 },
  "x_entry":     { "at": "next_open" },
  "x_exit":      { "type": "time", "hold_days": 20, "at": "open", "stop_loss": null },
  "x_portfolio": { "max_positions": 2, "priority": ["score desc", "vol20 asc"], "no_reentry_while_holding": true },
  "x_validation": { "train": {...}, "valid": {...}, "test": {...}, "verdict_deploy": "..." }
}
```
| 필드 | 뜻 |
|---|---|
| `bosses[].x_market: true` + `any[]` | 시장 단위 조건. `any` 중 하나만 맞으면 그 대장 충족(OR). 지표는 `idx_*` 만 |
| `bosses[].label` | 승인 메시지·카드에 쓰는 사람 말 |
| `scoring` | 점수 = 대장 충족수×boss + 졸병 충족수×soldier. 통과 = 대장 전부 + min_score + min_soldiers |
| `x_entry.at` | `next_open` — 신호일(일봉 확정) 다음 거래일 시가. 봇은 09시 첫 스캔에 승인 요청 |
| `x_exit` | `type: time` — hold_days 영업일 뒤 시가 청산. 손절/익절 없음(봇의 파국 -15%·만기 롤오버만). **운영 전략 `청산_일봉트랙.보유_영업일` 이 우선** |
| `x_portfolio.priority` | 후보 정렬. `"<score|k|지표> asc|desc"` 순서대로 |
| `x_portfolio.max_positions` | 참고값. 실제 한도는 **운영 전략 `자본.동시_최대_포지션`** |
| `x_portfolio.no_reentry_while_holding` | 봇이 보유 중 종목은 다시 요청하지 않음 |
| `x_validation` | 검증 요약(카드 한 줄) — 숫자는 근거 문서와 같게 |
| `candidate: true` | 전진검증 중 표시 |

op 는 `< <= > >= == between` (일봉 엔진은 cross 없음). `ref` 로 지표끼리 비교 가능.

### 1d 지표 (일봉 260봉 이상 있는 종목만, 마지막 확정봉 기준)
| 지표 | 뜻 |
|---|---|
| `close` | 종가 |
| `dev_ma60` | 종가 / 60일 단순이동평균 − 1 (%) |
| `vol20` | 최근 20일 일간수익률 표준편차 (%) |
| `vol20_cs_median` | 당일 유니버스 전체 `vol20` 의 중앙값 (횡단면 — 전 종목 계산 후 부여) |
| `dist_lo250` / `dist_hi250` | 종가 / 250일 최저가(최고가) − 1 (%) |
| `ret3` / `mom20` | 3일 / 20일 수익률 (%) |
| `ma60` `ma200` `rsi14` | 참고 |
| `idx_close` `idx_ma200` `idx_dd250` | KODEX200(069500) 종가 · 200일선 · 250일 최고가 대비 (%) — `x_market` 조건에서만 |

데이터: 종목 일봉 pykrx(6시간 캐시), 지수 KIS 일봉차트. 15:40 전에는 오늘 봉을 미확정으로 보고 버린다.
검증: `python daily_strategy_engine.py --check` (규격) · `python daily_strategy_engine.py` (오늘 후보 표, 241종목 약 20초).

### 3대 구성요소 (PO 원칙, 2026-09-21)
| 구성요소 | 파일 | 역할 |
|---|---|---|
| ① 신호 전략 | `strategies/*.json` — 1m 은 `strategy_engine.py`, 1d 는 `daily_strategy_engine.py` 가 평가 | 무엇을 살지 |
| ② 운영 전략 | `config_data/operating_strategy.json` (config.py 기본값을 덮어씀) | 얼마를·몇 개를·어떤 승인으로·언제 정리할지 (보유일·최대 포지션·가격 상한·승인) |
| ③ 매매 자동화 봇 | `trader.py` — `_daily_strategy_scan`(09시 1회) · `_execute_order`(승인) · `Position.check_exit`(시간 청산) | ①②를 연결해 승인된 주문만 실행 |
