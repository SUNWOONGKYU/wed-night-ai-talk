# strategies/ — 전략 파일 폴더 (전략 하나 = JSON 파일 하나)

스캐너(`scanner_262_52.py`)가 이 폴더의 `*.json` 을 **전부** 읽어 같은 262종목·같은 분봉 위에서 동시에 평가한다.
만드는 방법은 GUI 가 아니라 Claude Code 에게 말로: "RSI 30 이하 + 거래량 2배 조건으로 '눌림목반등' 전략 만들어줘" → 이 규격의 파일이 생긴다.

## 규격
```json
{
  "id": "눌림목반등",            // 파일명과 동일. 화면·결과에 쓰는 키
  "name": "눌림목 반등",         // 표시명
  "version": "v1",
  "description": "무슨 아이디어인지 한두 줄",
  "enabled": true,               // false = 스캔 제외 (켜기/끄기)
  "live": false,                 // true = 실매매 봇(trader.py) 후보. 기본 false = 신호만
  "sample": false,               // 기본 제공 샘플 표시용
  "direction": "CALL",           // CALL(매수) | PUT(매도)
  "timeframe": "1m",
  "hard_filters": [ ... ],       // 하나라도 실패 → 그 종목은 이 전략에서 0점(신호 없음)
  "bosses":   [ ... ],           // 대장 조건: 각 scoring.boss 점. 전부 충족해야 통과
  "soldiers": [ ... ],           // 졸병 조건: 각 scoring.soldier 점. min_soldiers 개 이상
  "scoring": { "boss": 10, "soldier": 5, "min_score": 65, "min_soldiers": 1 }
}
```

## 조건 문법
| 형태 | 예 | 뜻 |
|---|---|---|
| 값 비교 | `{ "ind": "rsi", "op": "<", "value": 30 }` | RSI < 30 |
| 구간 | `{ "ind": "adx", "op": "between", "value": [15, 45] }` | 15 ≤ ADX < 45 |
| 지표끼리 | `{ "ind": "close", "op": ">", "ref": "ma20" }` | 종가 > 20일선 |
| 골든크로스 | `{ "op": "cross_up", "a": "sonar_k", "b": "sonar_d" }` | 직전봉 a≤b, 현재봉 a>b |
| 데드크로스 | `{ "op": "cross_down", "a": "macd", "b": "macd_sig" }` | |
| 부가조건 | `{ ..., "and": [ {조건}, ... ] }` | 주조건 + and 전부 |
op: `<` `<=` `>` `>=` `==` `between` `cross_up` `cross_down`. 각 조건에 `"id"` 를 주면 결과에 그 이름으로 표시된다.

## 쓸 수 있는 지표
`open high low close volume` · `sonar_k sonar_d`(소나 SMI 14,3,3) · `rsi`(14) · `plus_di minus_di adx`(14) · `stoch_k`(14,3) · `macd macd_sig macd_hist`(12,26,9) · `vol_ratio`(20봉 평균 대비) · `willr`(14) · `ma5 ma10 ma20 ma60` · `ema20` · `bb_upper bb_lower`(20,2σ) · `atr`(14)

## 규칙
- `5대장2졸병.json` 은 기본 제공 **샘플·교육용**이다. 우리 분석에서 엣지가 확인되지 않았고, 성적을 약속하지 않는다. 출발점으로 복사해서 바꿔 쓴다.
- 여러 전략이 같은 종목에 동시에 걸리면 스캐너가 "겹침"으로 표시한다.
- 실매매는 `live: true` 인 전략만 후보. 기본은 전부 신호만.
- 검증: `python strategy_engine.py` → 각 파일 OK/오류 목록.
