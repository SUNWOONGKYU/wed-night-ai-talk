# -*- coding: utf-8 -*-
"""
전략 JSON 일봉 백테스트 — strategies/<id>.json 을 262종목 일봉 3.5년(research_backtest/daily_cache.pkl)에 돌린다.
  python strategy_backtest.py <전략id> [--hold 5] [--json]
  python strategy_backtest.py --all            # 활성 전략 전부 비교표
규칙: 조건 통과한 날 종가 진입 → hold 일 뒤 종가 청산, 왕복 비용 0.25%. 학습(~2024)/검증(2025~) 분리.
주의: 전략은 분봉용으로 쓰이지만 여기서는 같은 조건을 일봉에 적용한 "성향 확인"이다. 과거 성적은 미래를 보장하지 않는다.
"""
import sys, os, json, argparse, pickle
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import strategy_engine as se
from analysis import IndicatorEngine

CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'research_backtest', 'daily_cache.pkl')
COST = 0.25
SPLIT = pd.Timestamp('2025-01-01')


def _passed_series(spec, df_ind):
    """각 날짜에 대해 전략 통과 여부(bool Series). evaluate() 를 행마다 호출(느리지만 규칙 동일)."""
    n = len(df_ind)
    out = np.zeros(n, dtype=bool)
    sc = spec['scoring']
    rows = df_ind.to_dict('records')
    for i in range(1, n):
        cur, prev = rows[i], rows[i - 1]
        ok = True
        for c in spec.get('hard_filters', []) or []:
            if not se.eval_cond(c, cur, prev): ok = False; break
        if not ok: continue
        bosses = [se.eval_cond(c, cur, prev) for c in spec.get('bosses', []) or []]
        soldiers = [se.eval_cond(c, cur, prev) for c in spec.get('soldiers', []) or []]
        score = sum(bosses) * sc['boss'] + sum(soldiers) * sc['soldier']
        out[i] = score >= sc['min_score'] and sum(soldiers) >= sc.get('min_soldiers', 0) and (not bosses or all(bosses) or sc.get('allow_partial_bosses', False))
    return out


def run(spec, hold=5, data=None):
    data = data or pickle.load(open(CACHE, 'rb'))
    eng = IndicatorEngine()
    trades = []
    direction = 1 if spec.get('direction', 'CALL') == 'CALL' else -1
    for code, df in data.items():
        if df is None or len(df) < 80: continue
        d = df.copy(); d.columns = [c.lower() for c in d.columns]
        try:
            ind = se.extend_indicators(eng.calculate_all(d))
        except Exception:
            continue
        ps = _passed_series(spec, ind)
        close = ind['close'].values; idx = ind.index
        i = 1
        while i < len(ind) - hold:
            if ps[i]:
                r = (close[i + hold] / close[i] - 1) * 100 * direction - COST
                trades.append((idx[i], code, r))
                i += hold   # 겹치는 진입 방지
            else:
                i += 1
    if not trades:
        return {'id': spec['id'], 'hold': hold, 'n': 0}
    t = pd.DataFrame(trades, columns=['date', 'code', 'ret'])
    def stat(x):
        if len(x) == 0: return {'n': 0}
        return {'n': int(len(x)), 'win_rate': round(float((x['ret'] > 0).mean() * 100), 1), 'avg_ret': round(float(x['ret'].mean()), 2),
                'median_ret': round(float(x['ret'].median()), 2), 'total_ret': round(float(x['ret'].sum()), 1),
                'max_dd_trade': round(float(x['ret'].min()), 2), 'best': round(float(x['ret'].max()), 2)}
    return {'id': spec['id'], 'name': spec.get('name'), 'hold': hold, 'cost_pct': COST,
            'period': f"{t['date'].min().date()} ~ {t['date'].max().date()}",
            'all': stat(t), 'train(~2024)': stat(t[t['date'] < SPLIT]), 'valid(2025~)': stat(t[t['date'] >= SPLIT]),
            'per_year': {str(y): stat(g) for y, g in t.groupby(t['date'].dt.year)},
            'symbols_hit': int(t['code'].nunique())}


def verdict(res):
    """성적 표현 규칙: 보장·추천 어휘 금지, 숫자와 '검증구간' 기준만. 학습·검증 둘 다 +면 '일관', 아니면 '불일치'."""
    if res.get('n', 1) == 0 or res.get('all', {}).get('n', 0) < 30:
        return '표본 부족(30건 미만) — 성향 판단 불가'
    a, tr, va = res['all'], res['train(~2024)'], res['valid(2025~)']
    both = tr.get('n', 0) >= 10 and va.get('n', 0) >= 10 and tr.get('avg_ret', 0) > 0 and va.get('avg_ret', 0) > 0
    return ('학습·검증 구간 모두 평균수익 +' if both else '학습/검증 구간 불일치 또는 표본 부족') + f" · 전체 {a['n']}건 승률 {a['win_rate']}% 평균 {a['avg_ret']:+.2f}% (보유 {res['hold']}일, 비용 {res['cost_pct']}%)"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('id', nargs='?'); ap.add_argument('--hold', type=int, default=5); ap.add_argument('--json', action='store_true'); ap.add_argument('--all', action='store_true')
    a = ap.parse_args()
    sys.stdout.reconfigure(encoding='utf-8')
    strategies = se.load_strategies(force=True)
    targets = [s for s in strategies if (a.all and s.get('enabled') and not s.get('_errors')) or (a.id and s['id'] == a.id)]
    if not targets:
        print('전략 없음:', a.id or '(활성 전략 없음)'); sys.exit(1)
    for s in targets:
        if s.get('_errors'):
            print(s['id'], '규격 오류:', s['_errors']); continue
    data = pickle.load(open(CACHE, 'rb'))
    results = [run(s, a.hold, data) for s in targets if not s.get('_errors')]
    if a.json:
        print(json.dumps({'results': results, 'verdicts': {r['id']: verdict(r) for r in results}}, ensure_ascii=False, indent=1)); return
    for r in results:
        print(f"\n=== {r['id']} ({r.get('name','')}) 보유 {r['hold']}일 ===")
        if r.get('n', 1) == 0: print('  진입 0건'); continue
        for k in ('all', 'train(~2024)', 'valid(2025~)'):
            x = r[k]; print(f"  {k:14s} n={x.get('n',0):4d}  승률 {x.get('win_rate','-')}%  평균 {x.get('avg_ret','-')}%  중앙 {x.get('median_ret','-')}%  최악 {x.get('max_dd_trade','-')}%")
        print('  연도별:', {y: (v.get('n'), v.get('win_rate'), v.get('avg_ret')) for y, v in r['per_year'].items()})
        print('  판정:', verdict(r))


if __name__ == '__main__':
    main()
