# -*- coding: utf-8 -*-
"""
전략 엔진 — strategies/*.json (기계가 읽는 전략 규격) 을 전부 읽어 같은 지표 DataFrame 위에서 평가한다.

규격 (한 파일 = 한 전략):
{
  "id": "5대장2졸병",            # 파일명과 같게. 영문/한글/숫자/_ 만
  "name": "5대장 2졸병 (샘플)",   # 화면 표시명
  "version": "v3",
  "enabled": true,               # false 면 스캔에서 제외
  "live": false,                 # true 인 전략만 실매매(trader.py) 후보 — 기본 false
  "sample": true,                # 기본 제공 샘플 표시
  "direction": "CALL",           # CALL | PUT
  "timeframe": "1m",
  "hard_filters": [ {조건}, ... ],         # 하나라도 실패하면 신호 없음(0점)
  "bosses":   [ {조건}, ... ],             # 대장: 각 scoring.boss 점
  "soldiers": [ {조건}, ... ],             # 졸병: 각 scoring.soldier 점
  "scoring": { "boss": 10, "soldier": 5, "min_score": 65, "min_soldiers": 1 }
}
조건:
  { "id": "rsi_band", "ind": "rsi", "op": "between", "value": [30, 70] }
  { "ind": "close", "op": ">", "ref": "ma20" }                      # 다른 지표와 비교
  { "id": "sonar_golden", "op": "cross_up", "a": "sonar_k", "b": "sonar_d",
    "and": [ { "ind": "sonar_k", "op": "<", "value": 50 } ] }       # 골든크로스 + 부가조건
  op: < <= > >= == between cross_up cross_down
지표 열(IndicatorEngine.calculate_all + 확장): open high low close volume sonar_k sonar_d rsi plus_di minus_di adx
  stoch_k macd macd_sig macd_hist vol_ratio willr ma20 + ma5 ma10 ma60 ema20 bb_upper bb_lower atr
"""
import os
import json
import glob
import logging
import pandas as pd
import numpy as np

log = logging.getLogger(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STRATEGY_DIR = os.path.join(BASE_DIR, 'strategies')
SAMPLE_ID = '5대장2졸병'
OPS = {'<', '<=', '>', '>=', '==', 'between', 'cross_up', 'cross_down'}
IND_COLS = ['open', 'high', 'low', 'close', 'volume', 'sonar_k', 'sonar_d', 'rsi', 'plus_di', 'minus_di', 'adx',
            'stoch_k', 'macd', 'macd_sig', 'macd_hist', 'vol_ratio', 'willr', 'ma20', 'ma5', 'ma10', 'ma60', 'ema20',
            'bb_upper', 'bb_lower', 'atr']

_cache = {'mtime': None, 'strategies': []}


# ---------- 로드 / 검증 ----------
def validate(spec):
    """규격 검증. 문제 목록 반환(비어 있으면 OK)."""
    errs = []
    if not isinstance(spec, dict):
        return ['전략 파일이 객체(JSON object)가 아님']
    if not spec.get('id'):
        errs.append('id 없음')
    if spec.get('direction') not in ('CALL', 'PUT'):
        errs.append('direction 은 CALL 또는 PUT')
    for key in ('hard_filters', 'bosses', 'soldiers'):
        conds = spec.get(key, [])
        if not isinstance(conds, list):
            errs.append(f'{key} 는 목록이어야 함')
            continue
        for i, c in enumerate(conds):
            e = _validate_cond(c)
            if e:
                errs.append(f'{key}[{i}]: {e}')
    if not spec.get('bosses'):
        errs.append('bosses 가 비어 있음 (대장 조건 1개 이상)')
    sc = spec.get('scoring', {})
    if not isinstance(sc, dict):
        errs.append('scoring 은 객체')
    return errs


def _validate_cond(c):
    if not isinstance(c, dict):
        return '조건은 객체'
    op = c.get('op')
    if op not in OPS:
        return f'op 잘못됨: {op}'
    if op in ('cross_up', 'cross_down'):
        if c.get('a') not in IND_COLS or c.get('b') not in IND_COLS:
            return f'cross 는 a/b 지표 필요 (a={c.get("a")}, b={c.get("b")})'
    else:
        if c.get('ind') not in IND_COLS:
            return f'지표 없음: {c.get("ind")}'
        if 'ref' in c:
            if c['ref'] not in IND_COLS:
                return f'ref 지표 없음: {c["ref"]}'
        elif op == 'between':
            v = c.get('value')
            if not (isinstance(v, list) and len(v) == 2):
                return 'between 은 value=[하한, 상한]'
        elif not isinstance(c.get('value'), (int, float)):
            return 'value 숫자 필요'
    for sub in c.get('and', []) or []:
        e = _validate_cond(sub)
        if e:
            return 'and: ' + e
    return None


def load_strategies(force=False):
    """strategies/*.json 전부 로드 (파일 변경 시 자동 재로드). enabled=false 도 목록엔 포함."""
    try:
        files = sorted(glob.glob(os.path.join(STRATEGY_DIR, '*.json')))
        mtime = tuple((f, os.path.getmtime(f)) for f in files)
    except Exception:
        files, mtime = [], ()
    if not force and _cache['mtime'] == mtime:
        return _cache['strategies']
    out = []
    for f in files:
        try:
            with open(f, encoding='utf-8-sig') as fp:
                spec = json.load(fp)
            # 이 엔진은 분봉(1m) 전용 — timeframe "1d" 파일은 daily_strategy_engine 이 맡는다
            if isinstance(spec, dict) and spec.get('timeframe', '1m') != '1m':
                continue
            spec.setdefault('id', os.path.splitext(os.path.basename(f))[0])
            spec.setdefault('name', spec['id'])
            spec.setdefault('enabled', True)
            spec.setdefault('live', False)
            spec.setdefault('sample', False)
            spec.setdefault('scoring', {})
            spec['scoring'] = {'boss': 10, 'soldier': 5, 'min_score': 65, 'min_soldiers': 1, **spec['scoring']}
            spec['_file'] = f
            spec['_errors'] = validate(spec)
            out.append(spec)
        except Exception as e:
            out.append({'id': os.path.splitext(os.path.basename(f))[0], 'name': os.path.basename(f), 'enabled': False,
                        '_file': f, '_errors': [f'JSON 읽기 실패: {e}']})
    _cache['mtime'] = mtime
    _cache['strategies'] = out
    return out


def enabled_strategies():
    return [s for s in load_strategies() if s.get('enabled') and not s.get('_errors')]


def strategy_summary():
    """UI 용: id/name/direction/enabled/live/sample/errors/조건 수"""
    return [{
        'id': s['id'], 'name': s.get('name'), 'direction': s.get('direction'), 'timeframe': s.get('timeframe', '1m'),
        'enabled': bool(s.get('enabled')),
        'live': bool(s.get('live')), 'sample': bool(s.get('sample')), 'version': s.get('version'),
        'errors': s.get('_errors', []), 'min_score': s.get('scoring', {}).get('min_score'),
        'n_bosses': len(s.get('bosses', []) or []), 'n_soldiers': len(s.get('soldiers', []) or []),
        'description': s.get('description', ''),
    } for s in load_strategies()]


# ---------- 지표 확장 ----------
def extend_indicators(df):
    """IndicatorEngine.calculate_all 결과에 범용 지표 추가 (있으면 건너뜀)."""
    c = df['close']
    if 'ma5' not in df: df['ma5'] = c.rolling(5).mean()
    if 'ma10' not in df: df['ma10'] = c.rolling(10).mean()
    if 'ma60' not in df: df['ma60'] = c.rolling(60).mean()
    if 'ema20' not in df: df['ema20'] = c.ewm(span=20).mean()
    if 'bb_upper' not in df:
        m = c.rolling(20).mean(); sd = c.rolling(20).std()
        df['bb_upper'] = m + 2 * sd; df['bb_lower'] = m - 2 * sd
    if 'atr' not in df:
        h, l = df['high'], df['low']
        tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
        df['atr'] = tr.rolling(14).mean()
    return df


# ---------- 평가 ----------
def _num(row, col):
    v = row.get(col) if hasattr(row, 'get') else row[col]
    try:
        v = float(v)
    except Exception:
        return None
    return None if np.isnan(v) else v


def eval_cond(c, cur, prev):
    op = c['op']
    if op in ('cross_up', 'cross_down'):
        a0, b0, a1, b1 = _num(prev, c['a']), _num(prev, c['b']), _num(cur, c['a']), _num(cur, c['b'])
        if None in (a0, b0, a1, b1):
            return False
        ok = (a0 <= b0 and a1 > b1) if op == 'cross_up' else (a0 >= b0 and a1 < b1)
    else:
        x = _num(cur, c['ind'])
        if x is None:
            return False
        if 'ref' in c:
            y = _num(cur, c['ref'])
            if y is None:
                return False
        else:
            y = c.get('value')
        if op == '<': ok = x < y
        elif op == '<=': ok = x <= y
        elif op == '>': ok = x > y
        elif op == '>=': ok = x >= y
        elif op == '==': ok = abs(x - y) < 1e-9
        elif op == 'between': ok = y[0] <= x < y[1]
        else: ok = False
    if ok and c.get('and'):
        ok = all(eval_cond(sub, cur, prev) for sub in c['and'])
    return bool(ok)


def _cond_id(c, i, prefix):
    return c.get('id') or (c.get('ind') or c.get('a') or prefix) + ('' if not i else f'_{i}')


def evaluate(spec, df_ind):
    """지표가 계산된 df 로 전략 하나 평가. 반환: {id, name, direction, score, boss, soldier, passed, bosses, soldiers, blocked}"""
    sc = spec['scoring']
    out = {'id': spec['id'], 'name': spec.get('name'), 'direction': spec.get('direction'), 'live': bool(spec.get('live')),
           'score': 0, 'boss': 0, 'soldier': 0, 'passed': False, 'bosses': {}, 'soldiers': {}, 'blocked': None}
    if df_ind is None or len(df_ind) < 2:
        out['blocked'] = 'data'
        return out
    cur, prev = df_ind.iloc[-1], df_ind.iloc[-2]
    for i, c in enumerate(spec.get('hard_filters', []) or []):
        if not eval_cond(c, cur, prev):
            out['blocked'] = _cond_id(c, i, 'hard')
            return out
    for i, c in enumerate(spec.get('bosses', []) or []):
        out['bosses'][_cond_id(c, i, 'boss')] = eval_cond(c, cur, prev)
    for i, c in enumerate(spec.get('soldiers', []) or []):
        out['soldiers'][_cond_id(c, i, 'soldier')] = eval_cond(c, cur, prev)
    out['boss'] = sum(1 for v in out['bosses'].values() if v)
    out['soldier'] = sum(1 for v in out['soldiers'].values() if v)
    out['score'] = out['boss'] * sc['boss'] + out['soldier'] * sc['soldier']
    out['passed'] = out['score'] >= sc['min_score'] and out['soldier'] >= sc.get('min_soldiers', 0) \
        and (not out['bosses'] or all(out['bosses'].values()) or sc.get('allow_partial_bosses', False))
    return out


def evaluate_all(df_raw, engine=None):
    """OHLCV DataFrame → 활성 전략 전부 평가. 반환 list (전략 순서). 지표 계산은 1회."""
    strategies = enabled_strategies()
    if not strategies:
        return []
    if len(df_raw) < 20:
        return [dict(id=s['id'], name=s.get('name'), direction=s.get('direction'), live=bool(s.get('live')),
                     score=0, boss=0, soldier=0, passed=False, bosses={}, soldiers={}, blocked='data') for s in strategies]
    if engine is None:
        from analysis import IndicatorEngine
        engine = IndicatorEngine()
    df = engine.calculate_all(df_raw.copy())
    df = extend_indicators(df)
    return [evaluate(s, df) for s in strategies]


def compact(results):
    """스캐너 결과에 싣는 축약형: [{id, name, direction, score, passed, live}]"""
    return [{'id': r['id'], 'name': r['name'], 'direction': r['direction'], 'score': r['score'],
             'passed': bool(r['passed']), 'live': bool(r.get('live'))} for r in results]


if __name__ == '__main__':
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    for s in load_strategies(force=True):
        print(s['id'], '| enabled' if s.get('enabled') else '| disabled', '| live' if s.get('live') else '', '| 오류:' if s.get('_errors') else '| OK', s.get('_errors') or '')
