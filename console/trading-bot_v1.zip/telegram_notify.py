# -*- coding: utf-8 -*-
"""
텔레그램 승인 봇 — 매수 신호를 핸드폰으로 전송하고 승인/거절 응답 수신
"""
import os
import shutil
import threading
import time
import logging
import requests

log = logging.getLogger(__name__)


def _find_claude() -> str:
    """Windows에서 claude CLI 실행 파일 경로 탐색"""
    found = shutil.which('claude') or shutil.which('claude.cmd')
    if found:
        return found
    appdata = os.environ.get('APPDATA', '')
    for name in ('claude.cmd', 'claude'):
        p = os.path.join(appdata, 'npm', name)
        if os.path.exists(p):
            return p
    return 'claude'

_CLAUDE_BIN = _find_claude()

# config에서 로드 (없으면 환경변수 직접)
try:
    from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
except ImportError:
    TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '')
    TELEGRAM_CHAT_ID = os.getenv('TELEGRAM_CHAT_ID', '')


_OVERRIDES: dict = {}  # 텔레그램 실시간 지시 — trader.py가 읽는 공유 상태


def get_override(key, default=None):
    """trader.py에서 실시간 텔레그램 지시 조회"""
    return _OVERRIDES.get(key, default)


def _current_rate(code):
    """현물 기준 전일대비 등락률(%) 조회. 실패 시 None.
    선물 단축코드(A로 시작)가 들어오면 현물로 역매핑해서 조회."""
    try:
        from kis import get_stock_price
        c = code
        if isinstance(c, str) and c.startswith('A'):
            from futures_map import get_stock_code
            c = get_stock_code(code) or code
        info = get_stock_price(c)
        return info.get('change_pct') if info else None
    except Exception:
        return None


def _rate_str(pct):
    """등락률 → '▲ 상승 +1.23%' / '▼ 하락 -0.80%' / '― 보합 0.00%'."""
    if pct is None:
        return '조회불가'
    if pct > 0:
        return f'▲ 상승 +{pct:.2f}%'
    if pct < 0:
        return f'▼ 하락 {pct:.2f}%'
    return '― 보합 0.00%'


class TelegramApprovalBot:
    """텔레그램 인라인 버튼 승인/거절 봇"""

    def __init__(self):
        self.token = TELEGRAM_BOT_TOKEN
        self.chat_id = str(TELEGRAM_CHAT_ID)
        self.enabled = bool(self.token and self.chat_id and
                            self.token != 'YOUR_TOKEN' and self.chat_id != 'YOUR_CHAT_ID')
        self._pending = {}   # key -> {"event": Event, "result": None}
        self._offset = 0
        self._lock = threading.Lock()

        if self.enabled:
            self._register_commands()
            self._start_polling()
            log.info('[Telegram] 봇 활성화 — 폴링 시작')
        else:
            log.warning('[Telegram] 미설정 (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID 확인)')

    # ── 내부 API 호출 ──────────────────────────────

    def _api(self, method, retries=3, **kwargs):
        # 2026-09-21 실거래 교훈: 09:16 일시 네트워크 장애로 승인 요청 1건이 전송 실패 → 짧은 재시도(3회, 5/10초 간격)
        url = f'https://api.telegram.org/bot{self.token}/{method}'
        last = None
        for i in range(max(1, retries)):
            try:
                r = requests.post(url, json=kwargs, timeout=15)
                if r.ok:
                    return r.json()
                last = f'HTTP {r.status_code}'
                if 400 <= r.status_code < 500 and r.status_code != 429:
                    break  # 잘못된 요청은 재시도 무의미
            except Exception as e:
                last = e
            if i < retries - 1:
                time.sleep(5 * (i + 1))
        log.debug(f'[Telegram] API 오류({method}): {last}')
        return None

    # ── 메뉴 등록 ─────────────────────────────────

    def _register_commands(self):
        """BotFather에 슬래시 명령 등록 + 시작 메시지에 하단 키보드"""
        commands = [
            {'command': 'start',    'description': '봇 시작 및 메뉴 표시'},
            {'command': 'balance',  'description': '잔고 조회'},
            {'command': 'position', 'description': '보유 포지션 현황'},
            {'command': 'scan',     'description': 'CALL 신호 조회'},
            {'command': 'status',   'description': '봇 상태 확인'},
            {'command': 'strategy', 'description': '오늘 전략 확인'},
            {'command': 'pause',    'description': '자동매매 일시 정지'},
            {'command': 'resume',   'description': '자동매매 재개'},
        ]
        self._api('setMyCommands', commands=commands)

    def _send_menu(self, intro=''):
        """하단 고정 버튼판과 함께 메뉴 전송"""
        keyboard = {
            'keyboard': [
                [{'text': '💰 잔고'}, {'text': '📊 포지션'}],
                [{'text': '🔍 스캔'}, {'text': '⚙️ 상태'}],
                [{'text': '📋 전략'}, {'text': '⏸ 정지'}, {'text': '▶ 재개'}],
            ],
            'resize_keyboard': True,
            'persistent': True,
        }
        text = intro or '메뉴를 선택하세요.\n\n작전 지시:\n  min_score 70\n  방향 CALL / PUT / 중립\n  강도 공격적 / 보수적 / 일반'
        self._api('sendMessage', chat_id=self.chat_id,
                  text=text, reply_markup=keyboard)

    # ── 공개 인터페이스 ────────────────────────────

    def send_message(self, text, parse_mode='HTML'):
        """단순 알림 전송 (버튼 없음)"""
        if not self.enabled:
            log.info(f'[Telegram 미활성] {text[:80]}')
            return None
        return self._api('sendMessage', chat_id=self.chat_id,
                         text=text, parse_mode=parse_mode)

    def send_photo(self, image_path: str, caption: str = ''):
        """이미지 파일 전송"""
        if not self.enabled or not image_path:
            return None
        url = f'https://api.telegram.org/bot{self.token}/sendPhoto'
        try:
            with open(image_path, 'rb') as f:
                r = requests.post(url, data={'chat_id': self.chat_id,
                                             'caption': caption,
                                             'parse_mode': 'HTML'},
                                  files={'photo': f}, timeout=30)
            return r.json() if r.ok else None
        except Exception as e:
            log.warning(f'[Telegram] 이미지 전송 오류: {e}')
            return None

    def request_approval(self, name, code, side, score, price, qty=2, timeout=180):
        """
        승인 요청 전송 + 응답 대기 (최대 timeout초)
        Returns: True(승인) / False(거절 or 타임아웃)
        """
        if not self.enabled:
            log.warning('[Telegram] 미설정 — 승인 불가, 주문 건너뜀')
            return False

        margin = price * 10 * qty * 0.15
        key = f'{code}_{int(time.time())}'
        side_kr = 'CALL(매수)' if side == 'CALL' else 'PUT(매도)'
        rate = _current_rate(code)

        text = (
            f'<b>매수 승인 요청</b>\n\n'
            f'종목: {name} ({code})\n'
            f'방향: {side_kr}\n'
            f'점수: {score}점\n'
            f'현재가: {price:,}원\n'
            f'등락률: {_rate_str(rate)}\n'
            f'수량: {qty}계약\n'
            f'증거금: {margin:,.0f}원\n\n'
            f'<i>{timeout}초 내 응답 없으면 자동 취소</i>'
        )
        keyboard = {'inline_keyboard': [[
            {'text': '✅ 승인', 'callback_data': f'approve:{key}'},
            {'text': '❌ 거절', 'callback_data': f'reject:{key}'},
        ]]}

        # 차트 이미지 먼저 전송
        try:
            import importlib, chart_gen as _cg
            importlib.reload(_cg)
            img_path = _cg.generate_chart(code, name, score, side)
            if img_path:
                self.send_photo(img_path,
                    caption=f'<b>{name} ({code})</b>  |  {side} {score}점\n일봉(60개) + 3분봉(60개)')
                import os as _os
                try:
                    _os.remove(img_path)
                except Exception:
                    pass
        except Exception as e:
            log.debug(f'[Telegram] 차트 전송 스킵: {e}')

        event = threading.Event()
        with self._lock:
            self._pending[key] = {'event': event, 'result': None}

        resp = self._api('sendMessage', chat_id=self.chat_id,
                         text=text, parse_mode='HTML', reply_markup=keyboard)
        if not resp or not resp.get('ok'):
            log.warning('[Telegram] 승인 요청 전송 실패')
            with self._lock:
                self._pending.pop(key, None)
            return False

        msg_id = resp['result']['message_id']
        log.info(f'[Telegram] 승인 요청 전송: {name} (대기 {timeout}초)')

        # 응답 대기
        event.wait(timeout=timeout)

        with self._lock:
            result = self._pending.pop(key, {}).get('result')

        # 버튼 비활성화 (응답 후 버튼 제거)
        self._api('editMessageReplyMarkup',
                  chat_id=self.chat_id,
                  message_id=msg_id,
                  reply_markup={'inline_keyboard': []})

        if result is None:
            log.info(f'[Telegram] 타임아웃 — {name} 주문 취소')
            self.send_message(f'⏰ 승인 시간 초과 — {name} 주문 취소')
            return False

        approved = (result == 'approve')
        label = '✅ 승인' if approved else '❌ 거절'
        log.info(f'[Telegram] {label}: {name}')
        if approved:
            self.send_message(f'✅ <b>승인되었습니다</b> — {name} 매수를 진행합니다.')
        else:
            self.send_message(f'❌ <b>거절되었습니다</b> — {name} 주문을 취소합니다.')
        return approved

    def request_exit_approval(self, name, code, side, qty, price, pnl_pct, reason, timeout=120):
        """청산(매도) 승인 요청 + 응답 대기. Returns: 'approve' / 'reject' / None(타임아웃)"""
        if not self.enabled:
            log.warning('[Telegram] 미설정 — 청산 승인 불가')
            return None
        key = f'exit_{code}_{int(time.time())}'
        side_kr = 'CALL(매수 포지션 → 매도)' if side == 'CALL' else 'PUT(매도 포지션 → 매수)'
        text = (
            f'<b>청산(매도) 승인 요청</b>\n\n'
            f'종목: {name} ({code})\n'
            f'포지션: {side_kr}\n'
            f'수량: {qty}계약\n'
            f'현재가: {price:,.0f}원\n'
            f'손익: {pnl_pct:+.2f}%\n'
            f'사유: {reason}\n\n'
            f'<i>{timeout}초 내 응답 없으면 {"손절은 자동 청산, " if "손절" in str(reason) else ""}보류 후 다시 묻습니다</i>'
        )
        keyboard = {'inline_keyboard': [[
            {'text': '✅ 청산 승인', 'callback_data': f'approve:{key}'},
            {'text': '❌ 보류', 'callback_data': f'reject:{key}'},
        ]]}
        event = threading.Event()
        with self._lock:
            self._pending[key] = {'event': event, 'result': None}
        resp = self._api('sendMessage', chat_id=self.chat_id, text=text, parse_mode='HTML', reply_markup=keyboard)
        if not resp or not resp.get('ok'):
            log.warning('[Telegram] 청산 승인 요청 전송 실패')
            with self._lock:
                self._pending.pop(key, None)
            return None
        msg_id = resp['result']['message_id']
        log.info(f'[Telegram] 청산 승인 요청 전송: {name} ({reason}) 대기 {timeout}초')
        event.wait(timeout=timeout)
        with self._lock:
            result = self._pending.pop(key, {}).get('result')
        self._api('editMessageReplyMarkup', chat_id=self.chat_id, message_id=msg_id, reply_markup={'inline_keyboard': []})
        if result is None:
            log.info(f'[Telegram] 청산 승인 타임아웃: {name}')
            return None
        log.info(f'[Telegram] 청산 {"✅ 승인" if result == "approve" else "❌ 보류"}: {name}')
        return result

    def notify_buy(self, name, code, side, price, qty,
                   score=0, grade='', reason='',
                   stop_pct=3.0, take_pct=5.0):
        """매수 체결 알림"""
        if not self.enabled:
            return
        side_kr  = 'CALL(매수)' if side == 'CALL' else 'PUT(매도)'
        margin   = price * 10 * qty * 0.15
        stop_prc = price * (1 - stop_pct / 100) if side == 'CALL' else price * (1 + stop_pct / 100)
        take_prc = price * (1 + take_pct / 100) if side == 'CALL' else price * (1 - take_pct / 100)
        rate = _current_rate(code)
        # 신호 내역(점수/대장·졸병)은 승인 요청 메시지에만 — 체결 알림엔 실행 결과만
        text = (
            f'🚀 <b>매수 완료</b> — 매수가 되었습니다\n\n'
            f'종목: <b>{name}</b> ({code})\n'
            f'방향: {side_kr}\n'
            f'체결가: {price:,}원\n'
            f'등락률: {_rate_str(rate)}\n'
            f'수량: {qty}계약\n'
            f'증거금: {margin:,.0f}원\n'
            f'손절: {stop_prc:,.0f}원 (-{stop_pct}%)\n'
            f'익절: {take_prc:,.0f}원 (+{take_pct}%)'
        )
        self.send_message(text)

    def notify_sell(self, name, code, side, entry_price, exit_price,
                    qty, pnl_krw, pnl_pct, reason=''):
        """청산 알림"""
        if not self.enabled:
            return
        emoji    = '✅' if pnl_krw >= 0 else '🔴'
        side_kr  = 'CALL' if side == 'CALL' else 'PUT'
        rate = _current_rate(code)
        text = (
            f'{emoji} <b>매도 완료</b> — 매도가 되었습니다\n\n'
            f'종목: <b>{name}</b> ({code})\n'
            f'방향: {side_kr}\n'
            f'진입가: {entry_price:,}원\n'
            f'청산가: {exit_price:,}원\n'
            f'등락률: {_rate_str(rate)}\n'
            f'수량: {qty}계약\n'
            f'손익: <b>{pnl_krw:+,}원</b> ({pnl_pct:+.2f}%)\n'
            f'사유: {reason}'
        )
        self.send_message(text)

    def notify_order(self, name, code, side, price, qty, pnl=None, reason=''):
        """기존 호환용 (내부에서 notify_buy/notify_sell로 위임)"""
        if not self.enabled:
            return
        if pnl is not None:
            pnl_pct = (price / (price - pnl / (10 * qty)) - 1) * 100 if price else 0
            self.notify_sell(name, code, side, 0, price, qty, pnl, pnl_pct, reason)
        else:
            self.notify_buy(name, code, side, price, qty, reason=reason)

    def notify_position_status(self, positions_info):
        """포지션 현황 알림"""
        if not self.enabled or not positions_info:
            return
        lines = ['<b>현재 포지션 현황</b>\n']
        total_pnl = 0
        for p in positions_info:
            pnl = p.get('pnl', 0)
            total_pnl += pnl
            pct = p.get('pct', 0)
            emoji = '📈' if pnl >= 0 else '📉'
            lines.append(
                f"{emoji} {p['name']} {p['side']} x{p['qty']}\n"
                f"   진입 {p['entry']:,} → 현재 {p['current']:,} ({pct:+.2f}%)\n"
                f"   손익: {pnl:+,}원"
            )
        lines.append(f'\n합산 손익: {total_pnl:+,}원')
        self.send_message('\n'.join(lines))

    # ── 백그라운드 폴링 ────────────────────────────

    def _poll_loop(self):
        """callback_query 실시간 수신 (롱폴링)"""
        while True:
            try:
                data = self._api('getUpdates', offset=self._offset, timeout=25)
                if not data or not data.get('ok'):
                    time.sleep(3)
                    continue

                for update in data.get('result', []):
                    self._offset = update['update_id'] + 1

                    # 일반 텍스트 메시지 응답
                    msg = update.get('message')
                    if msg:
                        text = msg.get('text', '').strip()
                        chat_id = msg.get('chat', {}).get('id')
                        if chat_id and text:
                            self._handle_message(text)

                    # 버튼 콜백 처리
                    cb = update.get('callback_query')
                    if not cb:
                        continue

                    self._api('answerCallbackQuery',
                              callback_query_id=cb['id'],
                              text='응답 처리 중...')

                    data_str = cb.get('data', '')
                    if ':' not in data_str:
                        continue

                    action, key = data_str.split(':', 1)
                    with self._lock:
                        if key in self._pending:
                            self._pending[key]['result'] = action
                            self._pending[key]['event'].set()

            except Exception as e:
                log.debug(f'[Telegram] 폴링 오류: {e}')
                time.sleep(5)

    def _handle_message(self, text):
        """일반 텍스트 명령 처리"""
        # 이모지 포함 버튼 텍스트 정규화
        import unicodedata
        t = ''.join(c for c in text.strip().lower()
                    if unicodedata.category(c) not in ('So', 'Sk'))
        t = t.strip()

        if any(w in t for w in ['안녕', 'hello', 'hi', '/start']):
            self._send_menu('안녕하세요! 트레이더 봇입니다.\n아래 버튼을 눌러 명령하세요.')

        elif any(w in t for w in ['잔고', '예수금', '돈', '/balance', 'balance']):
            try:
                from kis import get_futures_balance
                bal = get_futures_balance()
                avail = bal.get('ord_psbl_cash', 0)
                eval_pnl = bal.get('eval_pnl', 0)
                trade_pnl = bal.get('trade_pnl', 0)
                self.send_message(
                    f'계좌 잔고\n\n'
                    f'주문가능: {avail:,}원\n'
                    f'평가손익: {eval_pnl:+,}원\n'
                    f'실현손익: {trade_pnl:+,}원'
                )
            except Exception as e:
                self.send_message(f'잔고 조회 실패: {e}')

        elif any(w in t for w in ['포지션', '보유', '현황', '/position', 'position']):
            try:
                from kis import get_futures_balance
                from scanner_262_52 import get_stock_info_naver
                bal = get_futures_balance()
                positions = bal.get('positions', [])
                if not positions:
                    self.send_message('현재 보유 포지션 없음')
                    return
                lines = [f'보유 포지션 {len(positions)}개\n']
                total_pnl = 0
                for p in positions:
                    name = p.get('name', '')
                    code = p.get('code', '')
                    qty = p.get('qty', 0)
                    avg = p.get('avg_price', 0)
                    try:
                        from futures_map import get_stock_code
                        sc = get_stock_code(code)
                        if sc:
                            _, cur, rate = get_stock_info_naver(sc)
                        else:
                            cur = p.get('current', avg)
                            rate = 0
                    except Exception:
                        cur = p.get('current', avg)
                        rate = 0
                    pct = (cur - avg) / avg * 100 if avg else 0
                    pnl = (cur - avg) * 10 * qty
                    total_pnl += pnl
                    emoji = '📈' if pnl >= 0 else '📉'
                    lines.append(f'{emoji} {name} x{qty}\n   {avg:,.0f}→{cur:,} ({pct:+.1f}%) {pnl:+,}원')
                lines.append(f'\n합산: {total_pnl:+,}원')
                self.send_message('\n'.join(lines))
            except Exception as e:
                self.send_message(f'포지션 조회 실패: {e}')

        elif any(w in t for w in ['스캔', '신호', '종목', '/scan', 'scan']):
            try:
                import requests as _req
                r = _req.get('http://localhost:5050/api/status', timeout=5)
                results = r.json().get('results', [])
                calls = [x for x in results if x.get('call_score', 0) >= 55 and x.get('has_futures')]
                calls.sort(key=lambda x: -x.get('call_score', 0))
                if not calls:
                    self.send_message('현재 CALL 55점+ 신호 없음')
                    return
                lines = [f'CALL 신호 {len(calls)}개\n']
                for s in calls[:8]:
                    name = s.get('name', s.get('code'))
                    score = s.get('call_score', 0)
                    rate = s.get('rate', 0)
                    price = s.get('price', 0)
                    lines.append(f'{name} {score}점 | {rate:+.1f}% | {price:,}원')
                self.send_message('\n'.join(lines))
            except Exception as e:
                self.send_message(f'스캔 조회 실패: {e}')

        elif any(w in t for w in ['상태', 'status', '/status']):
            import datetime
            now = datetime.datetime.now().strftime('%H:%M:%S')
            self.send_message(
                f'트레이더 봇 정상 동작 중\n'
                f'현재 시각: {now}\n'
                f'승인 모드: ON (매수 전 승인 필요)'
            )

        # ── 전략 조회 ──────────────────────────────────
        elif any(w in t for w in ['전략', 'strategy', '/strategy']):
            self._handle_strategy_show()

        # ── 매매 일시 정지 ──────────────────────────────
        elif any(w in t for w in ['정지', '멈춰', '멈춤', 'pause', '/pause', '⏸']):
            _OVERRIDES['paused'] = True
            log.info('[Telegram] 자동매매 일시 정지 명령')
            self.send_message('⏸ 자동매매 일시 정지\n재개하려면 "재개" 또는 /resume')

        # ── 매매 재개 ───────────────────────────────────
        elif any(w in t for w in ['재개', 'resume', '/resume', '▶']):
            _OVERRIDES.pop('paused', None)
            log.info('[Telegram] 자동매매 재개 명령')
            self.send_message('▶ 자동매매 재개')

        # ── min_score 설정 ──────────────────────────────
        elif 'min_score' in t or 'minscore' in t or '최소점수' in t:
            import re
            nums = re.findall(r'\d+', text)
            if nums:
                val = max(50, min(90, int(nums[0])))
                _OVERRIDES['min_score'] = val
                log.info(f'[Telegram] min_score → {val}')
                self.send_message(f'최소점수 → {val}점 적용 (이번 장 한정)')
            else:
                from config import SENTRY_MIN_SCORE
                cur = _OVERRIDES.get('min_score', SENTRY_MIN_SCORE)
                self.send_message(f'현재 최소점수: {cur}점\n변경: min_score 70')

        # ── 방향 편향 설정 ─────────────────────────────
        elif any(w in t for w in ['방향', 'bias', 'direction']):
            if any(w in t for w in ['call', 'c', '매수', '콜']):
                _OVERRIDES['direction_bias'] = 'CALL'
                self.send_message('방향 편향 → CALL (CALL 신호 우선)')
            elif any(w in t for w in ['put', 'p', '매도', '풋']):
                _OVERRIDES['direction_bias'] = 'PUT'
                self.send_message('방향 편향 → PUT (PUT 신호 우선)')
            else:
                _OVERRIDES.pop('direction_bias', None)
                self.send_message('방향 편향 → 중립 (양방향)')

        # ── 매매 강도 설정 ─────────────────────────────
        elif any(w in t for w in ['강도', 'aggr', '공격', '보수', '일반']):
            if any(w in t for w in ['공격', 'aggress', 'aggressive']):
                _OVERRIDES['aggression'] = 'AGGRESSIVE'
                self.send_message('매매 강도 → 공격적 (max_positions +1 효과)')
            elif any(w in t for w in ['보수', 'conserv', 'conservative']):
                _OVERRIDES['aggression'] = 'CONSERVATIVE'
                self.send_message('매매 강도 → 보수적 (min_score +5 효과)')
            else:
                _OVERRIDES.pop('aggression', None)
                self.send_message('매매 강도 → 일반')

        # ── 설정 초기화 ────────────────────────────────
        elif any(w in t for w in ['초기화', 'reset', '리셋']):
            _OVERRIDES.clear()
            log.info('[Telegram] 설정 초기화')
            self.send_message('설정 초기화 — daily_strategy.json 기본값으로 복귀')

        else:
            # 자연어 → Claude CLI로 해석 시도
            self._handle_natural_language(text)

    def _handle_strategy_show(self):
        """오늘 전략 파일 읽어 요약 전송"""
        try:
            from pathlib import Path
            import json as _json
            path = Path(__file__).parent / 'data' / 'daily_strategy.json'
            if not path.exists():
                self.send_message('전략 파일 없음 (daily_strategy.py를 먼저 실행하세요)')
                return
            s = _json.loads(path.read_text(encoding='utf-8'))
            overrides = []
            if _OVERRIDES:
                for k, v in _OVERRIDES.items():
                    overrides.append(f'  [{k}: {v}]')
            lines = [
                f'오늘 전략 ({s.get("date")} {s.get("weekday")})',
                '',
                s.get('today_briefing', ''),
                '',
                f'설정  min_score={s.get("min_score")}  max_pos={s.get("max_positions")}',
                f'      sl={s.get("stop_loss_pct")}%  tp={s.get("take_profit_pct")}%',
                f'방향  {s.get("direction_bias")} ({s.get("direction_bias_reason","")})',
                f'강도  {s.get("aggression")} ({s.get("aggression_reason","")})',
                f'확신도 {s.get("confidence")}%',
            ]
            if overrides:
                lines += ['', '실시간 override:'] + overrides
            self.send_message('\n'.join(lines))
        except Exception as e:
            self.send_message(f'전략 조회 실패: {e}')

    def _handle_natural_language(self, text: str):
        """Anthropic API (haiku)로 자연어 명령 해석
        — claude CLI는 agent 모드라 단순 분류에 부적합, API haiku 사용 (비용 < $0.001/회)
        """
        import json as _json

        override_summary = _json.dumps(_OVERRIDES, ensure_ascii=False) if _OVERRIDES else '없음'

        user_msg = f"""사용자 메시지: "{text}"
현재 override: {override_summary}

가능한 command:
pause / resume / reset /
set_min_score(50~90) / set_direction(CALL|PUT|NEUTRAL) / set_aggression(AGGRESSIVE|CONSERVATIVE|NORMAL) /
show_strategy / show_balance / show_position / show_scan / none

JSON으로만 응답:
{{"command":"...", "value":"... or null", "reply":"확인 메시지 1줄(한국어)"}}"""

        try:
            from config import ANTHROPIC_API_KEY
            if not ANTHROPIC_API_KEY:
                raise RuntimeError('자연어 해석은 .env 의 ANTHROPIC_API_KEY 가 있어야 합니다(선택 기능)')
            import anthropic
            client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
            resp = client.messages.create(
                model='claude-haiku-4-5-20251001',
                max_tokens=200,
                system='당신은 한국 주식 자동매매 봇 텔레그램 명령 해석기. 반드시 JSON만 출력.',
                messages=[{'role': 'user', 'content': user_msg}]
            )
            raw = resp.content[0].text.strip()

            start = raw.find('{')
            end = raw.rfind('}') + 1
            if start < 0 or end <= start:
                raise ValueError('JSON 없음')
            parsed = _json.loads(raw[start:end])

            cmd = parsed.get('command', 'none')
            val = parsed.get('value')
            reply = parsed.get('reply', '')

            # 명령 실행
            if cmd == 'pause':
                _OVERRIDES['paused'] = True
                self.send_message(f'⏸ {reply}')
            elif cmd == 'resume':
                _OVERRIDES.pop('paused', None)
                self.send_message(f'▶ {reply}')
            elif cmd == 'reset':
                _OVERRIDES.clear()
                self.send_message(f'🔄 {reply}')
            elif cmd == 'set_min_score' and val:
                score = max(50, min(90, int(str(val).strip())))
                _OVERRIDES['min_score'] = score
                self.send_message(f'🎯 {reply} (min_score={score})')
            elif cmd == 'set_direction' and val:
                direction = str(val).upper()
                if direction in ('CALL', 'PUT', 'NEUTRAL'):
                    if direction == 'NEUTRAL':
                        _OVERRIDES.pop('direction_bias', None)
                    else:
                        _OVERRIDES['direction_bias'] = direction
                    self.send_message(f'🧭 {reply}')
            elif cmd == 'set_aggression' and val:
                aggr = str(val).upper()
                if aggr in ('AGGRESSIVE', 'CONSERVATIVE', 'NORMAL'):
                    if aggr == 'NORMAL':
                        _OVERRIDES.pop('aggression', None)
                    else:
                        _OVERRIDES['aggression'] = aggr
                    self.send_message(f'⚡ {reply}')
            elif cmd == 'show_strategy':
                self._handle_strategy_show()
            elif cmd == 'show_balance':
                self._handle_message('잔고')
            elif cmd == 'show_position':
                self._handle_message('포지션')
            elif cmd == 'show_scan':
                self._handle_message('스캔')
            else:
                self.send_message(
                    f'"{text[:30]}" — 해석 불가\n\n'
                    '예시: "오늘 조심해" / "잠깐 쉬어" / "점수 올려" / "풋 위주로"'
                )

            log.info(f'[Telegram NL] "{text[:40]}" → {cmd}({val})')

        except Exception as e:
            log.warning(f'[Telegram NL] 자연어 해석 실패: {e}')
            self.send_message(
                f'해석 실패: {str(e)[:80]}\n\n'
                '직접 명령: 정지 / 재개 / min_score 70 / 방향 CALL / 강도 공격적'
            )

    def _start_polling(self):
        t = threading.Thread(target=self._poll_loop, daemon=True, name='TelegramPoller')
        t.start()


# ── 싱글톤 ────────────────────────────────────────

_bot: TelegramApprovalBot | None = None


def get_bot() -> TelegramApprovalBot:
    global _bot
    if _bot is None:
        _bot = TelegramApprovalBot()
    return _bot


# ── 편의 함수 ─────────────────────────────────────

def request_approval(name, code, side, score, price, qty=2, timeout=180):
    return get_bot().request_approval(name, code, side, score, price, qty, timeout)


def request_day_start(summary_text, timeout=600):
    """장 시작 전 '오늘 매매 시작' 승인. Returns 'approve' / 'reject' / None"""
    b = get_bot()
    if not b.enabled:
        return None
    key = f'day_{int(time.time())}'
    text = ('<b>오늘 자동매매 시작 승인</b>\n\n' + summary_text + f'\n\n<i>{timeout}초 내 응답 없으면 진입 없이 대기하고 다시 묻습니다</i>')
    keyboard = {'inline_keyboard': [[
        {'text': '✅ 오늘 매매 시작', 'callback_data': f'approve:{key}'},
        {'text': '⛔ 오늘은 쉼', 'callback_data': f'reject:{key}'},
    ]]}
    event = threading.Event()
    with b._lock:
        b._pending[key] = {'event': event, 'result': None}
    resp = b._api('sendMessage', chat_id=b.chat_id, text=text, parse_mode='HTML', reply_markup=keyboard)
    if not resp or not resp.get('ok'):
        with b._lock:
            b._pending.pop(key, None)
        return None
    msg_id = resp['result']['message_id']
    event.wait(timeout=timeout)
    with b._lock:
        result = b._pending.pop(key, {}).get('result')
    b._api('editMessageReplyMarkup', chat_id=b.chat_id, message_id=msg_id, reply_markup={'inline_keyboard': []})
    if result == 'approve':
        b.send_message('✅ 오늘 매매를 시작합니다. 매수·매도는 각각 승인 요청이 갑니다.')
    elif result == 'reject':
        b.send_message('⛔ 오늘은 신규 진입 없이 보유 포지션만 지켜봅니다.')
    return result


def request_exit_approval(name, code, side, qty, price, pnl_pct, reason, timeout=120):
    return get_bot().request_exit_approval(name, code, side, qty, price, pnl_pct, reason, timeout)


def notify(text):
    return get_bot().send_message(text)


def notify_order(name, code, side, price, qty, pnl=None, reason=''):
    return get_bot().notify_order(name, code, side, price, qty, pnl, reason)


def notify_buy(name, code, side, price, qty,
               score=0, grade='', reason='', stop_pct=3.0, take_pct=5.0):
    return get_bot().notify_buy(name, code, side, price, qty,
                                score, grade, reason, stop_pct, take_pct)


def notify_sell(name, code, side, entry_price, exit_price,
                qty, pnl_krw, pnl_pct, reason=''):
    return get_bot().notify_sell(name, code, side, entry_price, exit_price,
                                 qty, pnl_krw, pnl_pct, reason)


# ── 설정 테스트 ───────────────────────────────────

if __name__ == '__main__':
    import sys, io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    bot = get_bot()
    if not bot.enabled:
        print('.env에 TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID 설정 필요')
        print('1. https://t.me/BotFather 에서 /newbot')
        print('2. https://t.me/userinfobot 에서 chat_id 확인')
    else:
        print('연결 테스트 중...')
        bot.send_message('텔레그램 봇 연결 테스트 성공! 트레이더 봇과 연결됐습니다.')
        print('메시지 전송 완료. 핸드폰을 확인하세요.')
