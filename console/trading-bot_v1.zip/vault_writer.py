# -*- coding: utf-8 -*-
"""
vault_writer.py — Supabase 대신 Obsidian vault에 직접 기록
research_db.py를 대체. cpc_commands만 Supabase 유지.

저장 위치:
  신호       → wiki/신호/거래기록/YYYY-MM-DD_signals.md
  성과요약   → wiki/알고리즘/성과분석/YYYY-MM.md
  시장분류   → wiki/알고리즘/시장분류/YYYY-MM-DD.md (월별 집계)
  거래피드   → wiki/신호/거래기록/YYYY-MM-DD.md
"""
import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

log = logging.getLogger(__name__)

VAULT = Path(__file__).resolve().parent / 'wiki'   # 봇 자동기록(신호·성과) 노트 폴더 — 프로젝트 안에 생성
_KST  = timezone(timedelta(hours=9))


def _kst_now():
    return datetime.now(_KST)


def _read_md_table(path: Path) -> list[dict]:
    """마크다운 테이블 행 파싱 (| col | col | 형태)"""
    rows = []
    if not path.exists():
        return rows
    in_table = False
    for line in path.read_text(encoding='utf-8').splitlines():
        line = line.strip()
        if line.startswith('|') and not line.startswith('|---'):
            cols = [c.strip() for c in line.strip('|').split('|')]
            if in_table:
                rows.append(cols)
            else:
                in_table = True  # 헤더 행 건너뜀
    return rows


def _ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


# ═══════════════════════════════════════════
#  신호 기록
# ═══════════════════════════════════════════

def record_signal(algo_id, ticker, ticker_name, signal_type, score,
                  boss_count, soldier_count, indicator_values, price_at_signal):
    """신호를 vault 신호/거래기록/YYYY-MM-DD_signals.md 에 한 행 추가"""
    kst = _kst_now()
    date = kst.strftime('%Y-%m-%d')
    time_str = kst.strftime('%H:%M:%S')

    out_dir = VAULT / '신호' / '거래기록'
    _ensure_dir(out_dir)
    path = out_dir / f'{date}_signals.md'

    # 파일 없으면 헤더 생성
    if not path.exists():
        header = (
            f'---\n'
            f'title: "{date} 신호"\n'
            f'date: {date}\n'
            f'kind: "백테스트 결과"\n'
            f'status: active\n'
            f'tags:\n'
            f'  - kind/신호기록\n'
            f'  - time/{date[:7]}\n'
            f'---\n\n'
            f'| 종목 | 방향 | 점수 | 시간 | RSI | ADX | vol_ratio |\n'
            f'|---|---|---|---|---|---|---|\n'
        )
        path.write_text(header, encoding='utf-8')

    # 지표 값 추출
    iv = indicator_values or {}
    rsi = iv.get('rsi', 0)
    adx = iv.get('adx', 0)
    vol = iv.get('vol_ratio', 0)

    row = (
        f'| {ticker_name}({ticker}) | {signal_type} | {score}점 '
        f'| {time_str} | {rsi:.1f} | {adx:.1f} | {vol:.2f}x |\n'
    )

    with open(path, 'a', encoding='utf-8') as f:
        f.write(row)

    log.info(f'[VaultWriter] 신호 기록: {ticker_name} {signal_type} {score}점')
    return f'{date}_{ticker}_{time_str}'  # 로컬 signal_id


def fill_outcome(signal_id, offset_label, price):
    """결과 추적은 vault에선 별도 구현 안 함 (백테스트로 대체)"""
    pass


# ═══════════════════════════════════════════
#  시장 분류
# ═══════════════════════════════════════════

def classify_regime(date_str, kospi_change_pct, kospi_open=None, kospi_close=None):
    """시장 분류 → wiki/알고리즘/시장분류/YYYY-MM.md 에 행 추가"""
    if kospi_change_pct > 0.3:
        regime = 'A(상승)'
    elif kospi_change_pct < -0.3:
        regime = 'B(하락)'
    else:
        regime = 'C(횡보)'

    ym = date_str[:7]
    out_dir = VAULT / '알고리즘' / '시장분류'
    _ensure_dir(out_dir)
    path = out_dir / f'{ym}.md'

    if not path.exists():
        header = (
            f'---\ntitle: "{ym} 시장 분류"\ndate: {ym}-01\n'
            f'kind: "매크로 분석"\nstatus: active\n'
            f'tags: [kind/시장분류, time/{ym}]\n---\n\n'
            f'| 날짜 | 분류 | 코스피등락 | 시가 | 종가 |\n'
            f'|---|---|---|---|---|\n'
        )
        path.write_text(header, encoding='utf-8')

    row = (
        f'| {date_str} | {regime} | {kospi_change_pct:+.2f}% '
        f'| {kospi_open or "-"} | {kospi_close or "-"} |\n'
    )
    with open(path, 'a', encoding='utf-8') as f:
        f.write(row)

    log.info(f'[VaultWriter] 시장분류: {date_str} = {regime}')
    return regime


def get_regime(date_str):
    """특정 날짜 시장 분류 조회 (로컬 파일에서)"""
    ym = date_str[:7]
    path = VAULT / '알고리즘' / '시장분류' / f'{ym}.md'
    if not path.exists():
        return None
    for line in path.read_text(encoding='utf-8').splitlines():
        if line.startswith(f'| {date_str}'):
            parts = [c.strip() for c in line.strip('|').split('|')]
            if len(parts) >= 2:
                return parts[1]
    return None


# ═══════════════════════════════════════════
#  일일 요약
# ═══════════════════════════════════════════

def compute_daily_summary(date_str):
    """당일 신호 파일에서 집계 → 알고리즘/성과분석/YYYY-MM.md 갱신"""
    sig_path = VAULT / '신호' / '거래기록' / f'{date_str}_signals.md'
    if not sig_path.exists():
        log.info(f'[VaultWriter] {date_str} 신호 파일 없음 — 요약 생략')
        return

    total = call_n = put_n = 0
    for line in sig_path.read_text(encoding='utf-8').splitlines():
        if line.startswith('|') and not line.startswith('|---') and '방향' not in line:
            total += 1
            if 'CALL' in line:
                call_n += 1
            elif 'PUT' in line:
                put_n += 1

    ym = date_str[:7]
    out_dir = VAULT / '알고리즘' / '성과분석'
    _ensure_dir(out_dir)
    path = out_dir / f'{ym}.md'

    if not path.exists():
        header = (
            f'---\ntitle: "{ym} 성과 분석"\ndate: {ym}-01\n'
            f'kind: "백테스트 결과"\nstatus: active\n'
            f'tags: [kind/성과분석, time/{ym}]\n---\n\n'
            f'| 날짜 | 신호수 | CALL | PUT |\n'
            f'|---|---|---|---|\n'
        )
        path.write_text(header, encoding='utf-8')

    # 이미 해당 날짜 행 있으면 업데이트, 없으면 추가
    content = path.read_text(encoding='utf-8')
    new_row = f'| {date_str} | {total} | {call_n} | {put_n} |\n'
    if date_str in content:
        # 해당 행 교체
        lines = content.splitlines(keepends=True)
        lines = [new_row if l.startswith(f'| {date_str}') else l for l in lines]
        path.write_text(''.join(lines), encoding='utf-8')
    else:
        with open(path, 'a', encoding='utf-8') as f:
            f.write(new_row)

    log.info(f'[VaultWriter] 일일요약: {date_str} 총{total}건 (CALL {call_n} / PUT {put_n})')


# ═══════════════════════════════════════════
#  호환성 유지 (research_db 인터페이스)
# ═══════════════════════════════════════════

def register_algorithm(name, description, params_dict):
    """알고리즘 등록 — knowledge/strategies.json이 정본이므로 no-op"""
    return name


def get_algorithm_id(name):
    return name


def register_default_algorithms():
    return True


def override_regime(date_str, regime):
    pass


def get_algo_performance(algo_id=None, regime=None, days=30):
    return []


def get_recent_signals(ticker=None, algo_id=None, limit=50):
    return []
